# TechVault - AI Product Intelligence Platform

## Overview

TechVault is a comprehensive AI-powered product intelligence platform designed to help organizations manage their technology portfolios. The system enables users to upload documents, catalog products, generate AI-powered analysis, and interact with their product data through an intelligent chat interface. It features file processing capabilities, market opportunity analysis, and sophisticated search functionality to provide actionable insights from technical documentation.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend is built as a single-page application (SPA) using React with TypeScript and Vite as the build tool. It employs modern React patterns including:
- **Component Architecture**: Uses a component-based structure with reusable UI components built on Radix UI primitives and styled with Tailwind CSS
- **State Management**: Utilizes TanStack Query for server state management and caching, with React hooks for local component state
- **Routing**: Implements client-side routing using Wouter for a lightweight routing solution
- **Styling**: Uses Tailwind CSS with shadcn/ui components for a consistent design system following the "new-york" style variant

### Backend Architecture
The backend follows a Node.js Express.js architecture with TypeScript:
- **API Layer**: RESTful API endpoints organized in a centralized routes file with Express middleware
- **Data Access Layer**: Implements a storage interface pattern for database operations, allowing for abstraction between business logic and data persistence
- **Database ORM**: Uses Drizzle ORM for type-safe database operations with PostgreSQL
- **File Processing**: Handles PDF parsing and text extraction for document analysis

### Authentication & Authorization
The application implements session-based authentication with user management capabilities. Access control is managed through role-based permissions stored in the user entity.

### AI Integration
Integrates OpenAI's GPT models for various AI-powered features:
- **Document Analysis**: Extracts metadata and insights from uploaded documents
- **Chat Interface**: Provides conversational AI for product-related queries
- **Market Analysis**: Generates market opportunity assessments and product analysis reports

### File Storage & Management
Implements a dual storage strategy:
- **Object Storage**: Uses Google Cloud Storage for file uploads with access control policies
- **File Processing**: Processes uploaded documents (particularly PDFs) to extract text content for AI analysis
- **Upload Flow**: Direct-to-cloud upload pattern using presigned URLs for efficient file handling

### Data Architecture
The database schema is organized around core entities:
- **Projects**: Central entity representing products/technologies
- **Documents**: File attachments linked to projects with extracted content
- **AI Analysis**: Stores AI-generated insights and analysis results
- **Chat Sessions**: Maintains conversation history for the chat interface
- **Market Opportunities**: Captures market analysis and opportunity assessments

### Development & Build Process
- **Development Server**: Vite development server with Hot Module Replacement (HMR)
- **Build Process**: Separate client and server builds - Vite for frontend, esbuild for backend
- **Database Migrations**: Drizzle-kit for schema management and migrations
- **Environment Configuration**: Environment-based configuration for database connections and API keys

### UI/UX Design Patterns
The interface follows modern design principles with:
- **Component Library**: Custom components built on Radix UI primitives
- **Responsive Design**: Mobile-first responsive design using Tailwind CSS
- **Dark/Light Mode**: Support for theme switching with CSS custom properties
- **Accessibility**: Built-in accessibility features through Radix UI components

## External Dependencies

### Database & Storage
- **Neon Database**: PostgreSQL database hosting with serverless architecture
- **Google Cloud Storage**: Object storage for file uploads and document management

### AI & Machine Learning
- **OpenAI API**: GPT models for document analysis, chat functionality, and market analysis generation

### Frontend Libraries
- **React**: Core UI library with TypeScript support
- **Vite**: Build tool and development server
- **TanStack Query**: Server state management and caching
- **Radix UI**: Headless UI component primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Wouter**: Lightweight client-side routing

### Backend Services
- **Express.js**: Web application framework
- **Drizzle ORM**: Type-safe database ORM
- **Multer**: File upload middleware
- **PDF-Parse**: PDF text extraction library

### Development Tools
- **TypeScript**: Type safety across frontend and backend
- **ESBuild**: Fast bundler for server-side code
- **Replit Integration**: Development environment plugins and runtime error handling