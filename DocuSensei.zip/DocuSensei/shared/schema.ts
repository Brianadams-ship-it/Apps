import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, jsonb, boolean } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  role: text("role").default("user"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category"),
  technology: text("technology"),
  productLine: text("product_line"),
  dodCustomer: text("dod_customer"),
  developmentStatus: text("development_status").default("concept"),
  riskLevel: text("risk_level").default("medium"),
  marketOpportunity: text("market_opportunity"),
  thumbnailUrl: text("thumbnail_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const documents = pgTable("documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id).notNull(),
  fileName: text("file_name").notNull(),
  fileUrl: text("file_url").notNull(),
  fileType: text("file_type").notNull(),
  fileSize: integer("file_size"),
  extractedText: text("extracted_text"),
  metadata: jsonb("metadata"),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

export const aiAnalysis = pgTable("ai_analysis", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id).notNull(),
  analysisType: text("analysis_type").notNull(), // product_overview, risk_analysis, market_analysis
  content: jsonb("content").notNull(),
  generatedAt: timestamp("generated_at").defaultNow(),
});

export const chatSessions = pgTable("chat_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id),
  messages: jsonb("messages").notNull().default([]),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const marketOpportunities = pgTable("market_opportunities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  priority: text("priority").default("medium"), // high, medium, low
  opportunityType: text("opportunity_type").notNull(), // partnership, expansion, technology
  relatedTechnologies: text("related_technologies").array(),
  potentialCustomers: text("potential_customers").array(),
  estimatedValue: text("estimated_value"),
  recommendedActions: text("recommended_actions").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const solicitations = pgTable("solicitations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  solicitationNumber: text("solicitation_number").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  agency: text("agency").notNull(),
  department: text("department"),
  dueDate: timestamp("due_date"),
  releasedDate: timestamp("released_date"),
  estimatedValue: text("estimated_value"),
  contractType: text("contract_type"),
  setAside: text("set_aside"), // small business, veteran-owned, etc
  keywords: text("keywords").array(),
  technicalRequirements: text("technical_requirements"),
  rawContent: text("raw_content"), // full solicitation text
  sourceUrl: text("source_url"),
  status: text("status").default("open"), // open, closed, awarded
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const solicitationRatings = pgTable("solicitation_ratings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  solicitationId: varchar("solicitation_id").references(() => solicitations.id).notNull(),
  overallScore: integer("overall_score").notNull(), // 1-100
  technicalAlignment: integer("technical_alignment"), // 1-100
  pastExperience: integer("past_experience"), // 1-100
  competitiveAdvantage: integer("competitive_advantage"), // 1-100
  resourceRequirement: text("resource_requirement"), // low, medium, high
  riskAssessment: text("risk_assessment"), // low, medium, high
  recommendation: text("recommendation").notNull(), // pursue, consider, skip
  aiAnalysis: jsonb("ai_analysis"), // detailed AI analysis results
  rationale: text("rationale"), // explanation for the rating
  createdAt: timestamp("created_at").defaultNow(),
});

export const proposals = pgTable("proposals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  solicitationId: varchar("solicitation_id").references(() => solicitations.id).notNull(),
  projectId: varchar("project_id").references(() => projects.id), // linked project if applicable
  title: text("title").notNull(),
  status: text("status").default("draft"), // draft, in_progress, submitted, won, lost
  proposalType: text("proposal_type").default("technical"), // technical, cost, management
  sections: jsonb("sections").default([]), // structured proposal sections
  aiAssistance: jsonb("ai_assistance"), // AI-generated content and suggestions
  teamMembers: text("team_members").array(),
  estimatedEffort: text("estimated_effort"),
  proposedValue: text("proposed_value"),
  submissionDate: timestamp("submission_date"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const companyCapabilities = pgTable("company_capabilities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  category: text("category").notNull(), // technical, domain, industry
  description: text("description").notNull(),
  proficiencyLevel: text("proficiency_level").default("intermediate"), // novice, intermediate, advanced, expert
  relatedProjects: varchar("related_projects").array(), // project IDs
  keywords: text("keywords").array(),
  certifications: text("certifications").array(),
  teamMembers: text("team_members").array(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const projectsRelations = relations(projects, ({ many }) => ({
  documents: many(documents),
  aiAnalysis: many(aiAnalysis),
  chatSessions: many(chatSessions),
  proposals: many(proposals),
}));

export const documentsRelations = relations(documents, ({ one }) => ({
  project: one(projects, {
    fields: [documents.projectId],
    references: [projects.id],
  }),
}));

export const aiAnalysisRelations = relations(aiAnalysis, ({ one }) => ({
  project: one(projects, {
    fields: [aiAnalysis.projectId],
    references: [projects.id],
  }),
}));

export const chatSessionsRelations = relations(chatSessions, ({ one }) => ({
  project: one(projects, {
    fields: [chatSessions.projectId],
    references: [projects.id],
  }),
}));

export const solicitationsRelations = relations(solicitations, ({ many }) => ({
  ratings: many(solicitationRatings),
  proposals: many(proposals),
}));

export const solicitationRatingsRelations = relations(solicitationRatings, ({ one }) => ({
  solicitation: one(solicitations, {
    fields: [solicitationRatings.solicitationId],
    references: [solicitations.id],
  }),
}));

export const proposalsRelations = relations(proposals, ({ one }) => ({
  solicitation: one(solicitations, {
    fields: [proposals.solicitationId],
    references: [solicitations.id],
  }),
  project: one(projects, {
    fields: [proposals.projectId],
    references: [projects.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  role: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  uploadedAt: true,
});

export const insertAiAnalysisSchema = createInsertSchema(aiAnalysis).omit({
  id: true,
  generatedAt: true,
});

export const insertChatSessionSchema = createInsertSchema(chatSessions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMarketOpportunitySchema = createInsertSchema(marketOpportunities).omit({
  id: true,
  createdAt: true,
});

export const insertSolicitationSchema = createInsertSchema(solicitations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  dueDate: z.string().optional().transform((val) => val ? new Date(val) : undefined),
  releasedDate: z.string().optional().transform((val) => val ? new Date(val) : undefined),
});

export const insertSolicitationRatingSchema = createInsertSchema(solicitationRatings).omit({
  id: true,
  createdAt: true,
});

export const insertProposalSchema = createInsertSchema(proposals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  projectId: z.string().optional().nullable().transform((val) => val || null),
});

export const insertCompanyCapabilitySchema = createInsertSchema(companyCapabilities).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;
export type InsertAiAnalysis = z.infer<typeof insertAiAnalysisSchema>;
export type AiAnalysis = typeof aiAnalysis.$inferSelect;
export type InsertChatSession = z.infer<typeof insertChatSessionSchema>;
export type ChatSession = typeof chatSessions.$inferSelect;
export type InsertMarketOpportunity = z.infer<typeof insertMarketOpportunitySchema>;
export type MarketOpportunity = typeof marketOpportunities.$inferSelect;
export type InsertSolicitation = z.infer<typeof insertSolicitationSchema>;
export type Solicitation = typeof solicitations.$inferSelect;
export type InsertSolicitationRating = z.infer<typeof insertSolicitationRatingSchema>;
export type SolicitationRating = typeof solicitationRatings.$inferSelect;
export type InsertProposal = z.infer<typeof insertProposalSchema>;
export type Proposal = typeof proposals.$inferSelect;
export type InsertCompanyCapability = z.infer<typeof insertCompanyCapabilitySchema>;
export type CompanyCapability = typeof companyCapabilities.$inferSelect;
