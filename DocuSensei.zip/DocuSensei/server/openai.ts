import OpenAI from "openai";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface ProductAnalysis {
  overview: string;
  keyFeatures: string[];
  developmentStatus: string;
  riskAssessment: {
    technicalRisks: string[];
    marketRisks: string[];
    riskLevel: 'low' | 'medium' | 'high';
  };
  marketOpportunity: {
    targetMarkets: string[];
    competitiveAdvantage: string[];
    marketSize: string;
  };
  recommendations: string[];
}

export interface ChatResponse {
  message: string;
  confidence: number;
  sources?: string[];
}

export interface DocumentMetadata {
  title: string;
  category: string;
  technology: string;
  keyTerms: string[];
  summary: string;
}

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
export async function analyzeDocument(extractedText: string, fileName: string): Promise<DocumentMetadata> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a technical document analysis expert. Analyze the document and extract key metadata. Respond with JSON in this format: { 'title': string, 'category': string, 'technology': string, 'keyTerms': string[], 'summary': string }"
        },
        {
          role: "user",
          content: `Analyze this document titled "${fileName}" and extract metadata:\n\n${extractedText.slice(0, 8000)}`
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      title: result.title || fileName,
      category: result.category || 'General',
      technology: result.technology || 'Unknown',
      keyTerms: result.keyTerms || [],
      summary: result.summary || 'No summary available',
    };
  } catch (error) {
    throw new Error("Failed to analyze document: " + (error as Error).message);
  }
}

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
export async function generateProductAnalysis(documents: { fileName: string; extractedText: string }[]): Promise<ProductAnalysis> {
  try {
    const combinedText = documents.map(doc => 
      `Document: ${doc.fileName}\n${doc.extractedText}`
    ).join('\n\n---\n\n').slice(0, 15000);

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are an expert product analyst specializing in technology products. Analyze the provided documents and generate a comprehensive product analysis. 

Respond with JSON in this exact format:
{
  "overview": "string - comprehensive product overview",
  "keyFeatures": ["string array - key product features"],
  "developmentStatus": "string - concept/development/testing/production",
  "riskAssessment": {
    "technicalRisks": ["string array"],
    "marketRisks": ["string array"], 
    "riskLevel": "low/medium/high"
  },
  "marketOpportunity": {
    "targetMarkets": ["string array"],
    "competitiveAdvantage": ["string array"],
    "marketSize": "string"
  },
  "recommendations": ["string array - actionable recommendations"]
}`
        },
        {
          role: "user",
          content: `Analyze these product documents and generate a comprehensive analysis:\n\n${combinedText}`
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      overview: result.overview || 'No overview available',
      keyFeatures: result.keyFeatures || [],
      developmentStatus: result.developmentStatus || 'concept',
      riskAssessment: {
        technicalRisks: result.riskAssessment?.technicalRisks || [],
        marketRisks: result.riskAssessment?.marketRisks || [],
        riskLevel: result.riskAssessment?.riskLevel || 'medium',
      },
      marketOpportunity: {
        targetMarkets: result.marketOpportunity?.targetMarkets || [],
        competitiveAdvantage: result.marketOpportunity?.competitiveAdvantage || [],
        marketSize: result.marketOpportunity?.marketSize || 'Unknown',
      },
      recommendations: result.recommendations || [],
    };
  } catch (error) {
    throw new Error("Failed to generate product analysis: " + (error as Error).message);
  }
}

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
export async function chatWithProduct(
  question: string, 
  projectContext: { 
    name: string; 
    description?: string; 
    documents: { fileName: string; extractedText: string }[] 
  }
): Promise<ChatResponse> {
  try {
    const contextText = projectContext.documents.map(doc => 
      `Document: ${doc.fileName}\n${doc.extractedText.slice(0, 2000)}`
    ).join('\n\n---\n\n').slice(0, 10000);

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are an expert AI assistant specializing in the product "${projectContext.name}". You have access to all the product documentation and can answer detailed questions about the product's features, development, risks, and opportunities.

Based on the provided context, answer questions accurately and cite specific information from the documents when possible. If you cannot answer based on the available information, say so clearly.

Respond with JSON in this format:
{
  "message": "string - your detailed response",
  "confidence": number - confidence level 0-1,
  "sources": ["string array - document names referenced"]
}`
        },
        {
          role: "user",
          content: `Product Context:
Name: ${projectContext.name}
Description: ${projectContext.description || 'No description available'}

Available Documents:
${contextText}

Question: ${question}`
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      message: result.message || 'Unable to process your question.',
      confidence: Math.max(0, Math.min(1, result.confidence || 0.5)),
      sources: result.sources || [],
    };
  } catch (error) {
    throw new Error("Failed to process chat question: " + (error as Error).message);
  }
}

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
export async function generateMarketAnalysis(projects: { name: string; technology: string; description?: string }[]): Promise<{
  opportunities: Array<{
    title: string;
    description: string;
    priority: 'high' | 'medium' | 'low';
    opportunityType: 'partnership' | 'expansion' | 'technology';
    relatedTechnologies: string[];
    potentialCustomers: string[];
    estimatedValue: string;
    recommendedActions: string[];
  }>;
}> {
  try {
    const projectsContext = projects.map(p => 
      `${p.name} (${p.technology}): ${p.description || 'No description'}`
    ).join('\n');

    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: `You are a market analysis expert specializing in technology and defense markets. Analyze the provided product portfolio and identify market opportunities.

Respond with JSON in this format:
{
  "opportunities": [
    {
      "title": "string",
      "description": "string",
      "priority": "high/medium/low",
      "opportunityType": "partnership/expansion/technology",
      "relatedTechnologies": ["string array"],
      "potentialCustomers": ["string array"],
      "estimatedValue": "string",
      "recommendedActions": ["string array"]
    }
  ]
}`
        },
        {
          role: "user",
          content: `Analyze this technology portfolio and identify market opportunities:\n\n${projectsContext}`
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      opportunities: result.opportunities || [],
    };
  } catch (error) {
    throw new Error("Failed to generate market analysis: " + (error as Error).message);
  }
}
