import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ObjectStorageService, ObjectNotFoundError } from "./objectStorage";
import { analyzeDocument, generateProductAnalysis, chatWithProduct, generateMarketAnalysis } from "./openai";
import { 
  insertProjectSchema, 
  insertDocumentSchema, 
  insertChatSessionSchema,
  insertSolicitationSchema,
  insertSolicitationRatingSchema,
  insertProposalSchema,
  insertCompanyCapabilitySchema
} from "@shared/schema";
import multer from "multer";
import PDFParse from "pdf-parse";

const upload = multer({ storage: multer.memoryStorage() });

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve private objects (documents)
  app.get("/objects/:objectPath(*)", async (req, res) => {
    const objectStorageService = new ObjectStorageService();
    try {
      const objectFile = await objectStorageService.getObjectEntityFile(req.path);
      objectStorageService.downloadObject(objectFile, res);
    } catch (error) {
      console.error("Error accessing object:", error);
      if (error instanceof ObjectNotFoundError) {
        return res.sendStatus(404);
      }
      return res.sendStatus(500);
    }
  });

  // Get upload URL for documents
  app.post("/api/objects/upload", async (req, res) => {
    try {
      const objectStorageService = new ObjectStorageService();
      const uploadURL = await objectStorageService.getObjectEntityUploadURL();
      res.json({ uploadURL });
    } catch (error) {
      console.error("Error getting upload URL:", error);
      res.status(500).json({ error: "Failed to get upload URL" });
    }
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  // Get all projects
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  // Get project by ID with related data
  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }

      const documents = await storage.getDocumentsByProject(req.params.id);
      const analysis = await storage.getAnalysisByProject(req.params.id);
      const chatSession = await storage.getChatSession(req.params.id);

      res.json({
        project,
        documents,
        analysis,
        chatSession,
      });
    } catch (error) {
      console.error("Error fetching project:", error);
      res.status(500).json({ error: "Failed to fetch project" });
    }
  });

  // Create new project
  app.post("/api/projects", async (req, res) => {
    try {
      const validatedData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(validatedData);
      res.json(project);
    } catch (error) {
      console.error("Error creating project:", error);
      res.status(400).json({ error: "Failed to create project" });
    }
  });

  // Search projects
  app.get("/api/projects/search", async (req, res) => {
    try {
      const query = req.query.q as string || "";
      const filters = {
        technology: req.query.technology as string,
        dodCustomer: req.query.dodCustomer as string,
        productLine: req.query.productLine as string,
        developmentStatus: req.query.developmentStatus as string,
      };

      const projects = await storage.searchProjects(query, filters);
      res.json(projects);
    } catch (error) {
      console.error("Error searching projects:", error);
      res.status(500).json({ error: "Failed to search projects" });
    }
  });

  // Upload and process documents
  app.post("/api/projects/:projectId/documents", upload.array("files"), async (req, res) => {
    try {
      const projectId = req.params.projectId;
      const files = req.files as Express.Multer.File[];
      const uploadedUrls = JSON.parse(req.body.uploadedUrls || "[]");

      if (!files || files.length === 0) {
        return res.status(400).json({ error: "No files uploaded" });
      }

      const project = await storage.getProject(projectId);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }

      const processedDocuments = [];
      const objectStorageService = new ObjectStorageService();

      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const uploadedUrl = uploadedUrls[i];

        let extractedText = "";
        
        // Extract text based on file type
        if (file.mimetype === "application/pdf") {
          try {
            const pdfData = await PDFParse(file.buffer);
            extractedText = pdfData.text;
          } catch (error) {
            console.error("PDF parsing error:", error);
            extractedText = "Failed to extract text from PDF";
          }
        } else if (file.mimetype.startsWith("text/")) {
          extractedText = file.buffer.toString('utf-8');
        } else {
          extractedText = `Binary file: ${file.originalname}`;
        }

        // Analyze document with AI
        let metadata;
        try {
          metadata = await analyzeDocument(extractedText, file.originalname);
        } catch (error) {
          console.error("AI analysis error:", error);
          metadata = {
            title: file.originalname,
            category: 'General',
            technology: 'Unknown',
            keyTerms: [],
            summary: 'Analysis failed',
          };
        }

        // Normalize the object path
        const normalizedPath = objectStorageService.normalizeObjectEntityPath(uploadedUrl);

        // Store document in database
        const document = await storage.createDocument({
          projectId,
          fileName: file.originalname,
          fileUrl: normalizedPath,
          fileType: file.mimetype,
          fileSize: file.size,
          extractedText,
          metadata,
        });

        processedDocuments.push(document);
      }

      // Generate AI analysis for the project if we have documents
      try {
        const allProjectDocuments = await storage.getDocumentsByProject(projectId);
        const documentData = allProjectDocuments.map(doc => ({
          fileName: doc.fileName,
          extractedText: doc.extractedText || ""
        }));

        const productAnalysis = await generateProductAnalysis(documentData);
        
        // Store AI analysis
        await storage.createAnalysis({
          projectId,
          analysisType: "product_overview",
          content: productAnalysis,
        });

        // Update project with AI insights
        await storage.updateProject(projectId, {
          developmentStatus: productAnalysis.developmentStatus,
          riskLevel: productAnalysis.riskAssessment.riskLevel,
          marketOpportunity: productAnalysis.marketOpportunity.marketSize,
          technology: productAnalysis.keyFeatures.join(", ").slice(0, 255),
        });

      } catch (error) {
        console.error("AI analysis generation error:", error);
      }

      res.json({ documents: processedDocuments });
    } catch (error) {
      console.error("Error uploading documents:", error);
      res.status(500).json({ error: "Failed to upload documents" });
    }
  });

  // Chat with AI about a project
  app.post("/api/projects/:projectId/chat", async (req, res) => {
    try {
      const projectId = req.params.projectId;
      const { message } = req.body;

      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      const project = await storage.getProject(projectId);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }

      const documents = await storage.getDocumentsByProject(projectId);
      const documentData = documents.map(doc => ({
        fileName: doc.fileName,
        extractedText: doc.extractedText || ""
      }));

      const response = await chatWithProduct(message, {
        name: project.name,
        description: project.description || undefined,
        documents: documentData,
      });

      // Get or create chat session
      let chatSession = await storage.getChatSession(projectId);
      if (!chatSession) {
        chatSession = await storage.createChatSession({
          projectId,
          messages: [],
        });
      }

      // Add new messages to session
      const updatedMessages = [
        ...(chatSession.messages as any[]),
        { role: "user", content: message, timestamp: new Date() },
        { role: "assistant", content: response.message, timestamp: new Date(), confidence: response.confidence, sources: response.sources },
      ];

      await storage.updateChatSession(chatSession.id, updatedMessages);

      res.json(response);
    } catch (error) {
      console.error("Error processing chat:", error);
      res.status(500).json({ error: "Failed to process chat message" });
    }
  });

  // Get chat session for a project
  app.get("/api/projects/:projectId/chat", async (req, res) => {
    try {
      const chatSession = await storage.getChatSession(req.params.projectId);
      res.json(chatSession || { messages: [] });
    } catch (error) {
      console.error("Error fetching chat session:", error);
      res.status(500).json({ error: "Failed to fetch chat session" });
    }
  });

  // Get market opportunities
  app.get("/api/market-opportunities", async (req, res) => {
    try {
      const opportunities = await storage.getMarketOpportunities();
      res.json(opportunities);
    } catch (error) {
      console.error("Error fetching market opportunities:", error);
      res.status(500).json({ error: "Failed to fetch market opportunities" });
    }
  });

  // Generate market analysis
  app.post("/api/market-opportunities/generate", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      const projectData = projects.map(p => ({
        name: p.name,
        technology: p.technology || 'Unknown',
        description: p.description || undefined,
      }));

      const analysis = await generateMarketAnalysis(projectData);
      
      // Store opportunities in database
      const createdOpportunities = [];
      for (const opportunity of analysis.opportunities) {
        const created = await storage.createMarketOpportunity(opportunity);
        createdOpportunities.push(created);
      }

      res.json({ opportunities: createdOpportunities });
    } catch (error) {
      console.error("Error generating market analysis:", error);
      res.status(500).json({ error: "Failed to generate market analysis" });
    }
  });

  // Generate HTML product datasheet
  app.get("/api/projects/:projectId/datasheet", async (req, res) => {
    try {
      const project = await storage.getProject(req.params.projectId);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }

      const documents = await storage.getDocumentsByProject(req.params.projectId);
      const analysis = await storage.getAnalysisByProject(req.params.projectId, "product_overview");

      const productAnalysis = analysis[0]?.content as any;

      // Generate HTML datasheet
      const html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${project.name} - Product Datasheet</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        .header { border-bottom: 2px solid #3b82f6; padding-bottom: 20px; margin-bottom: 30px; }
        .section { margin-bottom: 30px; }
        .status-badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; }
        .status-concept { background: #dbeafe; color: #1e40af; }
        .status-development { background: #fef3c7; color: #92400e; }
        .status-testing { background: #fed7aa; color: #9a3412; }
        .status-production { background: #dcfce7; color: #166534; }
        .risk-low { color: #166534; }
        .risk-medium { color: #ca8a04; }
        .risk-high { color: #dc2626; }
        .documents { background: #f8fafc; padding: 15px; border-radius: 8px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>${project.name}</h1>
        <p><strong>Category:</strong> ${project.category || 'Not specified'}</p>
        <p><strong>Technology:</strong> ${project.technology || 'Not specified'}</p>
        <p><strong>Product Line:</strong> ${project.productLine || 'Not specified'}</p>
        <p><strong>DoD Customer:</strong> ${project.dodCustomer || 'Not specified'}</p>
        <span class="status-badge status-${project.developmentStatus}">${project.developmentStatus?.toUpperCase() || 'CONCEPT'}</span>
    </div>

    ${project.description ? `
    <div class="section">
        <h2>Description</h2>
        <p>${project.description}</p>
    </div>
    ` : ''}

    ${productAnalysis ? `
    <div class="section">
        <h2>Product Overview</h2>
        <p>${productAnalysis.overview}</p>
    </div>

    <div class="section">
        <h2>Key Features</h2>
        <ul>
            ${productAnalysis.keyFeatures.map((feature: string) => `<li>${feature}</li>`).join('')}
        </ul>
    </div>

    <div class="section">
        <h2>Risk Assessment</h2>
        <p><strong>Risk Level:</strong> <span class="risk-${productAnalysis.riskAssessment.riskLevel}">${productAnalysis.riskAssessment.riskLevel.toUpperCase()}</span></p>
        
        <h3>Technical Risks</h3>
        <ul>
            ${productAnalysis.riskAssessment.technicalRisks.map((risk: string) => `<li>${risk}</li>`).join('')}
        </ul>
        
        <h3>Market Risks</h3>
        <ul>
            ${productAnalysis.riskAssessment.marketRisks.map((risk: string) => `<li>${risk}</li>`).join('')}
        </ul>
    </div>

    <div class="section">
        <h2>Market Opportunity</h2>
        <p><strong>Market Size:</strong> ${productAnalysis.marketOpportunity.marketSize}</p>
        
        <h3>Target Markets</h3>
        <ul>
            ${productAnalysis.marketOpportunity.targetMarkets.map((market: string) => `<li>${market}</li>`).join('')}
        </ul>
        
        <h3>Competitive Advantages</h3>
        <ul>
            ${productAnalysis.marketOpportunity.competitiveAdvantage.map((advantage: string) => `<li>${advantage}</li>`).join('')}
        </ul>
    </div>

    <div class="section">
        <h2>Recommendations</h2>
        <ul>
            ${productAnalysis.recommendations.map((rec: string) => `<li>${rec}</li>`).join('')}
        </ul>
    </div>
    ` : ''}

    <div class="section">
        <h2>Supporting Documents</h2>
        <div class="documents">
            ${documents.length > 0 ? documents.map(doc => `
                <p><strong>${doc.fileName}</strong> (${doc.fileType}) - Uploaded ${new Date(doc.uploadedAt || new Date()).toLocaleDateString()}</p>
            `).join('') : '<p>No documents uploaded yet.</p>'}
        </div>
    </div>

    <div class="section">
        <p><em>Generated on ${new Date().toLocaleDateString()} by TechVault AI Product Intelligence Platform</em></p>
    </div>
</body>
</html>`;

      res.setHeader('Content-Type', 'text/html');
      res.send(html);
    } catch (error) {
      console.error("Error generating datasheet:", error);
      res.status(500).json({ error: "Failed to generate datasheet" });
    }
  });

  // ===== SOLICITATION ROUTES =====
  
  // Get all solicitations with optional search and filters
  app.get("/api/solicitations", async (req, res) => {
    try {
      const { search, agency, status, setAside } = req.query;
      
      let solicitations;
      if (search || agency || status || setAside) {
        solicitations = await storage.searchSolicitations(
          search as string || "",
          {
            agency: agency as string,
            status: status as string,
            setAside: setAside as string,
          }
        );
      } else {
        solicitations = await storage.getSolicitations();
      }
      
      res.json(solicitations);
    } catch (error) {
      console.error("Error fetching solicitations:", error);
      res.status(500).json({ error: "Failed to fetch solicitations" });
    }
  });

  // Get solicitation by ID with ratings
  app.get("/api/solicitations/:id", async (req, res) => {
    try {
      const solicitation = await storage.getSolicitation(req.params.id);
      if (!solicitation) {
        return res.status(404).json({ error: "Solicitation not found" });
      }

      const ratings = await storage.getSolicitationRatings(req.params.id);
      const proposals = await storage.getProposalsBySolicitation(req.params.id);

      res.json({
        solicitation,
        ratings,
        proposals,
      });
    } catch (error) {
      console.error("Error fetching solicitation:", error);
      res.status(500).json({ error: "Failed to fetch solicitation" });
    }
  });

  // Create new solicitation
  app.post("/api/solicitations", async (req, res) => {
    try {
      const validation = insertSolicitationSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Invalid solicitation data", 
          details: validation.error.errors 
        });
      }

      const solicitation = await storage.createSolicitation(validation.data);
      res.json(solicitation);
    } catch (error) {
      console.error("Error creating solicitation:", error);
      res.status(500).json({ error: "Failed to create solicitation" });
    }
  });

  // Update solicitation
  app.put("/api/solicitations/:id", async (req, res) => {
    try {
      const validation = insertSolicitationSchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Invalid solicitation data", 
          details: validation.error.errors 
        });
      }

      const solicitation = await storage.updateSolicitation(req.params.id, validation.data);
      if (!solicitation) {
        return res.status(404).json({ error: "Solicitation not found" });
      }

      res.json(solicitation);
    } catch (error) {
      console.error("Error updating solicitation:", error);
      res.status(500).json({ error: "Failed to update solicitation" });
    }
  });

  // ===== SOLICITATION RATING ROUTES =====

  // Create solicitation rating with AI analysis
  app.post("/api/solicitations/:id/rate", async (req, res) => {
    try {
      const solicitationId = req.params.id;
      const solicitation = await storage.getSolicitation(solicitationId);
      
      if (!solicitation) {
        return res.status(404).json({ error: "Solicitation not found" });
      }

      // Get company capabilities for AI analysis
      const capabilities = await storage.getCompanyCapabilities();
      
      // TODO: Add AI analysis using OpenAI to evaluate solicitation against capabilities
      // This would use the existing OpenAI service to analyze the solicitation
      
      const ratingData = {
        solicitationId,
        overallScore: 75, // This would come from AI analysis
        technicalAlignment: 80,
        pastExperience: 70,
        competitiveAdvantage: 75,
        resourceRequirement: "medium",
        riskAssessment: "medium",
        recommendation: "consider",
        aiAnalysis: {
          analysis: "Preliminary analysis - would be generated by AI",
          matchingCapabilities: capabilities.slice(0, 3).map(c => c.name),
          gaps: ["Some technical requirements may need additional expertise"],
          opportunities: ["Good alignment with core competencies"]
        },
        rationale: "This solicitation shows moderate alignment with our capabilities and past experience.",
      };

      const rating = await storage.createSolicitationRating(ratingData);
      res.json(rating);
    } catch (error) {
      console.error("Error rating solicitation:", error);
      res.status(500).json({ error: "Failed to rate solicitation" });
    }
  });

  // ===== PROPOSAL ROUTES =====

  // Get all proposals
  app.get("/api/proposals", async (req, res) => {
    try {
      const proposals = await storage.getProposals();
      res.json(proposals);
    } catch (error) {
      console.error("Error fetching proposals:", error);
      res.status(500).json({ error: "Failed to fetch proposals" });
    }
  });

  // Get proposal by ID
  app.get("/api/proposals/:id", async (req, res) => {
    try {
      const proposal = await storage.getProposal(req.params.id);
      if (!proposal) {
        return res.status(404).json({ error: "Proposal not found" });
      }

      res.json(proposal);
    } catch (error) {
      console.error("Error fetching proposal:", error);
      res.status(500).json({ error: "Failed to fetch proposal" });
    }
  });

  // Create new proposal
  app.post("/api/proposals", async (req, res) => {
    try {
      const validation = insertProposalSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Invalid proposal data", 
          details: validation.error.errors 
        });
      }

      const proposal = await storage.createProposal(validation.data);
      res.json(proposal);
    } catch (error) {
      console.error("Error creating proposal:", error);
      res.status(500).json({ error: "Failed to create proposal" });
    }
  });

  // Update proposal
  app.put("/api/proposals/:id", async (req, res) => {
    try {
      const validation = insertProposalSchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Invalid proposal data", 
          details: validation.error.errors 
        });
      }

      const proposal = await storage.updateProposal(req.params.id, validation.data);
      if (!proposal) {
        return res.status(404).json({ error: "Proposal not found" });
      }

      res.json(proposal);
    } catch (error) {
      console.error("Error updating proposal:", error);
      res.status(500).json({ error: "Failed to update proposal" });
    }
  });

  // Generate proposal content with AI assistance
  app.post("/api/proposals/:id/generate", async (req, res) => {
    try {
      const proposal = await storage.getProposal(req.params.id);
      if (!proposal) {
        return res.status(404).json({ error: "Proposal not found" });
      }

      const solicitation = await storage.getSolicitation(proposal.solicitationId);
      if (!solicitation) {
        return res.status(404).json({ error: "Related solicitation not found" });
      }

      // TODO: Add AI-powered proposal generation using OpenAI
      // This would analyze the solicitation requirements and generate proposal sections
      
      const generatedSections = [
        {
          id: "executive-summary",
          title: "Executive Summary",
          content: "AI-generated executive summary would appear here...",
          type: "text"
        },
        {
          id: "technical-approach",
          title: "Technical Approach",
          content: "AI-generated technical approach would appear here...",
          type: "text"
        },
        {
          id: "management-approach",
          title: "Management Approach", 
          content: "AI-generated management approach would appear here...",
          type: "text"
        }
      ];

      const updatedProposal = await storage.updateProposal(req.params.id, {
        sections: generatedSections,
        aiAssistance: {
          generatedAt: new Date().toISOString(),
          sectionsGenerated: generatedSections.length,
          model: "gpt-4",
        }
      });

      res.json(updatedProposal);
    } catch (error) {
      console.error("Error generating proposal content:", error);
      res.status(500).json({ error: "Failed to generate proposal content" });
    }
  });

  // ===== COMPANY CAPABILITIES ROUTES =====

  // Get all capabilities with optional search
  app.get("/api/capabilities", async (req, res) => {
    try {
      const { search, category } = req.query;
      
      let capabilities;
      if (search || category) {
        capabilities = await storage.searchCompanyCapabilities(
          search as string || "",
          category as string
        );
      } else {
        capabilities = await storage.getCompanyCapabilities();
      }
      
      res.json(capabilities);
    } catch (error) {
      console.error("Error fetching capabilities:", error);
      res.status(500).json({ error: "Failed to fetch capabilities" });
    }
  });

  // Create new capability
  app.post("/api/capabilities", async (req, res) => {
    try {
      const validation = insertCompanyCapabilitySchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Invalid capability data", 
          details: validation.error.errors 
        });
      }

      const capability = await storage.createCompanyCapability(validation.data);
      res.json(capability);
    } catch (error) {
      console.error("Error creating capability:", error);
      res.status(500).json({ error: "Failed to create capability" });
    }
  });

  // Update capability
  app.put("/api/capabilities/:id", async (req, res) => {
    try {
      const validation = insertCompanyCapabilitySchema.partial().safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ 
          error: "Invalid capability data", 
          details: validation.error.errors 
        });
      }

      const capability = await storage.updateCompanyCapability(req.params.id, validation.data);
      if (!capability) {
        return res.status(404).json({ error: "Capability not found" });
      }

      res.json(capability);
    } catch (error) {
      console.error("Error updating capability:", error);
      res.status(500).json({ error: "Failed to update capability" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
