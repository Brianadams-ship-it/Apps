import { 
  type User, 
  type InsertUser, 
  type Project, 
  type InsertProject,
  type Document,
  type InsertDocument,
  type AiAnalysis,
  type InsertAiAnalysis,
  type ChatSession,
  type InsertChatSession,
  type MarketOpportunity,
  type InsertMarketOpportunity,
  type Solicitation,
  type InsertSolicitation,
  type SolicitationRating,
  type InsertSolicitationRating,
  type Proposal,
  type InsertProposal,
  type CompanyCapability,
  type InsertCompanyCapability,
  users,
  projects,
  documents,
  aiAnalysis,
  chatSessions,
  marketOpportunities,
  solicitations,
  solicitationRatings,
  proposals,
  companyCapabilities
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, ilike, and, or, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Project operations
  getProjects(): Promise<Project[]>;
  getProject(id: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, updates: Partial<InsertProject>): Promise<Project | undefined>;
  searchProjects(query: string, filters?: {
    technology?: string;
    dodCustomer?: string;
    productLine?: string;
    developmentStatus?: string;
  }): Promise<Project[]>;

  // Document operations
  getDocumentsByProject(projectId: string): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  getDocument(id: string): Promise<Document | undefined>;

  // AI Analysis operations
  getAnalysisByProject(projectId: string, analysisType?: string): Promise<AiAnalysis[]>;
  createAnalysis(analysis: InsertAiAnalysis): Promise<AiAnalysis>;

  // Chat operations
  getChatSession(projectId: string): Promise<ChatSession | undefined>;
  createChatSession(session: InsertChatSession): Promise<ChatSession>;
  updateChatSession(id: string, messages: any[]): Promise<ChatSession | undefined>;

  // Market opportunities
  getMarketOpportunities(): Promise<MarketOpportunity[]>;
  createMarketOpportunity(opportunity: InsertMarketOpportunity): Promise<MarketOpportunity>;

  // Dashboard stats
  getDashboardStats(): Promise<{
    totalProducts: number;
    activeProjects: number;
    documentsProcessed: number;
    aiInsights: number;
    developmentStatusBreakdown: {
      concept: number;
      development: number;
      testing: number;
      production: number;
    };
  }>;

  // Solicitation operations
  getSolicitations(): Promise<Solicitation[]>;
  getSolicitation(id: string): Promise<Solicitation | undefined>;
  createSolicitation(solicitation: InsertSolicitation): Promise<Solicitation>;
  updateSolicitation(id: string, updates: Partial<InsertSolicitation>): Promise<Solicitation | undefined>;
  searchSolicitations(query: string, filters?: {
    agency?: string;
    status?: string;
    setAside?: string;
  }): Promise<Solicitation[]>;

  // Solicitation rating operations
  getSolicitationRatings(solicitationId: string): Promise<SolicitationRating[]>;
  createSolicitationRating(rating: InsertSolicitationRating): Promise<SolicitationRating>;
  updateSolicitationRating(id: string, updates: Partial<InsertSolicitationRating>): Promise<SolicitationRating | undefined>;

  // Proposal operations
  getProposals(): Promise<Proposal[]>;
  getProposal(id: string): Promise<Proposal | undefined>;
  getProposalsBySolicitation(solicitationId: string): Promise<Proposal[]>;
  createProposal(proposal: InsertProposal): Promise<Proposal>;
  updateProposal(id: string, updates: Partial<InsertProposal>): Promise<Proposal | undefined>;

  // Company capability operations
  getCompanyCapabilities(): Promise<CompanyCapability[]>;
  getCompanyCapability(id: string): Promise<CompanyCapability | undefined>;
  createCompanyCapability(capability: InsertCompanyCapability): Promise<CompanyCapability>;
  updateCompanyCapability(id: string, updates: Partial<InsertCompanyCapability>): Promise<CompanyCapability | undefined>;
  searchCompanyCapabilities(query: string, category?: string): Promise<CompanyCapability[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects).orderBy(desc(projects.updatedAt));
  }

  async getProject(id: string): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project || undefined;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db
      .insert(projects)
      .values(project)
      .returning();
    return newProject;
  }

  async updateProject(id: string, updates: Partial<InsertProject>): Promise<Project | undefined> {
    const [project] = await db
      .update(projects)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return project || undefined;
  }

  async searchProjects(query: string, filters?: {
    technology?: string;
    dodCustomer?: string;
    productLine?: string;
    developmentStatus?: string;
  }): Promise<Project[]> {
    let whereConditions = [];

    if (query) {
      whereConditions.push(
        or(
          ilike(projects.name, `%${query}%`),
          ilike(projects.description, `%${query}%`),
          ilike(projects.technology, `%${query}%`)
        )
      );
    }

    if (filters?.technology) {
      whereConditions.push(eq(projects.technology, filters.technology));
    }

    if (filters?.dodCustomer) {
      whereConditions.push(eq(projects.dodCustomer, filters.dodCustomer));
    }

    if (filters?.productLine) {
      whereConditions.push(eq(projects.productLine, filters.productLine));
    }

    if (filters?.developmentStatus) {
      whereConditions.push(eq(projects.developmentStatus, filters.developmentStatus));
    }

    const whereClause = whereConditions.length > 0 ? and(...whereConditions) : undefined;

    return await db
      .select()
      .from(projects)
      .where(whereClause)
      .orderBy(desc(projects.updatedAt));
  }

  async getDocumentsByProject(projectId: string): Promise<Document[]> {
    return await db
      .select()
      .from(documents)
      .where(eq(documents.projectId, projectId))
      .orderBy(desc(documents.uploadedAt));
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const [newDocument] = await db
      .insert(documents)
      .values(document)
      .returning();
    return newDocument;
  }

  async getDocument(id: string): Promise<Document | undefined> {
    const [document] = await db.select().from(documents).where(eq(documents.id, id));
    return document || undefined;
  }

  async getAnalysisByProject(projectId: string, analysisType?: string): Promise<AiAnalysis[]> {
    let whereConditions = [eq(aiAnalysis.projectId, projectId)];
    
    if (analysisType) {
      whereConditions.push(eq(aiAnalysis.analysisType, analysisType));
    }

    return await db
      .select()
      .from(aiAnalysis)
      .where(and(...whereConditions))
      .orderBy(desc(aiAnalysis.generatedAt));
  }

  async createAnalysis(analysis: InsertAiAnalysis): Promise<AiAnalysis> {
    const [newAnalysis] = await db
      .insert(aiAnalysis)
      .values(analysis)
      .returning();
    return newAnalysis;
  }

  async getChatSession(projectId: string): Promise<ChatSession | undefined> {
    const [session] = await db
      .select()
      .from(chatSessions)
      .where(eq(chatSessions.projectId, projectId))
      .orderBy(desc(chatSessions.updatedAt));
    return session || undefined;
  }

  async createChatSession(session: InsertChatSession): Promise<ChatSession> {
    const [newSession] = await db
      .insert(chatSessions)
      .values(session)
      .returning();
    return newSession;
  }

  async updateChatSession(id: string, messages: any[]): Promise<ChatSession | undefined> {
    const [session] = await db
      .update(chatSessions)
      .set({ messages, updatedAt: new Date() })
      .where(eq(chatSessions.id, id))
      .returning();
    return session || undefined;
  }

  async getMarketOpportunities(): Promise<MarketOpportunity[]> {
    return await db
      .select()
      .from(marketOpportunities)
      .orderBy(desc(marketOpportunities.createdAt));
  }

  async createMarketOpportunity(opportunity: InsertMarketOpportunity): Promise<MarketOpportunity> {
    const [newOpportunity] = await db
      .insert(marketOpportunities)
      .values(opportunity)
      .returning();
    return newOpportunity;
  }

  async getDashboardStats(): Promise<{
    totalProducts: number;
    activeProjects: number;
    documentsProcessed: number;
    aiInsights: number;
    developmentStatusBreakdown: {
      concept: number;
      development: number;
      testing: number;
      production: number;
    };
  }> {
    const [totalProductsResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(projects);

    const [activeProjectsResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(projects)
      .where(eq(projects.developmentStatus, 'development'));

    const [documentsResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(documents);

    const [analysisResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(aiAnalysis);

    const statusBreakdown = await db
      .select({
        status: projects.developmentStatus,
        count: sql<number>`count(*)`
      })
      .from(projects)
      .groupBy(projects.developmentStatus);

    const breakdown = {
      concept: 0,
      development: 0,
      testing: 0,
      production: 0,
    };

    statusBreakdown.forEach(item => {
      if (item.status && item.status in breakdown) {
        breakdown[item.status as keyof typeof breakdown] = item.count;
      }
    });

    return {
      totalProducts: totalProductsResult.count,
      activeProjects: activeProjectsResult.count,
      documentsProcessed: documentsResult.count,
      aiInsights: analysisResult.count,
      developmentStatusBreakdown: breakdown,
    };
  }

  // Solicitation operations
  async getSolicitations(): Promise<Solicitation[]> {
    return await db
      .select()
      .from(solicitations)
      .orderBy(desc(solicitations.dueDate));
  }

  async getSolicitation(id: string): Promise<Solicitation | undefined> {
    const [solicitation] = await db.select().from(solicitations).where(eq(solicitations.id, id));
    return solicitation;
  }

  async createSolicitation(solicitation: InsertSolicitation): Promise<Solicitation> {
    const [newSolicitation] = await db
      .insert(solicitations)
      .values(solicitation)
      .returning();
    return newSolicitation;
  }

  async updateSolicitation(id: string, updates: Partial<InsertSolicitation>): Promise<Solicitation | undefined> {
    const [updatedSolicitation] = await db
      .update(solicitations)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(solicitations.id, id))
      .returning();
    return updatedSolicitation;
  }

  async searchSolicitations(query: string, filters?: {
    agency?: string;
    status?: string;
    setAside?: string;
  }): Promise<Solicitation[]> {
    const conditions = [];
    
    if (query) {
      conditions.push(
        or(
          ilike(solicitations.title, `%${query}%`),
          ilike(solicitations.description, `%${query}%`),
          ilike(solicitations.solicitationNumber, `%${query}%`)
        )
      );
    }

    if (filters?.agency) {
      conditions.push(eq(solicitations.agency, filters.agency));
    }

    if (filters?.status) {
      conditions.push(eq(solicitations.status, filters.status));
    }

    if (filters?.setAside) {
      conditions.push(eq(solicitations.setAside, filters.setAside));
    }

    return await db
      .select()
      .from(solicitations)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(solicitations.dueDate));
  }

  // Solicitation rating operations
  async getSolicitationRatings(solicitationId: string): Promise<SolicitationRating[]> {
    return await db
      .select()
      .from(solicitationRatings)
      .where(eq(solicitationRatings.solicitationId, solicitationId))
      .orderBy(desc(solicitationRatings.createdAt));
  }

  async createSolicitationRating(rating: InsertSolicitationRating): Promise<SolicitationRating> {
    const [newRating] = await db
      .insert(solicitationRatings)
      .values(rating)
      .returning();
    return newRating;
  }

  async updateSolicitationRating(id: string, updates: Partial<InsertSolicitationRating>): Promise<SolicitationRating | undefined> {
    const [updatedRating] = await db
      .update(solicitationRatings)
      .set(updates)
      .where(eq(solicitationRatings.id, id))
      .returning();
    return updatedRating;
  }

  // Proposal operations
  async getProposals(): Promise<Proposal[]> {
    return await db
      .select()
      .from(proposals)
      .orderBy(desc(proposals.createdAt));
  }

  async getProposal(id: string): Promise<Proposal | undefined> {
    const [proposal] = await db.select().from(proposals).where(eq(proposals.id, id));
    return proposal;
  }

  async getProposalsBySolicitation(solicitationId: string): Promise<Proposal[]> {
    return await db
      .select()
      .from(proposals)
      .where(eq(proposals.solicitationId, solicitationId))
      .orderBy(desc(proposals.createdAt));
  }

  async createProposal(proposal: InsertProposal): Promise<Proposal> {
    const [newProposal] = await db
      .insert(proposals)
      .values(proposal)
      .returning();
    return newProposal;
  }

  async updateProposal(id: string, updates: Partial<InsertProposal>): Promise<Proposal | undefined> {
    const [updatedProposal] = await db
      .update(proposals)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(proposals.id, id))
      .returning();
    return updatedProposal;
  }

  // Company capability operations
  async getCompanyCapabilities(): Promise<CompanyCapability[]> {
    return await db
      .select()
      .from(companyCapabilities)
      .orderBy(desc(companyCapabilities.createdAt));
  }

  async getCompanyCapability(id: string): Promise<CompanyCapability | undefined> {
    const [capability] = await db.select().from(companyCapabilities).where(eq(companyCapabilities.id, id));
    return capability;
  }

  async createCompanyCapability(capability: InsertCompanyCapability): Promise<CompanyCapability> {
    const [newCapability] = await db
      .insert(companyCapabilities)
      .values(capability)
      .returning();
    return newCapability;
  }

  async updateCompanyCapability(id: string, updates: Partial<InsertCompanyCapability>): Promise<CompanyCapability | undefined> {
    const [updatedCapability] = await db
      .update(companyCapabilities)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(companyCapabilities.id, id))
      .returning();
    return updatedCapability;
  }

  async searchCompanyCapabilities(query: string, category?: string): Promise<CompanyCapability[]> {
    const conditions = [];
    
    if (query) {
      conditions.push(
        or(
          ilike(companyCapabilities.name, `%${query}%`),
          ilike(companyCapabilities.description, `%${query}%`)
        )
      );
    }

    if (category) {
      conditions.push(eq(companyCapabilities.category, category));
    }

    return await db
      .select()
      .from(companyCapabilities)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(companyCapabilities.createdAt));
  }
}

export const storage = new DatabaseStorage();
