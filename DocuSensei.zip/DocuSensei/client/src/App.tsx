import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Layout from "@/components/Layout";
import Dashboard from "@/pages/dashboard";
import Upload from "@/pages/upload";
import Catalog from "@/pages/catalog";
import Chat from "@/pages/chat";
import Search from "@/pages/search";
import Solicitations from "@/pages/solicitations";
import Proposals from "@/pages/proposals";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/upload" component={Upload} />
        <Route path="/catalog" component={Catalog} />
        <Route path="/chat/:projectId?" component={Chat} />
        <Route path="/search" component={Search} />
        <Route path="/solicitations" component={Solicitations} />
        <Route path="/proposals" component={Proposals} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
