import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import StatsCard from "@/components/StatsCard";
import ProductCard from "@/components/ProductCard";
import ChatInterface from "@/components/ChatInterface";
import FileUploadZone from "@/components/FileUploadZone";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";

export default function Dashboard() {
  const [technologyFilter, setTechnologyFilter] = useState("");
  const [customerFilter, setCustomerFilter] = useState("");
  const [productLineFilter, setProductLineFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  const queryClient = useQueryClient();

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: projects, isLoading: projectsLoading } = useQuery({
    queryKey: ["/api/projects"],
  });

  const { data: opportunities, isLoading: opportunitiesLoading } = useQuery({
    queryKey: ["/api/market-opportunities"],
  });

  const recentProjects = projects?.slice(0, 3) || [];

  const handleGenerateReport = async () => {
    try {
      await apiRequest("POST", "/api/market-opportunities/generate", {});
      queryClient.invalidateQueries({ queryKey: ["/api/market-opportunities"] });
    } catch (error) {
      console.error("Error generating report:", error);
    }
  };

  return (
    <div className="p-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatsCard
          title="Total Products"
          value={statsLoading ? "..." : stats?.totalProducts || 0}
          icon={<i className="fas fa-cube text-primary text-xl"></i>}
          trend={{ value: "12% this month", positive: true }}
          testId="stat-total-products"
        />
        <StatsCard
          title="Active Projects"
          value={statsLoading ? "..." : stats?.activeProjects || 0}
          icon={<i className="fas fa-project-diagram text-blue-600 text-xl"></i>}
          trend={{ value: "8% this month", positive: true }}
          testId="stat-active-projects"
        />
        <StatsCard
          title="Documents Processed"
          value={statsLoading ? "..." : stats?.documentsProcessed || 0}
          icon={<i className="fas fa-file-alt text-green-600 text-xl"></i>}
          trend={{ value: "24% this month", positive: true }}
          testId="stat-documents-processed"
        />
        <StatsCard
          title="AI Insights Generated"
          value={statsLoading ? "..." : stats?.aiInsights || 0}
          icon={<i className="fas fa-brain text-purple-600 text-xl"></i>}
          trend={{ value: "31% this month", positive: true }}
          testId="stat-ai-insights"
        />
      </div>

      {/* Quick Actions & Upload Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <FileUploadZone />
        </div>
        <ChatInterface messages={[]} />
      </div>

      {/* Recent Products & Development Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Recent Products */}
        <div className="bg-card p-6 rounded-lg border border-border">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-foreground">Recent Products</h3>
            <Button variant="link" className="text-primary hover:text-primary/80 text-sm font-medium">
              View All
            </Button>
          </div>
          <div className="space-y-4" data-testid="recent-products">
            {projectsLoading ? (
              <div>Loading...</div>
            ) : recentProjects.length > 0 ? (
              recentProjects.map(project => (
                <ProductCard key={project.id} project={project} />
              ))
            ) : (
              <p className="text-muted-foreground">No products available yet.</p>
            )}
          </div>
        </div>

        {/* Development Status Overview */}
        <div className="bg-card p-6 rounded-lg border border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Development Status Overview</h3>
          <div className="space-y-4">
            {statsLoading ? (
              <div>Loading...</div>
            ) : (
              <>
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-foreground">Concept Phase</span>
                    <span className="text-sm text-muted-foreground" data-testid="concept-count">
                      {stats?.developmentStatusBreakdown?.concept || 0} projects
                    </span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-blue-500 h-2 rounded-full" 
                      style={{ width: `${((stats?.developmentStatusBreakdown?.concept || 0) / (stats?.totalProducts || 1)) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-foreground">Development</span>
                    <span className="text-sm text-muted-foreground" data-testid="development-count">
                      {stats?.developmentStatusBreakdown?.development || 0} projects
                    </span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-yellow-500 h-2 rounded-full" 
                      style={{ width: `${((stats?.developmentStatusBreakdown?.development || 0) / (stats?.totalProducts || 1)) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-foreground">Testing</span>
                    <span className="text-sm text-muted-foreground" data-testid="testing-count">
                      {stats?.developmentStatusBreakdown?.testing || 0} projects
                    </span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-orange-500 h-2 rounded-full" 
                      style={{ width: `${((stats?.developmentStatusBreakdown?.testing || 0) / (stats?.totalProducts || 1)) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-foreground">Production</span>
                    <span className="text-sm text-muted-foreground" data-testid="production-count">
                      {stats?.developmentStatusBreakdown?.production || 0} projects
                    </span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full" 
                      style={{ width: `${((stats?.developmentStatusBreakdown?.production || 0) / (stats?.totalProducts || 1)) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </>
            )}
          </div>
          
          <div className="mt-6 p-4 bg-muted rounded-lg">
            <h4 className="font-medium text-foreground mb-2">AI Recommendations</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Focus on quantum computing partnerships for faster development</li>
              <li>• Consider expanding defense technology portfolio</li>
              <li>• Automation projects show high market potential</li>
            </ul>
          </div>
        </div>
      </div>

      {/* IP Catalog Search & Opportunities */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* IP Search Interface */}
        <div className="lg:col-span-2 bg-card p-6 rounded-lg border border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">IP Catalog Search</h3>
          
          {/* Search Filters */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Select value={technologyFilter} onValueChange={setTechnologyFilter}>
              <SelectTrigger data-testid="filter-technology">
                <SelectValue placeholder="All Technologies" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Technologies</SelectItem>
                <SelectItem value="quantum">Quantum Computing</SelectItem>
                <SelectItem value="defense">Defense Systems</SelectItem>
                <SelectItem value="automation">Automation</SelectItem>
                <SelectItem value="ai">AI/ML</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={customerFilter} onValueChange={setCustomerFilter}>
              <SelectTrigger data-testid="filter-customer">
                <SelectValue placeholder="DoD Customer" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Customers</SelectItem>
                <SelectItem value="navy">Navy</SelectItem>
                <SelectItem value="army">Army</SelectItem>
                <SelectItem value="airforce">Air Force</SelectItem>
                <SelectItem value="spaceforce">Space Force</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={productLineFilter} onValueChange={setProductLineFilter}>
              <SelectTrigger data-testid="filter-product-line">
                <SelectValue placeholder="Product Line" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Product Lines</SelectItem>
                <SelectItem value="sensors">Advanced Sensors</SelectItem>
                <SelectItem value="computing">Computing Systems</SelectItem>
                <SelectItem value="robotics">Robotics</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger data-testid="filter-status">
                <SelectValue placeholder="Development Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="concept">Concept</SelectItem>
                <SelectItem value="development">Development</SelectItem>
                <SelectItem value="testing">Testing</SelectItem>
                <SelectItem value="production">Production</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Search Results */}
          <div className="space-y-3" data-testid="search-results">
            {recentProjects.length > 0 ? (
              recentProjects.map(project => (
                <ProductCard key={project.id} project={project} />
              ))
            ) : (
              <p className="text-muted-foreground">No projects found. Upload some documents to get started.</p>
            )}
          </div>

          <div className="flex items-center justify-between mt-4">
            <p className="text-sm text-muted-foreground" data-testid="search-total">
              Showing {recentProjects.length} of {projects?.length || 0} results
            </p>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">Previous</Button>
              <Button size="sm">1</Button>
              <Button variant="outline" size="sm">2</Button>
              <Button variant="outline" size="sm">Next</Button>
            </div>
          </div>
        </div>

        {/* Market Opportunities */}
        <div className="bg-card p-6 rounded-lg border border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Market Opportunities</h3>
          
          <div className="space-y-4" data-testid="market-opportunities">
            {opportunitiesLoading ? (
              <div>Loading opportunities...</div>
            ) : opportunities && opportunities.length > 0 ? (
              opportunities.slice(0, 3).map((opportunity: any) => (
                <div key={opportunity.id} className={`p-4 border rounded-lg ${
                  opportunity.priority === 'high' ? 'bg-green-50 border-green-200' :
                  opportunity.priority === 'medium' ? 'bg-blue-50 border-blue-200' :
                  'bg-orange-50 border-orange-200'
                }`}>
                  <div className="flex items-center space-x-2 mb-2">
                    <i className={`fas ${
                      opportunity.opportunityType === 'partnership' ? 'fa-handshake' :
                      opportunity.opportunityType === 'expansion' ? 'fa-lightbulb' :
                      'fa-arrow-trend-up'
                    } ${
                      opportunity.priority === 'high' ? 'text-green-600' :
                      opportunity.priority === 'medium' ? 'text-blue-600' :
                      'text-orange-600'
                    }`}></i>
                    <h4 className={`font-medium ${
                      opportunity.priority === 'high' ? 'text-green-800' :
                      opportunity.priority === 'medium' ? 'text-blue-800' :
                      'text-orange-800'
                    }`}>
                      {opportunity.priority === 'high' ? 'High Priority' :
                       opportunity.priority === 'medium' ? 'Medium Priority' :
                       'Expansion Opportunity'}
                    </h4>
                  </div>
                  <p className={`text-sm ${
                    opportunity.priority === 'high' ? 'text-green-700' :
                    opportunity.priority === 'medium' ? 'text-blue-700' :
                    'text-orange-700'
                  }`}>
                    {opportunity.description}
                  </p>
                  <button className={`mt-2 text-xs font-medium ${
                    opportunity.priority === 'high' ? 'text-green-600 hover:text-green-800' :
                    opportunity.priority === 'medium' ? 'text-blue-600 hover:text-blue-800' :
                    'text-orange-600 hover:text-orange-800'
                  }`}
                  data-testid={`opportunity-details-${opportunity.id}`}>
                    View Details →
                  </button>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground">No opportunities identified yet.</p>
            )}
          </div>

          <div className="mt-6">
            <Button 
              onClick={handleGenerateReport}
              className="w-full"
              data-testid="generate-report"
            >
              <i className="fas fa-chart-line mr-2"></i>
              Generate Full Report
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
