import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ProductCard from "@/components/ProductCard";
import type { Project } from "@shared/schema";

export default function Catalog() {
  const [searchQuery, setSearchQuery] = useState("");
  const [technologyFilter, setTechnologyFilter] = useState("all");
  const [customerFilter, setCustomerFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");

  const { data: projects, isLoading } = useQuery({
    queryKey: ["/api/projects", "search", searchQuery, technologyFilter, customerFilter, statusFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchQuery) params.append("q", searchQuery);
      if (technologyFilter && technologyFilter !== "all") params.append("technology", technologyFilter);
      if (customerFilter && customerFilter !== "all") params.append("dodCustomer", customerFilter);
      if (statusFilter && statusFilter !== "all") params.append("developmentStatus", statusFilter);

      const response = await fetch(`/api/projects/search?${params}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to search projects");
      }
      
      return response.json();
    },
  });

  const handleSearch = () => {
    // The query will automatically refetch when dependencies change
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground mb-2">Product Catalog</h1>
        <p className="text-muted-foreground">
          Browse and manage your technology portfolio
        </p>
      </div>

      {/* Search and Filters */}
      <div className="bg-card p-6 rounded-lg border border-border mb-8">
        <div className="flex flex-col md:flex-row gap-4 mb-4">
          <div className="flex-1">
            <Input
              type="text"
              placeholder="Search products, technologies, descriptions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSearch()}
              data-testid="catalog-search-input"
            />
          </div>
          <Button onClick={handleSearch} data-testid="catalog-search-button">
            <i className="fas fa-search mr-2"></i>
            Search
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Select value={technologyFilter} onValueChange={setTechnologyFilter}>
            <SelectTrigger data-testid="catalog-technology-filter">
              <SelectValue placeholder="All Technologies" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Technologies</SelectItem>
              <SelectItem value="Quantum Computing">Quantum Computing</SelectItem>
              <SelectItem value="Defense Systems">Defense Systems</SelectItem>
              <SelectItem value="Automation">Automation</SelectItem>
              <SelectItem value="AI/ML">AI/ML</SelectItem>
            </SelectContent>
          </Select>

          <Select value={customerFilter} onValueChange={setCustomerFilter}>
            <SelectTrigger data-testid="catalog-customer-filter">
              <SelectValue placeholder="All Customers" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Customers</SelectItem>
              <SelectItem value="navy">Navy</SelectItem>
              <SelectItem value="army">Army</SelectItem>
              <SelectItem value="airforce">Air Force</SelectItem>
              <SelectItem value="spaceforce">Space Force</SelectItem>
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger data-testid="catalog-status-filter">
              <SelectValue placeholder="All Statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="concept">Concept</SelectItem>
              <SelectItem value="development">Development</SelectItem>
              <SelectItem value="testing">Testing</SelectItem>
              <SelectItem value="production">Production</SelectItem>
            </SelectContent>
          </Select>

          <Button 
            variant="outline" 
            onClick={() => {
              setSearchQuery("");
              setTechnologyFilter("all");
              setCustomerFilter("all");
              setStatusFilter("all");
            }}
            data-testid="clear-filters-button"
          >
            Clear Filters
          </Button>
        </div>
      </div>

      {/* Results */}
      <div className="bg-card p-6 rounded-lg border border-border">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-foreground">
            {isLoading ? "Loading..." : `${projects?.length || 0} Products Found`}
          </h2>
          <Link href="/upload">
            <Button data-testid="add-new-product-button">
              <i className="fas fa-plus mr-2"></i>
              Add New Product
            </Button>
          </Link>
        </div>

        <div className="space-y-4" data-testid="catalog-results">
          {isLoading ? (
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              <p className="mt-2 text-muted-foreground">Loading products...</p>
            </div>
          ) : projects && projects.length > 0 ? (
            projects.map((project: Project) => (
              <div key={project.id} className="relative">
                <ProductCard project={project} />
                <div className="absolute top-3 right-3 flex space-x-2">
                  <Link href={`/api/projects/${project.id}/datasheet`}>
                    <Button size="sm" variant="outline" data-testid={`view-datasheet-${project.id}`}>
                      <i className="fas fa-file-alt mr-1"></i>
                      Datasheet
                    </Button>
                  </Link>
                  <Link href={`/chat/${project.id}`}>
                    <Button size="sm" variant="outline" data-testid={`chat-project-${project.id}`}>
                      <i className="fas fa-comments mr-1"></i>
                      Chat
                    </Button>
                  </Link>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-search text-muted-foreground text-2xl"></i>
              </div>
              <h3 className="text-lg font-medium text-foreground mb-2">No products found</h3>
              <p className="text-muted-foreground mb-6">
                {searchQuery || technologyFilter || customerFilter || statusFilter
                  ? "Try adjusting your search criteria or filters"
                  : "Get started by uploading your first product documents"
                }
              </p>
              <Link href="/upload">
                <Button data-testid="empty-state-upload-button">
                  <i className="fas fa-upload mr-2"></i>
                  Upload Documents
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
