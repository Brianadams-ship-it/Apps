import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { insertSolicitationSchema } from '@shared/schema';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Search, FileText, Calendar, Building, Star, TrendingUp, AlertTriangle } from 'lucide-react';
import { Link } from 'wouter';
import type { Solicitation, SolicitationRating } from '@shared/schema';

interface SolicitationWithRating extends Solicitation {
  ratings?: SolicitationRating[];
}

const solicitationFormSchema = insertSolicitationSchema.extend({
  dueDate: z.string().min(1, 'Due date is required'),
  releasedDate: z.string().min(1, 'Released date is required'),
});

type SolicitationFormData = z.infer<typeof solicitationFormSchema>;

export default function Solicitations() {
  const [searchTerm, setSearchTerm] = useState('');
  const [agencyFilter, setAgencyFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const form = useForm<SolicitationFormData>({
    resolver: zodResolver(solicitationFormSchema),
    defaultValues: {
      solicitationNumber: '',
      title: '',
      description: '',
      agency: '',
      department: '',
      dueDate: '',
      releasedDate: '',
      estimatedValue: '',
      contractType: '',
      setAside: '',
      keywords: [],
      technicalRequirements: '',
      rawContent: '',
      sourceUrl: '',
      status: 'open',
    },
  });

  const { data: solicitations = [], isLoading } = useQuery<SolicitationWithRating[]>({
    queryKey: ['/api/solicitations', searchTerm, agencyFilter !== 'all' ? agencyFilter : '', statusFilter !== 'all' ? statusFilter : ''],
    enabled: true,
  });

  const createSolicitationMutation = useMutation({
    mutationFn: async (data: SolicitationFormData) => {
      const payload = {
        ...data,
        keywords: data.keywords || [],
      };
      
      const response = await fetch('/api/solicitations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      
      if (!response.ok) {
        throw new Error('Failed to create solicitation');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({ title: 'Success', description: 'Solicitation created successfully' });
      form.reset();
      setIsDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/solicitations'] });
    },
    onError: (error: any) => {
      toast({ 
        title: 'Error', 
        description: error.message || 'Failed to create solicitation',
        variant: 'destructive',
      });
    },
  });

  const rateSolicitationMutation = useMutation({
    mutationFn: async (solicitationId: string) => {
      const response = await fetch(`/api/solicitations/${solicitationId}/rate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      
      if (!response.ok) {
        throw new Error('Failed to rate solicitation');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({ title: 'Success', description: 'Solicitation rated successfully' });
      queryClient.invalidateQueries({ queryKey: ['/api/solicitations'] });
    },
    onError: (error: any) => {
      toast({ 
        title: 'Error', 
        description: error.message || 'Failed to rate solicitation',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: SolicitationFormData) => {
    createSolicitationMutation.mutate(data);
  };

  const handleRateSolicitation = (solicitationId: string) => {
    rateSolicitationMutation.mutate(solicitationId);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'closed': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      case 'awarded': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const getRecommendationColor = (recommendation: string) => {
    switch (recommendation) {
      case 'pursue': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'consider': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'skip': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const filteredSolicitations = solicitations.filter(solicitation => {
    const matchesSearch = !searchTerm || 
      solicitation.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      solicitation.solicitationNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      solicitation.agency.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesAgency = agencyFilter === 'all' || solicitation.agency === agencyFilter;
    const matchesStatus = statusFilter === 'all' || solicitation.status === statusFilter;
    
    return matchesSearch && matchesAgency && matchesStatus;
  });

  return (
    <div className="container mx-auto p-6 space-y-6" data-testid="solicitations-page">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white" data-testid="title-solicitations">
            DoD Solicitations
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Review and analyze Department of Defense proposal requests
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-solicitation">
              <FileText className="h-4 w-4 mr-2" />
              Add Solicitation
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Solicitation</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="solicitationNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Solicitation Number</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="e.g., W52P1J-24-R-0001" data-testid="input-solicitation-number" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="agency"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Agency</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="e.g., U.S. Army" data-testid="input-agency" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Solicitation title" data-testid="input-title" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea {...field} placeholder="Detailed description of the solicitation" data-testid="textarea-description" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="dueDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Due Date</FormLabel>
                        <FormControl>
                          <Input type="datetime-local" {...field} data-testid="input-due-date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="releasedDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Released Date</FormLabel>
                        <FormControl>
                          <Input type="datetime-local" {...field} data-testid="input-released-date" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="estimatedValue"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Estimated Value</FormLabel>
                        <FormControl>
                          <Input {...field} value={field.value || ""} placeholder="e.g., $500,000 - $1,000,000" data-testid="input-estimated-value" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="contractType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contract Type</FormLabel>
                        <FormControl>
                          <Input {...field} value={field.value || ""} placeholder="e.g., Fixed Price, Cost Plus" data-testid="input-contract-type" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex justify-end gap-4 pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createSolicitationMutation.isPending} data-testid="button-submit-solicitation">
                    {createSolicitationMutation.isPending ? 'Creating...' : 'Create Solicitation'}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search solicitations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
            data-testid="input-search-solicitations"
          />
        </div>
        <Select value={agencyFilter} onValueChange={setAgencyFilter}>
          <SelectTrigger className="w-[180px]" data-testid="select-agency-filter">
            <SelectValue placeholder="Filter by agency" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Agencies</SelectItem>
            <SelectItem value="U.S. Army">U.S. Army</SelectItem>
            <SelectItem value="U.S. Navy">U.S. Navy</SelectItem>
            <SelectItem value="U.S. Air Force">U.S. Air Force</SelectItem>
            <SelectItem value="DISA">DISA</SelectItem>
            <SelectItem value="DARPA">DARPA</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px]" data-testid="select-status-filter">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
            <SelectItem value="awarded">Awarded</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Solicitations Grid */}
      <div className="grid gap-6">
        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-gray-600 dark:text-gray-300">Loading solicitations...</p>
          </div>
        ) : filteredSolicitations.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No solicitations found</h3>
            <p className="text-gray-600 dark:text-gray-300">Try adjusting your search or add a new solicitation.</p>
          </div>
        ) : (
          filteredSolicitations.map((solicitation) => {
            const latestRating = solicitation.ratings?.[0];
            
            return (
              <Card key={solicitation.id} className="hover:shadow-md transition-shadow" data-testid={`card-solicitation-${solicitation.id}`}>
                <CardHeader>
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="flex items-center gap-2 mb-2">
                        <Link href={`/solicitations/${solicitation.id}`} className="text-blue-600 hover:text-blue-800 dark:text-blue-400">
                          {solicitation.title}
                        </Link>
                        <Badge className={getStatusColor(solicitation.status || 'open')}>
                          {solicitation.status?.toUpperCase()}
                        </Badge>
                      </CardTitle>
                      <div className="flex flex-wrap gap-4 text-sm text-gray-600 dark:text-gray-300">
                        <span className="flex items-center gap-1">
                          <FileText className="h-4 w-4" />
                          {solicitation.solicitationNumber}
                        </span>
                        <span className="flex items-center gap-1">
                          <Building className="h-4 w-4" />
                          {solicitation.agency}
                        </span>
                        {solicitation.dueDate && (
                          <span className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            Due: {new Date(solicitation.dueDate).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    {latestRating ? (
                      <div className="flex items-center gap-2">
                        <div className="text-right">
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 text-yellow-500" />
                            <span className="font-semibold">{latestRating.overallScore}/100</span>
                          </div>
                          <Badge className={getRecommendationColor(latestRating.recommendation)}>
                            {latestRating.recommendation?.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                    ) : (
                      <Button
                        onClick={() => handleRateSolicitation(solicitation.id)}
                        disabled={rateSolicitationMutation.isPending}
                        size="sm"
                        data-testid={`button-rate-${solicitation.id}`}
                      >
                        <TrendingUp className="h-4 w-4 mr-2" />
                        {rateSolicitationMutation.isPending ? 'Rating...' : 'Rate with AI'}
                      </Button>
                    )}
                  </div>
                </CardHeader>
                
                <CardContent>
                  <p className="text-gray-700 dark:text-gray-300 mb-4 line-clamp-3">
                    {solicitation.description}
                  </p>
                  
                  {solicitation.estimatedValue && (
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Estimated Value:</span>
                      <span className="text-sm text-gray-900 dark:text-white">{solicitation.estimatedValue}</span>
                    </div>
                  )}
                  
                  {latestRating && (
                    <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600 dark:text-gray-400">Technical:</span>
                          <span className="ml-2 font-medium">{latestRating.technicalAlignment}/100</span>
                        </div>
                        <div>
                          <span className="text-gray-600 dark:text-gray-400">Experience:</span>
                          <span className="ml-2 font-medium">{latestRating.pastExperience}/100</span>
                        </div>
                        <div>
                          <span className="text-gray-600 dark:text-gray-400">Advantage:</span>
                          <span className="ml-2 font-medium">{latestRating.competitiveAdvantage}/100</span>
                        </div>
                      </div>
                      {latestRating.rationale && (
                        <p className="mt-2 text-sm text-gray-700 dark:text-gray-300">
                          {latestRating.rationale}
                        </p>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}