import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ChatInterface from "@/components/ChatInterface";
import type { Project } from "@shared/schema";

export default function Chat() {
  const [, params] = useRoute("/chat/:projectId?");
  const [selectedProjectId, setSelectedProjectId] = useState<string>(params?.projectId || "");
  const [messages, setMessages] = useState<any[]>([]);

  const { data: projects } = useQuery({
    queryKey: ["/api/projects"],
  });

  const { data: projectData } = useQuery({
    queryKey: ["/api/projects", selectedProjectId],
    enabled: !!selectedProjectId,
  });

  const { data: chatSession } = useQuery({
    queryKey: ["/api/projects", selectedProjectId, "chat"],
    enabled: !!selectedProjectId,
  });

  useEffect(() => {
    if (chatSession?.messages) {
      setMessages(chatSession.messages);
    } else {
      setMessages([]);
    }
  }, [chatSession]);

  useEffect(() => {
    if (params?.projectId && params.projectId !== selectedProjectId) {
      setSelectedProjectId(params.projectId);
    }
  }, [params?.projectId]);

  const selectedProject = projectData?.project;

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground mb-2">AI Chat Assistant</h1>
        <p className="text-muted-foreground">
          Get instant answers about your products and technologies
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Project Selection and Info */}
        <div className="space-y-6">
          <div className="bg-card p-6 rounded-lg border border-border">
            <h2 className="text-lg font-semibold text-foreground mb-4">Select Project</h2>
            
            <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
              <SelectTrigger data-testid="chat-project-select">
                <SelectValue placeholder="Choose a project to chat about" />
              </SelectTrigger>
              <SelectContent>
                {projects && Array.isArray(projects) && projects.map((project: Project) => (
                  project?.id ? (
                    <SelectItem key={project.id} value={project.id}>
                      {project.name}
                    </SelectItem>
                  ) : null
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedProject && (
            <div className="bg-card p-6 rounded-lg border border-border">
              <h3 className="text-lg font-semibold text-foreground mb-4">Project Details</h3>
              
              <div className="space-y-3">
                <div>
                  <p className="text-sm font-medium text-foreground">Name</p>
                  <p className="text-sm text-muted-foreground" data-testid="chat-project-name">
                    {selectedProject.name}
                  </p>
                </div>
                
                {selectedProject.description && (
                  <div>
                    <p className="text-sm font-medium text-foreground">Description</p>
                    <p className="text-sm text-muted-foreground" data-testid="chat-project-description">
                      {selectedProject.description}
                    </p>
                  </div>
                )}
                
                <div>
                  <p className="text-sm font-medium text-foreground">Technology</p>
                  <p className="text-sm text-muted-foreground" data-testid="chat-project-technology">
                    {selectedProject.technology || 'Not specified'}
                  </p>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-foreground">Status</p>
                  <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                    selectedProject.developmentStatus === 'production' ? 'bg-green-100 text-green-700' :
                    selectedProject.developmentStatus === 'testing' ? 'bg-orange-100 text-orange-700' :
                    selectedProject.developmentStatus === 'development' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-blue-100 text-blue-700'
                  }`}
                  data-testid="chat-project-status">
                    {selectedProject.developmentStatus?.charAt(0).toUpperCase() + 
                     selectedProject.developmentStatus?.slice(1) || 'Concept'}
                  </span>
                </div>

                <div>
                  <p className="text-sm font-medium text-foreground">Documents</p>
                  <p className="text-sm text-muted-foreground" data-testid="chat-project-documents">
                    {projectData?.documents?.length || 0} files uploaded
                  </p>
                </div>
              </div>
            </div>
          )}

          {selectedProject && projectData?.documents && projectData.documents.length > 0 && (
            <div className="bg-card p-6 rounded-lg border border-border">
              <h3 className="text-lg font-semibold text-foreground mb-4">Available Documents</h3>
              
              <div className="space-y-2" data-testid="chat-document-list">
                {projectData.documents.map((doc: any) => (
                  <div key={doc.id} className="p-2 bg-muted rounded text-sm">
                    <p className="font-medium text-foreground">{doc.fileName}</p>
                    <p className="text-xs text-muted-foreground">
                      {doc.fileType} • Uploaded {new Date(doc.uploadedAt).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Chat Interface */}
        <div className="lg:col-span-2">
          <div className="bg-card rounded-lg border border-border h-[calc(100vh-12rem)]">
            <div className="p-6 border-b border-border">
              <h2 className="text-lg font-semibold text-foreground">
                {selectedProject 
                  ? `Chat about ${selectedProject.name}`
                  : "Select a project to start chatting"
                }
              </h2>
              <p className="text-sm text-muted-foreground">
                Ask questions about features, risks, opportunities, or technical details
              </p>
            </div>
            
            <div className="h-full p-6">
              <div className="h-[calc(100%-8rem)]">
                <ChatInterface
                  projectId={selectedProjectId}
                  messages={messages}
                  onNewMessage={setMessages}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Suggestions */}
      {selectedProject && (
        <div className="mt-8 bg-card p-6 rounded-lg border border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">Suggested Questions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              "What are the key features of this product?",
              "What are the main technical risks?",
              "Who are the target customers?",
              "What is the development timeline?",
              "What are the competitive advantages?",
              "What partnerships might be beneficial?",
            ].map((suggestion, index) => (
              <button
                key={index}
                onClick={() => {
                  if (selectedProjectId) {
                    // This would trigger sending the suggestion as a message
                    // For now, we'll just show it as a placeholder
                  }
                }}
                className="p-3 text-left bg-muted hover:bg-accent text-sm rounded-lg transition-colors"
                disabled={!selectedProjectId}
                data-testid={`chat-suggestion-${index}`}
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
