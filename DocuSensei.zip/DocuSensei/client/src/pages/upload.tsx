import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import FileUploadZone from "@/components/FileUploadZone";

export default function Upload() {
  const [projectName, setProjectName] = useState("");
  const [projectDescription, setProjectDescription] = useState("");
  const [category, setCategory] = useState("");
  const [technology, setTechnology] = useState("");
  const [productLine, setProductLine] = useState("");
  const [dodCustomer, setDodCustomer] = useState("");
  const [selectedProjectId, setSelectedProjectId] = useState<string>("");
  const [uploadedFiles, setUploadedFiles] = useState<{ files: File[], urls: string[] }>({ files: [], urls: [] });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: projects } = useQuery({
    queryKey: ["/api/projects"],
  });

  const createProjectMutation = useMutation({
    mutationFn: async (projectData: any) => {
      const response = await apiRequest("POST", "/api/projects", projectData);
      return response.json();
    },
    onSuccess: (newProject) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setSelectedProjectId(newProject.id);
      toast({
        title: "Success",
        description: "Project created successfully",
      });
    },
    onError: (error) => {
      console.error("Error creating project:", error);
      toast({
        title: "Error",
        description: "Failed to create project",
        variant: "destructive",
      });
    },
  });

  const uploadDocumentsMutation = useMutation({
    mutationFn: async ({ projectId, files, uploadedUrls }: { projectId: string, files: File[], uploadedUrls: string[] }) => {
      const formData = new FormData();
      files.forEach(file => formData.append("files", file));
      formData.append("uploadedUrls", JSON.stringify(uploadedUrls));

      const response = await fetch(`/api/projects/${projectId}/documents`, {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!response.ok) {
        throw new Error("Failed to upload documents");
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({
        title: "Success",
        description: "Documents uploaded and processed successfully",
      });
      // Reset form
      setUploadedFiles({ files: [], urls: [] });
      setProjectName("");
      setProjectDescription("");
      setCategory("");
      setTechnology("");
      setProductLine("");
      setDodCustomer("");
    },
    onError: (error) => {
      console.error("Error uploading documents:", error);
      toast({
        title: "Error",
        description: "Failed to upload documents",
        variant: "destructive",
      });
    },
  });

  const handleCreateProject = () => {
    if (!projectName.trim()) {
      toast({
        title: "Error",
        description: "Project name is required",
        variant: "destructive",
      });
      return;
    }

    createProjectMutation.mutate({
      name: projectName.trim(),
      description: projectDescription.trim() || undefined,
      category: category || undefined,
      technology: technology || undefined,
      productLine: productLine || undefined,
      dodCustomer: dodCustomer || undefined,
    });
  };

  const handleFilesUploaded = (files: File[], uploadedUrls: string[]) => {
    setUploadedFiles({ files, urls: uploadedUrls });
  };

  const handleUploadToProject = () => {
    if (!selectedProjectId) {
      toast({
        title: "Error",
        description: "Please select a project first",
        variant: "destructive",
      });
      return;
    }

    if (uploadedFiles.files.length === 0) {
      toast({
        title: "Error",
        description: "No files to upload",
        variant: "destructive",
      });
      return;
    }

    uploadDocumentsMutation.mutate({
      projectId: selectedProjectId,
      files: uploadedFiles.files,
      uploadedUrls: uploadedFiles.urls,
    });
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground mb-2">Upload Documents</h1>
        <p className="text-muted-foreground">
          Upload and organize your product documents for AI-powered analysis
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Project Creation/Selection */}
        <div className="space-y-6">
          <div className="bg-card p-6 rounded-lg border border-border">
            <h2 className="text-lg font-semibold text-foreground mb-4">Create New Project</h2>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="project-name">Project Name *</Label>
                <Input
                  id="project-name"
                  type="text"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  placeholder="Enter project name"
                  data-testid="project-name-input"
                />
              </div>

              <div>
                <Label htmlFor="project-description">Description</Label>
                <Textarea
                  id="project-description"
                  value={projectDescription}
                  onChange={(e) => setProjectDescription(e.target.value)}
                  placeholder="Describe your project"
                  rows={3}
                  data-testid="project-description-input"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Input
                    id="category"
                    type="text"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    placeholder="e.g., Defense Technology"
                    data-testid="category-input"
                  />
                </div>

                <div>
                  <Label htmlFor="technology">Technology</Label>
                  <Input
                    id="technology"
                    type="text"
                    value={technology}
                    onChange={(e) => setTechnology(e.target.value)}
                    placeholder="e.g., Quantum Computing"
                    data-testid="technology-input"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="product-line">Product Line</Label>
                  <Input
                    id="product-line"
                    type="text"
                    value={productLine}
                    onChange={(e) => setProductLine(e.target.value)}
                    placeholder="e.g., Advanced Sensors"
                    data-testid="product-line-input"
                  />
                </div>

                <div>
                  <Label htmlFor="dod-customer">DoD Customer</Label>
                  <Select value={dodCustomer} onValueChange={setDodCustomer}>
                    <SelectTrigger data-testid="dod-customer-select">
                      <SelectValue placeholder="Select customer" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="navy">Navy</SelectItem>
                      <SelectItem value="army">Army</SelectItem>
                      <SelectItem value="airforce">Air Force</SelectItem>
                      <SelectItem value="spaceforce">Space Force</SelectItem>
                      <SelectItem value="darpa">DARPA</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                onClick={handleCreateProject}
                disabled={createProjectMutation.isPending}
                className="w-full"
                data-testid="create-project-button"
              >
                {createProjectMutation.isPending ? "Creating..." : "Create Project"}
              </Button>
            </div>
          </div>

          {/* Existing Projects */}
          <div className="bg-card p-6 rounded-lg border border-border">
            <h2 className="text-lg font-semibold text-foreground mb-4">Or Select Existing Project</h2>
            
            <Select value={selectedProjectId} onValueChange={setSelectedProjectId}>
              <SelectTrigger data-testid="existing-project-select">
                <SelectValue placeholder="Select existing project" />
              </SelectTrigger>
              <SelectContent>
                {projects && Array.isArray(projects) && projects.filter((project: any) => project?.id).map((project: any) => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* File Upload */}
        <div className="space-y-6">
          <FileUploadZone 
            onFilesUploaded={handleFilesUploaded}
            projectId={selectedProjectId}
          />

          {uploadedFiles.files.length > 0 && (
            <div className="bg-card p-6 rounded-lg border border-border">
              <h3 className="text-lg font-semibold text-foreground mb-4">Uploaded Files</h3>
              <div className="space-y-2" data-testid="uploaded-files-list">
                {uploadedFiles.files.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                    <span className="text-sm font-medium">{file.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {(file.size / 1024).toFixed(1)} KB
                    </span>
                  </div>
                ))}
              </div>

              <Button
                onClick={handleUploadToProject}
                disabled={!selectedProjectId || uploadDocumentsMutation.isPending}
                className="w-full mt-4"
                data-testid="upload-to-project-button"
              >
                {uploadDocumentsMutation.isPending 
                  ? "Processing..." 
                  : `Upload to ${selectedProjectId ? "Selected Project" : "Project"}`
                }
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
