import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { insertProposalSchema } from '@shared/schema';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { FileText, Calendar, Building, Users, DollarSign, Bot, Edit, Eye, Send } from 'lucide-react';
import { Link } from 'wouter';
import type { Proposal, Solicitation } from '@shared/schema';

interface ProposalWithSolicitation extends Proposal {
  solicitation?: Solicitation;
}

const proposalFormSchema = insertProposalSchema;

type ProposalFormData = z.infer<typeof proposalFormSchema>;

export default function Proposals() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const form = useForm<ProposalFormData>({
    resolver: zodResolver(proposalFormSchema),
    defaultValues: {
      solicitationId: '',
      projectId: '',
      title: '',
      status: 'draft',
      proposalType: 'technical',
      sections: [],
      aiAssistance: {},
      teamMembers: [],
      estimatedEffort: '',
      proposedValue: '',
    },
  });

  const { data: proposals = [], isLoading } = useQuery<ProposalWithSolicitation[]>({
    queryKey: ['/api/proposals'],
    enabled: true,
  });

  const { data: solicitations = [] } = useQuery<Solicitation[]>({
    queryKey: ['/api/solicitations'],
    enabled: true,
  });

  const createProposalMutation = useMutation({
    mutationFn: async (data: ProposalFormData) => {
      const response = await fetch('/api/proposals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error('Failed to create proposal');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({ title: 'Success', description: 'Proposal created successfully' });
      form.reset();
      setIsDialogOpen(false);
      queryClient.invalidateQueries({ queryKey: ['/api/proposals'] });
    },
    onError: (error: any) => {
      toast({ 
        title: 'Error', 
        description: error.message || 'Failed to create proposal',
        variant: 'destructive',
      });
    },
  });

  const generateContentMutation = useMutation({
    mutationFn: async (proposalId: string) => {
      const response = await fetch(`/api/proposals/${proposalId}/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      
      if (!response.ok) {
        throw new Error('Failed to generate content');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({ title: 'Success', description: 'AI content generated successfully' });
      queryClient.invalidateQueries({ queryKey: ['/api/proposals'] });
    },
    onError: (error: any) => {
      toast({ 
        title: 'Error', 
        description: error.message || 'Failed to generate content',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: ProposalFormData) => {
    createProposalMutation.mutate(data);
  };

  const handleGenerateContent = (proposalId: string) => {
    generateContentMutation.mutate(proposalId);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
      case 'in_progress': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
      case 'submitted': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'won': return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/20 dark:text-emerald-300';
      case 'lost': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const getProposalTypeColor = (type: string) => {
    switch (type) {
      case 'technical': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300';
      case 'cost': return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300';
      case 'management': return 'bg-teal-100 text-teal-800 dark:bg-teal-900/20 dark:text-teal-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
    }
  };

  const openSolicitations = solicitations.filter(s => s.status === 'open');

  return (
    <div className="container mx-auto p-6 space-y-6" data-testid="proposals-page">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white" data-testid="title-proposals">
            Technical Proposals
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Build and manage proposals for DoD solicitations
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-proposal">
              <FileText className="h-4 w-4 mr-2" />
              New Proposal
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Proposal</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="solicitationId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Solicitation</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-solicitation">
                            <SelectValue placeholder="Select a solicitation" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {openSolicitations.map((solicitation) => (
                            <SelectItem key={solicitation.id} value={solicitation.id}>
                              {solicitation.title} - {solicitation.solicitationNumber}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Proposal Title</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Enter proposal title" data-testid="input-proposal-title" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="proposalType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Proposal Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value || undefined}>
                          <FormControl>
                            <SelectTrigger data-testid="select-proposal-type">
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="technical">Technical</SelectItem>
                            <SelectItem value="cost">Cost</SelectItem>
                            <SelectItem value="management">Management</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Status</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value || undefined}>
                          <FormControl>
                            <SelectTrigger data-testid="select-proposal-status">
                              <SelectValue placeholder="Select status" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="draft">Draft</SelectItem>
                            <SelectItem value="in_progress">In Progress</SelectItem>
                            <SelectItem value="submitted">Submitted</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="estimatedEffort"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Estimated Effort</FormLabel>
                        <FormControl>
                          <Input {...field} value={field.value || ""} placeholder="e.g., 6 months, 40 hours/week" data-testid="input-estimated-effort" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="proposedValue"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Proposed Value</FormLabel>
                        <FormControl>
                          <Input {...field} value={field.value || ""} placeholder="e.g., $500,000" data-testid="input-proposed-value" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="flex justify-end gap-4 pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createProposalMutation.isPending} data-testid="button-submit-proposal">
                    {createProposalMutation.isPending ? 'Creating...' : 'Create Proposal'}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Proposals Grid */}
      <div className="grid gap-6">
        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-gray-600 dark:text-gray-300">Loading proposals...</p>
          </div>
        ) : proposals.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No proposals yet</h3>
            <p className="text-gray-600 dark:text-gray-300">Create your first proposal to get started.</p>
          </div>
        ) : (
          proposals.map((proposal) => {
            const sectionsCount = Array.isArray(proposal.sections) ? proposal.sections.length : 0;
            const hasAiAssistance = proposal.aiAssistance && Object.keys(proposal.aiAssistance).length > 0;
            
            return (
              <Card key={proposal.id} className="hover:shadow-md transition-shadow" data-testid={`card-proposal-${proposal.id}`}>
                <CardHeader>
                  <div className="flex justify-between items-start gap-4">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="flex items-center gap-2 mb-2">
                        <Link href={`/proposals/${proposal.id}`} className="text-blue-600 hover:text-blue-800 dark:text-blue-400">
                          {proposal.title}
                        </Link>
                        <Badge className={getStatusColor(proposal.status || 'draft')}>
                          {proposal.status?.replace('_', ' ').toUpperCase()}
                        </Badge>
                        <Badge className={getProposalTypeColor(proposal.proposalType || 'technical')}>
                          {proposal.proposalType?.toUpperCase()}
                        </Badge>
                      </CardTitle>
                      
                      {proposal.solicitation && (
                        <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300 mb-2">
                          <Building className="h-4 w-4" />
                          <span>For: {proposal.solicitation.title}</span>
                          <span className="text-gray-400">•</span>
                          <span>{proposal.solicitation.agency}</span>
                        </div>
                      )}
                      
                      <div className="flex flex-wrap gap-4 text-sm text-gray-600 dark:text-gray-300">
                        {proposal.estimatedEffort && (
                          <span className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {proposal.estimatedEffort}
                          </span>
                        )}
                        {proposal.proposedValue && (
                          <span className="flex items-center gap-1">
                            <DollarSign className="h-4 w-4" />
                            {proposal.proposedValue}
                          </span>
                        )}
                        {proposal.teamMembers && proposal.teamMembers.length > 0 && (
                          <span className="flex items-center gap-1">
                            <Users className="h-4 w-4" />
                            {proposal.teamMembers.length} team member{proposal.teamMembers.length > 1 ? 's' : ''}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {sectionsCount === 0 ? (
                        <Button
                          onClick={() => handleGenerateContent(proposal.id)}
                          disabled={generateContentMutation.isPending}
                          size="sm"
                          data-testid={`button-generate-${proposal.id}`}
                        >
                          <Bot className="h-4 w-4 mr-2" />
                          {generateContentMutation.isPending ? 'Generating...' : 'Generate with AI'}
                        </Button>
                      ) : (
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/proposals/${proposal.id}/edit`} data-testid={`button-edit-${proposal.id}`}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </Link>
                          </Button>
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/proposals/${proposal.id}`} data-testid={`button-view-${proposal.id}`}>
                              <Eye className="h-4 w-4 mr-2" />
                              View
                            </Link>
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
                        Progress:
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-900 dark:text-white">
                          {sectionsCount} section{sectionsCount !== 1 ? 's' : ''}
                        </span>
                        {hasAiAssistance ? (
                          <Badge variant="outline" className="text-xs">
                            <Bot className="h-3 w-3 mr-1" />
                            AI-Assisted
                          </Badge>
                        ) : null}
                      </div>
                    </div>
                    
                    {sectionsCount > 0 && (
                      <div className="w-full bg-gray-200 rounded-full h-2 dark:bg-gray-700">
                        <div 
                          className="bg-blue-600 h-2 rounded-full transition-all" 
                          style={{ width: `${Math.min((sectionsCount / 5) * 100, 100)}%` }}
                        ></div>
                      </div>
                    )}
                    
                    {proposal.submissionDate && (
                      <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-300">
                        <Send className="h-4 w-4" />
                        <span>Submitted: {new Date(proposal.submissionDate).toLocaleDateString()}</span>
                      </div>
                    )}
                    
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      Created {new Date(proposal.createdAt || '').toLocaleDateString()}
                      {proposal.updatedAt && proposal.updatedAt !== proposal.createdAt && (
                        <span> • Updated {new Date(proposal.updatedAt).toLocaleDateString()}</span>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}