import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Project } from "@shared/schema";

export default function Search() {
  const [searchQuery, setSearchQuery] = useState("");
  const [technologyFilter, setTechnologyFilter] = useState("");
  const [customerFilter, setCustomerFilter] = useState("");
  const [productLineFilter, setProductLineFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  const { data: projects, isLoading, error } = useQuery({
    queryKey: ["/api/projects", "search", searchQuery, technologyFilter, customerFilter, productLineFilter, statusFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (searchQuery) params.append("q", searchQuery);
      if (technologyFilter) params.append("technology", technologyFilter);
      if (customerFilter) params.append("dodCustomer", customerFilter);
      if (productLineFilter) params.append("productLine", productLineFilter);
      if (statusFilter) params.append("developmentStatus", statusFilter);

      const response = await fetch(`/api/projects/search?${params}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to search projects");
      }
      
      return response.json();
    },
  });

  const { data: opportunities } = useQuery({
    queryKey: ["/api/market-opportunities"],
  });

  const handleSearch = () => {
    // Query will automatically refetch due to dependency changes
  };

  const clearFilters = () => {
    setSearchQuery("");
    setTechnologyFilter("");
    setCustomerFilter("");
    setProductLineFilter("");
    setStatusFilter("");
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'production': return 'bg-green-100 text-green-700';
      case 'testing': return 'bg-orange-100 text-orange-700';
      case 'development': return 'bg-yellow-100 text-yellow-700';
      default: return 'bg-blue-100 text-blue-700';
    }
  };

  const getTechnologyColor = (tech: string) => {
    if (tech?.toLowerCase().includes('quantum')) return 'bg-purple-100 text-purple-700';
    if (tech?.toLowerCase().includes('defense')) return 'bg-red-100 text-red-700';
    if (tech?.toLowerCase().includes('ai') || tech?.toLowerCase().includes('ml')) return 'bg-blue-100 text-blue-700';
    return 'bg-gray-100 text-gray-700';
  };

  const getCustomerColor = (customer: string) => {
    switch (customer?.toLowerCase()) {
      case 'navy': return 'bg-blue-100 text-blue-700';
      case 'army': return 'bg-green-100 text-green-700';
      case 'airforce': return 'bg-sky-100 text-sky-700';
      case 'spaceforce': return 'bg-purple-100 text-purple-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground mb-2">IP Catalog Search</h1>
        <p className="text-muted-foreground">
          Search and filter your intellectual property portfolio by technology, customer, and development status
        </p>
      </div>

      {/* Search and Filters */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Search & Filter</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <Input
                type="text"
                placeholder="Search by name, description, technology, or keywords..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                data-testid="ip-search-input"
              />
            </div>
            <Button onClick={handleSearch} data-testid="ip-search-button">
              <i className="fas fa-search mr-2"></i>
              Search
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <Select value={technologyFilter} onValueChange={setTechnologyFilter}>
              <SelectTrigger data-testid="ip-technology-filter">
                <SelectValue placeholder="All Technologies" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Technologies</SelectItem>
                <SelectItem value="Quantum Computing">Quantum Computing</SelectItem>
                <SelectItem value="Defense Systems">Defense Systems</SelectItem>
                <SelectItem value="Automation">Automation</SelectItem>
                <SelectItem value="AI/ML">AI/ML</SelectItem>
                <SelectItem value="Robotics">Robotics</SelectItem>
                <SelectItem value="Sensors">Advanced Sensors</SelectItem>
              </SelectContent>
            </Select>

            <Select value={customerFilter} onValueChange={setCustomerFilter}>
              <SelectTrigger data-testid="ip-customer-filter">
                <SelectValue placeholder="DoD Customer" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Customers</SelectItem>
                <SelectItem value="navy">Navy</SelectItem>
                <SelectItem value="army">Army</SelectItem>
                <SelectItem value="airforce">Air Force</SelectItem>
                <SelectItem value="spaceforce">Space Force</SelectItem>
                <SelectItem value="darpa">DARPA</SelectItem>
              </SelectContent>
            </Select>

            <Select value={productLineFilter} onValueChange={setProductLineFilter}>
              <SelectTrigger data-testid="ip-product-line-filter">
                <SelectValue placeholder="Product Line" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Product Lines</SelectItem>
                <SelectItem value="Advanced Sensors">Advanced Sensors</SelectItem>
                <SelectItem value="Computing Systems">Computing Systems</SelectItem>
                <SelectItem value="Robotics">Robotics</SelectItem>
                <SelectItem value="Defense Technology">Defense Technology</SelectItem>
                <SelectItem value="Communications">Communications</SelectItem>
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger data-testid="ip-status-filter">
                <SelectValue placeholder="Development Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Statuses</SelectItem>
                <SelectItem value="concept">Concept</SelectItem>
                <SelectItem value="development">Development</SelectItem>
                <SelectItem value="testing">Testing</SelectItem>
                <SelectItem value="production">Production</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" onClick={clearFilters} data-testid="clear-ip-filters">
              Clear Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results and Opportunities */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Search Results */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>
                  {isLoading ? "Searching..." : `${projects?.length || 0} Results Found`}
                </CardTitle>
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm">
                    <i className="fas fa-download mr-2"></i>
                    Export
                  </Button>
                  <Button variant="outline" size="sm">
                    <i className="fas fa-filter mr-2"></i>
                    Advanced
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4" data-testid="ip-search-results">
                {isLoading ? (
                  <div className="text-center py-8">
                    <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                    <p className="mt-2 text-muted-foreground">Searching IP catalog...</p>
                  </div>
                ) : error ? (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <i className="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
                    </div>
                    <h3 className="text-lg font-medium text-foreground mb-2">Search Error</h3>
                    <p className="text-muted-foreground">
                      Failed to search the IP catalog. Please try again.
                    </p>
                  </div>
                ) : projects && projects.length > 0 ? (
                  projects.map((project: Project) => (
                    <div key={project.id} className="p-4 border border-border rounded-lg hover:bg-accent transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-foreground mb-2" data-testid={`ip-result-title-${project.id}`}>
                            {project.name}
                          </h4>
                          <p className="text-sm text-muted-foreground mb-3" data-testid={`ip-result-description-${project.id}`}>
                            {project.description || "No description available"}
                          </p>
                          <div className="flex items-center flex-wrap gap-2">
                            {project.technology && (
                              <Badge className={getTechnologyColor(project.technology)} data-testid={`ip-result-tech-${project.id}`}>
                                {project.technology}
                              </Badge>
                            )}
                            {project.dodCustomer && (
                              <Badge className={getCustomerColor(project.dodCustomer)} data-testid={`ip-result-customer-${project.id}`}>
                                {project.dodCustomer.toUpperCase()}
                              </Badge>
                            )}
                            {project.productLine && (
                              <Badge variant="outline" data-testid={`ip-result-line-${project.id}`}>
                                {project.productLine}
                              </Badge>
                            )}
                            <Badge className={getStatusColor(project.developmentStatus || 'concept')} data-testid={`ip-result-status-${project.id}`}>
                              {(project.developmentStatus || 'concept').charAt(0).toUpperCase() + 
                               (project.developmentStatus || 'concept').slice(1)}
                            </Badge>
                            <span className="text-xs text-muted-foreground ml-2">
                              Updated: {new Date(project.updatedAt).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        <div className="ml-4 flex space-x-2">
                          <Link href={`/api/projects/${project.id}/datasheet`}>
                            <Button size="sm" variant="outline" data-testid={`ip-view-datasheet-${project.id}`}>
                              <i className="fas fa-external-link-alt text-sm"></i>
                            </Button>
                          </Link>
                          <Link href={`/chat/${project.id}`}>
                            <Button size="sm" variant="outline" data-testid={`ip-chat-${project.id}`}>
                              <i className="fas fa-comments text-sm"></i>
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center mx-auto mb-4">
                      <i className="fas fa-search text-muted-foreground text-2xl"></i>
                    </div>
                    <h3 className="text-lg font-medium text-foreground mb-2">No results found</h3>
                    <p className="text-muted-foreground mb-6">
                      {searchQuery || technologyFilter || customerFilter || productLineFilter || statusFilter
                        ? "Try adjusting your search criteria or filters"
                        : "Start by uploading your product documents to build your IP catalog"
                      }
                    </p>
                    <Link href="/upload">
                      <Button data-testid="ip-empty-upload">
                        <i className="fas fa-upload mr-2"></i>
                        Upload Documents
                      </Button>
                    </Link>
                  </div>
                )}
              </div>

              {projects && projects.length > 0 && (
                <div className="flex items-center justify-between mt-6 pt-4 border-t border-border">
                  <p className="text-sm text-muted-foreground" data-testid="ip-search-count">
                    Showing {projects.length} results
                  </p>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" disabled>
                      Previous
                    </Button>
                    <Button size="sm">1</Button>
                    <Button variant="outline" size="sm" disabled>
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Market Opportunities Sidebar */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Market Opportunities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4" data-testid="ip-market-opportunities">
                {opportunities && opportunities.length > 0 ? (
                  opportunities.slice(0, 3).map((opportunity: any) => (
                    <div key={opportunity.id} className={`p-4 border rounded-lg ${
                      opportunity.priority === 'high' ? 'bg-green-50 border-green-200' :
                      opportunity.priority === 'medium' ? 'bg-blue-50 border-blue-200' :
                      'bg-orange-50 border-orange-200'
                    }`}>
                      <div className="flex items-center space-x-2 mb-2">
                        <i className={`fas ${
                          opportunity.opportunityType === 'partnership' ? 'fa-handshake' :
                          opportunity.opportunityType === 'expansion' ? 'fa-lightbulb' :
                          'fa-arrow-trend-up'
                        } ${
                          opportunity.priority === 'high' ? 'text-green-600' :
                          opportunity.priority === 'medium' ? 'text-blue-600' :
                          'text-orange-600'
                        }`}></i>
                        <h4 className={`font-medium ${
                          opportunity.priority === 'high' ? 'text-green-800' :
                          opportunity.priority === 'medium' ? 'text-blue-800' :
                          'text-orange-800'
                        }`}>
                          {opportunity.title}
                        </h4>
                      </div>
                      <p className={`text-sm ${
                        opportunity.priority === 'high' ? 'text-green-700' :
                        opportunity.priority === 'medium' ? 'text-blue-700' :
                        'text-orange-700'
                      }`}>
                        {opportunity.description}
                      </p>
                      {opportunity.relatedTechnologies && opportunity.relatedTechnologies.length > 0 && (
                        <div className="mt-2">
                          <div className="flex flex-wrap gap-1">
                            {opportunity.relatedTechnologies.slice(0, 2).map((tech: string, index: number) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {tech}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      <button className={`mt-2 text-xs font-medium ${
                        opportunity.priority === 'high' ? 'text-green-600 hover:text-green-800' :
                        opportunity.priority === 'medium' ? 'text-blue-600 hover:text-blue-800' :
                        'text-orange-600 hover:text-orange-800'
                      }`}
                      data-testid={`ip-opportunity-details-${opportunity.id}`}>
                        View Details →
                      </button>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-6">
                    <div className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center mx-auto mb-3">
                      <i className="fas fa-lightbulb text-muted-foreground"></i>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      No market opportunities identified yet
                    </p>
                  </div>
                )}
              </div>

              <div className="mt-6 pt-4 border-t border-border">
                <Button className="w-full" size="sm" data-testid="ip-generate-opportunities">
                  <i className="fas fa-chart-line mr-2"></i>
                  Generate Market Analysis
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Search Tips */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-base">Search Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm text-muted-foreground">
                <div className="flex items-start space-x-2">
                  <i className="fas fa-lightbulb text-primary mt-0.5"></i>
                  <p>Use specific technology terms like "quantum", "radar", or "AI" for better results</p>
                </div>
                <div className="flex items-start space-x-2">
                  <i className="fas fa-filter text-primary mt-0.5"></i>
                  <p>Combine multiple filters to narrow down your search</p>
                </div>
                <div className="flex items-start space-x-2">
                  <i className="fas fa-search text-primary mt-0.5"></i>
                  <p>Search across project names, descriptions, and document content</p>
                </div>
                <div className="flex items-start space-x-2">
                  <i className="fas fa-download text-primary mt-0.5"></i>
                  <p>Export search results for external analysis and reporting</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
