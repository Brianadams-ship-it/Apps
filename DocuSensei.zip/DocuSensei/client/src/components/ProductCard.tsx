import { Link } from "wouter";
import type { Project } from "@shared/schema";

interface ProductCardProps {
  project: Project;
}

const statusConfig = {
  concept: { color: "bg-blue-100 text-blue-700", label: "Concept" },
  development: { color: "bg-yellow-100 text-yellow-700", label: "Development" },
  testing: { color: "bg-orange-100 text-orange-700", label: "Testing" },
  production: { color: "bg-green-100 text-green-700", label: "Production" },
};

export default function ProductCard({ project }: ProductCardProps) {
  const status = statusConfig[project.developmentStatus as keyof typeof statusConfig] || statusConfig.concept;
  
  return (
    <Link href={`/catalog/${project.id}`}>
      <div className="flex items-center space-x-4 p-3 rounded-lg border border-border hover:bg-accent transition-colors cursor-pointer"
           data-testid={`product-card-${project.id}`}>
        {project.thumbnailUrl ? (
          <img 
            src={project.thumbnailUrl} 
            alt={project.name}
            className="w-12 h-12 rounded-lg object-cover"
            data-testid={`product-image-${project.id}`}
          />
        ) : (
          <div className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center">
            <i className="fas fa-cube text-muted-foreground"></i>
          </div>
        )}
        <div className="flex-1">
          <h4 className="font-medium text-foreground" data-testid={`product-name-${project.id}`}>
            {project.name}
          </h4>
          <p className="text-sm text-muted-foreground" data-testid={`product-category-${project.id}`}>
            {project.category || project.technology || 'General'}
          </p>
          <div className="flex items-center space-x-2 mt-1">
            <span className={`px-2 py-1 text-xs rounded-full ${status.color}`}
                  data-testid={`product-status-${project.id}`}>
              {status.label}
            </span>
            <span className="text-xs text-muted-foreground" data-testid={`product-updated-${project.id}`}>
              Updated {new Date(project.updatedAt).toLocaleDateString()}
            </span>
          </div>
        </div>
        <button className="text-muted-foreground hover:text-foreground" data-testid={`product-view-${project.id}`}>
          <i className="fas fa-chevron-right text-sm"></i>
        </button>
      </div>
    </Link>
  );
}
