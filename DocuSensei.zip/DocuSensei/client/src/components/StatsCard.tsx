import { ReactNode } from "react";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: ReactNode;
  trend?: {
    value: string;
    positive: boolean;
  };
  testId?: string;
}

export default function StatsCard({ title, value, icon, trend, testId }: StatsCardProps) {
  return (
    <div className="bg-card p-6 rounded-lg border border-border" data-testid={testId}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-muted-foreground">{title}</p>
          <p className="text-2xl font-semibold text-foreground" data-testid={`${testId}-value`}>{value}</p>
        </div>
        <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
          {icon}
        </div>
      </div>
      {trend && (
        <div className="flex items-center mt-4 text-sm">
          <span className={`flex items-center ${trend.positive ? 'text-green-600' : 'text-red-600'}`}>
            <i className={`fas fa-arrow-${trend.positive ? 'up' : 'down'} text-xs mr-1`}></i>
            {trend.value}
          </span>
        </div>
      )}
    </div>
  );
}
