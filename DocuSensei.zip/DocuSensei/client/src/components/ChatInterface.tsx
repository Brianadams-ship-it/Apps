import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  confidence?: number;
  sources?: string[];
}

interface ChatInterfaceProps {
  projectId?: string;
  messages: Message[];
  onNewMessage?: (messages: Message[]) => void;
}

export default function ChatInterface({ projectId, messages, onNewMessage }: ChatInterfaceProps) {
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSendMessage = async () => {
    if (!message.trim() || !projectId) return;

    const userMessage: Message = {
      role: "user",
      content: message.trim(),
      timestamp: new Date(),
    };

    const newMessages = [...messages, userMessage];
    onNewMessage?.(newMessages);
    setMessage("");
    setIsLoading(true);

    try {
      const response = await apiRequest("POST", `/api/projects/${projectId}/chat`, {
        message: message.trim(),
      });

      const result = await response.json();

      const assistantMessage: Message = {
        role: "assistant",
        content: result.message,
        timestamp: new Date(),
        confidence: result.confidence,
        sources: result.sources,
      };

      onNewMessage?.([...newMessages, assistantMessage]);
    } catch (error) {
      console.error("Chat error:", error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="bg-card p-6 rounded-lg border border-border">
      <h3 className="text-lg font-semibold text-foreground mb-4">AI Assistant</h3>
      
      <div className="space-y-3 mb-4 h-40 overflow-y-auto" data-testid="chat-messages">
        {messages.length === 0 ? (
          <div className="flex items-start space-x-2">
            <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
              <i className="fas fa-robot text-primary-foreground text-xs"></i>
            </div>
            <div className="bg-muted p-3 rounded-lg text-sm">
              <p>Hello! I can help you analyze your product portfolio, find similar technologies, or answer questions about your documents.</p>
            </div>
          </div>
        ) : (
          messages.map((msg, index) => (
            <div key={index} className={`flex items-start space-x-2 ${msg.role === 'user' ? 'justify-end' : ''}`}>
              {msg.role === 'assistant' && (
                <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-robot text-primary-foreground text-xs"></i>
                </div>
              )}
              <div className={`p-3 rounded-lg text-sm max-w-xs ${
                msg.role === 'user' 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted'
              }`}
              data-testid={`chat-message-${index}`}>
                <p>{msg.content}</p>
                {msg.confidence && (
                  <p className="text-xs mt-1 opacity-70">
                    Confidence: {Math.round(msg.confidence * 100)}%
                  </p>
                )}
                {msg.sources && msg.sources.length > 0 && (
                  <p className="text-xs mt-1 opacity-70">
                    Sources: {msg.sources.join(", ")}
                  </p>
                )}
              </div>
              {msg.role === 'user' && (
                <div className="w-6 h-6 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-user text-muted-foreground text-xs"></i>
                </div>
              )}
            </div>
          ))
        )}
        {isLoading && (
          <div className="flex items-start space-x-2">
            <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
              <i className="fas fa-robot text-primary-foreground text-xs"></i>
            </div>
            <div className="bg-muted p-3 rounded-lg text-sm">
              <p>Thinking...</p>
            </div>
          </div>
        )}
      </div>
      
      <div className="flex space-x-2">
        <Input
          type="text"
          placeholder={projectId ? "Ask about this product..." : "Select a project to start chatting"}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyPress={handleKeyPress}
          disabled={!projectId || isLoading}
          className="flex-1"
          data-testid="chat-input"
        />
        <Button 
          onClick={handleSendMessage}
          disabled={!projectId || !message.trim() || isLoading}
          data-testid="chat-send"
        >
          <i className="fas fa-paper-plane text-sm"></i>
        </Button>
      </div>
    </div>
  );
}
