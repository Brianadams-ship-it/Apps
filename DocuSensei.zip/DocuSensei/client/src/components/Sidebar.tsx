import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Dashboard", href: "/", icon: "fas fa-home" },
  { name: "Upload Documents", href: "/upload", icon: "fas fa-upload" },
  { name: "Product Catalog", href: "/catalog", icon: "fas fa-folder-open" },
  { name: "AI Chat", href: "/chat", icon: "fas fa-comments" },
  { name: "IP Search", href: "/search", icon: "fas fa-search" },
  { name: "DoD Solicitations", href: "/solicitations", icon: "fas fa-file-contract" },
  { name: "Proposals", href: "/proposals", icon: "fas fa-file-signature" },
  { name: "Roadmaps", href: "/roadmaps", icon: "fas fa-route" },
  { name: "Analytics", href: "/analytics", icon: "fas fa-chart-bar" },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col">
      {/* Logo & Brand */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <i className="fas fa-cube text-primary-foreground text-sm"></i>
          </div>
          <div>
            <h1 className="text-lg font-semibold text-foreground">TechVault</h1>
            <p className="text-xs text-muted-foreground">AI Product Intelligence</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navigation.map((item) => {
            const isActive = location === item.href;
            return (
              <li key={item.name}>
                <Link href={item.href}>
                  <div className={cn(
                    "flex items-center space-x-3 px-3 py-2 rounded-md transition-colors cursor-pointer",
                    isActive 
                      ? "bg-accent text-accent-foreground" 
                      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                  )}
                  data-testid={`nav-${item.name.toLowerCase().replace(" ", "-")}`}
                  >
                    <i className={`${item.icon} w-4`}></i>
                    <span className="text-sm font-medium">{item.name}</span>
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <i className="fas fa-user text-primary-foreground text-xs"></i>
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-foreground">Sarah Johnson</p>
            <p className="text-xs text-muted-foreground">Product Manager</p>
          </div>
          <button className="text-muted-foreground hover:text-foreground" data-testid="user-settings">
            <i className="fas fa-cog text-sm"></i>
          </button>
        </div>
      </div>
    </div>
  );
}
