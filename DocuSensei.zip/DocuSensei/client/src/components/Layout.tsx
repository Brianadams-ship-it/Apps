import { ReactNode } from "react";
import Sidebar from "./Sidebar";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-card border-b border-border px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold text-foreground">Product Intelligence Dashboard</h2>
              <p className="text-sm text-muted-foreground">Technology portfolio & DoD proposal management</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground text-sm"></i>
                <input 
                  type="text" 
                  placeholder="Search products, technologies..." 
                  className="pl-10 pr-4 py-2 w-80 bg-background border border-border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  data-testid="global-search-input"
                />
              </div>
              <button className="relative p-2 text-muted-foreground hover:text-foreground" data-testid="notifications-button">
                <i className="fas fa-bell text-lg"></i>
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-destructive rounded-full text-destructive-foreground text-xs flex items-center justify-center">3</span>
              </button>
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
