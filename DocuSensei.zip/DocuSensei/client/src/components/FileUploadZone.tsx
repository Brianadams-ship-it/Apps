import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ObjectUploader } from "./ObjectUploader";
import type { UploadResult } from "@uppy/core";

interface FileUploadZoneProps {
  onFilesUploaded?: (files: File[], uploadedUrls: string[]) => void;
  projectId?: string;
}

export default function FileUploadZone({ onFilesUploaded, projectId }: FileUploadZoneProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleGetUploadParameters = async () => {
    try {
      const response = await fetch("/api/objects/upload", {
        method: "POST",
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to get upload URL");
      }
      
      const data = await response.json();
      return {
        method: "PUT" as const,
        url: data.uploadURL,
      };
    } catch (error) {
      console.error("Error getting upload parameters:", error);
      throw error;
    }
  };

  const handleUploadComplete = async (result: UploadResult<Record<string, unknown>, Record<string, unknown>>) => {
    try {
      setIsUploading(true);
      
      if (!result.successful || result.successful.length === 0) {
        throw new Error("No files were uploaded successfully");
      }

      // Get the uploaded URLs and file data
      const uploadedUrls = result.successful.map(file => file.uploadURL).filter((url): url is string => !!url);
      const fileData = result.successful.map(file => ({
        name: file.name || 'unnamed',
        type: file.type || "application/octet-stream",
        size: file.size || 0,
      }));

      // Create File objects for the uploaded files
      const files = fileData.map(data => new File([], data.name, { type: data.type }));

      onFilesUploaded?.(files, uploadedUrls);

      toast({
        title: "Success",
        description: `${result.successful.length} file(s) uploaded successfully`,
      });
    } catch (error) {
      console.error("Upload completion error:", error);
      toast({
        title: "Error",
        description: "Failed to complete file upload",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    // For drag and drop, we'll use the file input instead
    // This is a simplified version - in a real implementation,
    // you'd want to handle the dropped files directly
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  return (
    <div className="bg-card p-6 rounded-lg border border-border">
      <h3 className="text-lg font-semibold text-foreground mb-4">Quick Upload</h3>
      
      <div 
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
          isDragOver ? 'border-primary bg-primary/5' : 'border-border hover:border-primary'
        }`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        data-testid="file-upload-zone"
      >
        <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center mx-auto mb-4">
          <i className="fas fa-cloud-upload-alt text-muted-foreground text-2xl"></i>
        </div>
        <h4 className="text-lg font-medium text-foreground mb-2">Drag & drop your files here</h4>
        <p className="text-muted-foreground mb-4">or click to browse from your computer</p>
        <div className="flex items-center justify-center space-x-4 text-sm text-muted-foreground">
          <span><i className="fas fa-file-pdf mr-1"></i>PDF</span>
          <span><i className="fas fa-file-word mr-1"></i>DOCX</span>
          <span><i className="fas fa-file-excel mr-1"></i>XLSX</span>
          <span><i className="fas fa-image mr-1"></i>Images</span>
          <span><i className="fas fa-link mr-1"></i>Links</span>
        </div>
      </div>
      
      <div className="flex items-center justify-between mt-4">
        <ObjectUploader
          maxNumberOfFiles={10}
          maxFileSize={50 * 1024 * 1024} // 50MB
          onGetUploadParameters={handleGetUploadParameters}
          onComplete={handleUploadComplete}
          buttonClassName="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 transition-colors"
        >
          <i className="fas fa-upload mr-2"></i>
          {isUploading ? "Uploading..." : "Upload Files"}
        </ObjectUploader>
        
        <button 
          className="px-4 py-2 text-muted-foreground hover:text-foreground text-sm font-medium"
          data-testid="bulk-upload-options"
        >
          Bulk Upload Options
        </button>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        accept=".pdf,.doc,.docx,.xls,.xlsx,.txt,.jpg,.jpeg,.png,.gif"
      />
    </div>
  );
}
