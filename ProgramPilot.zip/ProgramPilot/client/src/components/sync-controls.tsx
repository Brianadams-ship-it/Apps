import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle, CheckCircle, Download, Upload, ExternalLink, RefreshCw, Clock, AlertTriangle, FileSpreadsheet, Eye } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SyncStatus {
  lastSyncAt: string | null;
  lastExportAt: string | null;
  lastImportAt: string | null;
  fileSHA: string | null;
  errors: string[];
  isExporting: boolean;
  isImporting: boolean;
}

interface FileUploadResult {
  success: boolean;
  dryRun: boolean;
  results: {
    errors: string[];
    warnings: string[];
    stats: { [sheetName: string]: number };
  };
  message: string;
}

export default function SyncControls() {
  const { toast } = useToast();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadResult, setUploadResult] = useState<FileUploadResult | null>(null);
  const [showUploadPreview, setShowUploadPreview] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: syncStatus, isLoading } = useQuery<SyncStatus>({
    queryKey: ["/api/sync/status"],
    refetchInterval: 2000, // Refresh every 2 seconds when operations are running
  });

  const { data: fileUrlData } = useQuery<{ fileUrl: string }>({
    queryKey: ["/api/sync/file-url"],
  });

  const exportMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/sync/export"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sync/status"] });
      toast({ title: "Export completed successfully", description: "Data has been uploaded to GitHub" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Export failed", 
        description: error.message || "Failed to export data to GitHub",
        variant: "destructive"
      });
    },
  });

  const importMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/sync/import"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sync/status"] });
      // Invalidate all data queries since import may have updated everything
      queryClient.invalidateQueries({ queryKey: ["/api/programs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/risks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/portfolio"] });
      toast({ title: "Import completed successfully", description: "Data has been synchronized from GitHub" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Import failed", 
        description: error.message || "Failed to import data from GitHub",
        variant: "destructive"
      });
    },
  });

  const importCostsMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/sync/import-costs"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sync/status"] });
      // Invalidate program and budget data since costs may have been updated
      queryClient.invalidateQueries({ queryKey: ["/api/programs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/budget-summary"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/resource-utilization"] });
      toast({ title: "Incurred costs updated", description: "Current costs imported from Project Data file" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Cost import failed", 
        description: error.message || "Failed to import incurred costs",
        variant: "destructive"
      });
    },
  });

  const fileUploadMutation = useMutation({
    mutationFn: async ({ file, dryRun }: { file: File; dryRun: boolean }) => {
      const formData = new FormData();
      formData.append('file', file);
      
      const url = `/api/sync/import-file${dryRun ? '?dryRun=true' : ''}`;
      const response = await fetch(url, {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) {
        let errorMessage;
        try {
          const error = await response.json();
          errorMessage = error.error || 'Upload failed';
        } catch {
          const errorText = await response.text();
          errorMessage = errorText || `Upload failed with status ${response.status}`;
        }
        throw new Error(errorMessage);
      }
      
      return response.json() as Promise<FileUploadResult>;
    },
    onSuccess: (result) => {
      setUploadResult(result);
      if (!result.dryRun) {
        // Actual import completed - invalidate all affected queries
        queryClient.invalidateQueries({ queryKey: ["/api/sync/status"] });
        queryClient.invalidateQueries({ queryKey: ["/api/programs"] });
        queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
        queryClient.invalidateQueries({ queryKey: ["/api/dashboard/resource-utilization"] });
        queryClient.invalidateQueries({ queryKey: ["/api/dashboard/budget-summary"] });
        queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
        toast({ 
          title: "File imported successfully", 
          description: result.message 
        });
        setSelectedFile(null);
        setShowUploadPreview(false);
      } else {
        // Dry run completed
        setShowUploadPreview(true);
        toast({ 
          title: "File validation completed", 
          description: result.message 
        });
      }
    },
    onError: (error: any) => {
      toast({ 
        title: "File upload failed", 
        description: error.message || "Failed to upload file",
        variant: "destructive"
      });
      setUploadResult(null);
      setShowUploadPreview(false);
    },
  });

  const handleRefreshStatus = async () => {
    setIsRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ["/api/sync/status"] });
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  const handleDownloadTemplate = async (includeExamples: boolean = false) => {
    try {
      const url = includeExamples ? '/api/templates/programs-example.xlsx' : '/api/templates/programs.xlsx';
      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error('Failed to download template');
      }
      
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = includeExamples ? 'programs-template-example.xlsx' : 'programs-template.xlsx';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(downloadUrl);
      
      toast({ 
        title: "Template downloaded", 
        description: `${includeExamples ? 'Example template' : 'Blank template'} downloaded successfully` 
      });
    } catch (error: any) {
      toast({ 
        title: "Download failed", 
        description: error.message || "Failed to download template",
        variant: "destructive"
      });
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setUploadResult(null);
      setShowUploadPreview(false);
    }
  };

  const handleValidateFile = () => {
    if (selectedFile) {
      fileUploadMutation.mutate({ file: selectedFile, dryRun: true });
    }
  };

  const handleImportFile = () => {
    if (selectedFile) {
      fileUploadMutation.mutate({ file: selectedFile, dryRun: false });
    }
  };

  const handleClearFile = () => {
    setSelectedFile(null);
    setUploadResult(null);
    setShowUploadPreview(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Never";
    return new Date(dateString).toLocaleString();
  };

  const getStatusIcon = () => {
    if (syncStatus?.errors?.length > 0) {
      return <AlertCircle className="h-5 w-5 text-red-500" />;
    }
    if (syncStatus?.isExporting || syncStatus?.isImporting) {
      return <RefreshCw className="h-5 w-5 text-blue-500 animate-spin" />;
    }
    return <CheckCircle className="h-5 w-5 text-green-500" />;
  };

  const getStatusText = () => {
    if (syncStatus?.isExporting) return "Exporting to GitHub...";
    if (syncStatus?.isImporting) return "Importing from GitHub...";
    if (syncStatus?.errors?.length > 0) return `${syncStatus.errors.length} error(s)`;
    return "Ready";
  };

  if (isLoading) {
    return (
      <Card data-testid="card-sync-controls">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RefreshCw className="h-5 w-5 animate-spin" />
            Excel Master File Sync
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-4">
            <Progress value={50} className="w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="card-sync-controls">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {getStatusIcon()}
          Excel Master File Sync
        </CardTitle>
        <CardDescription>
          Sync application data with GitHub-hosted Excel master file
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Status Section */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Status</span>
            <div className="flex items-center gap-2">
              <Badge variant={syncStatus?.errors?.length > 0 ? "destructive" : "default"}>
                {getStatusText()}
              </Badge>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleRefreshStatus}
                disabled={isRefreshing}
                data-testid="button-refresh-status"
              >
                <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
              </Button>
            </div>
          </div>

          {/* Progress bar for active operations */}
          {(syncStatus?.isExporting || syncStatus?.isImporting) && (
            <Progress value={undefined} className="w-full" />
          )}

          {/* Error display */}
          {syncStatus?.errors?.length > 0 && (
            <div className="space-y-2">
              {syncStatus.errors.map((error, index) => (
                <div key={index} className="flex items-start gap-2 p-2 bg-red-50 dark:bg-red-950/20 rounded-md">
                  <AlertTriangle className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm text-red-700 dark:text-red-400">{error}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Last Sync Information */}
        <div className="space-y-2">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Last Export:</span>
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {formatDate(syncStatus?.lastExportAt)}
              </div>
            </div>
            <div>
              <span className="text-muted-foreground">Last Import:</span>
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {formatDate(syncStatus?.lastImportAt)}
              </div>
            </div>
          </div>
        </div>

        {/* File Link */}
        {fileUrlData?.fileUrl && (
          <div className="space-y-2">
            <span className="text-sm font-medium">Excel File</span>
            <Button 
              variant="outline" 
              className="w-full justify-start"
              onClick={() => window.open(fileUrlData.fileUrl, '_blank')}
              data-testid="button-open-excel-file"
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              Open in GitHub
            </Button>
          </div>
        )}

        {/* Template Section */}
        <div className="space-y-4 border-t pt-4">
          <div className="space-y-2">
            <span className="text-sm font-medium">Templates</span>
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={() => handleDownloadTemplate(false)}
                data-testid="button-download-template"
              >
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Download Template
              </Button>
              <Button
                variant="outline"
                onClick={() => handleDownloadTemplate(true)}
                data-testid="button-download-example"
              >
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Download Example
              </Button>
            </div>
          </div>

          {/* File Upload Section */}
          <div className="space-y-3">
            <div className="space-y-2">
              <Label htmlFor="file-upload">Upload Excel File</Label>
              <Input
                id="file-upload"
                type="file"
                accept=".xlsx,.xls"
                onChange={handleFileSelect}
                ref={fileInputRef}
                data-testid="input-file-upload"
              />
            </div>

            {selectedFile && (
              <div className="space-y-3 p-3 bg-muted/30 rounded-md">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileSpreadsheet className="h-4 w-4" />
                    <span className="text-sm font-medium">{selectedFile.name}</span>
                    <Badge variant="secondary">{(selectedFile.size / 1024).toFixed(1)} KB</Badge>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleClearFile}
                    data-testid="button-clear-file"
                  >
                    Clear
                  </Button>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleValidateFile}
                    disabled={fileUploadMutation.isPending}
                    data-testid="button-validate-file"
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    {fileUploadMutation.isPending && uploadResult?.dryRun ? "Validating..." : "Validate"}
                  </Button>
                  <Button
                    size="sm"
                    onClick={handleImportFile}
                    disabled={fileUploadMutation.isPending || !uploadResult || (uploadResult?.results?.errors?.length > 0)}
                    data-testid="button-import-file"
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    {fileUploadMutation.isPending && !uploadResult?.dryRun ? "Importing..." : "Import"}
                  </Button>
                </div>

                {/* Upload Result Preview */}
                {showUploadPreview && uploadResult && (
                  <div className="space-y-2 border-t pt-3">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">Validation Results:</span>
                      <Badge variant={uploadResult.results.errors.length > 0 ? "destructive" : "default"}>
                        {uploadResult.results.errors.length} errors, {uploadResult.results.warnings.length} warnings
                      </Badge>
                    </div>

                    {uploadResult.results.errors.length > 0 && (
                      <div className="space-y-1">
                        <span className="text-xs font-medium text-red-600 dark:text-red-400">Errors:</span>
                        {uploadResult.results.errors.slice(0, 3).map((error, index) => (
                          <div key={index} className="text-xs text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/20 p-2 rounded">
                            {error}
                          </div>
                        ))}
                        {uploadResult.results.errors.length > 3 && (
                          <div className="text-xs text-muted-foreground">
                            ...and {uploadResult.results.errors.length - 3} more errors
                          </div>
                        )}
                      </div>
                    )}

                    {uploadResult.results.warnings.length > 0 && (
                      <div className="space-y-1">
                        <span className="text-xs font-medium text-yellow-600 dark:text-yellow-400">Warnings:</span>
                        {uploadResult.results.warnings.slice(0, 2).map((warning, index) => (
                          <div key={index} className="text-xs text-yellow-600 dark:text-yellow-400 bg-yellow-50 dark:bg-yellow-950/20 p-2 rounded">
                            {warning}
                          </div>
                        ))}
                        {uploadResult.results.warnings.length > 2 && (
                          <div className="text-xs text-muted-foreground">
                            ...and {uploadResult.results.warnings.length - 2} more warnings
                          </div>
                        )}
                      </div>
                    )}

                    <div className="text-xs text-muted-foreground">
                      Ready to process: {Object.entries(uploadResult.results.stats).map(([sheet, count]) => `${sheet} (${count})`).join(', ')}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 gap-3">
          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={() => exportMutation.mutate()}
              disabled={exportMutation.isPending || importMutation.isPending || importCostsMutation.isPending || syncStatus?.isExporting || syncStatus?.isImporting}
              data-testid="button-export-to-github"
            >
              <Upload className="h-4 w-4 mr-2" />
              {exportMutation.isPending ? "Exporting..." : "Export to GitHub"}
            </Button>
            
            <Button
              variant="outline"
              onClick={() => importMutation.mutate()}
              disabled={exportMutation.isPending || importMutation.isPending || importCostsMutation.isPending || syncStatus?.isExporting || syncStatus?.isImporting}
              data-testid="button-import-from-github"
            >
              <Download className="h-4 w-4 mr-2" />
              {importMutation.isPending ? "Importing..." : "Import from GitHub"}
            </Button>
          </div>
          
          <Button
            variant="secondary"
            onClick={() => importCostsMutation.mutate()}
            disabled={exportMutation.isPending || importMutation.isPending || importCostsMutation.isPending || syncStatus?.isExporting || syncStatus?.isImporting}
            data-testid="button-import-costs"
            className="w-full"
          >
            <Download className="h-4 w-4 mr-2" />
            {importCostsMutation.isPending ? "Importing Costs..." : "Import Current Costs"}
          </Button>
        </div>

        {/* Help Text */}
        <div className="text-xs text-muted-foreground bg-muted/30 p-3 rounded-md">
          <p><strong>Export:</strong> Uploads current application data to the Excel file on GitHub</p>
          <p><strong>Import:</strong> Downloads and synchronizes data from the GitHub Excel file</p>
          <p><strong>Import Costs:</strong> Updates incurred costs from Project Data.xlsx file</p>
          <p><strong>Note:</strong> Changes made directly to the Excel files in GitHub will be detected and can be imported</p>
        </div>
      </CardContent>
    </Card>
  );
}