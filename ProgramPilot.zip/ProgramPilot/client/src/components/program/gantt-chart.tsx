import { useMemo } from "react";
import { format, differenceInDays, addDays, startOfDay, parseISO } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface GanttChartProps {
  wbsData: any[];
  milestones: any[];
}

interface GanttTask {
  id: string;
  name: string;
  startDate: Date;
  endDate: Date;
  progress: number;
  phase: string;
  resourceType: string;
  dependencies: string[];
}

interface GanttMilestone {
  id: string;
  name: string;
  date: Date;
  type: string;
  status: string;
}

export default function GanttChart({ wbsData, milestones }: GanttChartProps) {
  const { tasks, chartMilestones, timelineStart, timelineEnd, totalDays } = useMemo(() => {
    if (!wbsData.length && !milestones.length) {
      return {
        tasks: [],
        chartMilestones: [],
        timelineStart: new Date(),
        timelineEnd: new Date(),
        totalDays: 0,
      };
    }

    // Process WBS data into Gantt tasks
    const ganttTasks: GanttTask[] = wbsData.map((wbs) => {
      const startDate = wbs.startDate ? parseISO(wbs.startDate) : new Date();
      const endDate = wbs.endDate ? parseISO(wbs.endDate) : addDays(startDate, 30);
      const estimated = parseFloat(wbs.estimatedHours) || 1;
      const actual = parseFloat(wbs.actualHours) || 0;
      const progress = Math.min(100, Math.round((actual / estimated) * 100));

      return {
        id: wbs.id,
        name: wbs.taskName,
        startDate: startOfDay(startDate),
        endDate: startOfDay(endDate),
        progress,
        phase: wbs.phase,
        resourceType: wbs.resourceType,
        dependencies: wbs.dependencies || [],
      };
    });

    // Process milestones
    const ganttMilestones: GanttMilestone[] = milestones.map((milestone) => ({
      id: milestone.id,
      name: milestone.name,
      date: milestone.targetDate ? startOfDay(parseISO(milestone.targetDate)) : new Date(),
      type: milestone.type,
      status: milestone.status,
    }));

    // Calculate timeline bounds
    const allDates = [
      ...ganttTasks.flatMap((task) => [task.startDate, task.endDate]),
      ...ganttMilestones.map((milestone) => milestone.date),
    ];

    const start = allDates.length > 0 ? new Date(Math.min(...allDates.map(d => d.getTime()))) : new Date();
    const end = allDates.length > 0 ? new Date(Math.max(...allDates.map(d => d.getTime()))) : addDays(new Date(), 365);
    
    // Add some padding
    const timelineStart = addDays(start, -7);
    const timelineEnd = addDays(end, 7);
    const totalDays = differenceInDays(timelineEnd, timelineStart);

    return {
      tasks: ganttTasks,
      chartMilestones: ganttMilestones,
      timelineStart,
      timelineEnd,
      totalDays,
    };
  }, [wbsData, milestones]);

  const getPhaseColor = (phase: string) => {
    const colors: Record<string, string> = {
      PDR: "bg-blue-500",
      CDR: "bg-green-500",
      TRR: "bg-yellow-500",
      QUAL: "bg-orange-500",
      PRODUCTION: "bg-red-500",
    };
    return colors[phase] || "bg-gray-500";
  };

  const getResourceTypeColor = (resourceType: string) => {
    const colors: Record<string, string> = {
      "software-engineer": "bg-blue-600",
      "hardware-engineer": "bg-green-600",
      "test-engineer": "bg-yellow-600",
      "project-manager": "bg-purple-600",
    };
    return colors[resourceType] || "bg-gray-600";
  };

  const calculatePosition = (date: Date) => {
    const daysDiff = differenceInDays(date, timelineStart);
    return (daysDiff / totalDays) * 100;
  };

  const calculateWidth = (startDate: Date, endDate: Date) => {
    const duration = differenceInDays(endDate, startDate);
    return Math.max(1, (duration / totalDays) * 100);
  };

  // Generate timeline months for header
  const timelineMonths = useMemo(() => {
    const months = [];
    let currentDate = new Date(timelineStart.getFullYear(), timelineStart.getMonth(), 1);
    
    while (currentDate <= timelineEnd) {
      const monthStart = new Date(currentDate);
      const monthEnd = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
      const startPos = calculatePosition(monthStart);
      const width = calculateWidth(monthStart, monthEnd);
      
      months.push({
        name: format(monthStart, "MMM yyyy"),
        startPos,
        width,
      });
      
      currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1);
    }
    
    return months;
  }, [timelineStart, timelineEnd, totalDays]);

  if (!tasks.length && !chartMilestones.length) {
    return (
      <Card data-testid="gantt-chart-empty">
        <CardContent className="p-8 text-center">
          <p className="text-muted-foreground">No schedule data available</p>
          <p className="text-sm text-muted-foreground mt-2">
            Create work breakdown structure items to see the project timeline
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <TooltipProvider>
      <Card data-testid="gantt-chart">
        <CardContent className="p-6">
          <div className="overflow-x-auto">
            <div className="min-w-[800px]">
              {/* Timeline Header */}
              <div className="border-b border-border pb-4 mb-4">
                <div className="flex relative h-8">
                  {timelineMonths.map((month, index) => (
                    <div
                      key={index}
                      className="absolute top-0 h-8 flex items-center justify-center text-xs font-medium text-muted-foreground border-l border-border"
                      style={{
                        left: `${month.startPos}%`,
                        width: `${month.width}%`,
                      }}
                    >
                      {month.name}
                    </div>
                  ))}
                </div>
              </div>

              {/* Tasks */}
              <div className="space-y-2">
                {tasks.map((task) => {
                  const startPos = calculatePosition(task.startDate);
                  const width = calculateWidth(task.startDate, task.endDate);
                  
                  return (
                    <div key={task.id} className="flex items-center" data-testid={`gantt-task-${task.id}`}>
                      {/* Task Info */}
                      <div className="w-64 pr-4 flex-shrink-0">
                        <div className="text-sm font-medium text-foreground truncate" title={task.name}>
                          {task.name}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {task.phase}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {task.progress}%
                          </span>
                        </div>
                      </div>

                      {/* Timeline Bar */}
                      <div className="flex-1 relative h-8">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div
                              className="absolute top-1 h-6 rounded cursor-pointer"
                              style={{
                                left: `${startPos}%`,
                                width: `${width}%`,
                              }}
                            >
                              <div className={`h-full rounded ${getPhaseColor(task.phase)} opacity-20`}></div>
                              <div
                                className={`h-full rounded ${getPhaseColor(task.phase)}`}
                                style={{ width: `${task.progress}%` }}
                              ></div>
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <div className="text-xs">
                              <p className="font-medium">{task.name}</p>
                              <p>{format(task.startDate, "MMM dd")} - {format(task.endDate, "MMM dd")}</p>
                              <p>Progress: {task.progress}%</p>
                              <p>Resource: {task.resourceType.replace(/-/g, ' ')}</p>
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                    </div>
                  );
                })}

                {/* Milestones */}
                {chartMilestones.map((milestone) => {
                  const position = calculatePosition(milestone.date);
                  
                  return (
                    <div key={milestone.id} className="flex items-center" data-testid={`gantt-milestone-${milestone.id}`}>
                      <div className="w-64 pr-4 flex-shrink-0">
                        <div className="text-sm font-medium text-foreground">
                          {milestone.name}
                        </div>
                        <Badge variant="outline" className="text-xs mt-1">
                          Milestone
                        </Badge>
                      </div>

                      <div className="flex-1 relative h-8">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div
                              className="absolute top-0 w-0 h-8 border-l-2 border-primary cursor-pointer"
                              style={{ left: `${position}%` }}
                            >
                              <div className="absolute -top-1 -left-2 w-4 h-4 bg-primary rounded-full border-2 border-background"></div>
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <div className="text-xs">
                              <p className="font-medium">{milestone.name}</p>
                              <p>{format(milestone.date, "MMM dd, yyyy")}</p>
                              <p>Status: {milestone.status}</p>
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Legend */}
              <div className="mt-6 pt-4 border-t border-border">
                <div className="flex items-center gap-6 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-3 bg-primary rounded"></div>
                    <span>Completed</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-3 bg-primary opacity-20 rounded"></div>
                    <span>Planned</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 bg-primary rounded-full border-2 border-background"></div>
                    <span>Milestone</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
}
