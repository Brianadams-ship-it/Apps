import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { insertProgramSchema, type InsertProgram } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { CalendarIcon, X } from "lucide-react";
import { format } from "date-fns";
import { z } from "zod";

const programFormSchema = insertProgramSchema.extend({
  pdrDate: z.string().optional(),
  cdrDate: z.string().optional(),
  trrDate: z.string().optional(),
  qualDate: z.string().optional(),
  productionDate: z.string().optional(),
});

type ProgramFormData = z.infer<typeof programFormSchema>;

interface ProgramFormProps {
  onClose: () => void;
}

export default function ProgramForm({ onClose }: ProgramFormProps) {
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [durationMultiplier, setDurationMultiplier] = useState([1.0]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<ProgramFormData>({
    resolver: zodResolver(programFormSchema),
    defaultValues: {
      name: "",
      programId: "",
      description: "",
      phase: "PDR",
      totalBudget: "0",
      designAssemblies: 0,
      verificationUnits: 0,
      qualificationUnits: 0,
      cdrlsCount: 0,
      drawingsCount: 0,
      costPerUnit: "0",
      complexityMultiplier: "1.0",
      durationMultiplier: "1.0",
      status: "active",
    },
  });

  const createProgramMutation = useMutation({
    mutationFn: async (data: ProgramFormData) => {
      const response = await apiRequest("POST", "/api/programs", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/programs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      toast({
        title: "Success",
        description: "Program created successfully",
      });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create program",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ProgramFormData) => {
    // Update duration multiplier from slider
    data.durationMultiplier = durationMultiplier[0].toString();
    createProgramMutation.mutate(data);
  };

  const handlePreview = () => {
    setIsPreviewMode(true);
    // Here you could potentially call a preview API endpoint
    toast({
      title: "Schedule Preview",
      description: "Schedule generated based on current inputs. Review and adjust as needed.",
    });
  };

  const generateProgramId = () => {
    const name = form.getValues("name");
    if (name) {
      const prefix = name.substring(0, 3).toUpperCase();
      const year = new Date().getFullYear();
      const random = Math.floor(Math.random() * 999) + 1;
      const id = `${prefix}-${year}-${random.toString().padStart(3, '0')}`;
      form.setValue("programId", id);
    }
  };

  return (
    <div className="max-w-4xl mx-auto" data-testid="program-form">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Create New Program</h3>
          <p className="text-sm text-muted-foreground">Set up a new program with automatic WBS generation</p>
        </div>
        <Button variant="ghost" size="sm" onClick={onClose} data-testid="button-close">
          <X className="h-4 w-4" />
        </Button>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Basic Program Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Program Name</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter program name" 
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                          if (!form.getValues("programId")) {
                            generateProgramId();
                          }
                        }}
                        data-testid="input-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="programId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Program ID</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Auto-generated" 
                        {...field}
                        data-testid="input-program-id"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="md:col-span-2">
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Program description (optional)" 
                          {...field}
                          value={field.value || ""}
                          data-testid="input-description"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="totalBudget"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Total Budget ($)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="0" 
                        {...field}
                        data-testid="input-total-budget"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="costPerUnit"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cost per Unit ($)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="0" 
                        {...field}
                        data-testid="input-cost-per-unit"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Milestone Target Dates */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Milestone Target Dates</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <FormField
                control={form.control}
                name="pdrDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>PDR</FormLabel>
                    <FormControl>
                      <Input 
                        type="date" 
                        {...field}
                        data-testid="input-pdr-date"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="cdrDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>CDR</FormLabel>
                    <FormControl>
                      <Input 
                        type="date" 
                        {...field}
                        data-testid="input-cdr-date"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="trrDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>TRR</FormLabel>
                    <FormControl>
                      <Input 
                        type="date" 
                        {...field}
                        data-testid="input-trr-date"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="qualDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>QUAL</FormLabel>
                    <FormControl>
                      <Input 
                        type="date" 
                        {...field}
                        data-testid="input-qual-date"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="productionDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>PRODUCTION</FormLabel>
                    <FormControl>
                      <Input 
                        type="date" 
                        {...field}
                        data-testid="input-production-date"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Work Breakdown Structure */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Work Breakdown Structure</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <FormField
                control={form.control}
                name="designAssemblies"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Design Assemblies/Packages</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="0" 
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        data-testid="input-design-assemblies"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="verificationUnits"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Verification Units</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="0" 
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        data-testid="input-verification-units"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="qualificationUnits"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Qualification Units</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="0" 
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        data-testid="input-qualification-units"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="cdrlsCount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>CDRLs Count</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="0" 
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        data-testid="input-cdrls-count"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="drawingsCount"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Number of Drawings</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="0" 
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        data-testid="input-drawings-count"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Complexity & Duration Multipliers */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Complexity & Duration Multipliers</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="complexityMultiplier"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Complexity Level</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger data-testid="select-complexity">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="0.8">Low (0.8x)</SelectItem>
                        <SelectItem value="1.0">Medium (1.0x)</SelectItem>
                        <SelectItem value="1.3">High (1.3x)</SelectItem>
                        <SelectItem value="1.6">Very High (1.6x)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div>
                <Label>Duration Multiplier: {durationMultiplier[0].toFixed(1)}x</Label>
                <div className="mt-2">
                  <Slider
                    value={durationMultiplier}
                    onValueChange={setDurationMultiplier}
                    min={0.5}
                    max={2.0}
                    step={0.1}
                    className="w-full"
                    data-testid="slider-duration"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>0.5x</span>
                    <span>1.0x</span>
                    <span>2.0x</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Form Actions */}
          <div className="flex items-center justify-end space-x-4 pt-6 border-t border-border">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button 
              type="button" 
              variant="secondary" 
              onClick={handlePreview}
              data-testid="button-preview"
            >
              Preview Schedule
            </Button>
            <Button 
              type="submit" 
              disabled={createProgramMutation.isPending}
              data-testid="button-create"
            >
              {createProgramMutation.isPending ? "Creating..." : "Create Program"}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
