import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";

interface BudgetChartProps {
  data: any[];
  isLoading: boolean;
}

export default function BudgetChart({ data, isLoading }: BudgetChartProps) {
  if (isLoading) {
    return (
      <Card data-testid="budget-chart-loading">
        <CardHeader>
          <CardTitle>Budget Burndown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
            <Skeleton className="h-24 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  // Calculate totals from data
  const totalBudgetITD = data.reduce((sum, item) => sum + (parseFloat(item.budgetSpent || 0)), 0);
  const totalBudget = data.reduce((sum, item) => sum + (parseFloat(item.totalBudget || 0)), 0);
  const totalLabor = data.reduce((sum, item) => sum + (parseFloat(item.laborCosts || 0)), 0);
  const totalMaterials = data.reduce((sum, item) => sum + (parseFloat(item.materialCosts || 0)), 0);
  const totalOther = data.reduce((sum, item) => sum + (parseFloat(item.otherCosts || 0)), 0);

  // Calculate EAC and ETC (simplified calculation)
  const eac = totalBudget > 0 ? totalBudget * 1.1 : 0; // Assume 10% overrun for demo
  const etc = Math.max(0, eac - totalBudgetITD);
  const monthlyBurn = totalBudgetITD > 0 ? totalBudgetITD / 12 : 0; // Assuming year-long project

  return (
    <Card data-testid="budget-chart">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Budget Burndown</CardTitle>
          <Select defaultValue="all">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Programs</SelectItem>
              {data.map((program, index) => (
                <SelectItem key={index} value={program.programId}>
                  {program.programName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div data-testid="budget-itd">
              <p className="text-2xl font-bold text-foreground">
                ${(totalBudgetITD / 1000000).toFixed(1)}M
              </p>
              <p className="text-xs text-muted-foreground">Budget ITD</p>
            </div>
            <div data-testid="budget-eac">
              <p className="text-2xl font-bold text-yellow-600">
                ${(eac / 1000000).toFixed(1)}M
              </p>
              <p className="text-xs text-muted-foreground">EAC</p>
            </div>
            <div data-testid="budget-etc">
              <p className="text-2xl font-bold text-blue-600">
                ${(etc / 1000000).toFixed(1)}M
              </p>
              <p className="text-xs text-muted-foreground">ETC</p>
            </div>
          </div>
          
          <div className="pt-4 border-t border-border">
            <div className="flex justify-between text-sm mb-2">
              <span>Monthly Burn Rate</span>
              <span className="font-medium">
                ${(monthlyBurn / 1000000).toFixed(1)}M
              </span>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span>Labor</span>
                <span>
                  ${(totalLabor / 1000).toFixed(0)}K ({totalBudgetITD > 0 ? Math.round((totalLabor / totalBudgetITD) * 100) : 0}%)
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span>Materials</span>
                <span>
                  ${(totalMaterials / 1000).toFixed(0)}K ({totalBudgetITD > 0 ? Math.round((totalMaterials / totalBudgetITD) * 100) : 0}%)
                </span>
              </div>
              <div className="flex justify-between text-xs">
                <span>Other Expenses</span>
                <span>
                  ${(totalOther / 1000).toFixed(0)}K ({totalBudgetITD > 0 ? Math.round((totalOther / totalBudgetITD) * 100) : 0}%)
                </span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
