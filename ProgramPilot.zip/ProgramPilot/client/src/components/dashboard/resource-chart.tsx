import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";

interface ResourceChartProps {
  data: any[];
  isLoading: boolean;
}

export default function ResourceChart({ data, isLoading }: ResourceChartProps) {
  if (isLoading) {
    return (
      <Card data-testid="resource-chart-loading">
        <CardHeader>
          <CardTitle>Resource Load vs Capacity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getUtilizationColor = (percentage: number) => {
    if (percentage >= 100) return "bg-red-500";
    if (percentage >= 90) return "bg-yellow-500";
    if (percentage >= 80) return "bg-blue-500";
    return "bg-green-500";
  };

  const formatResourceType = (type: string) => {
    return type.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  return (
    <Card data-testid="resource-chart">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Resource Load vs Capacity</CardTitle>
          <Select defaultValue="month">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">Next 3 Months</SelectItem>
              <SelectItem value="year">This Quarter</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {data.length > 0 ? (
            data.map((resource, index) => (
              <div key={index} data-testid={`resource-item-${index}`}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">
                    {formatResourceType(resource.resourceType)}
                  </span>
                  <span className="text-muted-foreground">
                    {resource.allocatedHours}/{resource.totalCapacity} ({resource.utilizationPercentage}%)
                  </span>
                </div>
                <Progress 
                  value={resource.utilizationPercentage} 
                  className="h-3"
                  data-testid={`progress-${index}`}
                />
              </div>
            ))
          ) : (
            <div className="space-y-4">
              {/* Default resource types when no data */}
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">Software Engineers</span>
                  <span className="text-muted-foreground">12/15 (80%)</span>
                </div>
                <div className="w-full bg-muted rounded-full h-3">
                  <div className="bg-blue-500 h-3 rounded-full" style={{ width: "80%" }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">Hardware Engineers</span>
                  <span className="text-muted-foreground">18/20 (90%)</span>
                </div>
                <div className="w-full bg-muted rounded-full h-3">
                  <div className="bg-yellow-500 h-3 rounded-full" style={{ width: "90%" }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">Test Engineers</span>
                  <span className="text-muted-foreground">8/12 (67%)</span>
                </div>
                <div className="w-full bg-muted rounded-full h-3">
                  <div className="bg-green-500 h-3 rounded-full" style={{ width: "67%" }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">Project Managers</span>
                  <span className="text-muted-foreground">6/6 (100%)</span>
                </div>
                <div className="w-full bg-muted rounded-full h-3">
                  <div className="bg-red-500 h-3 rounded-full" style={{ width: "100%" }}></div>
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
