import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const menuItems = [
  { icon: "fas fa-tachometer-alt", label: "Dashboard", href: "/" },
  { icon: "fas fa-crown", label: "Executive", href: "/executive" },
  { icon: "fas fa-project-diagram", label: "Programs", href: "/programs" },
  { icon: "fas fa-calendar-alt", label: "Schedule", href: "/schedule" },
  { icon: "fas fa-users", label: "Resources", href: "/resources" },
  { icon: "fas fa-cogs", label: "Optimization", href: "/optimization" },
  { icon: "fas fa-dollar-sign", label: "Budget", href: "/budget" },
  { icon: "fas fa-chart-bar", label: "Reports", href: "/reports" },
  { icon: "fas fa-sliders-h", label: "Settings", href: "/settings" },
];

export default function Sidebar() {
  const [activeItem, setActiveItem] = useState("Dashboard");
  const [, setLocation] = useLocation();

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col" data-testid="sidebar">
      <div className="p-6 border-b border-border">
        <h1 className="text-xl font-semibold text-foreground">Program Dashboard</h1>
        <p className="text-sm text-muted-foreground mt-1">Department Management</p>
      </div>
      
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => (
            <li key={item.label}>
              <Button
                variant="ghost"
                className={cn(
                  "w-full justify-start px-3 py-2 text-sm font-medium rounded-md",
                  activeItem === item.label
                    ? "text-primary-foreground bg-primary"
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                )}
                onClick={() => {
                  setActiveItem(item.label);
                  setLocation(item.href);
                }}
                data-testid={`nav-${item.label.toLowerCase()}`}
              >
                <i className={`${item.icon} mr-3`}></i>
                {item.label}
              </Button>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
}
