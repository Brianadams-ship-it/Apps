import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface MetricsCardsProps {
  metrics: any;
  isLoading: boolean;
}

export default function MetricsCards({ metrics, isLoading }: MetricsCardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <Skeleton className="h-16 w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Active Programs",
      value: metrics?.activePrograms || 0,
      icon: "fas fa-project-diagram",
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
      trend: "+12%",
      trendText: "from last month",
      trendIcon: "fas fa-arrow-up",
      trendColor: "text-green-600"
    },
    {
      title: "Total Budget",
      value: `$${((metrics?.totalBudget || 0) / 1000000).toFixed(1)}M`,
      icon: "fas fa-dollar-sign",
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
      trend: "8%",
      trendText: "budget utilization",
      trendIcon: "fas fa-arrow-up",
      trendColor: "text-blue-600"
    },
    {
      title: "Resource Load",
      value: "87%",
      icon: "fas fa-users",
      iconBg: "bg-yellow-100",
      iconColor: "text-yellow-600",
      trend: "",
      trendText: "Near capacity",
      trendIcon: "fas fa-exclamation-triangle",
      trendColor: "text-yellow-600"
    },
    {
      title: "On Schedule",
      value: `${metrics?.onSchedulePrograms || 0}/${metrics?.activePrograms || 0}`,
      icon: "fas fa-clock",
      iconBg: "bg-red-100",
      iconColor: "text-red-600",
      trend: "",
      trendText: `${(metrics?.activePrograms || 0) - (metrics?.onSchedulePrograms || 0)} programs at risk`,
      trendIcon: "fas fa-arrow-down",
      trendColor: "text-red-600"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8" data-testid="metrics-cards">
      {cards.map((card, index) => (
        <Card key={index} data-testid={`metric-card-${index}`}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
                <p className="text-3xl font-bold text-foreground" data-testid={`metric-value-${index}`}>
                  {card.value}
                </p>
              </div>
              <div className={`w-12 h-12 ${card.iconBg} rounded-lg flex items-center justify-center`}>
                <i className={`${card.icon} ${card.iconColor}`}></i>
              </div>
            </div>
            <p className={`text-sm ${card.trendColor} mt-2`}>
              <i className={`${card.trendIcon} mr-1`}></i>
              {card.trend} {card.trendText}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
