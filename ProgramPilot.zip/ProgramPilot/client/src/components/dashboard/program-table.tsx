import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";

interface ProgramTableProps {
  programs: any[];
  isLoading: boolean;
  searchTerm: string;
  onSearchChange: (value: string) => void;
  phaseFilter: string;
  onPhaseFilterChange: (value: string) => void;
}

export default function ProgramTable({ 
  programs, 
  isLoading, 
  searchTerm, 
  onSearchChange, 
  phaseFilter, 
  onPhaseFilterChange 
}: ProgramTableProps) {
  const [, setLocation] = useLocation();

  const getPhaseColor = (phase: string) => {
    const colors: Record<string, string> = {
      PDR: "bg-blue-100 text-blue-800",
      CDR: "bg-green-100 text-green-800",
      TRR: "bg-yellow-100 text-yellow-800",
      QUAL: "bg-orange-100 text-orange-800",
      PRODUCTION: "bg-red-100 text-red-800",
    };
    return colors[phase] || "bg-gray-100 text-gray-800";
  };

  const getBudgetColor = (percentage: number) => {
    if (percentage > 100) return "progress-red";
    if (percentage > 80) return "progress-yellow";
    return "progress-green";
  };

  const getScheduleColor = (percentage: number) => {
    if (percentage < 25) return "progress-red";
    if (percentage < 65) return "progress-yellow";
    return "progress-green";
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Skeleton className="h-10 w-64" />
            <Skeleton className="h-10 w-32" />
          </div>
          <div className="flex items-center space-x-2">
            <Skeleton className="h-10 w-10" />
            <Skeleton className="h-10 w-10" />
          </div>
        </div>
        <div className="space-y-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4" data-testid="program-table">
      {/* Filters */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Input
            type="text"
            placeholder="Search programs..."
            value={searchTerm}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-64"
            data-testid="input-search"
          />
          <Select value={phaseFilter} onValueChange={onPhaseFilterChange}>
            <SelectTrigger className="w-32" data-testid="select-phase-filter">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Phases</SelectItem>
              <SelectItem value="PDR">PDR</SelectItem>
              <SelectItem value="CDR">CDR</SelectItem>
              <SelectItem value="TRR">TRR</SelectItem>
              <SelectItem value="QUAL">QUAL</SelectItem>
              <SelectItem value="PRODUCTION">PRODUCTION</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" data-testid="button-filter">
            <i className="fas fa-filter"></i>
          </Button>
          <Button variant="outline" size="sm" data-testid="button-export">
            <i className="fas fa-download"></i>
          </Button>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border">
              <th className="text-left py-3 px-4 font-medium text-muted-foreground">Program</th>
              <th className="text-left py-3 px-4 font-medium text-muted-foreground">Phase</th>
              <th className="text-left py-3 px-4 font-medium text-muted-foreground">Schedule</th>
              <th className="text-left py-3 px-4 font-medium text-muted-foreground">Budget Status</th>
              <th className="text-left py-3 px-4 font-medium text-muted-foreground">Resources</th>
              <th className="text-left py-3 px-4 font-medium text-muted-foreground">Next Milestone</th>
              <th className="text-left py-3 px-4 font-medium text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {programs.map((program) => {
              const budgetPercentage = program.totalBudget > 0 
                ? Math.round((parseFloat(program.budgetSpent || 0) / parseFloat(program.totalBudget)) * 100)
                : 0;
              
              // Mock schedule progress - in real implementation this would be calculated from WBS
              const scheduleProgress = Math.floor(Math.random() * 100);

              return (
                <tr 
                  key={program.id} 
                  className="border-b border-border hover:bg-muted/50 cursor-pointer"
                  onClick={() => setLocation(`/programs/${program.id}`)}
                  data-testid={`program-row-${program.id}`}
                >
                  <td className="py-3 px-4">
                    <div>
                      <p className="font-medium text-foreground">{program.name}</p>
                      <p className="text-xs text-muted-foreground">{program.programId}</p>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <Badge className={getPhaseColor(program.phase)}>
                      {program.phase}
                    </Badge>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-24 bg-muted rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${getScheduleColor(scheduleProgress)}`}
                          style={{ width: `${Math.min(100, scheduleProgress)}%` }}
                        ></div>
                      </div>
                      <span className="text-xs text-muted-foreground">{scheduleProgress}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>
                          ${parseFloat(program.budgetSpent || 0).toLocaleString()} / ${parseFloat(program.totalBudget || 0).toLocaleString()}
                        </span>
                        <span className={budgetPercentage > 100 ? "text-red-600" : budgetPercentage > 80 ? "text-yellow-600" : "text-green-600"}>
                          {budgetPercentage}%
                        </span>
                      </div>
                      <div className="w-24 bg-muted rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${getBudgetColor(budgetPercentage)}`}
                          style={{ width: `${Math.min(100, budgetPercentage)}%` }}
                        ></div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex -space-x-1">
                      {/* Mock resource avatars */}
                      <Avatar className="w-6 h-6 border-2 border-white">
                        <AvatarFallback className="bg-blue-500 text-white text-xs">J</AvatarFallback>
                      </Avatar>
                      <Avatar className="w-6 h-6 border-2 border-white">
                        <AvatarFallback className="bg-green-500 text-white text-xs">M</AvatarFallback>
                      </Avatar>
                      <Avatar className="w-6 h-6 border-2 border-white">
                        <AvatarFallback className="bg-yellow-500 text-white text-xs">+3</AvatarFallback>
                      </Avatar>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div>
                      <p className="text-sm font-medium">Next Review</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(Date.now() + Math.random() * 90 * 24 * 60 * 60 * 1000).toLocaleDateString()}
                      </p>
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          // Handle edit
                        }}
                        data-testid={`button-edit-${program.id}`}
                      >
                        <i className="fas fa-edit text-xs"></i>
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          setLocation(`/programs/${program.id}`);
                        }}
                        data-testid={`button-view-${program.id}`}
                      >
                        <i className="fas fa-eye text-xs"></i>
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          // Handle more options
                        }}
                        data-testid={`button-options-${program.id}`}
                      >
                        <i className="fas fa-ellipsis-v text-xs"></i>
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
