import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, CheckCircle, Clock, Users, TrendingUp } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface ResourceConflict {
  resourceId: string;
  resourceName: string;
  conflictDate: Date;
  overallocation: number;
  affectedPrograms: {
    programId: string;
    programName: string;
    allocatedHours: number;
    priority: number;
  }[];
  recommendations: OptimizationRecommendation[];
}

interface OptimizationRecommendation {
  type: 'reschedule' | 'reassign' | 'split_task' | 'add_resource';
  description: string;
  impact: {
    scheduleDelay: number;
    costIncrease: number;
    riskLevel: 'low' | 'medium' | 'high';
  };
  actionPlan: {
    action: string;
    targetResourceId?: string;
    newStartDate?: Date;
    newEndDate?: Date;
    additionalCost?: number;
  };
}

interface OptimizationSolution {
  totalConflicts: number;
  resolvedConflicts: number;
  overallUtilization: number;
  recommendations: OptimizationRecommendation[];
  implementationPlan: {
    phase: number;
    actions: OptimizationRecommendation[];
    timeline: string;
  }[];
}

export default function ResourceOptimization() {
  const { toast } = useToast();
  const [selectedConflicts, setSelectedConflicts] = useState<ResourceConflict[]>([]);
  const [activeTab, setActiveTab] = useState("conflicts");

  // Fetch current resource conflicts
  const { data: conflicts = [], isLoading: conflictsLoading } = useQuery<ResourceConflict[]>({
    queryKey: ["/api/optimization/conflicts"],
  });

  // Generate optimization solution
  const generateSolutionMutation = useMutation({
    mutationFn: async (conflicts: ResourceConflict[]) => {
      const response = await apiRequest("POST", "/api/optimization/generate-solution", { conflicts });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/optimization/conflicts"] });
    },
  });

  // Apply optimization recommendations
  const applyRecommendationsMutation = useMutation({
    mutationFn: async (recommendations: OptimizationRecommendation[]) => {
      const response = await apiRequest("POST", "/api/optimization/apply-recommendations", { recommendations });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/optimization/conflicts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/programs"] });
    },
  });

  const getRiskColor = (riskLevel: string) => {
    switch (riskLevel) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'reschedule': return <Clock className="h-4 w-4" />;
      case 'reassign': return <Users className="h-4 w-4" />;
      case 'add_resource': return <TrendingUp className="h-4 w-4" />;
      default: return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const handleGenerateSolution = async () => {
    const conflictsToOptimize = selectedConflicts.length > 0 ? selectedConflicts : conflicts;
    await generateSolutionMutation.mutateAsync(conflictsToOptimize);
  };

  const handleApplyRecommendations = async (recommendations: OptimizationRecommendation[]) => {
    try {
      await applyRecommendationsMutation.mutateAsync(recommendations);
      toast({
        title: "Success",
        description: `Applied ${recommendations.length} optimization recommendation(s)`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to apply recommendations",
        variant: "destructive",
      });
    }
  };

  if (conflictsLoading) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Resource Optimization</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-20 w-full" />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const solution = generateSolutionMutation.data as OptimizationSolution;

  return (
    <div className="space-y-6" data-testid="resource-optimization">
      {/* Summary Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-orange-500" />
            Resource Optimization Center
          </CardTitle>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-red-600">{conflicts.length}</p>
              <p className="text-sm text-muted-foreground">Total Conflicts</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-orange-600">
                {conflicts.reduce((sum: number, c: any) => sum + c.overallocation, 0).toFixed(1)}h
              </p>
              <p className="text-sm text-muted-foreground">Overallocation</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">
                {solution?.resolvedConflicts || 0}
              </p>
              <p className="text-sm text-muted-foreground">Resolvable</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">
                {solution?.overallUtilization?.toFixed(1) || 0}%
              </p>
              <p className="text-sm text-muted-foreground">Utilization</p>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="conflicts">Resource Conflicts</TabsTrigger>
          <TabsTrigger value="recommendations">Optimization Plan</TabsTrigger>
          <TabsTrigger value="implementation">Implementation</TabsTrigger>
        </TabsList>

        {/* Conflicts Tab */}
        <TabsContent value="conflicts" className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Resource Conflicts</h3>
            <Button 
              onClick={handleGenerateSolution}
              disabled={generateSolutionMutation.isPending}
              data-testid="button-generate-solution"
            >
              {generateSolutionMutation.isPending ? "Generating..." : "Generate Solution"}
            </Button>
          </div>

          {conflicts.length === 0 ? (
            <Alert>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                No resource conflicts detected. All resources are optimally allocated.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-4">
              {conflicts.map((conflict: ResourceConflict, index: number) => (
                <Card key={index} data-testid={`conflict-${index}`}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-semibold">{conflict.resourceName}</h4>
                          <Badge variant="destructive">
                            +{conflict.overallocation.toFixed(1)}h overallocated
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">
                          Conflict on {new Date(conflict.conflictDate).toLocaleDateString()}
                        </p>
                        
                        <div className="mb-4">
                          <h5 className="font-medium mb-2">Affected Programs:</h5>
                          <div className="space-y-1">
                            {conflict.affectedPrograms.map((program, pIndex) => (
                              <div key={pIndex} className="flex items-center justify-between text-sm">
                                <span>{program.programName}</span>
                                <div className="flex items-center gap-2">
                                  <span>{program.allocatedHours}h</span>
                                  <Badge variant="outline" className="text-xs">
                                    Priority: {program.priority.toFixed(1)}
                                  </Badge>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div>
                          <h5 className="font-medium mb-2">Top Recommendations:</h5>
                          <div className="space-y-2">
                            {conflict.recommendations.slice(0, 2).map((rec, rIndex) => (
                              <div key={rIndex} className="flex items-center gap-2 text-sm">
                                {getTypeIcon(rec.type)}
                                <span className="flex-1">{rec.description}</span>
                                <Badge className={getRiskColor(rec.impact.riskLevel)}>
                                  {rec.impact.riskLevel}
                                </Badge>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      <div className="ml-4">
                        <input
                          type="checkbox"
                          checked={selectedConflicts.includes(conflict)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedConflicts([...selectedConflicts, conflict]);
                            } else {
                              setSelectedConflicts(selectedConflicts.filter(c => c !== conflict));
                            }
                          }}
                          className="h-4 w-4"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Recommendations Tab */}
        <TabsContent value="recommendations" className="space-y-4">
          {!solution ? (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Generate an optimization solution to view recommendations.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Optimization Recommendations</h3>
                <Button 
                  onClick={() => handleApplyRecommendations(solution.recommendations)}
                  disabled={applyRecommendationsMutation.isPending}
                  data-testid="button-apply-recommendations"
                >
                  {applyRecommendationsMutation.isPending ? "Applying..." : "Apply All"}
                </Button>
              </div>

              <div className="grid gap-4">
                {solution.recommendations.map((recommendation, index) => (
                  <Card key={index} data-testid={`recommendation-${index}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0">
                          {getTypeIcon(recommendation.type)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h4 className="font-semibold capitalize">{recommendation.type.replace('_', ' ')}</h4>
                            <Badge className={getRiskColor(recommendation.impact.riskLevel)}>
                              {recommendation.impact.riskLevel} risk
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">
                            {recommendation.description}
                          </p>
                          
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="font-medium">Schedule Impact:</span>
                              <p>{recommendation.impact.scheduleDelay} days delay</p>
                            </div>
                            <div>
                              <span className="font-medium">Cost Impact:</span>
                              <p>${recommendation.impact.costIncrease.toLocaleString()}</p>
                            </div>
                            <div>
                              <span className="font-medium">Action:</span>
                              <p>{recommendation.actionPlan.action}</p>
                            </div>
                          </div>
                        </div>
                        
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleApplyRecommendations([recommendation])}
                          data-testid={`button-apply-${index}`}
                        >
                          Apply
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </TabsContent>

        {/* Implementation Tab */}
        <TabsContent value="implementation" className="space-y-4">
          {!solution?.implementationPlan ? (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Generate an optimization solution to view the implementation plan.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">Implementation Plan</h3>
                <Button 
                  onClick={() => handleApplyRecommendations(solution.recommendations)}
                  disabled={applyRecommendationsMutation.isPending}
                  data-testid="button-apply-recommendations"
                >
                  {applyRecommendationsMutation.isPending ? "Applying..." : "Apply Implementation Plan"}
                </Button>
              </div>
              
              {solution.implementationPlan.map((phase, index) => (
                <Card key={index} data-testid={`phase-${index}`}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <span>Phase {phase.phase}</span>
                      <Badge variant="outline">{phase.timeline}</Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {phase.actions.map((action, aIndex) => (
                        <div key={aIndex} className="flex items-center gap-3 p-3 border rounded-lg">
                          {getTypeIcon(action.type)}
                          <div className="flex-1">
                            <p className="font-medium">{action.description}</p>
                            <p className="text-sm text-muted-foreground">{action.actionPlan.action}</p>
                          </div>
                          <Badge className={getRiskColor(action.impact.riskLevel)}>
                            {action.impact.riskLevel}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}