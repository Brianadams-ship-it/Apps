import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Save, RotateCcw, Settings as SettingsIcon } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";

interface Setting {
  id: string;
  key: string;
  value: string;
  description: string;
  category: string;
  dataType: string;
  updatedAt: string;
}

export default function Settings() {
  const { toast } = useToast();
  const [editingValues, setEditingValues] = useState<Record<string, string>>({});

  const { data: settings = [], isLoading } = useQuery<Setting[]>({
    queryKey: ["/api/settings"],
  });

  const updateSettingMutation = useMutation({
    mutationFn: (setting: Partial<Setting>) => 
      apiRequest("PUT", "/api/settings", setting),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      setEditingValues({});
      toast({ title: "Settings saved", description: "Your settings have been updated successfully" });
    },
    onError: (error: any) => {
      toast({ 
        title: "Save failed", 
        description: error.message || "Failed to save settings",
        variant: "destructive"
      });
    },
  });

  const handleValueChange = (key: string, value: string) => {
    setEditingValues(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const getCurrentValue = (setting: Setting) => {
    return editingValues[setting.key] !== undefined ? editingValues[setting.key] : setting.value;
  };

  const hasUnsavedChanges = (setting: Setting) => {
    return editingValues[setting.key] !== undefined && editingValues[setting.key] !== setting.value;
  };

  const saveSetting = (setting: Setting) => {
    let newValue = getCurrentValue(setting);
    
    // Convert numeric values to numbers for proper validation
    if (setting.dataType === 'number') {
      const numValue = parseFloat(newValue);
      if (isNaN(numValue)) {
        toast({ 
          title: "Invalid value", 
          description: "Please enter a valid number",
          variant: "destructive"
        });
        return;
      }
      // Send as string but ensure it's a valid number
      newValue = numValue.toString();
    }
    
    updateSettingMutation.mutate({
      key: setting.key,
      value: newValue,
      description: setting.description,
      category: setting.category,
      dataType: setting.dataType
    });
  };

  const resetSetting = (setting: Setting) => {
    setEditingValues(prev => {
      const { [setting.key]: removed, ...rest } = prev;
      return rest;
    });
  };

  const groupedSettings = settings.reduce((acc, setting) => {
    if (!acc[setting.category]) {
      acc[setting.category] = [];
    }
    acc[setting.category].push(setting);
    return acc;
  }, {} as Record<string, Setting[]>);

  if (isLoading) {
    return (
      <div className="flex h-screen bg-background">
        <Sidebar />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Header />
          <main className="flex-1 overflow-auto p-6">
            <div className="flex items-center justify-center py-8">
              <div className="text-center">
                <SettingsIcon className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
                <p className="text-muted-foreground">Loading settings...</p>
              </div>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background" data-testid="settings-container">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-auto p-6">
          <div className="max-w-4xl mx-auto space-y-8">
            {/* Page Header */}
            <div>
              <h1 className="text-3xl font-bold text-foreground">Settings</h1>
              <p className="text-muted-foreground mt-2">
                Configure overhead cost calculations and system preferences
              </p>
            </div>

            {/* Settings Categories */}
            {Object.entries(groupedSettings).map(([category, categorySettings]) => (
              <Card key={category} data-testid={`card-settings-${category}`}>
                <CardHeader>
                  <CardTitle className="capitalize flex items-center gap-2">
                    <SettingsIcon className="h-5 w-5" />
                    {category} Settings
                  </CardTitle>
                  <CardDescription>
                    {category === 'overhead' 
                      ? 'Configure multipliers for cost calculations and overhead rates'
                      : `Manage ${category} configuration options`
                    }
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {categorySettings.map((setting) => (
                    <div 
                      key={setting.key} 
                      className="space-y-2 p-4 border border-border rounded-lg bg-muted/30"
                      data-testid={`setting-${setting.key}`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <Label htmlFor={setting.key} className="font-medium">
                            {setting.key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                          </Label>
                          <p className="text-sm text-muted-foreground">
                            {setting.description}
                          </p>
                        </div>
                        <Badge variant="secondary" className="ml-4">
                          {setting.dataType}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        <div className="flex-1">
                          <Input
                            id={setting.key}
                            type={setting.dataType === 'number' ? 'number' : 'text'}
                            step={setting.dataType === 'number' ? '0.1' : undefined}
                            value={getCurrentValue(setting)}
                            onChange={(e) => handleValueChange(setting.key, e.target.value)}
                            placeholder={`Enter ${setting.dataType} value`}
                            data-testid={`input-${setting.key}`}
                            className={hasUnsavedChanges(setting) ? 'border-orange-500' : ''}
                          />
                        </div>
                        
                        <div className="flex items-center gap-2">
                          {hasUnsavedChanges(setting) && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => resetSetting(setting)}
                              data-testid={`button-reset-${setting.key}`}
                            >
                              <RotateCcw className="h-4 w-4" />
                            </Button>
                          )}
                          <Button
                            variant={hasUnsavedChanges(setting) ? "default" : "outline"}
                            size="sm"
                            onClick={() => saveSetting(setting)}
                            disabled={updateSettingMutation.isPending || !hasUnsavedChanges(setting)}
                            data-testid={`button-save-${setting.key}`}
                          >
                            <Save className="h-4 w-4 mr-1" />
                            {updateSettingMutation.isPending ? "Saving..." : "Save"}
                          </Button>
                        </div>
                      </div>
                      
                      <div className="text-xs text-muted-foreground">
                        Last updated: {new Date(setting.updatedAt).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}

            {/* Help Section */}
            <Card data-testid="card-settings-help">
              <CardHeader>
                <CardTitle>Overhead Calculation Information</CardTitle>
                <CardDescription>
                  Understanding how these settings affect your cost calculations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium text-foreground mb-2">Burdened Labor Multiplier</h4>
                  <p className="text-sm text-muted-foreground mb-1">
                    Applied to unburdened labor costs to account for benefits, overhead, and indirect costs.
                  </p>
                  <p className="text-sm font-mono bg-muted px-2 py-1 rounded">
                    Burdened Labor Cost = Unburdened Labor Cost × {getCurrentValue(
                      settings.find(s => s.key === 'burdened_labor_multiplier') || { value: '3.8' } as Setting
                    )}
                  </p>
                </div>
                
                <div>
                  <h4 className="font-medium text-foreground mb-2">Burdened Expenses Multiplier</h4>
                  <p className="text-sm text-muted-foreground mb-1">
                    Applied to unburdened expenses for overhead allocation and indirect costs.
                  </p>
                  <p className="text-sm font-mono bg-muted px-2 py-1 rounded">
                    Burdened Expenses = Unburdened Expenses × {getCurrentValue(
                      settings.find(s => s.key === 'burdened_expenses_multiplier') || { value: '1.4' } as Setting
                    )}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}