import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";
import MetricsCards from "@/components/dashboard/metrics-cards";
import ProgramTable from "@/components/dashboard/program-table";
import ResourceChart from "@/components/dashboard/resource-chart";
import BudgetChart from "@/components/dashboard/budget-chart";
import ProgramForm from "@/components/program/program-form";
import SyncControls from "@/components/sync-controls";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent } from "@/components/ui/dialog";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [showProgramForm, setShowProgramForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [phaseFilter, setPhaseFilter] = useState("all");

  const { data: programs = [], isLoading: programsLoading } = useQuery({
    queryKey: ["/api/programs"],
  });

  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
  });

  const { data: resourceUtilization = [], isLoading: resourceLoading } = useQuery({
    queryKey: ["/api/dashboard/resource-utilization"],
  });

  const { data: budgetSummary = [], isLoading: budgetLoading } = useQuery({
    queryKey: ["/api/dashboard/budget-summary"],
  });

  const filteredPrograms = (programs as any[]).filter((program: any) => {
    const matchesSearch = program.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         program.programId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPhase = phaseFilter === "all" || program.phase === phaseFilter;
    return matchesSearch && matchesPhase;
  });

  return (
    <div className="flex h-screen bg-background" data-testid="dashboard-container">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header onNewProgram={() => setShowProgramForm(true)} />
        
        <main className="flex-1 overflow-auto p-6">
          {/* Key Metrics */}
          <MetricsCards metrics={metrics} isLoading={metricsLoading} />
          
          {/* Main Content Tabs */}
          <div className="bg-card rounded-lg border border-border mt-8">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <div className="border-b border-border">
                <TabsList className="grid w-full grid-cols-4 bg-transparent h-auto p-0">
                  <TabsTrigger 
                    value="overview" 
                    className="border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary py-4 px-6 text-sm font-medium rounded-none bg-transparent"
                    data-testid="tab-overview"
                  >
                    Program Overview
                  </TabsTrigger>
                  <TabsTrigger 
                    value="schedule" 
                    className="border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary py-4 px-6 text-sm font-medium rounded-none bg-transparent"
                    data-testid="tab-schedule"
                  >
                    Schedule View
                  </TabsTrigger>
                  <TabsTrigger 
                    value="budget" 
                    className="border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary py-4 px-6 text-sm font-medium rounded-none bg-transparent"
                    data-testid="tab-budget"
                  >
                    Budget Analysis
                  </TabsTrigger>
                  <TabsTrigger 
                    value="resources" 
                    className="border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:text-primary py-4 px-6 text-sm font-medium rounded-none bg-transparent"
                    data-testid="tab-resources"
                  >
                    Resource Planning
                  </TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="overview" className="p-6 m-0">
                <ProgramTable 
                  programs={filteredPrograms}
                  isLoading={programsLoading}
                  searchTerm={searchTerm}
                  onSearchChange={setSearchTerm}
                  phaseFilter={phaseFilter}
                  onPhaseFilterChange={setPhaseFilter}
                />
              </TabsContent>

              <TabsContent value="schedule" className="p-6 m-0">
                <div className="text-center py-8">
                  <h3 className="text-lg font-semibold text-foreground mb-2">Schedule View</h3>
                  <p className="text-muted-foreground">Gantt chart and timeline view coming soon</p>
                </div>
              </TabsContent>

              <TabsContent value="budget" className="p-6 m-0">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <BudgetChart data={budgetSummary as any[]} isLoading={budgetLoading} />
                  <div className="bg-muted rounded-lg p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Budget Details</h3>
                    <div className="space-y-4">
                      {(budgetSummary as any[]).map((item: any, index: number) => (
                        <div key={index} className="flex justify-between items-center">
                          <span className="font-medium">{item.programName}</span>
                          <span className="text-muted-foreground">
                            ${parseFloat(item.budgetSpent || 0).toLocaleString()} / ${parseFloat(item.totalBudget || 0).toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="resources" className="p-6 m-0">
                <ResourceChart data={resourceUtilization as any[]} isLoading={resourceLoading} />
              </TabsContent>
            </Tabs>
          </div>

          {/* Bottom Charts and Sync Controls */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
            <ResourceChart data={resourceUtilization as any[]} isLoading={resourceLoading} />
            <BudgetChart data={budgetSummary as any[]} isLoading={budgetLoading} />
            <SyncControls />
          </div>
        </main>
      </div>

      {/* Program Creation Modal */}
      <Dialog open={showProgramForm} onOpenChange={setShowProgramForm}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <ProgramForm onClose={() => setShowProgramForm(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
