import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Clock, FileText, Download } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function ExecutiveDashboard() {
  const [activeTab, setActiveTab] = useState("health");
  const [reportType, setReportType] = useState("portfolio");
  const [period, setPeriod] = useState("6months");
  const [showReportModal, setShowReportModal] = useState(false);
  const [generatedReport, setGeneratedReport] = useState<any>(null);

  const { data: portfolioHealth, isLoading: healthLoading } = useQuery({
    queryKey: ["/api/executive/portfolio-health"],
  });

  const { data: scorecards = [], isLoading: scorecardsLoading } = useQuery({
    queryKey: ["/api/executive/performance-scorecards"],
  });

  const { data: trends, isLoading: trendsLoading } = useQuery({
    queryKey: ["/api/executive/trend-analysis", period],
    enabled: !!period,
  });

  const generateReportMutation = useMutation({
    mutationFn: (data: any) => apiRequest("/api/executive/generate-report", "POST", data),
    onSuccess: (report) => {
      setGeneratedReport(report);
      setShowReportModal(true);
      queryClient.invalidateQueries({ queryKey: ["/api/executive"] });
    },
  });

  const handleGenerateReport = () => {
    generateReportMutation.mutate({
      reportType,
      dateRange: period,
      includeCharts: true,
      programs: null
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'on-track': return 'bg-green-500';
      case 'at-risk': return 'bg-yellow-500';
      case 'delayed': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  return (
    <div className="min-h-screen bg-background p-6" data-testid="executive-dashboard">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-foreground" data-testid="title-executive-dashboard">
              Executive Dashboard
            </h1>
            <p className="text-muted-foreground mt-1">
              Portfolio health and performance analytics
            </p>
          </div>
          
          <div className="flex gap-4">
            <Select value={period} onValueChange={setPeriod}>
              <SelectTrigger className="w-[180px]" data-testid="select-period">
                <SelectValue placeholder="Select period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="3months">Last 3 Months</SelectItem>
                <SelectItem value="6months">Last 6 Months</SelectItem>
                <SelectItem value="12months">Last 12 Months</SelectItem>
              </SelectContent>
            </Select>

            <Dialog>
              <DialogTrigger asChild>
                <Button data-testid="button-generate-report">
                  <FileText className="w-4 h-4 mr-2" />
                  Generate Report
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Generate Executive Report</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Select value={reportType} onValueChange={setReportType}>
                    <SelectTrigger data-testid="select-report-type">
                      <SelectValue placeholder="Select report type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="portfolio">Portfolio Summary</SelectItem>
                      <SelectItem value="performance">Performance Report</SelectItem>
                      <SelectItem value="financial">Financial Analysis</SelectItem>
                      <SelectItem value="risk">Risk Assessment</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button 
                    onClick={handleGenerateReport}
                    disabled={generateReportMutation.isPending}
                    className="w-full"
                    data-testid="button-confirm-generate"
                  >
                    {generateReportMutation.isPending ? "Generating..." : "Generate Report"}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Portfolio Health Overview */}
        {portfolioHealth && (portfolioHealth as any).overallScore && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card data-testid="card-overall-score">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Overall Portfolio Score</CardTitle>
                <CheckCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-overall-score">
                  {(portfolioHealth as any).overallScore}/100
                </div>
                <Progress value={(portfolioHealth as any).overallScore} className="mt-2" />
              </CardContent>
            </Card>

            <Card data-testid="card-program-health">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Program Health</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600" data-testid="text-on-time-percentage">
                  {Math.round((portfolioHealth as any).programHealth.onTimePercentage)}%
                </div>
                <p className="text-xs text-muted-foreground">
                  {(portfolioHealth as any).programHealth.onTime} of {(portfolioHealth as any).programHealth.onTime + (portfolioHealth as any).programHealth.atRisk + (portfolioHealth as any).programHealth.delayed} on track
                </p>
              </CardContent>
            </Card>

            <Card data-testid="card-budget-efficiency">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Budget Efficiency</CardTitle>
                <TrendingDown className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-budget-efficiency">
                  {Math.round((portfolioHealth as any).budgetHealth.budgetEfficiency)}%
                </div>
                <p className="text-xs text-muted-foreground">
                  ${Math.round((portfolioHealth as any).budgetHealth.budgetSpent / 1000000)}M / ${Math.round((portfolioHealth as any).budgetHealth.totalBudget / 1000000)}M
                </p>
              </CardContent>
            </Card>

            <Card data-testid="card-risk-indicators">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Risk Indicators</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600" data-testid="text-high-risk-programs">
                  {(portfolioHealth as any).riskIndicators.highRiskPrograms}
                </div>
                <p className="text-xs text-muted-foreground">High risk programs</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="health" data-testid="tab-health">Portfolio Health</TabsTrigger>
            <TabsTrigger value="scorecards" data-testid="tab-scorecards">Performance Scorecards</TabsTrigger>
            <TabsTrigger value="trends" data-testid="tab-trends">Trend Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="health" className="space-y-6">
            {portfolioHealth && (portfolioHealth as any).programHealth && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card data-testid="card-program-status-chart">
                  <CardHeader>
                    <CardTitle>Program Status Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={[
                            { name: 'On Track', value: (portfolioHealth as any).programHealth.onTime },
                            { name: 'At Risk', value: (portfolioHealth as any).programHealth.atRisk },
                            { name: 'Delayed', value: (portfolioHealth as any).programHealth.delayed }
                          ]}
                          cx="50%"
                          cy="50%"
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label
                        >
                          {[
                            { name: 'On Track', value: (portfolioHealth as any).programHealth.onTime },
                            { name: 'At Risk', value: (portfolioHealth as any).programHealth.atRisk },
                            { name: 'Delayed', value: (portfolioHealth as any).programHealth.delayed }
                          ].map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card data-testid="card-risk-breakdown">
                  <CardHeader>
                    <CardTitle>Risk Breakdown</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Budget Overruns</span>
                      <Badge variant="destructive" data-testid="badge-budget-overruns">
                        {(portfolioHealth as any).riskIndicators.budgetOverruns}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Critical Milestones</span>
                      <Badge variant="secondary" data-testid="badge-critical-milestones">
                        {(portfolioHealth as any).riskIndicators.criticalMilestones}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>High Risk Programs</span>
                      <Badge variant="destructive" data-testid="badge-high-risk-total">
                        {(portfolioHealth as any).riskIndicators.highRiskPrograms}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>

          <TabsContent value="scorecards" className="space-y-6">
            <div className="grid gap-4">
              {(scorecards as any[]).map((scorecard: any) => (
                <Card key={scorecard.programId} data-testid={`card-scorecard-${scorecard.programId}`}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg" data-testid={`title-program-${scorecard.programId}`}>
                          {scorecard.programName}
                        </CardTitle>
                        <CardDescription>
                          {scorecard.phase} • Manager: {scorecard.manager}
                        </CardDescription>
                      </div>
                      <Badge 
                        className={getStatusColor(scorecard.status)}
                        data-testid={`badge-status-${scorecard.programId}`}
                      >
                        {scorecard.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className={`text-2xl font-bold ${getScoreColor(scorecard.overallScore)}`} data-testid={`score-overall-${scorecard.programId}`}>
                          {scorecard.overallScore}
                        </div>
                        <div className="text-sm text-muted-foreground">Overall</div>
                      </div>
                      <div className="text-center">
                        <div className={`text-2xl font-bold ${getScoreColor(scorecard.budgetScore)}`} data-testid={`score-budget-${scorecard.programId}`}>
                          {scorecard.budgetScore}
                        </div>
                        <div className="text-sm text-muted-foreground">Budget</div>
                      </div>
                      <div className="text-center">
                        <div className={`text-2xl font-bold ${getScoreColor(scorecard.scheduleScore)}`} data-testid={`score-schedule-${scorecard.programId}`}>
                          {scorecard.scheduleScore}
                        </div>
                        <div className="text-sm text-muted-foreground">Schedule</div>
                      </div>
                      <div className="text-center">
                        <div className={`text-2xl font-bold ${getScoreColor(scorecard.riskScore)}`} data-testid={`score-risk-${scorecard.programId}`}>
                          {scorecard.riskScore}
                        </div>
                        <div className="text-sm text-muted-foreground">Risk</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="trends" className="space-y-6">
            {trends && (trends as any).budgetTrend && (
              <div className="grid gap-6">
                <Card data-testid="card-budget-trend">
                  <CardHeader>
                    <CardTitle>Budget Trend Analysis</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={(trends as any).budgetTrend}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Line type="monotone" dataKey="planned" stroke="#8884d8" name="Planned" />
                        <Line type="monotone" dataKey="actual" stroke="#82ca9d" name="Actual" />
                        <Line type="monotone" dataKey="variance" stroke="#ffc658" name="Variance" />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card data-testid="card-program-completion">
                    <CardHeader>
                      <CardTitle>Program Completion Trends</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={200}>
                        <BarChart data={(trends as any).programCompletion}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip />
                          <Bar dataKey="completed" fill="#8884d8" />
                          <Bar dataKey="started" fill="#82ca9d" />
                          <Bar dataKey="delayed" fill="#ffc658" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>

                  <Card data-testid="card-resource-utilization-trend">
                    <CardHeader>
                      <CardTitle>Resource Utilization Trends</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={200}>
                        <LineChart data={(trends as any).resourceUtilization}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip />
                          <Line type="monotone" dataKey="utilization" stroke="#8884d8" />
                          <Line type="monotone" dataKey="efficiency" stroke="#82ca9d" />
                        </LineChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Generated Report Modal */}
        <Dialog open={showReportModal} onOpenChange={setShowReportModal}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Executive Report - {generatedReport?.type}</DialogTitle>
            </DialogHeader>
            {generatedReport && (
              <div className="space-y-6" data-testid="report-content">
                {/* Report Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle>Portfolio Summary</CardTitle>
                    <CardDescription>Generated on {new Date(generatedReport.generatedAt).toLocaleDateString()}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold" data-testid="report-total-programs">
                          {generatedReport.summary.totalPrograms}
                        </div>
                        <div className="text-sm text-muted-foreground">Total Programs</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold" data-testid="report-schedule-performance">
                          {generatedReport.summary.schedulePerformance}%
                        </div>
                        <div className="text-sm text-muted-foreground">Schedule Performance</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold" data-testid="report-budget-efficiency">
                          {generatedReport.summary.budgetEfficiency}%
                        </div>
                        <div className="text-sm text-muted-foreground">Budget Efficiency</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold" data-testid="report-portfolio-health">
                          {generatedReport.summary.portfolioHealth}
                        </div>
                        <div className="text-sm text-muted-foreground">Portfolio Health</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Charts */}
                {generatedReport.charts && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Visual Analysis</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div>
                          <h4 className="text-lg font-semibold mb-4">Budget vs Spending</h4>
                          <ResponsiveContainer width="100%" height={200}>
                            <BarChart data={generatedReport.charts.budgetTrend}>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="name" />
                              <YAxis />
                              <Tooltip />
                              <Bar dataKey="budget" fill="#8884d8" name="Budget" />
                              <Bar dataKey="spent" fill="#82ca9d" name="Spent" />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                        <div>
                          <h4 className="text-lg font-semibold mb-4">Schedule Status</h4>
                          <ResponsiveContainer width="100%" height={200}>
                            <PieChart>
                              <Pie
                                data={generatedReport.charts.scheduleStatus}
                                cx="50%"
                                cy="50%"
                                outerRadius={60}
                                fill="#8884d8"
                                dataKey="value"
                                label
                              >
                                {generatedReport.charts.scheduleStatus.map((entry: any, index: number) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <Tooltip />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Recommendations */}
                <Card>
                  <CardHeader>
                    <CardTitle>Executive Recommendations</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {generatedReport.recommendations.map((rec: string, index: number) => (
                        <li key={index} className="flex items-start">
                          <CheckCircle className="w-5 h-5 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                          <span data-testid={`recommendation-${index}`}>{rec}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                {/* Export Actions */}
                <div className="flex gap-4">
                  <Button 
                    onClick={() => {
                      const dataStr = JSON.stringify(generatedReport, null, 2);
                      const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
                      const exportFileDefaultName = `executive-report-${generatedReport.type}-${Date.now()}.json`;
                      const linkElement = document.createElement('a');
                      linkElement.setAttribute('href', dataUri);
                      linkElement.setAttribute('download', exportFileDefaultName);
                      linkElement.click();
                    }}
                    data-testid="button-export-json"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Export JSON
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => window.print()}
                    data-testid="button-print-report"
                  >
                    Print Report
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}