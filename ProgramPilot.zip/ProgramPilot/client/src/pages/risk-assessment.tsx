import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { AlertTriangle, CheckCircle, Clock, TrendingUp, TrendingDown, Shield, Target, FileText, Plus, Edit, Trash2, Eye } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertRiskSchema, insertRiskAssessmentSchema, insertRiskMitigationSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Extend shared schemas with UI-specific validation rules
const riskSchema = insertRiskSchema.extend({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  identifiedBy: z.string().min(1, "Identified by is required"),
});

const assessmentSchema = insertRiskAssessmentSchema.extend({
  assessedBy: z.string().min(1, "Assessed by is required"),
  probabilityScore: z.number().min(1).max(10),
  impactScore: z.number().min(1).max(10),
  scheduleImpactDays: z.number().min(0).default(0),
  budgetImpactAmount: z.string().default("0"),
  confidenceLevel: z.number().min(0).max(100).default(70),
});

const mitigationSchema = insertRiskMitigationSchema.extend({
  actionDescription: z.string().min(1, "Action description is required"),
  assignedTo: z.string().min(1, "Assigned to is required"),
  estimatedCost: z.string().default("0"),
});

export default function RiskAssessment() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [selectedProgram, setSelectedProgram] = useState("");
  const [selectedRisk, setSelectedRisk] = useState<any>(null);
  const [showRiskForm, setShowRiskForm] = useState(false);
  const [showAssessmentForm, setShowAssessmentForm] = useState(false);
  const [showMitigationForm, setShowMitigationForm] = useState(false);
  const { toast } = useToast();

  const { data: programs = [] } = useQuery({
    queryKey: ["/api/programs"],
  });

  const { data: risks = [], isLoading: risksLoading } = useQuery({
    queryKey: ["/api/risks", selectedProgram],
    enabled: !!selectedProgram,
  });

  const { data: riskAnalytics } = useQuery({
    queryKey: ["/api/programs", selectedProgram, "risk-analytics"],
    enabled: !!selectedProgram,
  });

  const { data: portfolioRiskSummary } = useQuery({
    queryKey: ["/api/portfolio/risk-summary"],
  });

  const createRiskMutation = useMutation({
    mutationFn: (data: any) => apiRequest("/api/risks", "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/risks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/programs", selectedProgram, "risk-analytics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/portfolio/risk-summary"] });
      setShowRiskForm(false);
      toast({ title: "Risk created successfully" });
    },
  });

  const createAssessmentMutation = useMutation({
    mutationFn: ({ riskId, data }: any) => apiRequest(`/api/risks/${riskId}/assessments`, "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/risks"] });
      setShowAssessmentForm(false);
      toast({ title: "Risk assessment created successfully" });
    },
  });

  const createMitigationMutation = useMutation({
    mutationFn: ({ riskId, data }: any) => apiRequest(`/api/risks/${riskId}/mitigations`, "POST", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/risks"] });
      setShowMitigationForm(false);
      toast({ title: "Risk mitigation created successfully" });
    },
  });

  const riskForm = useForm({
    resolver: zodResolver(riskSchema),
    defaultValues: {
      programId: selectedProgram,
      riskId: `RISK-${Date.now()}`,
      title: "",
      description: "",
      category: "technical",
      type: "program-level",
      source: "",
      severity: "medium",
      urgency: "medium",
      identifiedBy: "",
      targetResolutionDate: "",
      escalationRequired: false,
      escalationLevel: "",
    },
  });

  const assessmentForm = useForm({
    resolver: zodResolver(assessmentSchema),
    defaultValues: {
      probabilityScore: 5,
      impactScore: 5,
      scheduleImpactDays: 0,
      budgetImpactAmount: "0",
      riskTolerance: "medium",
      confidenceLevel: 70,
    },
  });

  const mitigationForm = useForm({
    resolver: zodResolver(mitigationSchema),
    defaultValues: {
      strategy: "mitigate",
      actionType: "preventive",
      priority: "medium",
      estimatedCost: "0",
    },
  });

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-600 text-white';
      case 'high': return 'bg-orange-600 text-white';
      case 'medium': return 'bg-yellow-600 text-white';
      case 'low': return 'bg-green-600 text-white';
      default: return 'bg-gray-600 text-white';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'bg-red-100 text-red-800';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800';
      case 'mitigated': return 'bg-blue-100 text-blue-800';
      case 'closed': return 'bg-green-100 text-green-800';
      case 'accepted': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

  // Update form programId when selectedProgram changes
  useEffect(() => {
    if (selectedProgram) {
      riskForm.setValue('programId', selectedProgram);
    }
  }, [selectedProgram, riskForm]);

  return (
    <div className="min-h-screen bg-background p-6" data-testid="risk-assessment-dashboard">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-foreground" data-testid="title-risk-assessment">
              Risk Assessment & Mitigation
            </h1>
            <p className="text-muted-foreground mt-1">
              Comprehensive risk identification, impact analysis, and mitigation workflows
            </p>
          </div>
          
          <div className="flex gap-4">
            <Select value={selectedProgram} onValueChange={setSelectedProgram}>
              <SelectTrigger className="w-[200px]" data-testid="select-program">
                <SelectValue placeholder="Select program" />
              </SelectTrigger>
              <SelectContent>
                {(programs as any[]).map((program: any) => (
                  <SelectItem key={program.id} value={program.id}>
                    {program.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Dialog open={showRiskForm} onOpenChange={setShowRiskForm}>
              <DialogTrigger asChild>
                <Button disabled={!selectedProgram} data-testid="button-add-risk">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Risk
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Add New Risk</DialogTitle>
                </DialogHeader>
                <Form {...riskForm}>
                  <form onSubmit={riskForm.handleSubmit((data) => createRiskMutation.mutate(data))} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={riskForm.control}
                        name="riskId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Risk ID</FormLabel>
                            <FormControl>
                              <Input {...field} data-testid="input-risk-id" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={riskForm.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Category</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid="select-risk-category">
                                  <SelectValue placeholder="Select category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="technical">Technical</SelectItem>
                                <SelectItem value="schedule">Schedule</SelectItem>
                                <SelectItem value="budget">Budget</SelectItem>
                                <SelectItem value="resource">Resource</SelectItem>
                                <SelectItem value="external">External</SelectItem>
                                <SelectItem value="regulatory">Regulatory</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={riskForm.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Risk Title</FormLabel>
                          <FormControl>
                            <Input {...field} data-testid="input-risk-title" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={riskForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea {...field} rows={3} data-testid="textarea-risk-description" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-3 gap-4">
                      <FormField
                        control={riskForm.control}
                        name="severity"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Severity</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid="select-risk-severity">
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="critical">Critical</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={riskForm.control}
                        name="urgency"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Urgency</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid="select-risk-urgency">
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="immediate">Immediate</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="low">Low</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={riskForm.control}
                        name="type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Type</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid="select-risk-type">
                                  <SelectValue />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="program-level">Program Level</SelectItem>
                                <SelectItem value="milestone-level">Milestone Level</SelectItem>
                                <SelectItem value="task-level">Task Level</SelectItem>
                                <SelectItem value="resource-level">Resource Level</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={riskForm.control}
                      name="identifiedBy"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Identified By</FormLabel>
                          <FormControl>
                            <Input {...field} data-testid="input-identified-by" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="flex justify-end gap-2">
                      <Button type="button" variant="outline" onClick={() => setShowRiskForm(false)}>
                        Cancel
                      </Button>
                      <Button type="submit" disabled={createRiskMutation.isPending} data-testid="button-save-risk">
                        {createRiskMutation.isPending ? "Creating..." : "Create Risk"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Portfolio Risk Summary */}
        {portfolioRiskSummary && (
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
            <Card data-testid="card-total-risks">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Risks</CardTitle>
                <Shield className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-total-risks">
                  {portfolioRiskSummary.totalRisks}
                </div>
              </CardContent>
            </Card>

            <Card data-testid="card-critical-risks">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Critical Risks</CardTitle>
                <AlertTriangle className="h-4 w-4 text-red-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600" data-testid="text-critical-risks">
                  {portfolioRiskSummary.criticalRisks}
                </div>
              </CardContent>
            </Card>

            <Card data-testid="card-high-risks">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">High Risks</CardTitle>
                <TrendingUp className="h-4 w-4 text-orange-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-orange-600" data-testid="text-high-risks">
                  {portfolioRiskSummary.highRisks}
                </div>
              </CardContent>
            </Card>

            <Card data-testid="card-open-risks">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Open Risks</CardTitle>
                <Clock className="h-4 w-4 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600" data-testid="text-open-risks">
                  {portfolioRiskSummary.openRisks}
                </div>
              </CardContent>
            </Card>

            <Card data-testid="card-escalated-risks">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Escalated</CardTitle>
                <Target className="h-4 w-4 text-purple-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600" data-testid="text-escalated-risks">
                  {portfolioRiskSummary.escalatedRisks}
                </div>
              </CardContent>
            </Card>

            <Card data-testid="card-risk-score">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Risk Score</CardTitle>
                <TrendingDown className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-portfolio-risk-score">
                  {portfolioRiskSummary.portfolioRiskScore}/10
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="dashboard" data-testid="tab-dashboard">Risk Dashboard</TabsTrigger>
            <TabsTrigger value="risks" data-testid="tab-risks">Risk Register</TabsTrigger>
            <TabsTrigger value="analytics" data-testid="tab-analytics">Analytics</TabsTrigger>
            <TabsTrigger value="mitigations" data-testid="tab-mitigations">Mitigations</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            {selectedProgram && riskAnalytics ? (
              <div className="grid gap-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card data-testid="card-risk-distribution">
                    <CardHeader>
                      <CardTitle>Risk Distribution by Category</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={Object.entries(riskAnalytics.risksByCategory).map(([category, count]) => ({ 
                              name: category, 
                              value: count 
                            }))}
                            cx="50%"
                            cy="50%"
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label
                          >
                            {Object.entries(riskAnalytics.risksByCategory).map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>

                  <Card data-testid="card-severity-breakdown">
                    <CardHeader>
                      <CardTitle>Risk Severity Breakdown</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={Object.entries(riskAnalytics.risksBySeverity).map(([severity, count]) => ({ 
                          severity, 
                          count 
                        }))}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="severity" />
                          <YAxis />
                          <Tooltip />
                          <Bar dataKey="count" fill="#8884d8" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card data-testid="card-budget-impact">
                    <CardHeader>
                      <CardTitle>Total Budget Impact</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold text-red-600" data-testid="text-budget-impact">
                        ${Math.round(riskAnalytics.totalBudgetImpact).toLocaleString()}
                      </div>
                      <p className="text-sm text-muted-foreground">Potential cost impact</p>
                    </CardContent>
                  </Card>

                  <Card data-testid="card-schedule-impact">
                    <CardHeader>
                      <CardTitle>Schedule Impact</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold text-orange-600" data-testid="text-schedule-impact">
                        {riskAnalytics.totalScheduleImpact} days
                      </div>
                      <p className="text-sm text-muted-foreground">Potential delays</p>
                    </CardContent>
                  </Card>

                  <Card data-testid="card-average-risk-score">
                    <CardHeader>
                      <CardTitle>Average Risk Score</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-3xl font-bold" data-testid="text-average-risk-score">
                        {riskAnalytics.averageRiskScore}/100
                      </div>
                      <Progress value={riskAnalytics.averageRiskScore} className="mt-2" />
                    </CardContent>
                  </Card>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <h3 className="text-lg font-semibold text-foreground mb-2">Select a Program</h3>
                <p className="text-muted-foreground">Choose a program to view risk dashboard</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="risks" className="space-y-6">
            {selectedProgram ? (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Risk Register</h3>
                <div className="grid gap-4">
                  {(risks as any[]).map((risk: any) => (
                    <Card key={risk.id} data-testid={`card-risk-${risk.id}`}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div className="space-y-2">
                            <CardTitle className="text-lg" data-testid={`title-risk-${risk.id}`}>
                              {risk.riskId}: {risk.title}
                            </CardTitle>
                            <CardDescription>{risk.description}</CardDescription>
                            <div className="flex gap-2">
                              <Badge className={getSeverityColor(risk.severity)} data-testid={`badge-severity-${risk.id}`}>
                                {risk.severity}
                              </Badge>
                              <Badge className={getStatusColor(risk.status)} data-testid={`badge-status-${risk.id}`}>
                                {risk.status}
                              </Badge>
                              <Badge variant="outline" data-testid={`badge-category-${risk.id}`}>
                                {risk.category}
                              </Badge>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => {
                              setSelectedRisk(risk);
                              setShowAssessmentForm(true);
                            }} data-testid={`button-assess-${risk.id}`}>
                              <Target className="w-4 h-4" />
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => {
                              setSelectedRisk(risk);
                              setShowMitigationForm(true);
                            }} data-testid={`button-mitigate-${risk.id}`}>
                              <Shield className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="font-medium">Identified by:</span>
                            <p>{risk.identifiedBy}</p>
                          </div>
                          <div>
                            <span className="font-medium">Type:</span>
                            <p>{risk.type}</p>
                          </div>
                          <div>
                            <span className="font-medium">Urgency:</span>
                            <p>{risk.urgency}</p>
                          </div>
                          <div>
                            <span className="font-medium">Identified:</span>
                            <p>{new Date(risk.identifiedDate).toLocaleDateString()}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <h3 className="text-lg font-semibold text-foreground mb-2">Select a Program</h3>
                <p className="text-muted-foreground">Choose a program to view risk register</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            {selectedProgram && riskAnalytics ? (
              <div className="grid gap-6">
                <Card data-testid="card-risk-trends">
                  <CardHeader>
                    <CardTitle>Risk Status Trends</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={Object.entries(riskAnalytics.risksByStatus).map(([status, count]) => ({ 
                        status, 
                        count 
                      }))}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="status" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="count" fill="#82ca9d" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card data-testid="card-risk-metrics">
                    <CardHeader>
                      <CardTitle>Risk Metrics</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex justify-between">
                        <span>High Risk Count:</span>
                        <Badge variant="destructive" data-testid="badge-high-risk-count">
                          {riskAnalytics.highRiskCount}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Open Risks:</span>
                        <Badge variant="secondary" data-testid="badge-open-risk-count">
                          {riskAnalytics.openRiskCount}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Escalation Required:</span>
                        <Badge variant="outline" data-testid="badge-escalation-required">
                          {riskAnalytics.escalationRequired}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>

                  <Card data-testid="card-impact-analysis">
                    <CardHeader>
                      <CardTitle>Impact Analysis</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between mb-2">
                            <span>Budget Risk Exposure</span>
                            <span>${Math.round(riskAnalytics.totalBudgetImpact).toLocaleString()}</span>
                          </div>
                          <Progress value={Math.min((riskAnalytics.totalBudgetImpact / 1000000) * 100, 100)} />
                        </div>
                        <div>
                          <div className="flex justify-between mb-2">
                            <span>Schedule Risk (Days)</span>
                            <span>{riskAnalytics.totalScheduleImpact}</span>
                          </div>
                          <Progress value={Math.min((riskAnalytics.totalScheduleImpact / 365) * 100, 100)} />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <h3 className="text-lg font-semibold text-foreground mb-2">Select a Program</h3>
                <p className="text-muted-foreground">Choose a program to view analytics</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="mitigations" className="space-y-6">
            <div className="text-center py-8">
              <h3 className="text-lg font-semibold text-foreground mb-2">Risk Mitigation Management</h3>
              <p className="text-muted-foreground">Track and manage risk mitigation actions</p>
            </div>
          </TabsContent>
        </Tabs>

        {/* Assessment Form Modal */}
        <Dialog open={showAssessmentForm} onOpenChange={setShowAssessmentForm}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Risk Assessment - {selectedRisk?.title}</DialogTitle>
            </DialogHeader>
            <Form {...assessmentForm}>
              <form onSubmit={assessmentForm.handleSubmit((data) => 
                createAssessmentMutation.mutate({ riskId: selectedRisk?.id, data })
              )} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={assessmentForm.control}
                    name="probabilityScore"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Probability Score (1-10)</FormLabel>
                        <FormControl>
                          <Input type="number" min="1" max="10" {...field} onChange={(e) => field.onChange(parseInt(e.target.value))} data-testid="input-probability-score" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={assessmentForm.control}
                    name="impactScore"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Impact Score (1-10)</FormLabel>
                        <FormControl>
                          <Input type="number" min="1" max="10" {...field} onChange={(e) => field.onChange(parseInt(e.target.value))} data-testid="input-impact-score" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={assessmentForm.control}
                    name="scheduleImpactDays"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Schedule Impact (Days)</FormLabel>
                        <FormControl>
                          <Input type="number" min="0" {...field} onChange={(e) => field.onChange(parseInt(e.target.value))} data-testid="input-schedule-impact" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={assessmentForm.control}
                    name="budgetImpactAmount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Budget Impact ($)</FormLabel>
                        <FormControl>
                          <Input type="number" min="0" {...field} data-testid="input-budget-impact" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={assessmentForm.control}
                  name="assessedBy"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Assessed By</FormLabel>
                      <FormControl>
                        <Input {...field} data-testid="input-assessed-by" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={assessmentForm.control}
                  name="assessmentNotes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Assessment Notes</FormLabel>
                      <FormControl>
                        <Textarea {...field} rows={3} data-testid="textarea-assessment-notes" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setShowAssessmentForm(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createAssessmentMutation.isPending} data-testid="button-save-assessment">
                    {createAssessmentMutation.isPending ? "Saving..." : "Save Assessment"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        {/* Mitigation Form Modal */}
        <Dialog open={showMitigationForm} onOpenChange={setShowMitigationForm}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Risk Mitigation - {selectedRisk?.title}</DialogTitle>
            </DialogHeader>
            <Form {...mitigationForm}>
              <form onSubmit={mitigationForm.handleSubmit((data) => 
                createMitigationMutation.mutate({ riskId: selectedRisk?.id, data })
              )} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={mitigationForm.control}
                    name="strategy"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Mitigation Strategy</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-mitigation-strategy">
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="avoid">Avoid</SelectItem>
                            <SelectItem value="mitigate">Mitigate</SelectItem>
                            <SelectItem value="transfer">Transfer</SelectItem>
                            <SelectItem value="accept">Accept</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={mitigationForm.control}
                    name="actionType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Action Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-action-type">
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="preventive">Preventive</SelectItem>
                            <SelectItem value="detective">Detective</SelectItem>
                            <SelectItem value="corrective">Corrective</SelectItem>
                            <SelectItem value="contingency">Contingency</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={mitigationForm.control}
                  name="actionDescription"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Action Description</FormLabel>
                      <FormControl>
                        <Textarea {...field} rows={3} data-testid="textarea-action-description" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={mitigationForm.control}
                    name="assignedTo"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Assigned To</FormLabel>
                        <FormControl>
                          <Input {...field} data-testid="input-assigned-to" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={mitigationForm.control}
                    name="priority"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Priority</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-mitigation-priority">
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="critical">Critical</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="low">Low</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={mitigationForm.control}
                  name="successCriteria"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Success Criteria</FormLabel>
                      <FormControl>
                        <Textarea {...field} rows={2} data-testid="textarea-success-criteria" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setShowMitigationForm(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createMitigationMutation.isPending} data-testid="button-save-mitigation">
                    {createMitigationMutation.isPending ? "Creating..." : "Create Mitigation"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}