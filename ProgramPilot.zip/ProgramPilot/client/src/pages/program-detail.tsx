import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Calendar, DollarSign, Users, FileText } from "lucide-react";
import { useLocation } from "wouter";
import GanttChart from "@/components/program/gantt-chart";

export default function ProgramDetail() {
  const { id } = useParams();
  const [, setLocation] = useLocation();

  const { data: program, isLoading } = useQuery({
    queryKey: ["/api/programs", id],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-muted rounded w-64 mb-4"></div>
          <div className="h-4 bg-muted rounded w-32 mb-8"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-32 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const programData = program as any;
  
  if (!programData) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="text-center py-12">
          <h1 className="text-2xl font-bold text-foreground">Program not found</h1>
          <Button 
            onClick={() => setLocation("/")} 
            className="mt-4"
            data-testid="button-back-to-dashboard"
          >
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const getPhaseColor = (phase: string) => {
    const colors: Record<string, string> = {
      PDR: "bg-blue-100 text-blue-800",
      CDR: "bg-green-100 text-green-800",
      TRR: "bg-yellow-100 text-yellow-800",
      QUAL: "bg-orange-100 text-orange-800",
      PRODUCTION: "bg-red-100 text-red-800",
    };
    return colors[phase] || "bg-gray-100 text-gray-800";
  };

  const overallProgress = programData.wbs?.length > 0 
    ? Math.round(
        programData.wbs.reduce((sum: number, task: any) => {
          const actual = parseFloat(task.actualHours) || 0;
          const estimated = parseFloat(task.estimatedHours) || 1;
          return sum + (actual / estimated);
        }, 0) / programData.wbs.length * 100
      )
    : 0;

  return (
    <div className="min-h-screen bg-background" data-testid="programData-detail-container">
      <div className="p-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setLocation("/")}
            data-testid="button-back"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-foreground" data-testid="text-programData-name">
              {programData.name}
            </h1>
            <p className="text-muted-foreground" data-testid="text-programData-id">
              {programData.program_id}
            </p>
          </div>
          <div className="ml-auto">
            <Badge className={getPhaseColor(programData.phase)}>
              {programData.phase}
            </Badge>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Progress</p>
                  <p className="text-2xl font-bold text-foreground">{overallProgress}%</p>
                </div>
                <Calendar className="h-8 w-8 text-chart-1" />
              </div>
              <Progress value={overallProgress} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Budget Status</p>
                  <p className="text-2xl font-bold text-foreground">
                    ${parseFloat(programData.budgetSpent || 0).toLocaleString()}
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-chart-2" />
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                of ${parseFloat(programData.totalBudget || 0).toLocaleString()} total
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Team Size</p>
                  <p className="text-2xl font-bold text-foreground">
                    {programData.resourceAllocations?.length || 0}
                  </p>
                </div>
                <Users className="h-8 w-8 text-chart-3" />
              </div>
              <p className="text-xs text-muted-foreground mt-1">active resources</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Tasks</p>
                  <p className="text-2xl font-bold text-foreground">
                    {programData.wbs?.length || 0}
                  </p>
                </div>
                <FileText className="h-8 w-8 text-chart-4" />
              </div>
              <p className="text-xs text-muted-foreground mt-1">work breakdown items</p>
            </CardContent>
          </Card>
        </div>

        {/* Content Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid grid-cols-5 w-fit">
            <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
            <TabsTrigger value="schedule" data-testid="tab-schedule">Schedule</TabsTrigger>
            <TabsTrigger value="wbs" data-testid="tab-wbs">WBS</TabsTrigger>
            <TabsTrigger value="budget" data-testid="tab-budget">Budget</TabsTrigger>
            <TabsTrigger value="resources" data-testid="tab-resources">Resources</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Program Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Description</label>
                    <p className="text-foreground">{programData.description || "No description provided"}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Design Assemblies</label>
                      <p className="text-foreground">{programData.designAssemblies}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Verification Units</label>
                      <p className="text-foreground">{programData.verificationUnits}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Qualification Units</label>
                      <p className="text-foreground">{programData.qualificationUnits}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">CDRLs</label>
                      <p className="text-foreground">{programData.cdrlsCount}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Milestones</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {programData.milestones?.map((milestone: any) => (
                      <div key={milestone.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{milestone.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {milestone.targetDate 
                              ? new Date(milestone.targetDate).toLocaleDateString()
                              : "No target date"
                            }
                          </p>
                        </div>
                        <Badge className={getPhaseColor(milestone.type.toUpperCase())}>
                          {milestone.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="schedule">
            <Card>
              <CardHeader>
                <CardTitle>Project Schedule</CardTitle>
              </CardHeader>
              <CardContent>
                <GanttChart wbsData={programData.wbs || []} milestones={programData.milestones || []} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="wbs">
            <Card>
              <CardHeader>
                <CardTitle>Work Breakdown Structure</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2">Task Code</th>
                        <th className="text-left p-2">Task Name</th>
                        <th className="text-left p-2">Phase</th>
                        <th className="text-left p-2">Estimated Hours</th>
                        <th className="text-left p-2">Actual Hours</th>
                        <th className="text-left p-2">Progress</th>
                        <th className="text-left p-2">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {programData.wbs?.map((task: any) => {
                        const estimated = parseFloat(task.estimatedHours) || 1;
                        const actual = parseFloat(task.actualHours) || 0;
                        const progress = Math.min(100, Math.round((actual / estimated) * 100));
                        
                        return (
                          <tr key={task.id} className="border-b hover:bg-muted/50">
                            <td className="p-2 font-mono text-xs">{task.taskCode}</td>
                            <td className="p-2">{task.taskName}</td>
                            <td className="p-2">
                              <Badge variant="outline" className="text-xs">
                                {task.phase}
                              </Badge>
                            </td>
                            <td className="p-2">{estimated.toFixed(1)}</td>
                            <td className="p-2">{actual.toFixed(1)}</td>
                            <td className="p-2">
                              <div className="flex items-center gap-2">
                                <Progress value={progress} className="h-2 w-16" />
                                <span className="text-xs">{progress}%</span>
                              </div>
                            </td>
                            <td className="p-2">
                              <Badge variant="outline">
                                {task.status}
                              </Badge>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="budget">
            <Card>
              <CardHeader>
                <CardTitle>Budget Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-foreground">
                        ${parseFloat(programData.totalBudget || 0).toLocaleString()}
                      </p>
                      <p className="text-sm text-muted-foreground">Total Budget</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-destructive">
                        ${parseFloat(programData.budgetSpent || 0).toLocaleString()}
                      </p>
                      <p className="text-sm text-muted-foreground">Spent</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-chart-2">
                        ${(parseFloat(programData.totalBudget || 0) - parseFloat(programData.budgetSpent || 0)).toLocaleString()}
                      </p>
                      <p className="text-sm text-muted-foreground">Remaining</p>
                    </div>
                  </div>
                  
                  {programData.budgetEntries && programData.budgetEntries.length > 0 && (
                    <div className="mt-6">
                      <h4 className="font-medium mb-4">Budget Entries</h4>
                      <div className="space-y-2">
                        {programData.budgetEntries.map((entry: any) => (
                          <div key={entry.id} className="flex justify-between items-center p-2 rounded bg-muted/50">
                            <div>
                              <p className="font-medium">{entry.category}</p>
                              <p className="text-sm text-muted-foreground">{entry.description}</p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">${parseFloat(entry.actualAmount || 0).toLocaleString()}</p>
                              <p className="text-xs text-muted-foreground">
                                Budget: ${parseFloat(entry.plannedAmount || 0).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="resources">
            <Card>
              <CardHeader>
                <CardTitle>Resource Allocations</CardTitle>
              </CardHeader>
              <CardContent>
                {programData.resourceAllocations && programData.resourceAllocations.length > 0 ? (
                  <div className="space-y-4">
                    {programData.resourceAllocations.map((allocation: any) => (
                      <div key={allocation.id} className="flex justify-between items-center p-4 border rounded">
                        <div>
                          <p className="font-medium">{allocation.resourceName}</p>
                          <p className="text-sm text-muted-foreground">{allocation.resourceType}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{allocation.allocatedHours} hours</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(allocation.startDate).toLocaleDateString()} - {new Date(allocation.endDate).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-8">No resource allocations found</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
