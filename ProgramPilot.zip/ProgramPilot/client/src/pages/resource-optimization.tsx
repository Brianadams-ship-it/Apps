import Sidebar from "@/components/dashboard/sidebar";
import Header from "@/components/dashboard/header";
import ResourceOptimization from "@/components/optimization/resource-optimization";

export default function ResourceOptimizationPage() {
  return (
    <div className="flex h-screen bg-background" data-testid="resource-optimization-page">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header onNewProgram={() => {}} />
        
        <main className="flex-1 overflow-auto p-6">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-foreground">Resource Optimization</h1>
            <p className="text-muted-foreground">
              Automatically detect conflicts and optimize resource allocation across all programs
            </p>
          </div>
          
          <ResourceOptimization />
        </main>
      </div>
    </div>
  );
}