import express from "express";
import multer from "multer";
import type { IStorage } from "./storage";
import { insertUserSchema, insertProgramSchema, insertMilestoneSchema, insertWbsSchema, insertResourceSchema, insertResourceAllocationSchema, insertBudgetEntrySchema, insertExpenseSchema, insertDocumentSchema, insertCdrlItemSchema, insertDocumentApprovalSchema, insertRiskSchema, insertRiskAssessmentSchema, insertRiskMitigationSchema, insertRiskImpactSchema, insertSettingsSchema } from "@shared/schema";
import { z } from "zod";
import { GitHubSyncService } from "./services/githubSyncService";

export function createRoutes(storage: IStorage) {
  const router = express.Router();
  const githubSync = new GitHubSyncService(storage);

  // Configure multer for file uploads
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 10 * 1024 * 1024, // 10MB limit
    },
    fileFilter: (req, file, cb) => {
      // Only allow Excel files
      const allowedMimes = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel'
      ];
      if (allowedMimes.includes(file.mimetype) || file.originalname.endsWith('.xlsx') || file.originalname.endsWith('.xls')) {
        cb(null, true);
      } else {
        cb(new Error('Only Excel files (.xlsx, .xls) are allowed'));
      }
    }
  });

  // GitHub Sync Routes
  router.get("/api/sync/status", async (req, res) => {
    try {
      const status = githubSync.getStatus();
      res.json(status);
    } catch (error: any) {
      console.error("Error getting sync status:", error);
      res.status(500).json({ error: "Failed to get sync status" });
    }
  });

  // GET endpoint for direct Excel download
  router.get("/api/sync/export", async (req, res) => {
    try {
      const buffer = await githubSync.exportToExcel();
      
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename="program-data.xlsx"');
      res.send(buffer);
    } catch (error: any) {
      console.error("Error generating Excel export:", error);
      res.status(500).json({ error: error.message || "Failed to generate Excel export" });
    }
  });

  // POST endpoint for GitHub sync (export + upload)
  router.post("/api/sync/export", async (req, res) => {
    try {
      await githubSync.syncToGitHub();
      res.json({ success: true, message: "Export to GitHub completed" });
    } catch (error: any) {
      console.error("Error exporting to GitHub:", error);
      res.status(500).json({ error: error.message || "Failed to export to GitHub" });
    }
  });

  router.post("/api/sync/import", async (req, res) => {
    try {
      await githubSync.syncFromGitHub();
      res.json({ success: true, message: "Import from GitHub completed" });
    } catch (error: any) {
      console.error("Error importing from GitHub:", error);
      res.status(500).json({ error: error.message || "Failed to import from GitHub" });
    }
  });

  // Template download endpoints
  router.get("/api/templates/programs.xlsx", async (req, res) => {
    try {
      const buffer = await githubSync.generateTemplate(false);
      
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename="programs-template.xlsx"');
      res.send(buffer);
    } catch (error: any) {
      console.error("Error generating blank template:", error);
      res.status(500).json({ error: error.message || "Failed to generate template" });
    }
  });

  router.get("/api/templates/programs-example.xlsx", async (req, res) => {
    try {
      const buffer = await githubSync.generateTemplate(true);
      
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename="programs-template-example.xlsx"');
      res.send(buffer);
    } catch (error: any) {
      console.error("Error generating example template:", error);
      res.status(500).json({ error: error.message || "Failed to generate example template" });
    }
  });

  // File upload endpoint with dry-run support
  router.post("/api/sync/import-file", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const dryRun = req.query.dryRun === 'true';
      console.log(`Processing file upload: ${req.file.originalname} (${req.file.size} bytes), dryRun: ${dryRun}`);

      try {
        const result = await githubSync.parseAndUpsert(req.file.buffer, { dryRun });
        
        if (dryRun) {
          // Dry run - return validation results
          res.json({
            success: true,
            dryRun: true,
            results: result,
            message: `File validation completed. Found ${result.errors.length} errors and ${result.warnings.length} warnings.`
          });
        } else {
          // Actual import - update sync status and clear calculation service cache
          githubSync.updateImportStatus();
          
          const { calculationService } = await import('./services/calculationService');
          calculationService.clearSettingsCache();
          
          res.json({
            success: true,
            dryRun: false,
            results: result,
            message: `File imported successfully. Processed ${Object.values(result.stats).reduce((sum, count) => sum + count, 0)} records.`
          });
        }
      } catch (parseError: any) {
        console.error("File parsing error:", parseError);
        res.status(400).json({ 
          error: `File parsing failed: ${parseError.message}`,
          dryRun 
        });
      }
    } catch (error: any) {
      console.error("File upload error:", error);
      
      // Handle multer-specific errors with proper status codes
      if (error.code === 'LIMIT_FILE_SIZE') {
        return res.status(413).json({ error: "File too large (max 10MB)" });
      }
      if (error.message.includes('Only Excel files')) {
        return res.status(400).json({ error: error.message });
      }
      
      res.status(500).json({ error: error.message || "File upload failed" });
    }
  });

  router.get("/api/sync/file-url", async (req, res) => {
    try {
      const fileUrl = githubSync.getFileUrl();
      res.json({ fileUrl });
    } catch (error: any) {
      console.error("Error getting file URL:", error);
      res.status(500).json({ error: "Failed to get file URL" });
    }
  });

  router.post("/api/sync/import-costs", async (req, res) => {
    try {
      await githubSync.syncIncurredCostsFromGitHub();
      res.json({ success: true, message: "Incurred costs imported from Project Data file" });
    } catch (error: any) {
      console.error("Error importing incurred costs:", error);
      res.status(500).json({ error: error.message || "Failed to import incurred costs" });
    }
  });

  // Settings routes
  router.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getSettings();
      res.json(settings);
    } catch (error: any) {
      console.error("Error getting settings:", error);
      res.status(500).json({ error: "Failed to get settings" });
    }
  });

  router.get("/api/settings/:key", async (req, res) => {
    try {
      const setting = await storage.getSetting(req.params.key);
      if (!setting) {
        return res.status(404).json({ error: "Setting not found" });
      }
      res.json(setting);
    } catch (error: any) {
      console.error("Error getting setting:", error);
      res.status(500).json({ error: "Failed to get setting" });
    }
  });

  router.put("/api/settings", async (req, res) => {
    try {
      const settingData = insertSettingsSchema.parse(req.body);
      const setting = await storage.upsertSetting(settingData);
      
      // Clear calculation service cache when settings are updated
      // This ensures overhead calculations use the latest settings values
      const { calculationService } = await import('./services/calculationService');
      calculationService.clearSettingsCache();
      
      res.json(setting);
    } catch (error: any) {
      console.error("Error upserting setting:", error);
      res.status(400).json({ error: error.message || "Failed to save setting" });
    }
  });

  router.delete("/api/settings/:key", async (req, res) => {
    try {
      await storage.deleteSetting(req.params.key);
      res.json({ success: true, message: "Setting deleted" });
    } catch (error: any) {
      console.error("Error deleting setting:", error);
      res.status(500).json({ error: "Failed to delete setting" });
    }
  });

  // User routes
  router.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json({ id: user.id, username: user.username });
    } catch (error: any) {
      console.error("Registration error:", error);
      res.status(400).json({ error: "Registration failed" });
    }
  });

  // Program routes
  router.get("/api/programs", async (req, res) => {
    try {
      const programs = await storage.getPrograms();
      res.json(programs);
    } catch (error: any) {
      console.error("Error fetching programs:", error);
      res.status(500).json({ error: "Failed to fetch programs" });
    }
  });

  router.get("/api/programs/:id", async (req, res) => {
    try {
      const program = await storage.getProgram(req.params.id);
      if (!program) {
        return res.status(404).json({ error: "Program not found" });
      }
      res.json(program);
    } catch (error: any) {
      console.error("Error fetching program:", error);
      res.status(500).json({ error: "Failed to fetch program" });
    }
  });

  router.post("/api/programs", async (req, res) => {
    try {
      const programData = insertProgramSchema.parse(req.body);
      const program = await storage.createProgram(programData);
      res.status(201).json(program);
    } catch (error: any) {
      console.error("Error creating program:", error);
      res.status(400).json({ error: error.message || "Failed to create program" });
    }
  });

  router.put("/api/programs/:id", async (req, res) => {
    try {
      const programData = insertProgramSchema.partial().parse(req.body);
      const program = await storage.updateProgram(req.params.id, programData);
      res.json(program);
    } catch (error: any) {
      console.error("Error updating program:", error);
      res.status(400).json({ error: "Failed to update program" });
    }
  });

  router.delete("/api/programs/:id", async (req, res) => {
    try {
      await storage.deleteProgram(req.params.id);
      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting program:", error);
      res.status(500).json({ error: "Failed to delete program" });
    }
  });

  // Program details with calculations
  router.get("/api/programs/:id/details", async (req, res) => {
    try {
      const details = await storage.getProgramWithDetails(req.params.id);
      res.json(details);
    } catch (error: any) {
      console.error("Error fetching program details:", error);
      res.status(500).json({ error: "Failed to fetch program details" });
    }
  });

  // Milestone routes
  router.get("/api/programs/:programId/milestones", async (req, res) => {
    try {
      const milestones = await storage.getMilestonesByProgram(req.params.programId);
      res.json(milestones);
    } catch (error: any) {
      console.error("Error fetching milestones:", error);
      res.status(500).json({ error: "Failed to fetch milestones" });
    }
  });

  router.post("/api/milestones", async (req, res) => {
    try {
      const milestoneData = insertMilestoneSchema.parse(req.body);
      const milestone = await storage.createMilestone(milestoneData);
      res.status(201).json(milestone);
    } catch (error: any) {
      console.error("Error creating milestone:", error);
      res.status(400).json({ error: "Failed to create milestone" });
    }
  });

  router.put("/api/milestones/:id", async (req, res) => {
    try {
      const milestoneData = insertMilestoneSchema.partial().parse(req.body);
      const milestone = await storage.updateMilestone(req.params.id, milestoneData);
      res.json(milestone);
    } catch (error: any) {
      console.error("Error updating milestone:", error);
      res.status(400).json({ error: "Failed to update milestone" });
    }
  });

  // Work Breakdown Structure routes
  router.get("/api/programs/:programId/wbs", async (req, res) => {
    try {
      const wbs = await storage.getWbsByProgram(req.params.programId);
      res.json(wbs);
    } catch (error: any) {
      console.error("Error fetching WBS:", error);
      res.status(500).json({ error: "Failed to fetch WBS" });
    }
  });

  router.post("/api/wbs", async (req, res) => {
    try {
      const wbsData = insertWbsSchema.parse(req.body);
      const wbs = await storage.createWbs(wbsData);
      res.status(201).json(wbs);
    } catch (error: any) {
      console.error("Error creating WBS:", error);
      res.status(400).json({ error: "Failed to create WBS" });
    }
  });

  router.put("/api/wbs/:id", async (req, res) => {
    try {
      const wbsData = insertWbsSchema.partial().parse(req.body);
      const wbs = await storage.updateWbs(req.params.id, wbsData);
      res.json(wbs);
    } catch (error: any) {
      console.error("Error updating WBS:", error);
      res.status(400).json({ error: "Failed to update WBS" });
    }
  });

  // Resource routes
  router.get("/api/resources", async (req, res) => {
    try {
      const resources = await storage.getResources();
      res.json(resources);
    } catch (error: any) {
      console.error("Error fetching resources:", error);
      res.status(500).json({ error: "Failed to fetch resources" });
    }
  });

  router.post("/api/resources", async (req, res) => {
    try {
      const resourceData = insertResourceSchema.parse(req.body);
      const resource = await storage.createResource(resourceData);
      res.status(201).json(resource);
    } catch (error: any) {
      console.error("Error creating resource:", error);
      res.status(400).json({ error: "Failed to create resource" });
    }
  });

  // Resource allocation routes
  router.get("/api/resource-allocations", async (req, res) => {
    try {
      const allocations = await storage.getResourceAllocations();
      res.json(allocations);
    } catch (error: any) {
      console.error("Error fetching resource allocations:", error);
      res.status(500).json({ error: "Failed to fetch resource allocations" });
    }
  });

  router.post("/api/resource-allocations", async (req, res) => {
    try {
      const allocationData = insertResourceAllocationSchema.parse(req.body);
      const allocation = await storage.createResourceAllocation(allocationData);
      res.status(201).json(allocation);
    } catch (error: any) {
      console.error("Error creating resource allocation:", error);
      res.status(400).json({ error: "Failed to create resource allocation" });
    }
  });

  // Budget routes
  router.get("/api/programs/:programId/budget", async (req, res) => {
    try {
      const budget = await storage.getBudgetEntries(req.params.programId);
      res.json(budget);
    } catch (error: any) {
      console.error("Error fetching budget:", error);
      res.status(500).json({ error: "Failed to fetch budget" });
    }
  });

  router.post("/api/budget-entries", async (req, res) => {
    try {
      const budgetData = insertBudgetEntrySchema.parse(req.body);
      const budget = await storage.createBudgetEntry(budgetData);
      res.status(201).json(budget);
    } catch (error: any) {
      console.error("Error creating budget entry:", error);
      res.status(400).json({ error: "Failed to create budget entry" });
    }
  });

  // Expense routes
  router.get("/api/programs/:programId/expenses", async (req, res) => {
    try {
      const expenses = await storage.getExpensesByProgram(req.params.programId);
      res.json(expenses);
    } catch (error: any) {
      console.error("Error fetching expenses:", error);
      res.status(500).json({ error: "Failed to fetch expenses" });
    }
  });

  router.post("/api/expenses", async (req, res) => {
    try {
      const expenseData = insertExpenseSchema.parse(req.body);
      const expense = await storage.createExpense(expenseData);
      res.status(201).json(expense);
    } catch (error: any) {
      console.error("Error creating expense:", error);
      res.status(400).json({ error: "Failed to create expense" });
    }
  });

  // Document routes
  router.get("/api/programs/:programId/documents", async (req, res) => {
    try {
      const documents = await storage.getDocumentsByProgram(req.params.programId);
      res.json(documents);
    } catch (error: any) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ error: "Failed to fetch documents" });
    }
  });

  router.post("/api/documents", async (req, res) => {
    try {
      const documentData = insertDocumentSchema.parse(req.body);
      const document = await storage.createDocument(documentData);
      res.status(201).json(document);
    } catch (error: any) {
      console.error("Error creating document:", error);
      res.status(400).json({ error: "Failed to create document" });
    }
  });

  // CDRL routes
  router.get("/api/programs/:programId/cdrls", async (req, res) => {
    try {
      const cdrls = await storage.getCdrlsByProgram(req.params.programId);
      res.json(cdrls);
    } catch (error: any) {
      console.error("Error fetching CDRLs:", error);
      res.status(500).json({ error: "Failed to fetch CDRLs" });
    }
  });

  router.post("/api/cdrls", async (req, res) => {
    try {
      const cdrlData = insertCdrlItemSchema.parse(req.body);
      const cdrl = await storage.createCdrl(cdrlData);
      res.status(201).json(cdrl);
    } catch (error: any) {
      console.error("Error creating CDRL:", error);
      res.status(400).json({ error: "Failed to create CDRL" });
    }
  });

  // Risk routes
  router.get("/api/risks", async (req, res) => {
    try {
      const risks = await storage.getRisks();
      res.json(risks);
    } catch (error: any) {
      console.error("Error fetching risks:", error);
      res.status(500).json({ error: "Failed to fetch risks" });
    }
  });

  router.post("/api/risks", async (req, res) => {
    try {
      const riskData = insertRiskSchema.parse(req.body);
      const risk = await storage.createRisk(riskData);
      res.status(201).json(risk);
    } catch (error: any) {
      console.error("Error creating risk:", error);
      res.status(400).json({ error: "Failed to create risk" });
    }
  });

  router.get("/api/risks/:id/assessments", async (req, res) => {
    try {
      const assessments = await storage.getRiskAssessmentsByRisk(req.params.id);
      res.json(assessments);
    } catch (error: any) {
      console.error("Error fetching risk assessments:", error);
      res.status(500).json({ error: "Failed to fetch risk assessments" });
    }
  });

  router.post("/api/risks/:id/assessments", async (req, res) => {
    try {
      const assessmentData = insertRiskAssessmentSchema.parse(req.body);
      assessmentData.riskId = req.params.id;
      const assessment = await storage.createRiskAssessment(assessmentData);
      res.status(201).json(assessment);
    } catch (error: any) {
      console.error("Error creating risk assessment:", error);
      res.status(400).json({ error: "Failed to create risk assessment" });
    }
  });

  router.get("/api/risks/:id/mitigations", async (req, res) => {
    try {
      const mitigations = await storage.getRiskMitigationsByRisk(req.params.id);
      res.json(mitigations);
    } catch (error: any) {
      console.error("Error fetching risk mitigations:", error);
      res.status(500).json({ error: "Failed to fetch risk mitigations" });
    }
  });

  router.post("/api/risks/:id/mitigations", async (req, res) => {
    try {
      const mitigationData = insertRiskMitigationSchema.parse(req.body);
      mitigationData.riskId = req.params.id;
      const mitigation = await storage.createRiskMitigation(mitigationData);
      res.status(201).json(mitigation);
    } catch (error: any) {
      console.error("Error creating risk mitigation:", error);
      res.status(400).json({ error: "Failed to create risk mitigation" });
    }
  });

  router.get("/api/risks/:id/impacts", async (req, res) => {
    try {
      const impacts = await storage.getRiskImpactsByRisk(req.params.id);
      res.json(impacts);
    } catch (error: any) {
      console.error("Error fetching risk impacts:", error);
      res.status(500).json({ error: "Failed to fetch risk impacts" });
    }
  });

  router.post("/api/risks/:id/impacts", async (req, res) => {
    try {
      const impactData = insertRiskImpactSchema.parse(req.body);
      impactData.riskId = req.params.id;
      const impact = await storage.createRiskImpact(impactData);
      res.status(201).json(impact);
    } catch (error: any) {
      console.error("Error creating risk impact:", error);
      res.status(400).json({ error: "Failed to create risk impact" });
    }
  });

  // Program-level risk analytics
  router.get("/api/programs/:id/risk-analytics", async (req, res) => {
    try {
      const analytics = await storage.getProgramRiskAnalytics(req.params.id);
      res.json(analytics);
    } catch (error: any) {
      console.error("Error fetching program risk analytics:", error);
      res.status(500).json({ error: "Failed to fetch program risk analytics" });
    }
  });

  // Portfolio-level risk summary
  router.get("/api/portfolio/risk-summary", async (req, res) => {
    try {
      const summary = await storage.getPortfolioRiskSummary();
      res.json(summary);
    } catch (error: any) {
      console.error("Error fetching portfolio risk summary:", error);
      res.status(500).json({ error: "Failed to fetch portfolio risk summary" });
    }
  });

  // Dashboard routes
  router.get("/api/dashboard/metrics", async (req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json(metrics);
    } catch (error: any) {
      console.error("Error fetching dashboard metrics:", error);
      res.status(500).json({ error: "Failed to fetch dashboard metrics" });
    }
  });

  router.get("/api/dashboard/resource-utilization", async (req, res) => {
    try {
      const utilization = await storage.getResourceUtilization();
      res.json(utilization);
    } catch (error: any) {
      console.error("Error fetching resource utilization:", error);
      res.status(500).json({ error: "Failed to fetch resource utilization" });
    }
  });

  router.get("/api/dashboard/budget-summary", async (req, res) => {
    try {
      const summary = await storage.getBudgetSummary();
      res.json(summary);
    } catch (error: any) {
      console.error("Error fetching budget summary:", error);
      res.status(500).json({ error: "Failed to fetch budget summary" });
    }
  });

  // Executive dashboard routes
  router.get("/api/executive/portfolio-health", async (req, res) => {
    try {
      const health = await storage.getPortfolioHealth();
      res.json(health);
    } catch (error: any) {
      console.error("Error fetching portfolio health:", error);
      res.status(500).json({ error: "Failed to fetch portfolio health" });
    }
  });

  router.get("/api/executive/performance-scorecards", async (req, res) => {
    try {
      const scorecards = await storage.getPerformanceScorecards();
      res.json(scorecards);
    } catch (error: any) {
      console.error("Error fetching performance scorecards:", error);
      res.status(500).json({ error: "Failed to fetch performance scorecards" });
    }
  });

  router.get("/api/executive/trend-analysis/:period", async (req, res) => {
    try {
      const period = req.params.period as '3months' | '6months' | '12months';
      const trends = await storage.getTrendAnalysis(period);
      res.json(trends);
    } catch (error: any) {
      console.error("Error fetching trend analysis:", error);
      res.status(500).json({ error: "Failed to fetch trend analysis" });
    }
  });

  return router;
}