import {
  users,
  programs,
  milestones,
  workBreakdownStructure,
  resources,
  resourceAllocations,
  budgetEntries,
  expenses,
  documents,
  cdrlItems,
  documentApprovals,
  risks,
  riskAssessments,
  riskMitigations,
  riskImpacts,
  settings,
  type User,
  type InsertUser,
  type Program,
  type InsertProgram,
  type Milestone,
  type InsertMilestone,
  type WorkBreakdownStructure,
  type InsertWorkBreakdownStructure,
  type Resource,
  type InsertResource,
  type ResourceAllocation,
  type InsertResourceAllocation,
  type BudgetEntry,
  type InsertBudgetEntry,
  type Expense,
  type InsertExpense,
  type Document,
  type InsertDocument,
  type CdrlItem,
  type InsertCdrlItem,
  type DocumentApproval,
  type InsertDocumentApproval,
  type Risk,
  type InsertRisk,
  type RiskAssessment,
  type InsertRiskAssessment,
  type RiskMitigation,
  type InsertRiskMitigation,
  type RiskImpact,
  type InsertRiskImpact,
  type Settings,
  type InsertSettings,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc, sql } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Program methods
  getPrograms(): Promise<Program[]>;
  getProgram(id: string): Promise<Program | undefined>;
  createProgram(program: InsertProgram): Promise<Program>;
  updateProgram(id: string, program: Partial<Program>): Promise<Program>;
  deleteProgram(id: string): Promise<void>;
  getProgramWithDetails(id: string): Promise<any>;

  // Milestone methods
  getMilestonesByProgram(programId: string): Promise<Milestone[]>;
  createMilestone(milestone: InsertMilestone): Promise<Milestone>;
  updateMilestone(id: string, milestone: Partial<Milestone>): Promise<Milestone>;

  // WBS methods
  getWbsByProgram(programId: string): Promise<WorkBreakdownStructure[]>;
  createWbs(wbs: InsertWorkBreakdownStructure): Promise<WorkBreakdownStructure>;
  updateWbs(id: string, wbs: Partial<WorkBreakdownStructure>): Promise<WorkBreakdownStructure>;

  // Resource methods
  getResources(): Promise<Resource[]>;
  createResource(resource: InsertResource): Promise<Resource>;
  getResourceAllocations(programId?: string): Promise<any[]>;
  createResourceAllocation(allocation: InsertResourceAllocation): Promise<ResourceAllocation>;

  // Budget methods
  getBudgetEntries(programId: string): Promise<BudgetEntry[]>;
  createBudgetEntry(entry: InsertBudgetEntry): Promise<BudgetEntry>;
  getExpenses(programId: string): Promise<Expense[]>;
  createExpense(expense: InsertExpense): Promise<Expense>;

  // Dashboard methods
  getDashboardMetrics(): Promise<any>;
  getResourceUtilization(): Promise<any>;
  getBudgetSummary(programId?: string): Promise<any>;

  // Document methods
  getDocuments(programId?: string): Promise<Document[]>;
  getDocument(id: string): Promise<Document | undefined>;
  createDocument(document: InsertDocument): Promise<Document>;
  updateDocument(id: string, document: Partial<Document>): Promise<Document>;
  deleteDocument(id: string): Promise<void>;
  getDocumentsByMilestone(milestoneId: string): Promise<Document[]>;
  getDocumentsByWbs(wbsId: string): Promise<Document[]>;

  // CDRL methods
  getCdrlItems(programId?: string): Promise<CdrlItem[]>;
  getCdrlItem(id: string): Promise<CdrlItem | undefined>;
  createCdrlItem(cdrlItem: InsertCdrlItem): Promise<CdrlItem>;
  updateCdrlItem(id: string, cdrlItem: Partial<CdrlItem>): Promise<CdrlItem>;
  getCdrlsByMilestone(milestone: string): Promise<CdrlItem[]>;

  // Document approval methods
  getDocumentApprovals(documentId: string): Promise<DocumentApproval[]>;
  createDocumentApproval(approval: InsertDocumentApproval): Promise<DocumentApproval>;
  updateDocumentApproval(id: string, approval: Partial<DocumentApproval>): Promise<DocumentApproval>;

  // Risk assessment methods
  getRisks(programId?: string): Promise<Risk[]>;
  getRisk(id: string): Promise<Risk | undefined>;
  createRisk(risk: InsertRisk): Promise<Risk>;
  updateRisk(id: string, risk: Partial<Risk>): Promise<Risk>;
  deleteRisk(id: string): Promise<void>;
  getRisksByCategory(programId: string, category: string): Promise<Risk[]>;
  getRisksByStatus(programId: string, status: string): Promise<Risk[]>;

  // Risk assessment methods
  getRiskAssessments(riskId: string): Promise<RiskAssessment[]>;
  getCurrentRiskAssessment(riskId: string): Promise<RiskAssessment | undefined>;
  createRiskAssessment(assessment: InsertRiskAssessment): Promise<RiskAssessment>;
  updateRiskAssessment(id: string, assessment: Partial<RiskAssessment>): Promise<RiskAssessment>;

  // Risk mitigation methods
  getRiskMitigations(riskId: string): Promise<RiskMitigation[]>;
  createRiskMitigation(mitigation: InsertRiskMitigation): Promise<RiskMitigation>;
  updateRiskMitigation(id: string, mitigation: Partial<RiskMitigation>): Promise<RiskMitigation>;
  getMitigationsByStatus(programId: string, status: string): Promise<RiskMitigation[]>;

  // Risk impact methods
  getRiskImpacts(riskId: string): Promise<RiskImpact[]>;
  createRiskImpact(impact: InsertRiskImpact): Promise<RiskImpact>;
  updateRiskImpact(id: string, impact: Partial<RiskImpact>): Promise<RiskImpact>;

  // Risk analytics methods
  getRiskAnalytics(programId: string): Promise<any>;
  getPortfolioRiskSummary(): Promise<any>;
  
  // Settings methods
  getSettings(): Promise<Settings[]>;
  getSetting(key: string): Promise<Settings | undefined>;
  upsertSetting(setting: InsertSettings): Promise<Settings>;
  deleteSetting(key: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Program methods
  async getPrograms(): Promise<Program[]> {
    return await db.select().from(programs).orderBy(desc(programs.createdAt));
  }

  async getProgram(id: string): Promise<Program | undefined> {
    const [program] = await db.select().from(programs).where(eq(programs.id, id));
    return program || undefined;
  }

  async createProgram(program: InsertProgram): Promise<Program> {
    const [newProgram] = await db
      .insert(programs)
      .values({
        ...program,
        updatedAt: sql`now()`,
      })
      .returning();
    return newProgram;
  }

  async updateProgram(id: string, program: Partial<Program>): Promise<Program> {
    const [updatedProgram] = await db
      .update(programs)
      .set({
        ...program,
        updatedAt: sql`now()`,
      })
      .where(eq(programs.id, id))
      .returning();
    return updatedProgram;
  }

  async deleteProgram(id: string): Promise<void> {
    await db.delete(programs).where(eq(programs.id, id));
  }

  async getProgramWithDetails(id: string): Promise<any> {
    const program = await this.getProgram(id);
    if (!program) return null;

    const programMilestones = await this.getMilestonesByProgram(id);
    const programWbs = await this.getWbsByProgram(id);
    const programBudget = await this.getBudgetEntries(id);
    const programExpenses = await this.getExpenses(id);
    const allocations = await this.getResourceAllocations(id);

    return {
      ...program,
      milestones: programMilestones,
      wbs: programWbs,
      budgetEntries: programBudget,
      expenses: programExpenses,
      resourceAllocations: allocations,
    };
  }

  // Milestone methods
  async getMilestonesByProgram(programId: string): Promise<Milestone[]> {
    return await db.select().from(milestones).where(eq(milestones.programId, programId));
  }

  async createMilestone(milestone: InsertMilestone): Promise<Milestone> {
    const [newMilestone] = await db
      .insert(milestones)
      .values(milestone)
      .returning();
    return newMilestone;
  }

  async updateMilestone(id: string, milestone: Partial<Milestone>): Promise<Milestone> {
    const [updatedMilestone] = await db
      .update(milestones)
      .set(milestone)
      .where(eq(milestones.id, id))
      .returning();
    return updatedMilestone;
  }

  // WBS methods
  async getWbsByProgram(programId: string): Promise<WorkBreakdownStructure[]> {
    return await db.select().from(workBreakdownStructure).where(eq(workBreakdownStructure.programId, programId));
  }

  async createWbs(wbs: InsertWorkBreakdownStructure): Promise<WorkBreakdownStructure> {
    const [newWbs] = await db
      .insert(workBreakdownStructure)
      .values(wbs)
      .returning();
    return newWbs;
  }

  async updateWbs(id: string, wbs: Partial<WorkBreakdownStructure>): Promise<WorkBreakdownStructure> {
    const [updatedWbs] = await db
      .update(workBreakdownStructure)
      .set(wbs)
      .where(eq(workBreakdownStructure.id, id))
      .returning();
    return updatedWbs;
  }

  // Resource methods
  async getResources(): Promise<Resource[]> {
    return await db.select().from(resources).where(eq(resources.isActive, true));
  }

  async createResource(resource: InsertResource): Promise<Resource> {
    const [newResource] = await db
      .insert(resources)
      .values(resource)
      .returning();
    return newResource;
  }

  async getResourceAllocations(programId?: string): Promise<any[]> {
    let query = db
      .select({
        id: resourceAllocations.id,
        programId: resourceAllocations.programId,
        programName: programs.name,
        resourceId: resourceAllocations.resourceId,
        resourceName: resources.name,
        resourceType: resources.type,
        capacity: resources.capacity,
        allocatedHours: resourceAllocations.allocatedHours,
        startDate: resourceAllocations.startDate,
        endDate: resourceAllocations.endDate,
      })
      .from(resourceAllocations)
      .leftJoin(programs, eq(resourceAllocations.programId, programs.id))
      .leftJoin(resources, eq(resourceAllocations.resourceId, resources.id));

    if (programId) {
      query = query.where(eq(resourceAllocations.programId, programId));
    }

    return await query;
  }

  async createResourceAllocation(allocation: InsertResourceAllocation): Promise<ResourceAllocation> {
    const [newAllocation] = await db
      .insert(resourceAllocations)
      .values(allocation)
      .returning();
    return newAllocation;
  }

  // Budget methods
  async getBudgetEntries(programId: string): Promise<BudgetEntry[]> {
    return await db.select().from(budgetEntries).where(eq(budgetEntries.programId, programId));
  }

  async createBudgetEntry(entry: InsertBudgetEntry): Promise<BudgetEntry> {
    const [newEntry] = await db
      .insert(budgetEntries)
      .values(entry)
      .returning();
    return newEntry;
  }

  async getExpenses(programId: string): Promise<Expense[]> {
    return await db.select().from(expenses)
      .where(eq(expenses.programId, programId))
      .orderBy(desc(expenses.date));
  }

  async createExpense(expense: InsertExpense): Promise<Expense> {
    const [newExpense] = await db
      .insert(expenses)
      .values(expense)
      .returning();
    return newExpense;
  }

  // Dashboard methods
  async getDashboardMetrics(): Promise<any> {
    const totalPrograms = await db.select({ count: sql<number>`count(*)` }).from(programs);
    const activePrograms = await db.select({ count: sql<number>`count(*)` }).from(programs).where(eq(programs.status, 'active'));
    const totalBudget = await db.select({ total: sql<number>`sum(${programs.totalBudget})` }).from(programs);
    const budgetSpent = await db.select({ total: sql<number>`sum(${programs.budgetSpent})` }).from(programs);
    
    const onSchedulePrograms = await db
      .select({ count: sql<number>`count(distinct ${programs.id})` })
      .from(programs)
      .leftJoin(milestones, eq(programs.id, milestones.programId))
      .where(and(
        eq(programs.status, 'active'),
        sql`${milestones.targetDate} >= ${milestones.actualDate} OR ${milestones.actualDate} IS NULL`
      ));

    return {
      totalPrograms: totalPrograms[0]?.count || 0,
      activePrograms: activePrograms[0]?.count || 0,
      totalBudget: totalBudget[0]?.total || 0,
      budgetSpent: budgetSpent[0]?.total || 0,
      onSchedulePrograms: onSchedulePrograms[0]?.count || 0,
    };
  }

  async getResourceUtilization(): Promise<any> {
    const utilization = await db
      .select({
        resourceType: resources.type,
        totalCapacity: sql<number>`sum(${resources.capacity})`,
        allocatedHours: sql<number>`sum(${resourceAllocations.allocatedHours})`,
      })
      .from(resources)
      .leftJoin(resourceAllocations, eq(resources.id, resourceAllocations.resourceId))
      .where(eq(resources.isActive, true))
      .groupBy(resources.type);

    return utilization.map(item => ({
      resourceType: item.resourceType,
      totalCapacity: item.totalCapacity || 0,
      allocatedHours: item.allocatedHours || 0,
      utilizationPercentage: item.totalCapacity > 0 
        ? Math.round((item.allocatedHours / item.totalCapacity) * 100)
        : 0,
    }));
  }

  async getBudgetSummary(programId?: string): Promise<any> {
    // Import calculation service for overhead calculations
    const { calculationService } = await import('./services/calculationService');
    
    let budgetQuery = db
      .select({
        programId: programs.id,
        programName: programs.name,
        totalBudget: programs.totalBudget,
        budgetSpent: programs.budgetSpent,
        laborCosts: sql<number>`coalesce(sum(case when ${budgetEntries.category} = 'labor' then ${budgetEntries.actualAmount} else 0 end), 0)`,
        materialCosts: sql<number>`coalesce(sum(case when ${budgetEntries.category} = 'materials' then ${budgetEntries.actualAmount} else 0 end), 0)`,
        otherCosts: sql<number>`coalesce(sum(case when ${budgetEntries.category} = 'other' then ${budgetEntries.actualAmount} else 0 end), 0)`,
      })
      .from(programs)
      .leftJoin(budgetEntries, eq(programs.id, budgetEntries.programId))
      .groupBy(programs.id, programs.name, programs.totalBudget, programs.budgetSpent);

    if (programId) {
      budgetQuery = budgetQuery.where(eq(programs.id, programId));
    }

    const results = await budgetQuery;
    
    // Apply overhead calculations to each program using configurable settings
    const enhancedResults = await Promise.all(results.map(async (result) => {
      const laborCosts = result.laborCosts || 0;
      const materialCosts = result.materialCosts || 0;
      const otherCosts = result.otherCosts || 0;
      
      // Calculate burdened costs using overhead multipliers from settings
      const burdendLabor = await calculationService.calculateBurdendLaborCost(laborCosts);
      const burdendMaterials = await calculationService.calculateBurdendExpenses(materialCosts);
      
      return {
        ...result,
        // Original unburdened costs
        unburdendLaborCosts: laborCosts,
        unburdendMaterialCosts: materialCosts,
        unburdendOtherCosts: otherCosts,
        // Burdened costs with overhead multipliers
        burdendLaborCosts: burdendLabor,
        burdendMaterialCosts: burdendMaterials,
        burdendOtherCosts: otherCosts, // Other costs don't get overhead multiplier
        // Totals
        totalUnburdendCosts: laborCosts + materialCosts + otherCosts,
        totalBurdendCosts: burdendLabor + burdendMaterials + otherCosts
      };
    }));
    
    return enhancedResults;
  }

  // Document methods
  async getDocuments(programId?: string): Promise<Document[]> {
    let query = db.select().from(documents).orderBy(desc(documents.createdAt));
    
    if (programId) {
      return await query.where(eq(documents.programId, programId));
    }
    
    return await query;
  }

  async getDocument(id: string): Promise<Document | undefined> {
    const [document] = await db.select().from(documents).where(eq(documents.id, id));
    return document || undefined;
  }

  async createDocument(document: InsertDocument): Promise<Document> {
    const [newDocument] = await db
      .insert(documents)
      .values({
        ...document,
        updatedAt: sql`now()`,
      })
      .returning();
    return newDocument;
  }

  async updateDocument(id: string, document: Partial<Document>): Promise<Document> {
    const [updatedDocument] = await db
      .update(documents)
      .set({
        ...document,
        updatedAt: sql`now()`,
      })
      .where(eq(documents.id, id))
      .returning();
    return updatedDocument;
  }

  async deleteDocument(id: string): Promise<void> {
    await db.delete(documents).where(eq(documents.id, id));
  }

  async getDocumentsByMilestone(milestoneId: string): Promise<Document[]> {
    return await db.select().from(documents)
      .where(eq(documents.linkedMilestoneId, milestoneId))
      .orderBy(desc(documents.createdAt));
  }

  async getDocumentsByWbs(wbsId: string): Promise<Document[]> {
    return await db.select().from(documents)
      .where(eq(documents.linkedWbsId, wbsId))
      .orderBy(desc(documents.createdAt));
  }

  // CDRL methods
  async getCdrlItems(programId?: string): Promise<CdrlItem[]> {
    let query = db.select().from(cdrlItems).orderBy(desc(cdrlItems.createdAt));
    
    if (programId) {
      return await query.where(eq(cdrlItems.programId, programId));
    }
    
    return await query;
  }

  async getCdrlItem(id: string): Promise<CdrlItem | undefined> {
    const [cdrlItem] = await db.select().from(cdrlItems).where(eq(cdrlItems.id, id));
    return cdrlItem || undefined;
  }

  async createCdrlItem(cdrlItem: InsertCdrlItem): Promise<CdrlItem> {
    const [newCdrlItem] = await db
      .insert(cdrlItems)
      .values({
        ...cdrlItem,
        updatedAt: sql`now()`,
      })
      .returning();
    return newCdrlItem;
  }

  async updateCdrlItem(id: string, cdrlItem: Partial<CdrlItem>): Promise<CdrlItem> {
    const [updatedCdrlItem] = await db
      .update(cdrlItems)
      .set({
        ...cdrlItem,
        updatedAt: sql`now()`,
      })
      .where(eq(cdrlItems.id, id))
      .returning();
    return updatedCdrlItem;
  }

  async getCdrlsByMilestone(milestone: string): Promise<CdrlItem[]> {
    return await db.select().from(cdrlItems)
      .where(eq(cdrlItems.linkedMilestone, milestone))
      .orderBy(desc(cdrlItems.createdAt));
  }

  // Document approval methods
  async getDocumentApprovals(documentId: string): Promise<DocumentApproval[]> {
    return await db.select().from(documentApprovals)
      .where(eq(documentApprovals.documentId, documentId))
      .orderBy(documentApprovals.approvalOrder);
  }

  async createDocumentApproval(approval: InsertDocumentApproval): Promise<DocumentApproval> {
    const [newApproval] = await db
      .insert(documentApprovals)
      .values(approval)
      .returning();
    return newApproval;
  }

  async updateDocumentApproval(id: string, approval: Partial<DocumentApproval>): Promise<DocumentApproval> {
    const [updatedApproval] = await db
      .update(documentApprovals)
      .set(approval)
      .where(eq(documentApprovals.id, id))
      .returning();
    return updatedApproval;
  }

  // Risk assessment methods
  async getRisks(programId?: string): Promise<Risk[]> {
    let query = db.select().from(risks).orderBy(desc(risks.createdAt));
    
    if (programId) {
      return await query.where(eq(risks.programId, programId));
    }
    
    return await query;
  }

  async getRisk(id: string): Promise<Risk | undefined> {
    const [risk] = await db.select().from(risks).where(eq(risks.id, id));
    return risk || undefined;
  }

  async createRisk(risk: InsertRisk): Promise<Risk> {
    const [newRisk] = await db
      .insert(risks)
      .values({
        ...risk,
        updatedAt: sql`now()`,
      })
      .returning();
    return newRisk;
  }

  async updateRisk(id: string, risk: Partial<Risk>): Promise<Risk> {
    const [updatedRisk] = await db
      .update(risks)
      .set({
        ...risk,
        updatedAt: sql`now()`,
      })
      .where(eq(risks.id, id))
      .returning();
    return updatedRisk;
  }

  async deleteRisk(id: string): Promise<void> {
    await db.delete(risks).where(eq(risks.id, id));
  }

  async getRisksByCategory(programId: string, category: string): Promise<Risk[]> {
    return await db.select().from(risks)
      .where(and(eq(risks.programId, programId), eq(risks.category, category)))
      .orderBy(desc(risks.createdAt));
  }

  async getRisksByStatus(programId: string, status: string): Promise<Risk[]> {
    return await db.select().from(risks)
      .where(and(eq(risks.programId, programId), eq(risks.status, status)))
      .orderBy(desc(risks.identifiedDate));
  }

  // Risk assessment methods
  async getRiskAssessments(riskId: string): Promise<RiskAssessment[]> {
    return await db.select().from(riskAssessments)
      .where(eq(riskAssessments.riskId, riskId))
      .orderBy(desc(riskAssessments.assessmentDate));
  }

  async getCurrentRiskAssessment(riskId: string): Promise<RiskAssessment | undefined> {
    const [assessment] = await db.select().from(riskAssessments)
      .where(and(eq(riskAssessments.riskId, riskId), eq(riskAssessments.isCurrentAssessment, true)));
    return assessment || undefined;
  }

  async createRiskAssessment(assessment: InsertRiskAssessment): Promise<RiskAssessment> {
    // Mark all existing assessments as non-current
    await db.update(riskAssessments)
      .set({ isCurrentAssessment: false })
      .where(eq(riskAssessments.riskId, assessment.riskId));

    const [newAssessment] = await db
      .insert(riskAssessments)
      .values({
        ...assessment,
        isCurrentAssessment: true,
      })
      .returning();
    return newAssessment;
  }

  async updateRiskAssessment(id: string, assessment: Partial<RiskAssessment>): Promise<RiskAssessment> {
    const [updatedAssessment] = await db
      .update(riskAssessments)
      .set(assessment)
      .where(eq(riskAssessments.id, id))
      .returning();
    return updatedAssessment;
  }

  // Risk mitigation methods
  async getRiskMitigations(riskId: string): Promise<RiskMitigation[]> {
    return await db.select().from(riskMitigations)
      .where(eq(riskMitigations.riskId, riskId))
      .orderBy(desc(riskMitigations.createdAt));
  }

  async createRiskMitigation(mitigation: InsertRiskMitigation): Promise<RiskMitigation> {
    const [newMitigation] = await db
      .insert(riskMitigations)
      .values({
        ...mitigation,
        updatedAt: sql`now()`,
      })
      .returning();
    return newMitigation;
  }

  async updateRiskMitigation(id: string, mitigation: Partial<RiskMitigation>): Promise<RiskMitigation> {
    const [updatedMitigation] = await db
      .update(riskMitigations)
      .set({
        ...mitigation,
        updatedAt: sql`now()`,
      })
      .where(eq(riskMitigations.id, id))
      .returning();
    return updatedMitigation;
  }

  async getMitigationsByStatus(programId: string, status: string): Promise<RiskMitigation[]> {
    return await db.select().from(riskMitigations)
      .leftJoin(risks, eq(riskMitigations.riskId, risks.id))
      .where(and(eq(risks.programId, programId), eq(riskMitigations.status, status)))
      .then(results => results.map(result => result.risk_mitigations));
  }

  // Risk impact methods
  async getRiskImpacts(riskId: string): Promise<RiskImpact[]> {
    return await db.select().from(riskImpacts)
      .where(eq(riskImpacts.riskId, riskId))
      .orderBy(desc(riskImpacts.calculatedAt));
  }

  async createRiskImpact(impact: InsertRiskImpact): Promise<RiskImpact> {
    const [newImpact] = await db
      .insert(riskImpacts)
      .values(impact)
      .returning();
    return newImpact;
  }

  async updateRiskImpact(id: string, impact: Partial<RiskImpact>): Promise<RiskImpact> {
    const [updatedImpact] = await db
      .update(riskImpacts)
      .set(impact)
      .where(eq(riskImpacts.id, id))
      .returning();
    return updatedImpact;
  }

  // Risk analytics methods
  async getRiskAnalytics(programId: string): Promise<any> {
    const programRisks = await db.select().from(risks).where(eq(risks.programId, programId));
    
    const risksByCategory = programRisks.reduce((acc: any, risk) => {
      acc[risk.category] = (acc[risk.category] || 0) + 1;
      return acc;
    }, {});

    const risksBySeverity = programRisks.reduce((acc: any, risk) => {
      acc[risk.severity] = (acc[risk.severity] || 0) + 1;
      return acc;
    }, {});

    const risksByStatus = programRisks.reduce((acc: any, risk) => {
      acc[risk.status] = (acc[risk.status] || 0) + 1;
      return acc;
    }, {});

    // Get current assessments for all risks
    const assessments = await db.select().from(riskAssessments)
      .leftJoin(risks, eq(riskAssessments.riskId, risks.id))
      .where(and(eq(risks.programId, programId), eq(riskAssessments.isCurrentAssessment, true)));

    const totalBudgetImpact = assessments.reduce((sum, assessment) => {
      return sum + parseFloat(assessment.risk_assessments?.budgetImpactAmount || "0");
    }, 0);

    const totalScheduleImpact = assessments.reduce((sum, assessment) => {
      return sum + (assessment.risk_assessments?.scheduleImpactDays || 0);
    }, 0);

    const averageRiskScore = assessments.length > 0 
      ? assessments.reduce((sum, assessment) => sum + (assessment.risk_assessments?.riskScore || 0), 0) / assessments.length
      : 0;

    return {
      totalRisks: programRisks.length,
      risksByCategory,
      risksBySeverity,
      risksByStatus,
      totalBudgetImpact,
      totalScheduleImpact,
      averageRiskScore: Math.round(averageRiskScore),
      highRiskCount: programRisks.filter(r => r.severity === 'critical' || r.severity === 'high').length,
      openRiskCount: programRisks.filter(r => r.status === 'open').length,
      escalationRequired: programRisks.filter(r => r.escalationRequired).length
    };
  }

  async getPortfolioRiskSummary(): Promise<any> {
    const allRisks = await db.select().from(risks);
    const allPrograms = await db.select().from(programs);

    const risksByProgram = allRisks.reduce((acc: any, risk) => {
      acc[risk.programId] = (acc[risk.programId] || 0) + 1;
      return acc;
    }, {});

    const criticalRisks = allRisks.filter(r => r.severity === 'critical').length;
    const highRisks = allRisks.filter(r => r.severity === 'high').length;
    const openRisks = allRisks.filter(r => r.status === 'open').length;
    const escalatedRisks = allRisks.filter(r => r.escalationRequired).length;

    return {
      totalPrograms: allPrograms.length,
      totalRisks: allRisks.length,
      criticalRisks,
      highRisks,
      openRisks,
      escalatedRisks,
      risksByProgram,
      averageRisksPerProgram: allPrograms.length > 0 ? Math.round(allRisks.length / allPrograms.length) : 0,
      portfolioRiskScore: Math.round((criticalRisks * 10 + highRisks * 7) / Math.max(allRisks.length, 1))
    };
  }

  // Settings methods
  async getSettings(): Promise<Settings[]> {
    return await db.select().from(settings).orderBy(settings.category, settings.key);
  }

  async getSetting(key: string): Promise<Settings | undefined> {
    const [setting] = await db.select().from(settings).where(eq(settings.key, key));
    return setting || undefined;
  }

  async upsertSetting(settingData: InsertSettings): Promise<Settings> {
    const existing = await this.getSetting(settingData.key);
    
    if (existing) {
      // Update existing setting
      const [updated] = await db
        .update(settings)
        .set({
          ...settingData,
          updatedAt: sql`now()`,
        })
        .where(eq(settings.key, settingData.key))
        .returning();
      return updated;
    } else {
      // Create new setting
      const [created] = await db
        .insert(settings)
        .values({
          ...settingData,
          updatedAt: sql`now()`,
        })
        .returning();
      return created;
    }
  }

  async deleteSetting(key: string): Promise<void> {
    await db.delete(settings).where(eq(settings.key, key));
  }
}

export const storage = new DatabaseStorage();
