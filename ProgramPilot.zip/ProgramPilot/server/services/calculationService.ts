import { Program, InsertMilestone, InsertWorkBreakdownStructure, Settings } from "@shared/schema";
import { storage } from "../storage";

interface WorkTypeConfig {
  baseHours: number;
  leadTimeDays: number;
  resourceType: string;
}

const WORK_TYPE_CONFIGS: Record<string, WorkTypeConfig> = {
  "design-assembly": {
    baseHours: 120,
    leadTimeDays: 30,
    resourceType: "hardware-engineer"
  },
  "verification-unit": {
    baseHours: 80,
    leadTimeDays: 20,
    resourceType: "test-engineer"
  },
  "qualification-unit": {
    baseHours: 100,
    leadTimeDays: 25,
    resourceType: "test-engineer"
  },
  "cdrl": {
    baseHours: 40,
    leadTimeDays: 10,
    resourceType: "software-engineer"
  },
  "drawing": {
    baseHours: 8,
    leadTimeDays: 2,
    resourceType: "hardware-engineer"
  },
  "verification-testing": {
    baseHours: 60,
    leadTimeDays: 15,
    resourceType: "test-engineer"
  },
  "qualification-testing": {
    baseHours: 80,
    leadTimeDays: 20,
    resourceType: "test-engineer"
  }
};

const MILESTONE_ORDER = ['PDR', 'CDR', 'TRR', 'QUAL', 'PRODUCTION'];
const MILESTONE_DEPENDENCIES: Record<string, string[]> = {
  'CDR': ['PDR'],
  'TRR': ['CDR'],
  'QUAL': ['TRR'],
  'PRODUCTION': ['QUAL']
};

class CalculationService {
  private settingsCache: { [key: string]: string } = {};
  private settingsCacheExpiry: number = 0;
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

  /**
   * Clear the settings cache to force refresh on next access
   */
  clearSettingsCache(): void {
    this.settingsCache = {};
    this.settingsCacheExpiry = 0;
  }

  /**
   * Get overhead calculation settings with caching
   */
  private async getOverheadSettings(): Promise<{ burdened_labor_multiplier: number; burdened_expenses_multiplier: number }> {
    const now = Date.now();
    
    // Check if cache is expired
    if (now > this.settingsCacheExpiry) {
      const settings = await storage.getSettings();
      this.settingsCache = {};
      settings.forEach(setting => {
        this.settingsCache[setting.key] = setting.value;
      });
      this.settingsCacheExpiry = now + this.CACHE_DURATION;
    }

    // Get values with defaults
    const burdened_labor_multiplier = parseFloat(this.settingsCache['burdened_labor_multiplier']) || 3.8;
    const burdened_expenses_multiplier = parseFloat(this.settingsCache['burdened_expenses_multiplier']) || 1.4;

    return { burdened_labor_multiplier, burdened_expenses_multiplier };
  }

  /**
   * Calculate burdened labor cost from unburdened labor cost
   */
  async calculateBurdendLaborCost(unburdendLaborCost: number): Promise<number> {
    const settings = await this.getOverheadSettings();
    return unburdendLaborCost * settings.burdened_labor_multiplier;
  }

  /**
   * Calculate burdened expenses from unburdened expenses
   */
  async calculateBurdendExpenses(unburdendExpenses: number): Promise<number> {
    const settings = await this.getOverheadSettings();
    return unburdendExpenses * settings.burdened_expenses_multiplier;
  }

  /**
   * Calculate total project costs with overhead multipliers
   */
  async calculateProjectCosts(laborCost: number, expenseCost: number): Promise<{
    unburdendLabor: number;
    burdendLabor: number;
    unburdendExpenses: number;
    burdendExpenses: number;
    totalUnburdend: number;
    totalBurdend: number;
  }> {
    const burdendLabor = await this.calculateBurdendLaborCost(laborCost);
    const burdendExpenses = await this.calculateBurdendExpenses(expenseCost);

    return {
      unburdendLabor: laborCost,
      burdendLabor,
      unburdendExpenses: expenseCost,
      burdendExpenses,
      totalUnburdend: laborCost + expenseCost,
      totalBurdend: burdendLabor + burdendExpenses
    };
  }

  /**
   * Generate program structure including milestones and WBS
   */
  async generateProgramStructure(program: Program) {
    const milestones = await this.generateMilestones(program);
    const wbs = await this.generateWBS(program);
    
    // Create milestones in database
    const createdMilestones = [];
    for (const milestone of milestones) {
      const created = await storage.createMilestone(milestone);
      createdMilestones.push(created);
    }
    
    // Create WBS entries in database
    const createdWBS = [];
    for (const wbsEntry of wbs) {
      const created = await storage.createWbs(wbsEntry);
      createdWBS.push(created);
    }
    
    return {
      milestones: createdMilestones,
      wbs: createdWBS
    };
  }

  /**
   * Generate milestones based on program inputs
   */
  private async generateMilestones(program: Program): Promise<InsertMilestone[]> {
    const milestones: InsertMilestone[] = [];
    
    // Generate standard milestones
    for (const milestoneName of MILESTONE_ORDER) {
      const milestone: InsertMilestone = {
        programId: program.id,
        name: milestoneName,
        type: milestoneName.toLowerCase(),
        targetDate: this.calculateMilestoneDate(program, milestoneName),
        status: 'planned',
        progress: 0,
        dependencies: MILESTONE_DEPENDENCIES[milestoneName] || []
      };
      
      milestones.push(milestone);
    }
    
    return milestones;
  }

  /**
   * Calculate target date for a milestone based on program complexity and duration multipliers
   */
  private calculateMilestoneDate(program: Program, milestoneName: string): Date {
    const baseDate = new Date();
    const complexityMultiplier = parseFloat(program.complexityMultiplier) || 1.0;
    const durationMultiplier = parseFloat(program.durationMultiplier) || 1.0;
    
    // Base timeline in days for each milestone
    const baseTimelines: Record<string, number> = {
      'PDR': 90,
      'CDR': 180,
      'TRR': 270,
      'QUAL': 360,
      'PRODUCTION': 450
    };
    
    const baseDays = baseTimelines[milestoneName] || 90;
    const adjustedDays = Math.round(baseDays * complexityMultiplier * durationMultiplier);
    
    const targetDate = new Date(baseDate);
    targetDate.setDate(baseDate.getDate() + adjustedDays);
    
    return targetDate;
  }

  /**
   * Generate Work Breakdown Structure based on program inputs
   */
  private async generateWBS(program: Program): Promise<InsertWorkBreakdownStructure[]> {
    const wbs: InsertWorkBreakdownStructure[] = [];
    const complexityMultiplier = parseFloat(program.complexityMultiplier) || 1.0;
    
    // Generate WBS for design assemblies
    for (let i = 1; i <= program.designAssemblies; i++) {
      const taskCode = `DA-${i.toString().padStart(3, '0')}`;
      const config = WORK_TYPE_CONFIGS["design-assembly"];
      const estimatedHours = config.baseHours * complexityMultiplier;
      
      wbs.push({
        programId: program.id,
        taskName: `Design Assembly ${i}`,
        taskCode,
        phase: 'PDR',
        estimatedHours: estimatedHours.toString(),
        actualHours: "0",
        startDate: new Date(),
        endDate: this.addDays(new Date(), Math.round(config.leadTimeDays * complexityMultiplier)),
        dependencies: [],
        resourceType: config.resourceType,
        status: 'not-started'
      });
    }

    // Generate WBS for verification units
    for (let i = 1; i <= program.verificationUnits; i++) {
      const taskCode = `VU-${i.toString().padStart(3, '0')}`;
      const config = WORK_TYPE_CONFIGS["verification-unit"];
      const estimatedHours = config.baseHours * complexityMultiplier;
      
      wbs.push({
        programId: program.id,
        taskName: `Verification Unit ${i}`,
        taskCode,
        phase: 'CDR',
        estimatedHours: estimatedHours.toString(),
        actualHours: "0",
        startDate: this.calculateMilestoneDate(program, 'CDR'),
        endDate: this.addDays(this.calculateMilestoneDate(program, 'CDR'), Math.round(config.leadTimeDays * complexityMultiplier)),
        dependencies: ['DA-001'], // Depends on first design assembly
        resourceType: config.resourceType,
        status: 'not-started'
      });

      // Add verification testing
      const testConfig = WORK_TYPE_CONFIGS["verification-testing"];
      const testTaskCode = `VT-${i.toString().padStart(3, '0')}`;
      
      wbs.push({
        programId: program.id,
        taskName: `Verification Testing ${i}`,
        taskCode: testTaskCode,
        phase: 'TRR',
        estimatedHours: (testConfig.baseHours * complexityMultiplier).toString(),
        actualHours: "0",
        startDate: this.calculateMilestoneDate(program, 'TRR'),
        endDate: this.addDays(this.calculateMilestoneDate(program, 'TRR'), Math.round(testConfig.leadTimeDays * complexityMultiplier)),
        dependencies: [taskCode],
        resourceType: testConfig.resourceType,
        status: 'not-started'
      });
    }

    // Generate WBS for qualification units
    for (let i = 1; i <= program.qualificationUnits; i++) {
      const taskCode = `QU-${i.toString().padStart(3, '0')}`;
      const config = WORK_TYPE_CONFIGS["qualification-unit"];
      const estimatedHours = config.baseHours * complexityMultiplier;
      
      wbs.push({
        programId: program.id,
        taskName: `Qualification Unit ${i}`,
        taskCode,
        phase: 'QUAL',
        estimatedHours: estimatedHours.toString(),
        actualHours: "0",
        startDate: this.calculateMilestoneDate(program, 'QUAL'),
        endDate: this.addDays(this.calculateMilestoneDate(program, 'QUAL'), Math.round(config.leadTimeDays * complexityMultiplier)),
        dependencies: [`VU-${i.toString().padStart(3, '0')}`],
        resourceType: config.resourceType,
        status: 'not-started'
      });

      // Add qualification testing
      const testConfig = WORK_TYPE_CONFIGS["qualification-testing"];
      const testTaskCode = `QT-${i.toString().padStart(3, '0')}`;
      
      wbs.push({
        programId: program.id,
        taskName: `Qualification Testing ${i}`,
        taskCode: testTaskCode,
        phase: 'QUAL',
        estimatedHours: (testConfig.baseHours * complexityMultiplier).toString(),
        actualHours: "0",
        startDate: this.addDays(this.calculateMilestoneDate(program, 'QUAL'), 30),
        endDate: this.addDays(this.calculateMilestoneDate(program, 'QUAL'), 30 + Math.round(testConfig.leadTimeDays * complexityMultiplier)),
        dependencies: [taskCode],
        resourceType: testConfig.resourceType,
        status: 'not-started'
      });
    }

    // Generate WBS for CDRLs
    for (let i = 1; i <= program.cdrlsCount; i++) {
      const taskCode = `CDRL-${i.toString().padStart(3, '0')}`;
      const config = WORK_TYPE_CONFIGS["cdrl"];
      const estimatedHours = config.baseHours * complexityMultiplier;
      
      wbs.push({
        programId: program.id,
        taskName: `CDRL Document ${i}`,
        taskCode,
        phase: 'PDR',
        estimatedHours: estimatedHours.toString(),
        actualHours: "0",
        startDate: new Date(),
        endDate: this.addDays(new Date(), Math.round(config.leadTimeDays * complexityMultiplier)),
        dependencies: [],
        resourceType: config.resourceType,
        status: 'not-started'
      });
    }

    // Generate WBS for drawings
    for (let i = 1; i <= program.drawingsCount; i++) {
      const taskCode = `DWG-${i.toString().padStart(3, '0')}`;
      const config = WORK_TYPE_CONFIGS["drawing"];
      const estimatedHours = config.baseHours * complexityMultiplier;
      
      wbs.push({
        programId: program.id,
        taskName: `Drawing ${i}`,
        taskCode,
        phase: 'CDR',
        estimatedHours: estimatedHours.toString(),
        actualHours: "0",
        startDate: this.calculateMilestoneDate(program, 'CDR'),
        endDate: this.addDays(this.calculateMilestoneDate(program, 'CDR'), Math.round(config.leadTimeDays * complexityMultiplier)),
        dependencies: [],
        resourceType: config.resourceType,
        status: 'not-started'
      });
    }

    return wbs;
  }

  /**
   * Recalculate program schedules and budgets
   */
  async recalculateProgram(program: Program) {
    const wbsEntries = await storage.getWbsByProgram(program.id);
    const milestones = await storage.getMilestonesByProgram(program.id);
    
    let totalEstimatedHours = 0;
    let totalActualHours = 0;
    
    for (const wbs of wbsEntries) {
      totalEstimatedHours += parseFloat(wbs.estimatedHours) || 0;
      totalActualHours += parseFloat(wbs.actualHours) || 0;
    }
    
    // Calculate EAC (Estimate at Completion)
    const budgetSpent = parseFloat(program.budgetSpent) || 0;
    const totalBudget = parseFloat(program.totalBudget) || 0;
    const progressRatio = totalActualHours > 0 ? totalActualHours / totalEstimatedHours : 0;
    const eac = progressRatio > 0 ? budgetSpent / progressRatio : totalBudget;
    
    // Calculate ETC (Estimate to Complete)
    const etc = Math.max(0, eac - budgetSpent);
    
    return {
      totalEstimatedHours,
      totalActualHours,
      progressPercentage: Math.round((totalActualHours / totalEstimatedHours) * 100),
      eac,
      etc,
      budgetVariance: totalBudget - eac,
      scheduleVariance: this.calculateScheduleVariance(milestones)
    };
  }

  private calculateScheduleVariance(milestones: any[]): number {
    let totalVariance = 0;
    let count = 0;
    
    for (const milestone of milestones) {
      if (milestone.targetDate && milestone.actualDate) {
        const target = new Date(milestone.targetDate);
        const actual = new Date(milestone.actualDate);
        const variance = (actual.getTime() - target.getTime()) / (1000 * 60 * 60 * 24); // days
        totalVariance += variance;
        count++;
      }
    }
    
    return count > 0 ? totalVariance / count : 0;
  }

  private addDays(date: Date, days: number): Date {
    const result = new Date(date);
    result.setDate(date.getDate() + days);
    return result;
  }
}

export const calculationService = new CalculationService();
