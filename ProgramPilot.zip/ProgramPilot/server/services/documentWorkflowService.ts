import { storage } from "../storage";
import type { DocumentApproval, Document, CdrlItem } from "@shared/schema";

export class DocumentWorkflowService {
  /**
   * Updates document status based on approval workflow state
   */
  async processApprovalUpdate(documentId: string, approvalId: string): Promise<void> {
    try {
      // Get all approvals for this document
      const approvals = await storage.getDocumentApprovals(documentId);
      const document = await storage.getDocument(documentId);
      
      if (!document) {
        throw new Error(`Document ${documentId} not found`);
      }

      // Calculate new document status based on approval state
      const newStatus = this.calculateDocumentStatus(approvals);
      
      // Update document status if changed
      if (document.status !== newStatus) {
        await storage.updateDocument(documentId, { 
          status: newStatus,
          approvedDate: newStatus === 'approved' ? new Date() : undefined
        });

        // If document is linked to a CDRL, update CDRL status too
        const cdrlItems = await storage.getCdrlItems();
        const linkedCdrl = cdrlItems.find(cdrl => cdrl.documentId === documentId);
        
        if (linkedCdrl) {
          await this.updateCdrlStatus(linkedCdrl, newStatus);
        }
      }
    } catch (error) {
      console.error('Error processing approval update:', error);
      throw error;
    }
  }

  /**
   * Calculate document status based on approval workflow
   */
  private calculateDocumentStatus(approvals: DocumentApproval[]): string {
    if (approvals.length === 0) {
      return 'draft';
    }

    // Check if any required approvals are rejected
    const rejectedRequired = approvals.some(
      approval => approval.isRequired && approval.status === 'rejected'
    );
    if (rejectedRequired) {
      return 'rejected';
    }

    // Check if any required approvals are pending
    const pendingRequired = approvals.some(
      approval => approval.isRequired && approval.status === 'pending'
    );
    if (pendingRequired) {
      return 'in-review';
    }

    // Check if all required approvals are approved
    const requiredApprovals = approvals.filter(approval => approval.isRequired);
    const approvedRequired = requiredApprovals.filter(approval => approval.status === 'approved');
    
    if (requiredApprovals.length > 0 && approvedRequired.length === requiredApprovals.length) {
      return 'approved';
    }

    return 'in-review';
  }

  /**
   * Update CDRL status based on document status
   */
  private async updateCdrlStatus(cdrl: CdrlItem, documentStatus: string): Promise<void> {
    let cdrlStatus = cdrl.status;
    
    switch (documentStatus) {
      case 'approved':
        cdrlStatus = 'approved';
        await storage.updateCdrlItem(cdrl.id, {
          status: cdrlStatus,
          approvalDate: new Date(),
          submissionCount: cdrl.submissionCount + 1,
          lastSubmissionDate: new Date()
        });
        break;
      case 'rejected':
        cdrlStatus = 'rejected';
        await storage.updateCdrlItem(cdrl.id, { status: cdrlStatus });
        break;
      case 'in-review':
        cdrlStatus = 'submitted';
        await storage.updateCdrlItem(cdrl.id, { 
          status: cdrlStatus,
          lastSubmissionDate: new Date()
        });
        break;
      default:
        cdrlStatus = 'in-progress';
        await storage.updateCdrlItem(cdrl.id, { status: cdrlStatus });
    }
  }

  /**
   * Validate approval workflow order
   */
  async validateApprovalOrder(documentId: string, newApproval: DocumentApproval): Promise<boolean> {
    const existingApprovals = await storage.getDocumentApprovals(documentId);
    
    // Check if previous required approvals in order are completed
    const previousApprovals = existingApprovals.filter(
      approval => approval.approvalOrder < newApproval.approvalOrder && approval.isRequired
    );
    
    const incompletePrevious = previousApprovals.some(
      approval => approval.status === 'pending'
    );
    
    return !incompletePrevious;
  }

  /**
   * Get approval workflow status for a document
   */
  async getWorkflowStatus(documentId: string): Promise<{
    currentStatus: string;
    nextApprover?: string;
    completedApprovals: number;
    totalRequiredApprovals: number;
    pendingApprovals: DocumentApproval[];
  }> {
    const approvals = await storage.getDocumentApprovals(documentId);
    const requiredApprovals = approvals.filter(approval => approval.isRequired);
    const completedApprovals = approvals.filter(
      approval => approval.status === 'approved' || approval.status === 'rejected'
    );
    const pendingApprovals = approvals.filter(approval => approval.status === 'pending');
    
    // Find next approver in order
    const nextPending = pendingApprovals
      .sort((a, b) => a.approvalOrder - b.approvalOrder)[0];

    return {
      currentStatus: this.calculateDocumentStatus(approvals),
      nextApprover: nextPending?.approverName,
      completedApprovals: completedApprovals.length,
      totalRequiredApprovals: requiredApprovals.length,
      pendingApprovals
    };
  }

  /**
   * Initiate approval workflow for a document
   */
  async initiateApprovalWorkflow(documentId: string, approvers: Array<{
    approverName: string;
    approverRole: string;
    approvalType: string;
    approvalOrder: number;
    isRequired: boolean;
  }>): Promise<void> {
    // Create approval records for all approvers
    for (const approver of approvers) {
      await storage.createDocumentApproval({
        documentId,
        approverName: approver.approverName,
        approverRole: approver.approverRole,
        approvalType: approver.approvalType,
        status: 'pending',
        approvalOrder: approver.approvalOrder,
        isRequired: approver.isRequired
      });
    }

    // Update document status to in-review
    await storage.updateDocument(documentId, { 
      status: 'in-review',
      submittedDate: new Date()
    });
  }
}

export const documentWorkflowService = new DocumentWorkflowService();