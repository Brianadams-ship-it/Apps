import { Octokit } from '@octokit/rest';
import * as XLSX from 'xlsx';
import type { IStorage } from '../storage';

let connectionSettings: any;

async function getAccessToken() {
  if (connectionSettings && connectionSettings.settings.expires_at && new Date(connectionSettings.settings.expires_at).getTime() > Date.now()) {
    return connectionSettings.settings.access_token;
  }
  
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=github',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  const accessToken = connectionSettings?.settings?.access_token || connectionSettings.settings?.oauth?.credentials?.access_token;

  if (!connectionSettings || !accessToken) {
    throw new Error('GitHub not connected');
  }
  return accessToken;
}

// WARNING: Never cache this client.
// Access tokens expire, so a new client must be created each time.
// Always call this function again to get a fresh client.
export async function getUncachableGitHubClient() {
  const accessToken = await getAccessToken();
  return new Octokit({ auth: accessToken });
}

export interface SyncStatus {
  lastSyncAt: Date | null;
  lastExportAt: Date | null;
  lastImportAt: Date | null;
  fileSHA: string | null;
  errors: string[];
  isExporting: boolean;
  isImporting: boolean;
}

export class GitHubSyncService {
  private storage: IStorage;
  private owner = 'Brianadams-ship-it';
  private repo = 'Apps';
  private filePath = 'master-data/program-portfolio.xlsx';
  private projectDataFilePath = 'Project Data.xlsx';
  private status: SyncStatus = {
    lastSyncAt: null,
    lastExportAt: null,
    lastImportAt: null,
    fileSHA: null,
    errors: [],
    isExporting: false,
    isImporting: false
  };

  constructor(storage: IStorage) {
    this.storage = storage;
  }

  getStatus(): SyncStatus {
    return { ...this.status };
  }

  updateImportStatus(): void {
    this.status.lastImportAt = new Date();
    this.status.lastSyncAt = new Date();
  }

  async exportToExcel(): Promise<Buffer> {
    console.log('Starting Excel export...');
    this.status.isExporting = true;
    this.status.errors = [];

    try {
      const ExcelJS = await import('exceljs');
      const workbook = new ExcelJS.default.Workbook();
      workbook.creator = 'Program Management Dashboard';
      workbook.created = new Date();

      // Programs sheet
      const programsSheet = workbook.addWorksheet('Programs');
      const programs = await this.storage.getPrograms();
      
      // Add headers for programs
      programsSheet.columns = [
        { header: 'ID', key: 'id', width: 40 },
        { header: 'Program ID', key: 'programId', width: 20 },
        { header: 'Name', key: 'name', width: 30 },
        { header: 'Description', key: 'description', width: 50 },
        { header: 'Phase', key: 'phase', width: 20 },
        { header: 'Total Budget', key: 'totalBudget', width: 15 },
        { header: 'Budget Spent', key: 'budgetSpent', width: 15 },
        { header: 'Status', key: 'status', width: 15 },
        { header: 'Created At', key: 'createdAt', width: 20 },
        { header: 'Updated At', key: 'updatedAt', width: 20 }
      ];

      // Add program data
      programs.forEach(program => {
        programsSheet.addRow({
          id: program.id,
          programId: program.programId,
          name: program.name,
          description: program.description,
          phase: program.phase,
          totalBudget: program.totalBudget,
          budgetSpent: program.budgetSpent,
          status: program.status,
          createdAt: program.createdAt,
          updatedAt: program.updatedAt
        });
      });

      // Milestones sheet
      const milestonesSheet = workbook.addWorksheet('Milestones');
      const allMilestones: any[] = [];
      for (const program of programs) {
        const programMilestones = await this.storage.getMilestonesByProgram(program.id);
        allMilestones.push(...programMilestones);
      }
      
      milestonesSheet.columns = [
        { header: 'ID', key: 'id', width: 40 },
        { header: 'Program ID', key: 'programId', width: 40 },
        { header: 'Name', key: 'name', width: 30 },
        { header: 'Type', key: 'type', width: 15 },
        { header: 'Target Date', key: 'targetDate', width: 15 },
        { header: 'Actual Date', key: 'actualDate', width: 15 },
        { header: 'Status', key: 'status', width: 15 },
        { header: 'Progress', key: 'progress', width: 15 }
      ];

      allMilestones.forEach((milestone: any) => {
        milestonesSheet.addRow({
          id: milestone.id,
          programId: milestone.programId,
          name: milestone.name,
          type: milestone.type,
          targetDate: milestone.targetDate,
          actualDate: milestone.actualDate,
          status: milestone.status,
          progress: milestone.progress
        });
      });

      // Work Breakdown Structure sheet
      const wbsSheet = workbook.addWorksheet('WBS');
      const allWbsItems: any[] = [];
      for (const program of programs) {
        const programWbs = await this.storage.getWbsByProgram(program.id);
        allWbsItems.push(...programWbs);
      }
      
      wbsSheet.columns = [
        { header: 'ID', key: 'id', width: 40 },
        { header: 'Program ID', key: 'programId', width: 40 },
        { header: 'Task Name', key: 'taskName', width: 30 },
        { header: 'Task Code', key: 'taskCode', width: 20 },
        { header: 'Phase', key: 'phase', width: 15 },
        { header: 'Estimated Hours', key: 'estimatedHours', width: 15 },
        { header: 'Actual Hours', key: 'actualHours', width: 15 },
        { header: 'Start Date', key: 'startDate', width: 15 },
        { header: 'End Date', key: 'endDate', width: 15 },
        { header: 'Resource Type', key: 'resourceType', width: 20 },
        { header: 'Status', key: 'status', width: 15 }
      ];

      allWbsItems.forEach((wbs: any) => {
        wbsSheet.addRow({
          id: wbs.id,
          programId: wbs.programId,
          taskName: wbs.taskName,
          taskCode: wbs.taskCode,
          phase: wbs.phase,
          estimatedHours: wbs.estimatedHours,
          actualHours: wbs.actualHours,
          startDate: wbs.startDate,
          endDate: wbs.endDate,
          resourceType: wbs.resourceType,
          status: wbs.status
        });
      });

      // Resources sheet
      const resourcesSheet = workbook.addWorksheet('Resources');
      const resources = await this.storage.getResources();
      
      resourcesSheet.columns = [
        { header: 'ID', key: 'id', width: 40 },
        { header: 'Name', key: 'name', width: 30 },
        { header: 'Type', key: 'type', width: 20 },
        { header: 'Capacity', key: 'capacity', width: 15 },
        { header: 'Hourly Rate', key: 'hourlyRate', width: 15 },
        { header: 'Is Active', key: 'isActive', width: 15 }
      ];

      resources.forEach(resource => {
        resourcesSheet.addRow({
          id: resource.id,
          name: resource.name,
          type: resource.type,
          capacity: resource.capacity,
          hourlyRate: resource.hourlyRate,
          isActive: resource.isActive
        });
      });

      // Resource Allocations sheet
      const allocationsSheet = workbook.addWorksheet('ResourceAllocations');
      const allocations = await this.storage.getResourceAllocations();
      
      allocationsSheet.columns = [
        { header: 'ID', key: 'id', width: 40 },
        { header: 'Program ID', key: 'programId', width: 40 },
        { header: 'Resource ID', key: 'resourceId', width: 40 },
        { header: 'Allocated Hours', key: 'allocatedHours', width: 15 },
        { header: 'Start Date', key: 'startDate', width: 15 },
        { header: 'End Date', key: 'endDate', width: 15 }
      ];

      allocations.forEach((allocation: any) => {
        allocationsSheet.addRow({
          id: allocation.id,
          programId: allocation.programId,
          resourceId: allocation.resourceId,
          allocatedHours: allocation.allocatedHours,
          startDate: allocation.startDate,
          endDate: allocation.endDate
        });
      });

      // Budget Entries sheet
      const budgetSheet = workbook.addWorksheet('BudgetEntries');
      // Get all budget entries across all programs
      const allBudgetEntries: any[] = [];
      for (const program of programs) {
        const programBudget = await this.storage.getBudgetEntries(program.id);
        allBudgetEntries.push(...programBudget);
      }
      
      budgetSheet.columns = [
        { header: 'ID', key: 'id', width: 40 },
        { header: 'Program ID', key: 'programId', width: 40 },
        { header: 'Category', key: 'category', width: 20 },
        { header: 'Description', key: 'description', width: 50 },
        { header: 'Planned Amount', key: 'plannedAmount', width: 15 },
        { header: 'Actual Amount', key: 'actualAmount', width: 15 },
        { header: 'Month', key: 'month', width: 10 },
        { header: 'Year', key: 'year', width: 10 }
      ];

      allBudgetEntries.forEach((budget: any) => {
        budgetSheet.addRow({
          id: budget.id,
          programId: budget.programId,
          category: budget.category,
          description: budget.description,
          plannedAmount: budget.plannedAmount,
          actualAmount: budget.actualAmount,
          month: budget.month,
          year: budget.year
        });
      });

      // Risks sheet
      const risksSheet = workbook.addWorksheet('Risks');
      const risks = await this.storage.getRisks();
      
      risksSheet.columns = [
        { header: 'ID', key: 'id', width: 40 },
        { header: 'Program ID', key: 'programId', width: 40 },
        { header: 'Risk ID', key: 'riskId', width: 20 },
        { header: 'Title', key: 'title', width: 30 },
        { header: 'Description', key: 'description', width: 50 },
        { header: 'Category', key: 'category', width: 15 },
        { header: 'Type', key: 'type', width: 15 },
        { header: 'Severity', key: 'severity', width: 15 },
        { header: 'Urgency', key: 'urgency', width: 15 },
        { header: 'Status', key: 'status', width: 15 },
        { header: 'Identified By', key: 'identifiedBy', width: 20 },
        { header: 'Updated At', key: 'updatedAt', width: 20 }
      ];

      risks.forEach(risk => {
        risksSheet.addRow({
          id: risk.id,
          programId: risk.programId,
          riskId: risk.riskId,
          title: risk.title,
          description: risk.description,
          category: risk.category,
          type: risk.type,
          severity: risk.severity,
          urgency: risk.urgency,
          status: risk.status,
          identifiedBy: risk.identifiedBy,
          updatedAt: risk.updatedAt
        });
      });

      // Settings sheet
      const settingsSheet = workbook.addWorksheet('Settings');
      const settings = await this.storage.getSettings();
      
      settingsSheet.columns = [
        { header: 'Key', key: 'key', width: 30 },
        { header: 'Value', key: 'value', width: 20 },
        { header: 'Description', key: 'description', width: 60 },
        { header: 'Category', key: 'category', width: 20 },
        { header: 'Data Type', key: 'dataType', width: 15 },
        { header: 'Updated At', key: 'updatedAt', width: 20 }
      ];

      settings.forEach(setting => {
        settingsSheet.addRow({
          key: setting.key,
          value: setting.value,
          description: setting.description,
          category: setting.category,
          dataType: setting.dataType,
          updatedAt: setting.updatedAt
        });
      });

      const buffer = await workbook.xlsx.writeBuffer();
      
      this.status.lastExportAt = new Date();
      this.status.isExporting = false;
      
      console.log('Excel export completed successfully');
      return Buffer.from(buffer);
      
    } catch (error: any) {
      this.status.isExporting = false;
      this.status.errors.push(`Export error: ${error.message}`);
      console.error('Excel export failed:', error);
      throw error;
    }
  }

  async uploadToGitHub(buffer: Buffer, message: string = 'Update program portfolio data'): Promise<void> {
    console.log('Uploading to GitHub...');
    
    try {
      const octokit = await getUncachableGitHubClient();
      const base64Content = buffer.toString('base64');

      // Check if file exists to get SHA for updating
      let sha: string | undefined;
      try {
        const existingFile = await octokit.rest.repos.getContent({
          owner: this.owner,
          repo: this.repo,
          path: this.filePath
        });
        
        if ('sha' in existingFile.data) {
          sha = existingFile.data.sha;
          this.status.fileSHA = sha;
        }
      } catch (error) {
        // File doesn't exist yet, no SHA needed
        console.log('File does not exist yet, creating new file');
      }

      const result = await octokit.rest.repos.createOrUpdateFileContents({
        owner: this.owner,
        repo: this.repo,
        path: this.filePath,
        message,
        content: base64Content,
        sha
      });

      this.status.fileSHA = result.data.content?.sha || null;
      console.log('Successfully uploaded to GitHub');
      
    } catch (error: any) {
      this.status.errors.push(`GitHub upload error: ${error.message}`);
      console.error('GitHub upload failed:', error);
      throw error;
    }
  }

  async downloadFromGitHub(): Promise<Buffer> {
    console.log('Downloading from GitHub...');
    
    try {
      const octokit = await getUncachableGitHubClient();
      
      const response = await octokit.rest.repos.getContent({
        owner: this.owner,
        repo: this.repo,
        path: this.filePath
      });

      if ('content' in response.data) {
        this.status.fileSHA = response.data.sha;
        const buffer = Buffer.from(response.data.content, 'base64');
        console.log('Successfully downloaded from GitHub');
        return buffer;
      } else {
        throw new Error('File content not found');
      }
      
    } catch (error: any) {
      this.status.errors.push(`GitHub download error: ${error.message}`);
      console.error('GitHub download failed:', error);
      throw error;
    }
  }

  async parseAndUpsert(buffer: Buffer, options: { dryRun?: boolean } = {}): Promise<{
    errors: string[];
    warnings: string[];
    stats: { [sheetName: string]: number };
  }> {
    console.log(`Starting Excel parse and upsert (dryRun: ${options.dryRun || false})...`);
    
    const result = {
      errors: [] as string[],
      warnings: [] as string[],
      stats: {} as { [sheetName: string]: number }
    };

    try {
      const workbook = XLSX.read(buffer, { type: 'buffer' });
      
      // Import Programs sheet
      if (workbook.SheetNames.includes('Programs')) {
        console.log('Processing Programs sheet...');
        const programsSheet = workbook.Sheets['Programs'];
        const programsData = XLSX.utils.sheet_to_json(programsSheet);
        let processedCount = 0;
        
        for (const row of programsData) {
          const program = row as any;
          if (program.ID) {
            try {
              if (!options.dryRun) {
                await this.storage.updateProgram(program.ID, {
                  programId: program['Program ID'],
                  name: program.Name,
                  description: program.Description,
                  phase: program.Phase,
                  totalBudget: program['Total Budget'],
                  budgetSpent: program['Budget Spent'],
                  status: program.Status
                });
              }
              processedCount++;
            } catch (error: any) {
              result.errors.push(`Program update error (ID: ${program.ID}): ${error.message}`);
            }
          } else if (program.Name) {
            // This is a new program row (no ID), could be template data
            result.warnings.push(`Program row without ID found: ${program.Name} - will be skipped`);
          }
        }
        result.stats['Programs'] = processedCount;
      }

      // Import Settings sheet
      if (workbook.SheetNames.includes('Settings')) {
        console.log('Processing Settings sheet...');
        const settingsSheet = workbook.Sheets['Settings'];
        const settingsData = XLSX.utils.sheet_to_json(settingsSheet);
        let processedCount = 0;
        
        for (const row of settingsData) {
          const settingRow = row as any;
          if (settingRow.Key && settingRow.Value !== undefined) {
            try {
              // Validate data type and coerce value if needed
              let processedValue = settingRow.Value;
              
              if (settingRow['Data Type'] === 'number') {
                const numValue = parseFloat(settingRow.Value);
                if (!isNaN(numValue)) {
                  processedValue = numValue.toString();
                } else {
                  result.errors.push(`Settings import error (Key: ${settingRow.Key}): Invalid numeric value`);
                  continue;
                }
              }

              if (!options.dryRun) {
                await this.storage.upsertSetting({
                  key: settingRow.Key,
                  value: processedValue,
                  description: settingRow.Description || '',
                  category: settingRow.Category || 'general',
                  dataType: settingRow['Data Type'] || 'string'
                });
              }
              processedCount++;
            } catch (error: any) {
              result.errors.push(`Settings import error (Key: ${settingRow.Key}): ${error.message}`);
            }
          }
        }
        result.stats['Settings'] = processedCount;
      }

      // Clear calculation service cache after settings import to ensure immediate consistency
      if (!options.dryRun && workbook.SheetNames.includes('Settings')) {
        const { calculationService } = await import('./calculationService');
        calculationService.clearSettingsCache();
      }

      // Import other sheets similarly...
      // For now, we'll focus on programs and settings as the main entities
      
      console.log(`Excel parse and upsert completed successfully (dryRun: ${options.dryRun || false})`);
      return result;
      
    } catch (error: any) {
      result.errors.push(`Parse error: ${error.message}`);
      console.error('Excel parse and upsert failed:', error);
      throw new Error(`Parse failed: ${error.message}`);
    }
  }

  async importFromExcel(buffer: Buffer): Promise<void> {
    console.log('Starting Excel import...');
    this.status.isImporting = true;
    this.status.errors = [];

    try {
      const result = await this.parseAndUpsert(buffer, { dryRun: false });
      
      // Update status with results
      this.status.errors = result.errors;
      this.status.lastImportAt = new Date();
      this.status.lastSyncAt = new Date();
      this.status.isImporting = false;
      
      if (result.warnings.length > 0) {
        console.log('Import warnings:', result.warnings);
      }
      
      console.log('Excel import completed successfully with stats:', result.stats);
      
    } catch (error: any) {
      this.status.isImporting = false;
      this.status.errors.push(`Import error: ${error.message}`);
      console.error('Excel import failed:', error);
      throw error;
    }
  }

  async syncFromGitHub(): Promise<void> {
    console.log('Starting sync from GitHub...');
    
    try {
      const buffer = await this.downloadFromGitHub();
      await this.importFromExcel(buffer);
      console.log('Sync from GitHub completed successfully');
    } catch (error: any) {
      console.error('Sync from GitHub failed:', error);
      throw error;
    }
  }

  async syncToGitHub(): Promise<void> {
    console.log('Starting sync to GitHub...');
    
    try {
      const buffer = await this.exportToExcel();
      await this.uploadToGitHub(buffer, `Sync: Export program data - ${new Date().toISOString()}`);
      console.log('Sync to GitHub completed successfully');
    } catch (error: any) {
      console.error('Sync to GitHub failed:', error);
      throw error;
    }
  }

  async generateTemplate(includeExamples: boolean = false): Promise<Buffer> {
    console.log(`Generating template (includeExamples: ${includeExamples})...`);
    
    try {
      const ExcelJS = await import('exceljs');
      const workbook = new ExcelJS.default.Workbook();
      workbook.creator = 'Program Management Dashboard';
      workbook.created = new Date();

      // Template Info sheet
      const infoSheet = workbook.addWorksheet('Template Info');
      infoSheet.columns = [
        { header: 'Property', key: 'property', width: 20 },
        { header: 'Value', key: 'value', width: 40 }
      ];
      infoSheet.addRow({ property: 'Template Version', value: '1.0' });
      infoSheet.addRow({ property: 'Generated At', value: new Date().toISOString() });
      infoSheet.addRow({ property: 'Instructions', value: 'Fill in the data sheets below and upload the file to import your data' });

      // Programs sheet
      const programsSheet = workbook.addWorksheet('Programs');
      programsSheet.columns = [
        { header: 'ID', key: 'id', width: 40 },
        { header: 'Program ID', key: 'programId', width: 20 },
        { header: 'Name', key: 'name', width: 30 },
        { header: 'Description', key: 'description', width: 50 },
        { header: 'Phase', key: 'phase', width: 20 },
        { header: 'Total Budget', key: 'totalBudget', width: 15 },
        { header: 'Budget Spent', key: 'budgetSpent', width: 15 },
        { header: 'Status', key: 'status', width: 15 },
        { header: 'Created At', key: 'createdAt', width: 20 },
        { header: 'Updated At', key: 'updatedAt', width: 20 }
      ];

      if (includeExamples) {
        programsSheet.addRow({
          id: 'example-uuid-1234-5678-90ab-cdef',
          programId: 'PROG-001',
          name: 'Example Program',
          description: 'This is an example program entry',
          phase: 'Development',
          totalBudget: '1000000',
          budgetSpent: '250000',
          status: 'In Progress',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      }

      // Settings sheet
      const settingsSheet = workbook.addWorksheet('Settings');
      settingsSheet.columns = [
        { header: 'Key', key: 'key', width: 30 },
        { header: 'Value', key: 'value', width: 20 },
        { header: 'Description', key: 'description', width: 50 },
        { header: 'Category', key: 'category', width: 20 },
        { header: 'Data Type', key: 'dataType', width: 15 }
      ];

      if (includeExamples) {
        settingsSheet.addRow({
          key: 'burdened_labor_multiplier',
          value: '3.8',
          description: 'Multiplier for burdened labor costs',
          category: 'overhead',
          dataType: 'number'
        });
        settingsSheet.addRow({
          key: 'expense_multiplier',
          value: '1.4',
          description: 'Multiplier for expense costs',
          category: 'overhead',
          dataType: 'number'
        });
      }

      // Add validation comments for categorical fields (since ExcelJS data validation can be problematic)
      programsSheet.getCell('E1').note = 'Valid values: Planning, Development, Testing, Deployment, Completed';
      programsSheet.getCell('H1').note = 'Valid values: Planning, In Progress, On Hold, Completed, Cancelled';
      settingsSheet.getCell('D1').note = 'Valid values: general, overhead, calculation, display';
      settingsSheet.getCell('E1').note = 'Valid values: string, number, boolean, date';

      const arrayBuffer = await workbook.xlsx.writeBuffer();
      const buffer = Buffer.isBuffer(arrayBuffer) ? arrayBuffer : Buffer.from(arrayBuffer);
      console.log(`Template generated successfully (${buffer.length} bytes)`);
      return buffer;
      
    } catch (error: any) {
      console.error('Template generation failed:', error);
      throw error;
    }
  }


  getFileUrl(): string {
    return `https://github.com/${this.owner}/${this.repo}/blob/main/${this.filePath}`;
  }

  getRawFileUrl(): string {
    return `https://raw.githubusercontent.com/${this.owner}/${this.repo}/main/${this.filePath}`;
  }

  async downloadProjectDataFromGitHub(): Promise<Buffer> {
    console.log('Downloading Project Data from GitHub...');
    
    try {
      const octokit = await getUncachableGitHubClient();
      
      const response = await octokit.rest.repos.getContent({
        owner: this.owner,
        repo: this.repo,
        path: this.projectDataFilePath
      });

      if ('content' in response.data) {
        const buffer = Buffer.from(response.data.content, 'base64');
        console.log('Successfully downloaded Project Data from GitHub');
        return buffer;
      } else {
        throw new Error('Project Data file content not found');
      }
      
    } catch (error: any) {
      this.status.errors.push(`Project Data download error: ${error.message}`);
      console.error('Project Data download failed:', error);
      throw error;
    }
  }

  async importIncurredCostsFromProjectData(buffer: Buffer): Promise<void> {
    console.log('Starting incurred costs import from Project Data...');
    
    try {
      const workbook = XLSX.read(buffer, { type: 'buffer' });
      
      // Find sheet with project/program cost data (try common sheet names)
      const possibleSheetNames = ['Sheet1', 'Projects', 'Programs', 'Cost Data', 'Data'];
      let dataSheet = null;
      let sheetName = '';
      
      for (const name of possibleSheetNames) {
        if (workbook.SheetNames.includes(name)) {
          dataSheet = workbook.Sheets[name];
          sheetName = name;
          break;
        }
      }
      
      // If no common names found, use the first sheet
      if (!dataSheet && workbook.SheetNames.length > 0) {
        sheetName = workbook.SheetNames[0];
        dataSheet = workbook.Sheets[sheetName];
      }
      
      if (!dataSheet) {
        throw new Error('No data sheet found in Project Data file');
      }
      
      console.log(`Processing sheet: ${sheetName}`);
      const costData = XLSX.utils.sheet_to_json(dataSheet);
      
      // Fetch programs once and create indexes for efficient lookup
      const programs = await this.storage.getPrograms();
      const programByProgramId = new Map();
      const programByName = new Map();
      const programById = new Map();
      
      programs.forEach(program => {
        if (program.programId) {
          programByProgramId.set(this.normalizeIdentifier(program.programId), program);
        }
        if (program.name) {
          programByName.set(this.normalizeIdentifier(program.name), program);
        }
        if (program.id) {
          programById.set(this.normalizeIdentifier(program.id), program);
        }
      });
      
      let updatedCount = 0;
      
      for (const row of costData) {
        const data = row as any;
        
        // Try to match program by various possible column names
        const programIdentifier = data['Program ID'] || data['ProgramID'] || data['Program'] || data['Project'] || 
                                 data['ID'] || data['Project ID'] || data['ProjectID'];
        const incurredCost = data['Incurred Cost'] || data['Cost to Date'] || data['Actual Cost'] || 
                            data['Spent'] || data['ITD'] || data['Cost'] || data['Actual'];
        
        if (programIdentifier && incurredCost !== undefined) {
          try {
            // Try to find program using normalized identifiers for better matching
            const normalizedId = this.normalizeIdentifier(programIdentifier);
            const program = programByProgramId.get(normalizedId) || 
                           programByName.get(normalizedId) || 
                           programById.get(normalizedId);
            
            if (program) {
              // Parse cost value with better number handling
              const costValue = this.parseCurrencyValue(incurredCost);
              
              if (!isNaN(costValue)) {
                await this.storage.updateProgram(program.id, {
                  budgetSpent: costValue.toString()
                });
                console.log(`Updated incurred cost for program ${program.name}: $${costValue.toLocaleString()}`);
                updatedCount++;
              } else {
                console.warn(`Invalid cost value for ${programIdentifier}: ${incurredCost}`);
              }
            } else {
              console.warn(`No matching program found for identifier: ${programIdentifier}`);
            }
          } catch (error: any) {
            this.status.errors.push(`Cost update error for ${programIdentifier}: ${error.message}`);
            console.error(`Failed to update cost for ${programIdentifier}:`, error);
          }
        }
      }
      
      console.log(`Incurred costs import completed successfully. Updated ${updatedCount} programs.`);
      
    } catch (error: any) {
      this.status.errors.push(`Incurred costs import error: ${error.message}`);
      console.error('Incurred costs import failed:', error);
      throw error;
    }
  }

  private normalizeIdentifier(identifier: string): string {
    return String(identifier).trim().toLowerCase();
  }

  private parseCurrencyValue(value: any): number {
    if (typeof value === 'number') {
      return value;
    }
    
    if (typeof value === 'string') {
      // Handle parentheses for negative values (e.g., "($1,234.56)" becomes -1234.56)
      let cleanValue = value.trim();
      let isNegative = false;
      
      if (cleanValue.startsWith('(') && cleanValue.endsWith(')')) {
        isNegative = true;
        cleanValue = cleanValue.slice(1, -1);
      }
      
      // Remove currency symbols, commas, and spaces
      cleanValue = cleanValue.replace(/[\$,£€¥\s]/g, '');
      
      const parsed = parseFloat(cleanValue);
      return isNegative ? -parsed : parsed;
    }
    
    return NaN;
  }

  async syncIncurredCostsFromGitHub(): Promise<void> {
    console.log('Starting incurred costs sync from GitHub...');
    
    try {
      const buffer = await this.downloadProjectDataFromGitHub();
      await this.importIncurredCostsFromProjectData(buffer);
      console.log('Incurred costs sync from GitHub completed successfully');
    } catch (error: any) {
      console.error('Incurred costs sync from GitHub failed:', error);
      throw error;
    }
  }
}