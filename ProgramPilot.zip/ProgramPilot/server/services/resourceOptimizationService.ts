import { db } from "../db";
import { resources, resourceAllocations, programs, workBreakdownStructure } from "../../shared/schema";
import { eq, and, gte, lte, sql } from "drizzle-orm";

export interface ResourceConflict {
  resourceId: string;
  resourceName: string;
  conflictDate: Date;
  overallocation: number;
  affectedPrograms: {
    programId: string;
    programName: string;
    allocatedHours: number;
    priority: number;
  }[];
  recommendations: OptimizationRecommendation[];
}

export interface OptimizationRecommendation {
  type: 'reschedule' | 'reassign' | 'split_task' | 'add_resource';
  description: string;
  impact: {
    scheduleDelay: number; // days
    costIncrease: number; // dollars
    riskLevel: 'low' | 'medium' | 'high';
  };
  actionPlan: {
    action: string;
    targetResourceId?: string;
    newStartDate?: Date;
    newEndDate?: Date;
    additionalCost?: number;
  };
}

export interface OptimizationSolution {
  totalConflicts: number;
  resolvedConflicts: number;
  overallUtilization: number;
  recommendations: OptimizationRecommendation[];
  implementationPlan: {
    phase: number;
    actions: OptimizationRecommendation[];
    timeline: string;
  }[];
}

class ResourceOptimizationService {
  
  /**
   * Detect resource conflicts across all programs
   */
  async detectResourceConflicts(dateRange?: { start: Date; end: Date }): Promise<ResourceConflict[]> {
    const startDate = dateRange?.start || new Date('2025-01-01');
    const endDate = dateRange?.end || new Date('2025-12-31');

    console.log("Detecting conflicts for date range:", { startDate, endDate });
    
    // Get all resource allocations within the date range
    const allocations = await db
      .select({
        resourceId: resourceAllocations.resourceId,
        resourceName: resources.name,
        resourceCapacity: resources.capacity,
        programId: resourceAllocations.programId,
        programName: programs.name,
        allocatedHours: resourceAllocations.allocatedHours,
        startDate: resourceAllocations.startDate,
        endDate: resourceAllocations.endDate,
        programPhase: programs.phase,
        totalBudget: programs.totalBudget,
      })
      .from(resourceAllocations)
      .innerJoin(resources, and(
        eq(resourceAllocations.resourceId, resources.id),
        eq(resources.isActive, true)
      ))
      .leftJoin(programs, eq(resourceAllocations.programId, programs.id))
      .where(
        and(
          // Check for overlapping allocations: start_date <= endDate AND end_date >= startDate
          lte(resourceAllocations.startDate, endDate),
          gte(resourceAllocations.endDate, startDate)
        )
      );

    console.log(`Found ${allocations.length} allocations to analyze`);
    if (allocations.length > 0) {
      console.log("First allocation sample:", allocations[0]);
    }

    // Group allocations by resource and detect conflicts for ALL resources
    const resourceGroups = this.groupAllocationsByResource(allocations);
    const conflicts: ResourceConflict[] = [];
    
    console.log(`Grouped into ${resourceGroups.size} resource groups`);

    for (const [resourceId, resourceAllocations] of Array.from(resourceGroups.entries())) {
      console.log(`Analyzing resource ${resourceId} with ${resourceAllocations.length} allocations`);
      const resourceCapacity = parseFloat(resourceAllocations[0].resourceCapacity);
      const conflictDates = this.findOverallocatedPeriods(resourceAllocations, resourceCapacity);

      for (const conflictDate of conflictDates) {
        const affectedPrograms = this.getAffectedPrograms(resourceAllocations, conflictDate);
        const totalAllocation = affectedPrograms.reduce((sum, p) => sum + p.allocatedHours, 0);
        const overallocation = totalAllocation - resourceCapacity;

        if (overallocation > 0) {
          const recommendations = await this.generateRecommendations(
            resourceId,
            conflictDate,
            affectedPrograms,
            overallocation
          );

          conflicts.push({
            resourceId,
            resourceName: resourceAllocations[0].resourceName,
            conflictDate,
            overallocation,
            affectedPrograms,
            recommendations,
          });
        }
      }
    }

    console.log(`Found conflicts: ${conflicts.length}`);
    return conflicts;
  }

  /**
   * Generate optimization solution for all detected conflicts
   */
  async generateOptimizationSolution(conflicts: ResourceConflict[]): Promise<OptimizationSolution> {
    const allRecommendations: OptimizationRecommendation[] = [];
    let resolvedConflicts = 0;

    // Handle case where conflicts is undefined or null
    if (!conflicts || !Array.isArray(conflicts)) {
      conflicts = [];
    }

    // Prioritize conflicts by impact and complexity
    const prioritizedConflicts = conflicts.sort((a, b) => {
      const impactA = a.overallocation * a.affectedPrograms.length;
      const impactB = b.overallocation * b.affectedPrograms.length;
      return impactB - impactA;
    });

    for (const conflict of prioritizedConflicts) {
      // Select best recommendation for each conflict
      const bestRecommendation = this.selectBestRecommendation(conflict.recommendations);
      if (bestRecommendation) {
        allRecommendations.push(bestRecommendation);
        if (bestRecommendation.impact.riskLevel !== 'high') {
          resolvedConflicts++;
        }
      }
    }

    // Calculate overall utilization
    const overallUtilization = await this.calculateOverallUtilization();

    // Create implementation plan
    const implementationPlan = this.createImplementationPlan(allRecommendations);

    return {
      totalConflicts: conflicts.length,
      resolvedConflicts,
      overallUtilization,
      recommendations: allRecommendations,
      implementationPlan,
    };
  }

  /**
   * Get available resources that can handle specific work types
   */
  async getAvailableResources(workType: string, dateRange: { start: Date; end: Date }): Promise<any[]> {
    return await db
      .select({
        id: resources.id,
        name: resources.name,
        type: resources.type,
        capacity: resources.capacity,
        hourlyRate: resources.hourlyRate,
        currentAllocation: sql<number>`COALESCE(SUM(${resourceAllocations.allocatedHours}), 0)`,
        availableCapacity: sql<number>`${resources.capacity} - COALESCE(SUM(${resourceAllocations.allocatedHours}), 0)`,
      })
      .from(resources)
      .leftJoin(
        resourceAllocations,
        and(
          eq(resources.id, resourceAllocations.resourceId),
          gte(resourceAllocations.startDate, dateRange.start),
          lte(resourceAllocations.endDate, dateRange.end)
        )
      )
      .where(
        and(
          eq(resources.isActive, true),
          eq(resources.type, workType)
        )
      )
      .groupBy(resources.id, resources.name, resources.type, resources.capacity, resources.hourlyRate)
      .having(sql`${resources.capacity} - COALESCE(SUM(${resourceAllocations.allocatedHours}), 0) > 0`);
  }

  /**
   * Apply optimization recommendations
   */
  async applyOptimizationRecommendations(recommendations: OptimizationRecommendation[]): Promise<{
    applied: number;
    failed: number;
    results: { recommendation: OptimizationRecommendation; success: boolean; error?: string }[];
  }> {
    const results = [];
    let applied = 0;
    let failed = 0;

    for (const recommendation of recommendations) {
      try {
        await this.applyRecommendation(recommendation);
        results.push({ recommendation, success: true });
        applied++;
      } catch (error) {
        results.push({ 
          recommendation, 
          success: false, 
          error: error instanceof Error ? error.message : 'Unknown error' 
        });
        failed++;
      }
    }

    return { applied, failed, results };
  }

  // Private helper methods

  private groupAllocationsByResource(allocations: any[]): Map<string, any[]> {
    const groups = new Map<string, any[]>();
    
    for (const allocation of allocations) {
      const resourceId = allocation.resourceId;
      if (!groups.has(resourceId)) {
        groups.set(resourceId, []);
      }
      groups.get(resourceId)!.push(allocation);
    }
    
    return groups;
  }

  private findOverallocatedPeriods(allocations: any[], capacity: number): Date[] {
    const conflictDates: Date[] = [];
    
    // Check for overlapping allocations that exceed capacity
    // For each possible date, sum up all overlapping allocations
    const allDates = new Set<string>();
    
    // Collect all dates covered by any allocation
    for (const allocation of allocations) {
      const start = new Date(allocation.startDate);
      const end = new Date(allocation.endDate);
      
      for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
        allDates.add(d.toISOString().split('T')[0]);
      }
    }
    
    console.log(`Resource capacity: ${capacity}`);
    console.log(`Found ${allDates.size} time slots to check`);
    
    // For each date, check if total overlapping allocations exceed capacity
    for (const dateStr of allDates) {
      const checkDate = new Date(dateStr);
      let totalAllocationOnDate = 0;
      
      for (const allocation of allocations) {
        const start = new Date(allocation.startDate);
        const end = new Date(allocation.endDate);
        
        // If this allocation overlaps with the check date
        if (checkDate >= start && checkDate <= end) {
          totalAllocationOnDate += parseFloat(allocation.allocatedHours);
        }
      }
      
      // If total allocation exceeds resource capacity, it's a conflict
      if (totalAllocationOnDate > capacity) {
        console.log(`CONFLICT on ${dateStr}: total allocation ${totalAllocationOnDate} > capacity ${capacity}`);
        conflictDates.push(new Date(dateStr));
      }
    }
    
    console.log(`Found ${conflictDates.length} conflict dates`);
    if (conflictDates.length > 0) {
      console.log("Sample conflict dates:", conflictDates.slice(0, 3));
    }

    return conflictDates;
  }

  private getAffectedPrograms(allocations: any[], conflictDate: Date): any[] {
    return allocations
      .filter(allocation => {
        const start = new Date(allocation.startDate);
        const end = new Date(allocation.endDate);
        return conflictDate >= start && conflictDate <= end;
      })
      .map(allocation => ({
        programId: allocation.programId,
        programName: allocation.programName,
        allocatedHours: parseFloat(allocation.allocatedHours),
        priority: this.calculateProgramPriority(allocation),
      }));
  }

  private calculateProgramPriority(allocation: any): number {
    // Priority based on phase, budget, and current progress
    const phaseWeights = { 'PDR': 1, 'CDR': 2, 'TRR': 3, 'QUAL': 4, 'PRODUCTION': 5 };
    const phaseWeight = phaseWeights[allocation.programPhase as keyof typeof phaseWeights] || 1;
    const budgetWeight = Math.min(parseFloat(allocation.totalBudget) / 10000000, 3); // Normalize to 0-3
    
    return phaseWeight + budgetWeight;
  }

  private async generateRecommendations(
    resourceId: string,
    conflictDate: Date,
    affectedPrograms: any[],
    overallocation: number
  ): Promise<OptimizationRecommendation[]> {
    const recommendations: OptimizationRecommendation[] = [];

    // Recommendation 1: Reschedule lower priority programs
    const sortedPrograms = affectedPrograms.sort((a, b) => a.priority - b.priority);
    const lowPriorityPrograms = sortedPrograms.slice(0, Math.ceil(sortedPrograms.length / 2));
    
    recommendations.push({
      type: 'reschedule',
      description: `Reschedule ${lowPriorityPrograms.length} lower priority program(s) to reduce conflict`,
      impact: {
        scheduleDelay: Math.ceil(overallocation / 8), // Assume 8 hours per day
        costIncrease: 0,
        riskLevel: lowPriorityPrograms.length > 2 ? 'medium' : 'low',
      },
      actionPlan: {
        action: 'Delay start dates for lower priority programs',
        newStartDate: new Date(conflictDate.getTime() + 7 * 24 * 60 * 60 * 1000), // 1 week delay
      },
    });

    // Recommendation 2: Find alternative resources
    const availableResources = await this.getAvailableResources(
      'Systems Engineer', // This should be dynamic based on actual resource type
      { start: conflictDate, end: new Date(conflictDate.getTime() + 30 * 24 * 60 * 60 * 1000) }
    );

    if (availableResources.length > 0) {
      const alternativeResource = availableResources[0];
      recommendations.push({
        type: 'reassign',
        description: `Reassign work to available resource: ${alternativeResource.name}`,
        impact: {
          scheduleDelay: 0,
          costIncrease: parseFloat(alternativeResource.hourlyRate) * overallocation,
          riskLevel: 'low',
        },
        actionPlan: {
          action: 'Reassign tasks to alternative resource',
          targetResourceId: alternativeResource.id,
        },
      });
    }

    // Recommendation 3: Add temporary resource
    recommendations.push({
      type: 'add_resource',
      description: 'Hire temporary contractor or consultant',
      impact: {
        scheduleDelay: 0,
        costIncrease: 150 * overallocation, // Assume $150/hour for contractor
        riskLevel: 'medium',
      },
      actionPlan: {
        action: 'Engage external contractor',
        additionalCost: 150 * overallocation,
      },
    });

    return recommendations;
  }

  private selectBestRecommendation(recommendations: OptimizationRecommendation[]): OptimizationRecommendation | null {
    if (recommendations.length === 0) return null;

    // Score recommendations based on cost, risk, and schedule impact
    const scoredRecommendations = recommendations.map(rec => {
      let score = 0;
      
      // Lower cost is better
      score -= rec.impact.costIncrease / 1000;
      
      // Lower schedule delay is better
      score -= rec.impact.scheduleDelay * 2;
      
      // Lower risk is better
      const riskPenalty = { low: 0, medium: -5, high: -15 };
      score += riskPenalty[rec.impact.riskLevel];
      
      return { recommendation: rec, score };
    });

    return scoredRecommendations
      .sort((a, b) => b.score - a.score)[0]
      .recommendation;
  }

  private async calculateOverallUtilization(): Promise<number> {
    const result = await db
      .select({
        totalCapacity: sql<number>`SUM(${resources.capacity})`,
        totalAllocated: sql<number>`COALESCE(SUM(${resourceAllocations.allocatedHours}), 0)`,
      })
      .from(resources)
      .leftJoin(resourceAllocations, eq(resources.id, resourceAllocations.resourceId))
      .where(eq(resources.isActive, true));

    const { totalCapacity, totalAllocated } = result[0];
    return totalCapacity > 0 ? (totalAllocated / totalCapacity) * 100 : 0;
  }

  private createImplementationPlan(recommendations: OptimizationRecommendation[]): any[] {
    const phases = [
      {
        phase: 1,
        actions: recommendations.filter(r => r.impact.riskLevel === 'low'),
        timeline: 'Immediate (1-3 days)',
      },
      {
        phase: 2,
        actions: recommendations.filter(r => r.impact.riskLevel === 'medium'),
        timeline: 'Short-term (1-2 weeks)',
      },
      {
        phase: 3,
        actions: recommendations.filter(r => r.impact.riskLevel === 'high'),
        timeline: 'Long-term (2-4 weeks)',
      },
    ];

    return phases.filter(phase => phase.actions.length > 0);
  }

  private async applyRecommendation(recommendation: OptimizationRecommendation): Promise<void> {
    switch (recommendation.type) {
      case 'reschedule':
        if (recommendation.actionPlan.newStartDate) {
          // Update resource allocation dates
          // This would need specific resource allocation IDs which would be passed in a real implementation
        }
        break;
        
      case 'reassign':
        if (recommendation.actionPlan.targetResourceId) {
          // Update resource allocation to new resource
        }
        break;
        
      case 'add_resource':
        // Create new resource entry
        await db.insert(resources).values({
          name: 'Temporary Contractor',
          type: 'Systems Engineer',
          capacity: '40',
          hourlyRate: '150.00',
          isActive: true,
        });
        break;
        
      case 'split_task':
        // Split WBS task into multiple smaller tasks
        break;
    }
  }
}

export const resourceOptimizationService = new ResourceOptimizationService();