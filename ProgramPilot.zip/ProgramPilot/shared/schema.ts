import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, boolean, jsonb, uuid } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const programs = pgTable("programs", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  programId: text("program_id").notNull().unique(),
  description: text("description"),
  phase: text("phase").notNull().default("PDR"), // PDR, CDR, TRR, QUAL, PRODUCTION
  totalBudget: decimal("total_budget", { precision: 12, scale: 2 }).notNull().default("0"),
  budgetSpent: decimal("budget_spent", { precision: 12, scale: 2 }).notNull().default("0"),
  designAssemblies: integer("design_assemblies").notNull().default(0),
  verificationUnits: integer("verification_units").notNull().default(0),
  qualificationUnits: integer("qualification_units").notNull().default(0),
  cdrlsCount: integer("cdrls_count").notNull().default(0),
  drawingsCount: integer("drawings_count").notNull().default(0),
  costPerUnit: decimal("cost_per_unit", { precision: 10, scale: 2 }).notNull().default("0"),
  complexityMultiplier: decimal("complexity_multiplier", { precision: 3, scale: 2 }).notNull().default("1.0"),
  durationMultiplier: decimal("duration_multiplier", { precision: 3, scale: 2 }).notNull().default("1.0"),
  status: text("status").notNull().default("active"), // active, completed, on-hold, cancelled
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const milestones = pgTable("milestones", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  programId: uuid("program_id").notNull().references(() => programs.id, { onDelete: 'cascade' }),
  name: text("name").notNull(), // PDR, CDR, TRR, QUAL, PRODUCTION
  type: text("type").notNull(), // milestone type
  targetDate: timestamp("target_date"),
  actualDate: timestamp("actual_date"),
  status: text("status").notNull().default("planned"), // planned, in-progress, completed, delayed
  progress: integer("progress").notNull().default(0), // 0-100
  dependencies: text("dependencies").array(),
});

export const workBreakdownStructure = pgTable("work_breakdown_structure", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  programId: uuid("program_id").notNull().references(() => programs.id, { onDelete: 'cascade' }),
  taskName: text("task_name").notNull(),
  taskCode: text("task_code").notNull(),
  phase: text("phase").notNull(),
  estimatedHours: decimal("estimated_hours", { precision: 8, scale: 2 }).notNull().default("0"),
  actualHours: decimal("actual_hours", { precision: 8, scale: 2 }).notNull().default("0"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  dependencies: text("dependencies").array(),
  resourceType: text("resource_type").notNull(), // software, hardware, test, management
  status: text("status").notNull().default("not-started"),
});

export const resources = pgTable("resources", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // software-engineer, hardware-engineer, test-engineer, project-manager
  capacity: decimal("capacity", { precision: 5, scale: 2 }).notNull().default("40"), // hours per week
  hourlyRate: decimal("hourly_rate", { precision: 6, scale: 2 }).notNull().default("0"),
  isActive: boolean("is_active").notNull().default(true),
});

export const resourceAllocations = pgTable("resource_allocations", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  programId: uuid("program_id").notNull().references(() => programs.id, { onDelete: 'cascade' }),
  resourceId: uuid("resource_id").notNull().references(() => resources.id, { onDelete: 'cascade' }),
  allocatedHours: decimal("allocated_hours", { precision: 8, scale: 2 }).notNull().default("0"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
});

export const budgetEntries = pgTable("budget_entries", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  programId: uuid("program_id").notNull().references(() => programs.id, { onDelete: 'cascade' }),
  category: text("category").notNull(), // labor, materials, other
  description: text("description"),
  plannedAmount: decimal("planned_amount", { precision: 12, scale: 2 }).notNull().default("0"),
  actualAmount: decimal("actual_amount", { precision: 12, scale: 2 }).notNull().default("0"),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
});

export const expenses = pgTable("expenses", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  programId: uuid("program_id").notNull().references(() => programs.id, { onDelete: 'cascade' }),
  description: text("description").notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  category: text("category").notNull(),
  date: timestamp("date").notNull(),
  documentUrl: text("document_url"),
});

export const documents = pgTable("documents", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  programId: uuid("program_id").notNull().references(() => programs.id, { onDelete: 'cascade' }),
  name: text("name").notNull(),
  documentNumber: text("document_number"), // e.g., CDRL-001
  type: text("type").notNull(), // cdrl, drawing, specification, report, other
  category: text("category"), // SRS, ICD, TRR, etc.
  description: text("description"),
  version: text("version").notNull().default("1.0"),
  status: text("status").notNull().default("draft"), // draft, in-review, approved, rejected, superseded
  fileUrl: text("file_url"), // Internal storage URL
  externalUrl: text("external_url"), // External system URL (SharePoint, etc.)
  externalSystemId: text("external_system_id"), // ID in external system
  externalSystemType: text("external_system_type"), // sharepoint, onedrive, dropbox, notion
  fileSize: integer("file_size"), // bytes
  mimeType: text("mime_type"),
  linkedMilestoneId: uuid("linked_milestone_id").references(() => milestones.id),
  linkedWbsId: uuid("linked_wbs_id").references(() => workBreakdownStructure.id),
  dueDate: timestamp("due_date"),
  submittedDate: timestamp("submitted_date"),
  approvedDate: timestamp("approved_date"),
  metadata: jsonb("metadata"), // Flexible metadata storage
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const cdrlItems = pgTable("cdrl_items", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  programId: uuid("program_id").notNull().references(() => programs.id, { onDelete: 'cascade' }),
  documentId: uuid("document_id").references(() => documents.id),
  cdrlNumber: text("cdrl_number").notNull(), // CDRL-001, CDRL-002, etc.
  title: text("title").notNull(),
  description: text("description"),
  format: text("format").notNull().default("electronic"), // electronic, hardcopy, both
  classification: text("classification").notNull().default("unclassified"), // unclassified, cui, secret, etc.
  frequency: text("frequency"), // one-time, monthly, quarterly, etc.
  firstDueDate: timestamp("first_due_date"),
  finalDueDate: timestamp("final_due_date"),
  linkedMilestone: text("linked_milestone"), // PDR, CDR, TRR, etc.
  deliveryMethod: text("delivery_method").notNull().default("electronic"), // electronic, mail, hand-delivery
  responsibleOrg: text("responsible_org"), // Organization responsible for delivery
  reviewCycle: integer("review_cycle").default(30), // days for review
  status: text("status").notNull().default("pending"), // pending, in-progress, submitted, approved, rejected
  submissionCount: integer("submission_count").notNull().default(0),
  lastSubmissionDate: timestamp("last_submission_date"),
  approvalDate: timestamp("approval_date"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const documentApprovals = pgTable("document_approvals", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  documentId: uuid("document_id").notNull().references(() => documents.id, { onDelete: 'cascade' }),
  approverName: text("approver_name").notNull(),
  approverRole: text("approver_role"), // engineer, manager, customer, etc.
  approvalType: text("approval_type").notNull(), // technical, editorial, customer, final
  status: text("status").notNull().default("pending"), // pending, approved, rejected, with-comments
  submittedDate: timestamp("submitted_date").notNull().default(sql`now()`),
  reviewedDate: timestamp("reviewed_date"),
  comments: text("comments"),
  approvalOrder: integer("approval_order").notNull().default(1), // Order in approval workflow
  isRequired: boolean("is_required").notNull().default(true),
});

export const risks = pgTable("risks", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  programId: uuid("program_id").notNull().references(() => programs.id, { onDelete: 'cascade' }),
  riskId: text("risk_id").notNull().unique(), // RISK-001, RISK-002, etc.
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(), // technical, schedule, budget, resource, external, regulatory
  type: text("type").notNull(), // program-level, milestone-level, task-level, resource-level
  source: text("source"), // program-manager, engineering-team, customer, audit, etc.
  status: text("status").notNull().default("open"), // open, in-progress, mitigated, closed, accepted
  severity: text("severity").notNull().default("medium"), // critical, high, medium, low
  urgency: text("urgency").notNull().default("medium"), // immediate, high, medium, low
  linkedMilestoneId: uuid("linked_milestone_id").references(() => milestones.id),
  linkedWbsId: uuid("linked_wbs_id").references(() => workBreakdownStructure.id),
  linkedResourceId: uuid("linked_resource_id").references(() => resources.id),
  identifiedBy: text("identified_by").notNull(), // who identified the risk
  identifiedDate: timestamp("identified_date").notNull().default(sql`now()`),
  targetResolutionDate: timestamp("target_resolution_date"),
  actualResolutionDate: timestamp("actual_resolution_date"),
  escalationRequired: boolean("escalation_required").notNull().default(false),
  escalationLevel: text("escalation_level"), // program, department, executive
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const riskAssessments = pgTable("risk_assessments", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  riskId: uuid("risk_id").notNull().references(() => risks.id, { onDelete: 'cascade' }),
  assessmentDate: timestamp("assessment_date").notNull().default(sql`now()`),
  assessedBy: text("assessed_by").notNull(),
  probabilityScore: integer("probability_score").notNull(), // 1-10 scale
  impactScore: integer("impact_score").notNull(), // 1-10 scale  
  riskScore: integer("risk_score").notNull(), // probability * impact
  scheduleImpactDays: integer("schedule_impact_days").default(0), // potential delay in days
  budgetImpactAmount: decimal("budget_impact_amount", { precision: 12, scale: 2 }).default("0"), // potential cost impact
  qualityImpact: text("quality_impact"), // description of quality/performance impact
  riskTolerance: text("risk_tolerance").notNull().default("medium"), // high, medium, low
  residualRisk: text("residual_risk"), // description of remaining risk after mitigation
  confidenceLevel: integer("confidence_level").notNull().default(70), // 0-100% confidence in assessment
  assessmentNotes: text("assessment_notes"),
  reviewDate: timestamp("review_date"),
  isCurrentAssessment: boolean("is_current_assessment").notNull().default(true),
});

export const riskMitigations = pgTable("risk_mitigations", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  riskId: uuid("risk_id").notNull().references(() => risks.id, { onDelete: 'cascade' }),
  strategy: text("strategy").notNull(), // avoid, mitigate, transfer, accept
  actionDescription: text("action_description").notNull(),
  actionType: text("action_type").notNull(), // preventive, detective, corrective, contingency
  assignedTo: text("assigned_to").notNull(),
  priority: text("priority").notNull().default("medium"), // critical, high, medium, low
  plannedStartDate: timestamp("planned_start_date"),
  plannedCompletionDate: timestamp("planned_completion_date"),
  actualStartDate: timestamp("actual_start_date"),
  actualCompletionDate: timestamp("actual_completion_date"),
  status: text("status").notNull().default("planned"), // planned, in-progress, completed, deferred, cancelled
  estimatedCost: decimal("estimated_cost", { precision: 12, scale: 2 }).default("0"),
  actualCost: decimal("actual_cost", { precision: 12, scale: 2 }).default("0"),
  effectiveness: integer("effectiveness").default(0), // 0-100% effectiveness after implementation
  verificationMethod: text("verification_method"), // how to verify mitigation is working
  contingencyPlan: text("contingency_plan"), // backup plan if mitigation fails
  successCriteria: text("success_criteria"),
  progressNotes: text("progress_notes"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const riskImpacts = pgTable("risk_impacts", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  riskId: uuid("risk_id").notNull().references(() => risks.id, { onDelete: 'cascade' }),
  impactType: text("impact_type").notNull(), // schedule, budget, scope, quality, resource
  impactArea: text("impact_area"), // which specific area is affected
  quantitativeImpact: decimal("quantitative_impact", { precision: 15, scale: 2 }), // numerical impact
  qualitativeImpact: text("qualitative_impact"), // description of impact
  impactStartDate: timestamp("impact_start_date"),
  impactEndDate: timestamp("impact_end_date"),
  cascadingEffects: text("cascading_effects").array(), // downstream impacts
  affectedStakeholders: text("affected_stakeholders").array(), // who is affected
  mitigationCost: decimal("mitigation_cost", { precision: 12, scale: 2 }).default("0"),
  calculatedAt: timestamp("calculated_at").notNull().default(sql`now()`),
  calculationMethod: text("calculation_method"), // how the impact was calculated
  confidence: integer("confidence").notNull().default(70), // 0-100% confidence
  notes: text("notes"),
});

// Relations
export const programsRelations = relations(programs, ({ many }) => ({
  milestones: many(milestones),
  wbs: many(workBreakdownStructure),
  resourceAllocations: many(resourceAllocations),
  budgetEntries: many(budgetEntries),
  expenses: many(expenses),
  documents: many(documents),
  cdrlItems: many(cdrlItems),
  risks: many(risks),
}));

export const milestonesRelations = relations(milestones, ({ one, many }) => ({
  program: one(programs, {
    fields: [milestones.programId],
    references: [programs.id],
  }),
  linkedRisks: many(risks),
}));

export const wbsRelations = relations(workBreakdownStructure, ({ one, many }) => ({
  program: one(programs, {
    fields: [workBreakdownStructure.programId],
    references: [programs.id],
  }),
  linkedRisks: many(risks),
}));

export const resourcesRelations = relations(resources, ({ many }) => ({
  allocations: many(resourceAllocations),
  linkedRisks: many(risks),
}));

export const resourceAllocationsRelations = relations(resourceAllocations, ({ one }) => ({
  program: one(programs, {
    fields: [resourceAllocations.programId],
    references: [programs.id],
  }),
  resource: one(resources, {
    fields: [resourceAllocations.resourceId],
    references: [resources.id],
  }),
}));

export const budgetEntriesRelations = relations(budgetEntries, ({ one }) => ({
  program: one(programs, {
    fields: [budgetEntries.programId],
    references: [programs.id],
  }),
}));

export const expensesRelations = relations(expenses, ({ one }) => ({
  program: one(programs, {
    fields: [expenses.programId],
    references: [programs.id],
  }),
}));

export const documentsRelations = relations(documents, ({ one, many }) => ({
  program: one(programs, {
    fields: [documents.programId],
    references: [programs.id],
  }),
  linkedMilestone: one(milestones, {
    fields: [documents.linkedMilestoneId],
    references: [milestones.id],
  }),
  linkedWbs: one(workBreakdownStructure, {
    fields: [documents.linkedWbsId],
    references: [workBreakdownStructure.id],
  }),
  approvals: many(documentApprovals),
  cdrlItems: many(cdrlItems),
}));

export const cdrlItemsRelations = relations(cdrlItems, ({ one }) => ({
  program: one(programs, {
    fields: [cdrlItems.programId],
    references: [programs.id],
  }),
  document: one(documents, {
    fields: [cdrlItems.documentId],
    references: [documents.id],
  }),
}));

export const documentApprovalsRelations = relations(documentApprovals, ({ one }) => ({
  document: one(documents, {
    fields: [documentApprovals.documentId],
    references: [documents.id],
  }),
}));

export const risksRelations = relations(risks, ({ one, many }) => ({
  program: one(programs, {
    fields: [risks.programId],
    references: [programs.id],
  }),
  linkedMilestone: one(milestones, {
    fields: [risks.linkedMilestoneId],
    references: [milestones.id],
  }),
  linkedWbs: one(workBreakdownStructure, {
    fields: [risks.linkedWbsId],
    references: [workBreakdownStructure.id],
  }),
  linkedResource: one(resources, {
    fields: [risks.linkedResourceId],
    references: [resources.id],
  }),
  assessments: many(riskAssessments),
  mitigations: many(riskMitigations),
  impacts: many(riskImpacts),
}));

export const riskAssessmentsRelations = relations(riskAssessments, ({ one }) => ({
  risk: one(risks, {
    fields: [riskAssessments.riskId],
    references: [risks.id],
  }),
}));

export const riskMitigationsRelations = relations(riskMitigations, ({ one }) => ({
  risk: one(risks, {
    fields: [riskMitigations.riskId],
    references: [risks.id],
  }),
}));

export const riskImpactsRelations = relations(riskImpacts, ({ one }) => ({
  risk: one(risks, {
    fields: [riskImpacts.riskId],
    references: [risks.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertProgramSchema = createInsertSchema(programs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMilestoneSchema = createInsertSchema(milestones).omit({
  id: true,
});

export const insertWbsSchema = createInsertSchema(workBreakdownStructure).omit({
  id: true,
});

export const insertResourceSchema = createInsertSchema(resources).omit({
  id: true,
});

export const insertResourceAllocationSchema = createInsertSchema(resourceAllocations).omit({
  id: true,
});

export const insertBudgetEntrySchema = createInsertSchema(budgetEntries).omit({
  id: true,
});

export const insertExpenseSchema = createInsertSchema(expenses).omit({
  id: true,
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCdrlItemSchema = createInsertSchema(cdrlItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDocumentApprovalSchema = createInsertSchema(documentApprovals).omit({
  id: true,
});

export const insertRiskSchema = createInsertSchema(risks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRiskAssessmentSchema = createInsertSchema(riskAssessments).omit({
  id: true,
});

export const insertRiskMitigationSchema = createInsertSchema(riskMitigations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRiskImpactSchema = createInsertSchema(riskImpacts).omit({
  id: true,
});

export const settings = pgTable("settings", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  key: text("key").notNull().unique(), // setting identifier like 'burdened_labor_multiplier'
  value: text("value").notNull(), // setting value stored as string
  description: text("description"), // human readable description
  category: text("category").notNull().default("overhead"), // category grouping
  dataType: text("data_type").notNull().default("number"), // number, string, boolean
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

// Insert schemas with enhanced validation
export const insertSettingsSchema = createInsertSchema(settings).extend({
  value: z.string().transform((val) => {
    // For numeric settings, validate and coerce the value
    const trimmedVal = val.trim();
    
    // If this looks like a number, ensure it's valid
    if (/^-?\d*\.?\d+$/.test(trimmedVal)) {
      const numValue = parseFloat(trimmedVal);
      if (isNaN(numValue)) {
        throw new Error('Invalid numeric value');
      }
      return numValue.toString();
    }
    
    return trimmedVal;
  }),
  key: z.string().min(1, "Key is required"),
  category: z.string().min(1, "Category is required"),
  dataType: z.enum(['number', 'string', 'boolean'], {
    errorMap: () => ({ message: "Data type must be number, string, or boolean" })
  })
}).superRefine((data, ctx) => {
  // Additional validation for specific setting keys
  if (data.dataType === 'number') {
    const numValue = parseFloat(data.value);
    
    if (isNaN(numValue)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Value must be a valid number for numeric settings",
        path: ['value']
      });
      return;
    }

    // Validate overhead multiplier ranges
    if (data.key === 'burdened_labor_multiplier' && (numValue < 1.0 || numValue > 10.0)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Burdened labor multiplier must be between 1.0 and 10.0",
        path: ['value']
      });
    }
    
    if (data.key === 'burdened_expenses_multiplier' && (numValue < 1.0 || numValue > 5.0)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Burdened expenses multiplier must be between 1.0 and 5.0",
        path: ['value']
      });
    }
  }
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Program = typeof programs.$inferSelect;
export type InsertProgram = z.infer<typeof insertProgramSchema>;
export type Milestone = typeof milestones.$inferSelect;
export type InsertMilestone = z.infer<typeof insertMilestoneSchema>;
export type WorkBreakdownStructure = typeof workBreakdownStructure.$inferSelect;
export type InsertWorkBreakdownStructure = z.infer<typeof insertWbsSchema>;
export type Resource = typeof resources.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;
export type ResourceAllocation = typeof resourceAllocations.$inferSelect;
export type InsertResourceAllocation = z.infer<typeof insertResourceAllocationSchema>;
export type BudgetEntry = typeof budgetEntries.$inferSelect;
export type InsertBudgetEntry = z.infer<typeof insertBudgetEntrySchema>;
export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type CdrlItem = typeof cdrlItems.$inferSelect;
export type InsertCdrlItem = z.infer<typeof insertCdrlItemSchema>;
export type DocumentApproval = typeof documentApprovals.$inferSelect;
export type InsertDocumentApproval = z.infer<typeof insertDocumentApprovalSchema>;
export type Risk = typeof risks.$inferSelect;
export type InsertRisk = z.infer<typeof insertRiskSchema>;
export type RiskAssessment = typeof riskAssessments.$inferSelect;
export type InsertRiskAssessment = z.infer<typeof insertRiskAssessmentSchema>;
export type RiskMitigation = typeof riskMitigations.$inferSelect;
export type InsertRiskMitigation = z.infer<typeof insertRiskMitigationSchema>;
export type RiskImpact = typeof riskImpacts.$inferSelect;
export type InsertRiskImpact = z.infer<typeof insertRiskImpactSchema>;
export type Settings = typeof settings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
