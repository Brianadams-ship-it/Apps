# Overview

This is a full-stack web application for program management and project tracking. The system provides a comprehensive dashboard for managing programs, resources, budgets, and project milestones. It features a React-based frontend with a modern UI design system (shadcn/ui) and an Express.js backend with PostgreSQL database integration using Drizzle ORM.

The application is designed for department-level program management, allowing users to track program progress, resource utilization, budget allocation, and project schedules through interactive dashboards and detailed program views.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The frontend is built using **React 18** with **TypeScript** and follows a modern component-based architecture:

- **Routing**: Uses Wouter for client-side routing with a simple switch-based approach
- **State Management**: Leverages React Query (TanStack Query) for server state management and caching
- **UI Framework**: Built on top of shadcn/ui components with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with CSS custom properties for theming support
- **Form Handling**: React Hook Form with Zod validation for type-safe form management
- **Build Tool**: Vite for fast development and optimized production builds

The application structure follows a feature-based organization with shared components and utilities. The main pages include a dashboard overview and detailed program views with interactive charts and tables.

## Backend Architecture

The backend is implemented as a **REST API** using **Express.js** with TypeScript:

- **Database Layer**: Drizzle ORM provides type-safe database operations with PostgreSQL
- **Connection Pooling**: Uses Neon's serverless PostgreSQL with connection pooling for scalability
- **API Structure**: RESTful endpoints organized by feature areas (programs, dashboard, resources, budget)
- **Error Handling**: Centralized error handling middleware with proper status codes
- **Development Tools**: Hot reload support with custom logging middleware for API requests

The server includes specialized services like a calculation service for program metrics, work breakdown structures, and resource allocation computations.

## Database Design

The system uses **PostgreSQL** with a well-structured schema managed by Drizzle ORM:

- **Core Entities**: Programs, milestones, work breakdown structure, resources, budget entries, and expenses
- **Relationships**: Foreign key constraints maintain data integrity across related entities
- **Data Types**: Uses appropriate PostgreSQL types including UUIDs for primary keys, decimal for financial data, and JSONB for flexible metadata
- **Schema Management**: Database migrations are handled through Drizzle Kit with version control

The schema supports complex program management workflows including hierarchical work breakdown structures, resource allocation tracking, and multi-phase milestone management.

## Data Flow and State Management

- **Client-Server Communication**: RESTful API calls with proper error handling and loading states
- **Caching Strategy**: React Query provides intelligent caching with configurable stale times
- **Real-time Updates**: UI updates optimistically with server-side validation
- **Form Validation**: Client-side validation using Zod schemas shared between frontend and backend

## Development and Deployment

The application is configured for both development and production environments:

- **Development**: Vite dev server with HMR, TypeScript checking, and custom middleware
- **Build Process**: Separate client and server builds with optimized bundling
- **Environment Configuration**: Environment-based configuration for database connections and API endpoints
- **Code Quality**: TypeScript strict mode with comprehensive type checking across the entire stack

# External Dependencies

## Database
- **Neon PostgreSQL**: Serverless PostgreSQL database with connection pooling
- **Drizzle ORM**: Type-safe ORM for database operations and migrations

## UI and Styling
- **shadcn/ui**: Pre-built accessible component library built on Radix UI
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Radix UI**: Accessible component primitives for complex UI interactions
- **Lucide React**: Icon library for consistent iconography

## Development and Build Tools
- **Vite**: Fast build tool with hot module replacement and optimized bundling
- **TypeScript**: Type safety across the entire application
- **React Query**: Server state management and caching
- **React Hook Form**: Form state management and validation

## Backend Services
- **Express.js**: Web application framework for the REST API
- **date-fns**: Date manipulation and formatting utilities
- **Zod**: Runtime type validation for API contracts and form validation

## Fonts and Assets
- **Google Fonts**: Inter font family for typography
- **Font Awesome**: Icon library for dashboard interface elements

The application is designed to be deployed on platforms that support Node.js applications with PostgreSQL databases, with particular optimization for serverless deployment patterns.