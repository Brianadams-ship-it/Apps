// Dynamic imports for better ES module compatibility

interface ParsedData {
  assemblies: Array<{
    name: string;
    level: number;
    parentId?: string;
    parentName?: string; // For relationship resolution
    containment?: {
      contains?: string;
      partOf?: string;
      mountedOn?: string;
    };
    metadata?: {
      drawingNumber?: string;
      revision?: string;
      scale?: string;
      material?: string;
    };
  }>;
  parts: Array<{
    name: string;
    partNumber: string;
    quantity: number;
    assemblyName?: string;
    metadata?: {
      dimensions?: string;
      material?: string;
      materialGrade?: string;
      materialStandard?: string;
      diameter?: string;
      length?: string;
      width?: string;
      height?: string;
      thickness?: string;
      weight?: string;
      tolerance?: string;
      geometricTolerance?: string;
      surfaceFinish?: string;
      threading?: string;
      heatTreatment?: string;
      coating?: string;
      finish?: string;
      supplier?: string;
      cost?: number;
      leadTime?: string;
      standard?: string;
      certification?: string;
      manufacturing?: string[];
    };
  }>;
}

export async function parsePdfDwg(buffer: Buffer, filename: string): Promise<ParsedData> {
  try {
    console.log(`Parsing CAD file: ${filename}`);
    
    // Detect file format and route to appropriate parser
    const fileExtension = filename.toLowerCase().split('.').pop();
    let textContent = '';
    
    switch (fileExtension) {
      case 'pdf':
        console.log('Processing PDF file with pdf-parse');
        try {
          const pdfParse = (await import('pdf-parse')).default;
          const pdfData = await pdfParse(buffer);
          textContent = pdfData.text;
        } catch (pdfError) {
          console.warn('PDF parsing failed:', pdfError);
          textContent = `Error parsing PDF: ${pdfError}`;
        }
        break;
        
      case 'txt':
        console.log('Processing text file');
        textContent = buffer.toString('utf-8');
        break;
        
      case 'dxf':
        console.log('Processing DXF file');
        try {
          const DxfParser = (await import('dxf-parser')).default;
          const parser = new DxfParser();
          const dxfData = parser.parseSync(buffer.toString('utf-8'));
          textContent = extractTextFromDxf(dxfData);
          console.log(`Extracted ${textContent.length} characters from DXF entities`);
        } catch (dxfError) {
          console.warn('DXF parsing failed, falling back to text extraction:', dxfError);
          textContent = buffer.toString('utf-8');
        }
        break;
        
      case 'dwg':
        console.log('DWG format detected - binary format requires specialized conversion');
        console.log('Note: DWG files require conversion to DXF for text extraction - using intelligent defaults');
        return createIntelligentDefaults(filename, 'DWG format detected - recommend converting to DXF for better parsing');
        
      default:
        console.log(`Unknown format: ${fileExtension} - treating as text`);
        textContent = buffer.toString('utf-8');
    }
    
    console.log(`Extracted ${textContent.length} characters from ${fileExtension?.toUpperCase() || 'file'}`);
    
    // Parse the extracted text for CAD-specific information
    const parsedData = parseCADContent(textContent, filename);
    
    // If no meaningful data was extracted, fall back to intelligent defaults
    if (parsedData.assemblies.length === 0 && parsedData.parts.length === 0) {
      console.log('No structured data found, creating intelligent defaults');
      return createIntelligentDefaults(filename);
    }
    
    console.log(`Successfully parsed ${parsedData.assemblies.length} assemblies and ${parsedData.parts.length} parts`);
    return parsedData;
    
  } catch (error) {
    console.error("Error parsing CAD file:", error);
    // Fallback to intelligent structure generation
    return createIntelligentDefaults(filename, `Parsing error: ${error}`);
  }
}

function parseCADContent(textContent: string, filename: string): ParsedData {
  const assemblies: ParsedData['assemblies'] = [];
  const parts: ParsedData['parts'] = [];
  
  // Enhanced relationship detection patterns (non-global to avoid lastIndex issues)
  const relationshipPatterns = {
    // Hierarchical structure indicators
    subAssembly: /(?:SUB[\s-]*ASSEMBLY|SUBASSY|SUB[\s-]*ASM)[:\s]*([A-Z0-9\s\-]{3,50})/i,
    assemblyLevel: /^(\s*)([\d\.]+\.)?\s*(?:ASSEMBLY|ASSY|SUB[\s-]*ASSEMBLY)/mi,
    indentation: /^(\s+)(.+)/m,
    
    // Part numbering hierarchy patterns  
    hierarchicalPartNumber: /([A-Z0-9]+)[\-\.](\d+)[\-\.](\d+)/,
    parentPartNumber: /([A-Z0-9]+)[\-\.](\d+)(?=[\-\.])/,
    
    // Assembly containment indicators (non-global for safe testing)
    containsKeywords: /(?:CONTAINS|INCLUDES|COMPRISES|CONSISTS\s+OF)[:\s]*(.+)/i,
    partOfKeywords: /(?:PART\s+OF|BELONGS\s+TO|MEMBER\s+OF)[:\s]*(.+)/i,
    
    // Spatial relationship indicators
    mountedOn: /(?:MOUNTED\s+ON|ATTACHED\s+TO|CONNECTED\s+TO)[:\s]*(.+)/i,
    attachmentMethod: /(?:BOLTED|WELDED|RIVETED|SCREWED|GLUED|PRESSED)\s+(?:TO|ON|INTO)/i,
    
    // Dependency indicators
    requires: /(?:REQUIRES|NEEDS|DEPENDS\s+ON)[:\s]*(.+)/i,
    after: /(?:AFTER|FOLLOWING|ONCE)[:\s]*(.+)/i,
  };
  
  // Enhanced CAD-specific patterns for detailed part recognition
  const patterns = {
    // Basic identification patterns
    partNumber: /(?:P\/N|PART[\s#-]*(?:NO|NUMBER))[:\s]*([A-Z0-9\-]{3,20})/gi,
    dwgNumber: /(?:DWG|DRAWING)\s*(?:NO|NUMBER)?[:\s#-]*([A-Z0-9\-]{3,30})/i,
    assembly: /(\b.+?)\s+(?:ASSEMBLY|ASSY)\b[\s:]*([A-Z0-9\-]{3,50})|(?:ASSEMBLY|ASSY|SUB[\s-]*ASSEMBLY)[:\s]*([A-Z0-9\s\-]{3,50})/gi,
    quantity: /(?:QTY|QUANTITY)[:\s]*(\d+)/gi,
    
    // Enhanced material recognition  
    material: /(?:MAT(?:ERIAL)?|MATL)[:\s]*([A-Z0-9\s\-]{2,30})|(?:STAINLESS\s+STEEL|STEEL|ALUMINUM|BRASS|COPPER|PLASTIC|TITANIUM|CARBON)/i,
    materialGrade: /(?:GRADE|GR)[:\s]*([A-Z0-9\-]+)|(?:STAINLESS\s+STEEL|STEEL|AL(?:UMINUM)?|BRASS|COPPER)\s+([A-Z0-9\-]+)\b/i,
    materialStandard: /(?:ASTM|ISO|DIN|JIS|BS|ANSI)[\s\-]*([A-Z0-9\-]{2,15})/i,
    
    // Advanced dimensional analysis
    dimension: /(\d+\.?\d*)\s*[xX×]\s*(\d+\.?\d*)\s*[xX×]?\s*(\d+\.?\d*)?/,
    diameter: /[Ø∅Φ]\s*(\d+\.?\d*)\s*(?:mm|in|"|′)?/,
    length: /(?:LENGTH|L)[:\s]*(\d+\.?\d*)\s*(?:mm|in|"|′)?/i,
    width: /(?:WIDTH|W)[:\s]*(\d+\.?\d*)\s*(?:mm|in|"|′)?/i,
    height: /(?:HEIGHT|H)[:\s]*(\d+\.?\d*)\s*(?:mm|in|"|′)?/i,
    thickness: /(?:THICKNESS|THK|T)[:\s]*(\d+\.?\d*)\s*(?:mm|in|"|′)?/i,
    
    // Geometric dimensioning and tolerancing
    tolerance: /[±]\s*(\d+\.?\d*)\s*(?:mm|in|")?/,
    geometricTolerance: /(?:GD&T|GEOMETRIC)\s*[:\s]*([A-Z0-9\s\±\.]{5,30})/i,
    surfaceFinish: /(?:SURFACE|FINISH|Ra|Rz)[:\s]*(\d+\.?\d*)\s*(?:μm|μin|RMS)?/i,
    
    // Manufacturing specifications
    machining: /(?:MACHINED|CNC|TURNED|MILLED|DRILLED|BORED|GROUND)/i,
    welding: /(?:WELDED|WELD|TIG|MIG|ARC|SPOT)/i,
    forming: /(?:FORMED|BENT|PRESSED|STAMPED|FORGED|CAST)/i,
    threading: /(?:THREAD|THD|NPT|BSP|METRIC)[:\s-]*([A-Z0-9\s\-./×x]+?)(?=\s*$|,|;|\n)/i,
    
    // Coating and treatment
    finish: /(?:FINISH|COATING|TREATMENT|PLATING)[:\s]*([A-Z0-9\s\-]{2,30})/i,
    heatTreatment: /HEAT[\s-]*TREAT(?:MENT)?:\s*([A-Z0-9\s-]{2,20})|\b(HARDENED|TEMPERED|ANNEALED|NORMALIZED)\b/i,
    coating: /(?:ANODIZED|GALVANIZED|PAINTED|POWDER[\s\-]*COAT|ZINC|CHROME|NICKEL|PASSIVATED|PHOSPHATE|BLACK\s+OXIDE)/i,
    
    // Sourcing and cost information
    supplier: /(?:SUPPLIER|VENDOR|MFG|MANUFACTURER)[:\s]*([A-Z0-9\s\-]{2,30})/i,
    partCost: /(?:COST|PRICE)[:\s]*[\$£€¥]?\s*(\d+\.?\d*)/i,
    leadTime: /(?:LEAD[\s\-]*TIME|DELIVERY)[:\s]*(\d+)\s*(?:DAYS?|WEEKS?|WKS?)/i,
    
    // Standards and certifications
    standard: /(?:STANDARD|STD)[:\s]*([A-Z0-9\-\s]{3,20})/i,
    certification: /(?:CERT|CERTIFIED|COMPLIANCE)[:\s]*([A-Z0-9\-\s]{2,25})/i,
    
    // Drawing metadata
    revision: /(?:REV|REVISION)[:\s]*([A-Z0-9]{1,5})/i,
    scale: /(?:SCALE)[:\s]*(\d+:\d+|\d+\/\d+|\d+\.?\d*)/i,
    weight: /(?:WEIGHT|WT)[:\s]*(\d+\.?\d*)\s*(?:kg|lb|g|oz)?/i,
  };
  
  // Split text into lines for better parsing
  const lines = textContent.split(/[\n\r]+/).filter(line => line.trim().length > 0);
  
  // Extract drawing metadata
  const drawingMetadata = extractDrawingMetadata(textContent, patterns);
  
  // Advanced assembly relationship analysis
  const assemblyStructure = analyzeAssemblyHierarchy(textContent, patterns, relationshipPatterns, filename);
  assemblies.push(...assemblyStructure.assemblies);
  
  let currentAssembly = assemblyStructure.assemblies[0]?.name || `${filename.replace(/\.[^/.]+$/, "")} Main Assembly`;
  
  // If no assemblies were detected, create a default main assembly
  if (assemblies.length === 0) {
    assemblies.push({
      name: currentAssembly,
      level: 0,
      metadata: extractDrawingMetadata(textContent, patterns)
    });
  }
  
  // Parse parts with advanced pattern matching and intelligent assembly assignment
  const partAssignments = analyzePartAssemblyRelationships(textContent, patterns, relationshipPatterns, assemblies);
  parts.push(...partAssignments);
  
  // If no parts found with part numbers, try to extract from BOM tables
  if (parts.length === 0) {
    const bomParts = extractFromBOMTable(textContent, assemblies[0]?.name || currentAssembly);
    parts.push(...bomParts);
  }
  
  return { assemblies, parts };
}

function analyzeAssemblyHierarchy(textContent: string, patterns: any, relationshipPatterns: any, filename: string) {
  const assemblies: ParsedData['assemblies'] = [];
  const lines = textContent.split(/[\n\r]+/);
  
  // Extract drawing metadata once
  const drawingMetadata = extractDrawingMetadata(textContent, patterns);
  
  // Step 1: Detect assemblies with hierarchical analysis
  const assemblyMatches = Array.from(textContent.matchAll(patterns.assembly)) || [];
  const assemblyHierarchy = new Map<string, { level: number; parentName?: string; children: string[] }>();
  
  // Analyze indentation and numbering patterns for hierarchy
  const indentationMap = analyzeIndentationHierarchy(lines);
  const numberingHierarchy = analyzeNumberingHierarchy(textContent, patterns);
  
  if (assemblyMatches.length > 0) {
    assemblyMatches.forEach((match, index) => {
      let assemblyName = '';
      let level = 0;
      
      // Extract assembly name
      if (match[1] && match[2]) {
        assemblyName = `${match[1].trim()} ASSEMBLY ${match[2].trim()}`;
      } else if (match[3]) {
        assemblyName = match[3].trim();
      } else {
        assemblyName = match[0].replace(/(?:ASSEMBLY|ASSY|SUB[\s-]*ASSEMBLY)[:\s]*/gi, '').trim();
      }
      
      if (assemblyName.length > 2) {
        // Determine hierarchy level from multiple sources
        level = determineAssemblyLevel(assemblyName, match[0], indentationMap, numberingHierarchy);
        
        // Detect parent-child relationships
        const parentName = findParentAssembly(assemblyName, level, assemblies, numberingHierarchy);
        
        const containmentInfo = analyzeContainmentRelationships(textContent, assemblyName, relationshipPatterns);
        
        assemblies.push({
          name: assemblyName,
          level,
          parentId: undefined, // Will be resolved after all assemblies are created
          parentName: parentName, // Store parent name for resolution
          containment: containmentInfo,
          metadata: {
            drawingNumber: drawingMetadata.drawingNumber,
            revision: drawingMetadata.revision,
            scale: drawingMetadata.scale
          }
        });
        
        // Store hierarchy information
        assemblyHierarchy.set(assemblyName, {
          level,
          parentName,
          children: []
        });
      }
    });
  } else {
    // Create default main assembly
    const mainAssemblyName = `${filename.replace(/\.[^/.]+$/, "")} Main Assembly`;
    assemblies.push({
      name: mainAssemblyName,
      level: 0,
      metadata: drawingMetadata
    });
  }
  
  // Step 2: Establish parent-child relationships based on detected hierarchy
  establishParentChildRelationships(assemblies, assemblyHierarchy);
  
  return { assemblies, hierarchy: assemblyHierarchy };
}

function analyzeIndentationHierarchy(lines: string[]): Map<string, number> {
  const indentationMap = new Map<string, number>();
  
  lines.forEach(line => {
    const match = line.match(/^(\s*)(.+)/);
    if (match && match[2].trim()) {
      const indentLevel = Math.floor(match[1].length / 2); // 2 spaces = 1 level
      const content = match[2].trim();
      if (/(?:ASSEMBLY|ASSY|PART|P\/N)/i.test(content)) {
        indentationMap.set(content, indentLevel);
      }
    }
  });
  
  return indentationMap;
}

function analyzeNumberingHierarchy(textContent: string, patterns: any): Map<string, { level: number; parent?: string }> {
  const numberingHierarchy = new Map<string, { level: number; parent?: string }>();
  
  // Analyze hierarchical part numbers (e.g., 9001-2000-01, 9001-2000-02)
  const hierarchicalMatches = Array.from(textContent.matchAll(/([A-Z0-9]+)[\-\.](\d+)[\-\.](\d+)/g));
  
  hierarchicalMatches.forEach(match => {
    const fullNumber = match[0];
    const prefix = match[1];
    const major = match[2];
    const minor = match[3];
    
    // Root level: just prefix (9001)
    // Level 1: prefix-major (9001-2000)  
    // Level 2: prefix-major-minor (9001-2000-01)
    
    const level = fullNumber.split(/[\-\.]/).length - 1;
    const parentNumber = level > 1 ? `${prefix}-${major}` : level > 0 ? prefix : undefined;
    
    numberingHierarchy.set(fullNumber, { level, parent: parentNumber });
  });
  
  return numberingHierarchy;
}

function determineAssemblyLevel(assemblyName: string, matchText: string, indentationMap: Map<string, number>, numberingHierarchy: Map<string, { level: number; parent?: string }>): number {
  // Check if it's explicitly marked as sub-assembly
  if (/SUB[\s-]*ASSEMBLY|SUBASSY/i.test(matchText)) {
    return 1;
  }
  
  // Check numbering hierarchy
  for (const [number, info] of Array.from(numberingHierarchy)) {
    if (assemblyName.includes(number)) {
      return Math.min(info.level, 3); // Cap at level 3
    }
  }
  
  // Check indentation
  for (const [content, level] of Array.from(indentationMap)) {
    if (content.includes(assemblyName) || assemblyName.includes(content)) {
      return Math.min(level, 3);
    }
  }
  
  // Default to root level
  return 0;
}

function findParentAssembly(assemblyName: string, assemblyLevel: number, existingAssemblies: ParsedData['assemblies'], numberingHierarchy: Map<string, { level: number; parent?: string }>): string | undefined {
  // Check numbering hierarchy first
  for (const [number, info] of Array.from(numberingHierarchy)) {
    if (assemblyName.includes(number) && info.parent) {
      // Find assembly that contains the parent number
      const parentAssembly = existingAssemblies.find(asm => asm.name.includes(info.parent!));
      if (parentAssembly) {
        return parentAssembly.name;
      }
    }
  }
  
  // Find assembly with lower level that could be parent
  if (assemblyLevel > 0) {
    // Find the most recent assembly with level = assemblyLevel - 1
    for (let i = existingAssemblies.length - 1; i >= 0; i--) {
      const assembly = existingAssemblies[i];
      if (assembly.level === assemblyLevel - 1) {
        return assembly.name;
      }
    }
  }
  
  return undefined;
}

function analyzeContainmentRelationships(textContent: string, assemblyName: string, relationshipPatterns: any): any {
  const containment: any = {};
  
  // Find text near this assembly to analyze relationships
  const assemblyIndex = textContent.indexOf(assemblyName);
  const nearbyText = textContent.substring(Math.max(0, assemblyIndex - 500), assemblyIndex + 500);
  
  // Create fresh regex instances to avoid global state issues
  const containsRegex = new RegExp(relationshipPatterns.containsKeywords.source, 'i');
  const partOfRegex = new RegExp(relationshipPatterns.partOfKeywords.source, 'i');
  const mountedOnRegex = new RegExp(relationshipPatterns.mountedOn.source, 'i');
  
  // Check for containment keywords
  const containsMatch = containsRegex.exec(nearbyText);
  if (containsMatch) {
    containment.contains = containsMatch[1].trim();
  }
  
  const partOfMatch = partOfRegex.exec(nearbyText);
  if (partOfMatch) {
    containment.partOf = partOfMatch[1].trim();
  }
  
  const mountedOnMatch = mountedOnRegex.exec(nearbyText);
  if (mountedOnMatch) {
    containment.mountedOn = mountedOnMatch[1].trim();
  }
  
  return Object.keys(containment).length > 0 ? containment : undefined;
}

function establishParentChildRelationships(assemblies: ParsedData['assemblies'], assemblyHierarchy: Map<string, { level: number; parentName?: string; children: string[] }>) {
  // Note: parentId resolution should happen in the storage layer after assembly IDs are generated
  // Here we only ensure parentName is properly set for later resolution
  assemblies.forEach(assembly => {
    const hierarchyInfo = assemblyHierarchy.get(assembly.name);
    if (hierarchyInfo?.parentName && !assembly.parentName) {
      assembly.parentName = hierarchyInfo.parentName;
    }
  });
  
  // Build children lists for hierarchy tracking
  assemblies.forEach(assembly => {
    const hierarchyInfo = assemblyHierarchy.get(assembly.name);
    if (hierarchyInfo && assembly.parentName) {
      const parentHierarchy = assemblyHierarchy.get(assembly.parentName);
      if (parentHierarchy) {
        parentHierarchy.children.push(assembly.name);
      }
    }
  });
}

function analyzePartAssemblyRelationships(textContent: string, patterns: any, relationshipPatterns: any, assemblies: ParsedData['assemblies']): ParsedData['parts'] {
  const parts: ParsedData['parts'] = [];
  const lines = textContent.split(/[\n\r]+/);
  
  // Parse parts with advanced pattern matching
  const partMatches: RegExpExecArray[] = [];
  let match;
  while ((match = patterns.partNumber.exec(textContent)) !== null) {
    partMatches.push(match);
  }
  const processedParts = new Set<string>();
  
  // Create assembly context map for intelligent assignment
  const assemblyContextMap = createAssemblyContextMap(lines, assemblies);
  
  partMatches.forEach((match, index) => {
    const partNumber = match[1];
    if (processedParts.has(partNumber)) return;
    processedParts.add(partNumber);
    
    // Find the position of this part in the document
    const partPosition = textContent.indexOf(partNumber);
    const partLineIndex = findLineIndexFromPosition(textContent, partPosition);
    
    // Find quantity for this part
    const quantity = findQuantityForPart(textContent, partNumber, patterns.quantity);
    
    // Extract part metadata from surrounding text
    const partMetadata = extractPartMetadata(textContent, partNumber, patterns);
    
    // Generate intelligent part name
    const partName = generatePartName(partNumber, partMetadata);
    
    // Intelligent assembly assignment based on context
    const assemblyName = determinePartAssembly(
      partNumber, 
      partLineIndex, 
      lines, 
      assemblies, 
      assemblyContextMap, 
      relationshipPatterns
    );
    
    parts.push({
      name: partName,
      partNumber,
      quantity,
      assemblyName,
      metadata: partMetadata
    });
  });
  
  return parts;
}

function createAssemblyContextMap(lines: string[], assemblies: ParsedData['assemblies']): Map<string, { startLine: number; endLine: number; level: number }> {
  const contextMap = new Map<string, { startLine: number; endLine: number; level: number }>();
  
  assemblies.forEach(assembly => {
    let startLine = -1;
    let endLine = lines.length - 1;
    
    // Find the line where this assembly is mentioned
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].includes(assembly.name) || 
          (assembly.name.includes('ASSEMBLY') && lines[i].includes(assembly.name.replace(' ASSEMBLY', '')))) {
        startLine = i;
        break;
      }
    }
    
    if (startLine >= 0) {
      // Find the end of this assembly's section (next assembly or end of document)
      for (let i = startLine + 1; i < lines.length; i++) {
        const line = lines[i];
        if (/(?:ASSEMBLY|ASSY)/i.test(line) && !line.includes(assembly.name)) {
          // Check if this is a different assembly
          const isSubAssembly = /SUB[\s-]*ASSEMBLY/i.test(line);
          const currentAssemblyLevel = assembly.level || 0;
          
          if (!isSubAssembly || currentAssemblyLevel === 0) {
            endLine = i - 1;
            break;
          }
        }
      }
      
      contextMap.set(assembly.name, {
        startLine,
        endLine,
        level: assembly.level || 0
      });
    }
  });
  
  return contextMap;
}

function findLineIndexFromPosition(textContent: string, position: number): number {
  const beforeText = textContent.substring(0, position);
  return beforeText.split(/[\n\r]+/).length - 1;
}

function determinePartAssembly(
  partNumber: string, 
  partLineIndex: number, 
  lines: string[], 
  assemblies: ParsedData['assemblies'], 
  assemblyContextMap: Map<string, { startLine: number; endLine: number; level: number }>,
  relationshipPatterns: any
): string {
  
  // Strategy 1: Check if part is within an assembly's context range
  // Find the most specific (deepest level, smallest range) assembly that contains this part
  let bestAssembly: { name: string; level: number; range: number } | undefined;
  
  for (const [assemblyName, context] of Array.from(assemblyContextMap)) {
    if (partLineIndex >= context.startLine && partLineIndex <= context.endLine) {
      const range = context.endLine - context.startLine;
      
      if (!bestAssembly || 
          context.level > bestAssembly.level || 
          (context.level === bestAssembly.level && range < bestAssembly.range)) {
        bestAssembly = { name: assemblyName, level: context.level, range };
      }
    }
  }
  
  if (bestAssembly) {
    return bestAssembly.name;
  }
  
  // Strategy 2: Check part numbering hierarchy
  const partAssemblyFromNumbering = findAssemblyFromPartNumbering(partNumber, assemblies);
  if (partAssemblyFromNumbering) {
    return partAssemblyFromNumbering;
  }
  
  // Strategy 3: Look for explicit relationship keywords nearby
  const nearbyLines = lines.slice(Math.max(0, partLineIndex - 5), Math.min(lines.length, partLineIndex + 5));
  const nearbyText = nearbyLines.join(' ');
  
  for (const assembly of assemblies) {
    // Check for explicit relationships using fresh regex instances
    const partOfRegex = new RegExp(relationshipPatterns.partOfKeywords.source, 'i');
    const mountedOnRegex = new RegExp(relationshipPatterns.mountedOn.source, 'i');
    
    if (partOfRegex.test(nearbyText) && nearbyText.includes(assembly.name)) {
      return assembly.name;
    }
    if (mountedOnRegex.test(nearbyText) && nearbyText.includes(assembly.name)) {
      return assembly.name;
    }
  }
  
  // Strategy 4: Find the closest assembly above this part
  let closestAssembly = assemblies[0]?.name || 'Main Assembly';
  let closestDistance = Infinity;
  
  for (const [assemblyName, context] of Array.from(assemblyContextMap)) {
    if (context.startLine <= partLineIndex) {
      const distance = partLineIndex - context.startLine;
      if (distance < closestDistance) {
        closestDistance = distance;
        closestAssembly = assemblyName;
      }
    }
  }
  
  return closestAssembly;
}

function findAssemblyFromPartNumbering(partNumber: string, assemblies: ParsedData['assemblies']): string | undefined {
  // Look for assemblies that share numbering patterns with the part
  // e.g., part "9001-2000-01" might belong to assembly "TANK ASSEMBLY 9001-2000"
  
  for (const assembly of assemblies) {
    // Extract numbers from assembly name
    const assemblyNumbers = assembly.name.match(/([A-Z0-9]+)[\-\.](\d+)/);
    const partNumbers = partNumber.match(/([A-Z0-9]+)[\-\.](\d+)/);
    
    if (assemblyNumbers && partNumbers) {
      // Check if they share the same prefix and major number
      if (assemblyNumbers[1] === partNumbers[1] && assemblyNumbers[2] === partNumbers[2]) {
        return assembly.name;
      }
    }
    
    // Also check if the assembly name contains part of the part number
    const partPrefix = partNumber.split(/[\-\.]/)[0];
    if (partPrefix.length >= 3 && assembly.name.includes(partPrefix)) {
      return assembly.name;
    }
  }
  
  return undefined;
}

function extractDrawingMetadata(text: string, patterns: any) {
  const dwgMatch = patterns.dwgNumber.exec(text);
  const revMatch = patterns.revision.exec(text);
  const scaleMatch = patterns.scale.exec(text);
  
  return {
    drawingNumber: dwgMatch?.[1],
    revision: revMatch?.[1],
    scale: scaleMatch?.[1]
  };
}

function findQuantityForPart(text: string, partNumber: string, quantityPattern: RegExp): number {
  // Look for quantity in a larger window after finding the part
  const lines = text.split(/[\n\r]+/);
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.includes(partNumber)) {
      // Create a non-global regex for each line to avoid lastIndex issues
      const qtyRegex = /(?:QTY|QUANTITY)[:\s]*(\d+)/i;
      
      // First, check the same line for quantity
      const qtyMatch = qtyRegex.exec(line);
      if (qtyMatch) {
        return parseInt(qtyMatch[1], 10);
      }
      
      // Search forward up to 20 lines or until next part marker
      for (let j = i + 1; j <= Math.min(lines.length - 1, i + 20); j++) {
        const searchLine = lines[j];
        
        // Stop if we hit another part number
        if (/PART[\s#-]*(?:NO|NUMBER)|P\/N/i.test(searchLine) && !searchLine.includes(partNumber)) {
          break;
        }
        
        const adjacentQtyMatch = qtyRegex.exec(searchLine);
        if (adjacentQtyMatch) {
          return parseInt(adjacentQtyMatch[1], 10);
        }
      }
      
      // Also search backward for 5 lines
      for (let j = Math.max(0, i - 5); j < i; j++) {
        const adjacentQtyMatch = qtyRegex.exec(lines[j]);
        if (adjacentQtyMatch) {
          return parseInt(adjacentQtyMatch[1], 10);
        }
      }
      
      break; // Found the part, no need to check other lines
    }
  }
  
  return 1; // Default quantity
}

function extractPartMetadata(text: string, partNumber: string, patterns: any) {
  const partIndex = text.indexOf(partNumber);
  const nearbyText = text.substring(Math.max(0, partIndex - 400), partIndex + 400);
  
  // Advanced metadata extraction using enhanced patterns
  const metadata: any = {};
  
  // Material properties
  const materialMatch = patterns.material.exec(nearbyText);
  const materialGradeMatch = patterns.materialGrade.exec(nearbyText);
  const materialStandardMatch = patterns.materialStandard.exec(nearbyText);
  
  if (materialMatch) {
    // Prefer explicit material specification over matched material names
    metadata.material = materialMatch[1]?.trim() || materialMatch[0]?.trim();
  }
  if (materialGradeMatch) {
    metadata.materialGrade = (materialGradeMatch[1] || materialGradeMatch[2])?.trim();
    // Ensure we don't duplicate material in grade
    if (metadata.material && metadata.materialGrade && metadata.materialGrade.includes(metadata.material)) {
      metadata.materialGrade = metadata.materialGrade.replace(metadata.material, '').trim();
    }
  }
  if (materialStandardMatch) {
    metadata.materialStandard = materialStandardMatch[1]?.trim();
  }
  
  // Advanced dimensional analysis
  const dimensionMatch = patterns.dimension.exec(nearbyText);
  const diameterMatch = patterns.diameter.exec(nearbyText);
  const lengthMatch = patterns.length.exec(nearbyText);
  const widthMatch = patterns.width.exec(nearbyText);
  const heightMatch = patterns.height.exec(nearbyText);
  const thicknessMatch = patterns.thickness.exec(nearbyText);
  const weightMatch = patterns.weight.exec(nearbyText);
  
  if (dimensionMatch) {
    const dims = [dimensionMatch[1], dimensionMatch[2], dimensionMatch[3]].filter(Boolean);
    metadata.dimensions = dims.join(' × ');
  }
  if (diameterMatch) metadata.diameter = diameterMatch[1];
  if (lengthMatch) metadata.length = lengthMatch[1];
  if (widthMatch) metadata.width = widthMatch[1];
  if (heightMatch) metadata.height = heightMatch[1];
  if (thicknessMatch) metadata.thickness = thicknessMatch[1];
  if (weightMatch) metadata.weight = weightMatch[1];
  
  // Tolerances and surface finish
  const toleranceMatch = patterns.tolerance.exec(nearbyText);
  const geometricToleranceMatch = patterns.geometricTolerance.exec(nearbyText);
  const surfaceFinishMatch = patterns.surfaceFinish.exec(nearbyText);
  
  if (toleranceMatch) metadata.tolerance = toleranceMatch[1];
  if (geometricToleranceMatch) metadata.geometricTolerance = geometricToleranceMatch[1]?.trim();
  if (surfaceFinishMatch) metadata.surfaceFinish = surfaceFinishMatch[1];
  
  // Manufacturing processes
  if (patterns.machining.test(nearbyText)) {
    metadata.manufacturing = metadata.manufacturing || [];
    metadata.manufacturing.push('Machining');
  }
  if (patterns.welding.test(nearbyText)) {
    metadata.manufacturing = metadata.manufacturing || [];
    metadata.manufacturing.push('Welding');
  }
  if (patterns.forming.test(nearbyText)) {
    metadata.manufacturing = metadata.manufacturing || [];
    metadata.manufacturing.push('Forming');
  }
  
  const threadingMatch = patterns.threading.exec(nearbyText);
  if (threadingMatch) {
    metadata.threading = threadingMatch[1]?.trim() || 'Standard Threading';
  }
  
  // Surface treatments and finishes
  const finishMatch = patterns.finish.exec(nearbyText);
  const heatTreatmentMatch = patterns.heatTreatment.exec(nearbyText);
  const coatingMatch = patterns.coating.exec(nearbyText);
  
  if (finishMatch) metadata.finish = finishMatch[1]?.trim();
  if (heatTreatmentMatch) {
    metadata.heatTreatment = (heatTreatmentMatch[1] || heatTreatmentMatch[2])?.trim() || 'Heat Treated';
  }
  if (coatingMatch) metadata.coating = coatingMatch[0];
  
  // Sourcing and cost information
  const supplierMatch = patterns.supplier.exec(nearbyText);
  const costMatch = patterns.partCost.exec(nearbyText);
  const leadTimeMatch = patterns.leadTime.exec(nearbyText);
  
  if (supplierMatch) metadata.supplier = supplierMatch[1]?.trim();
  if (costMatch) metadata.cost = parseFloat(costMatch[1]);
  if (leadTimeMatch) metadata.leadTime = leadTimeMatch[1];
  
  // Standards and certifications
  const standardMatch = patterns.standard.exec(nearbyText);
  const certificationMatch = patterns.certification.exec(nearbyText);
  
  if (standardMatch) metadata.standard = standardMatch[1]?.trim();
  if (certificationMatch) metadata.certification = certificationMatch[1]?.trim();
  
  return metadata;
}

function classifyPartType(partNumber: string, metadata: any): string {
  // Advanced part classification based on multiple factors
  const pn = partNumber.toUpperCase();
  
  // Fastener identification
  if (/BOLT|BT|SCREW|SC|NUT|NT|WASHER|WS|RIVET|RV/.test(pn) || 
      metadata.threading || 
      (metadata.dimensions && /M\d+|#\d+|\d+\/\d+/.test(metadata.dimensions))) {
    if (/BOLT|BT/.test(pn)) return 'Bolt';
    if (/SCREW|SC/.test(pn)) return 'Screw';
    if (/NUT|NT/.test(pn)) return 'Nut';
    if (/WASHER|WS/.test(pn)) return 'Washer';
    if (/RIVET|RV/.test(pn)) return 'Rivet';
    return 'Fastener';
  }
  
  // Structural components
  if (/FRAME|FR|BEAM|BM|PLATE|PL|BRACKET|BR|SUPPORT|SUP/.test(pn) ||
      (metadata.thickness && parseFloat(metadata.thickness) > 5)) {
    if (/FRAME|FR/.test(pn)) return 'Frame';
    if (/BEAM|BM/.test(pn)) return 'Beam';
    if (/PLATE|PL/.test(pn)) return 'Plate';
    if (/BRACKET|BR/.test(pn)) return 'Bracket';
    if (/SUPPORT|SUP/.test(pn)) return 'Support';
    return 'Structural Component';
  }
  
  // Rotating components
  if (/SHAFT|SH|GEAR|GR|BEARING|BG|PULLEY|PU|SPROCKET|SPR/.test(pn) ||
      metadata.diameter) {
    if (/SHAFT|SH/.test(pn)) return 'Shaft';
    if (/GEAR|GR/.test(pn)) return 'Gear';
    if (/BEARING|BG/.test(pn)) return 'Bearing';
    if (/PULLEY|PU/.test(pn)) return 'Pulley';
    if (/SPROCKET|SPR/.test(pn)) return 'Sprocket';
    return 'Rotating Component';
  }
  
  // Sealing components
  if (/SEAL|SE|GASKET|GS|RING|RG|O-RING|OR/.test(pn) ||
      (metadata.material && /RUBBER|VITON|SILICONE/.test(metadata.material.toUpperCase()))) {
    if (/SEAL|SE/.test(pn)) return 'Seal';
    if (/GASKET|GS/.test(pn)) return 'Gasket';
    if (/O-RING|OR/.test(pn)) return 'O-Ring';
    return 'Sealing Component';
  }
  
  // Housing and covers
  if (/HOUSING|HS|COVER|CV|CAP|CP|CASE|CS/.test(pn)) {
    if (/HOUSING|HS/.test(pn)) return 'Housing';
    if (/COVER|CV/.test(pn)) return 'Cover';
    if (/CAP|CP/.test(pn)) return 'Cap';
    if (/CASE|CS/.test(pn)) return 'Case';
    return 'Housing Component';
  }
  
  // Springs and elastic components
  if (/SPRING|SP|DAMPER|DP|SHOCK|SH/.test(pn)) {
    if (/SPRING|SP/.test(pn)) return 'Spring';
    if (/DAMPER|DP/.test(pn)) return 'Damper';
    if (/SHOCK|SH/.test(pn)) return 'Shock Absorber';
    return 'Elastic Component';
  }
  
  // Electrical components
  if (/WIRE|WR|CABLE|CB|CONNECTOR|CN|SWITCH|SW|SENSOR|SN/.test(pn)) {
    if (/WIRE|WR/.test(pn)) return 'Wire';
    if (/CABLE|CB/.test(pn)) return 'Cable';
    if (/CONNECTOR|CN/.test(pn)) return 'Connector';
    if (/SWITCH|SW/.test(pn)) return 'Switch';
    if (/SENSOR|SN/.test(pn)) return 'Sensor';
    return 'Electrical Component';
  }
  
  // Generic classification
  return 'Component';
}

function generatePartName(partNumber: string, metadata: any): string {
  // Use advanced classification to generate intelligent part names
  const partType = classifyPartType(partNumber, metadata);
  let baseName = partType;
  
  // Add dimensional information if available
  if (metadata.diameter) {
    baseName += ` Ø${metadata.diameter}`;
  } else if (metadata.dimensions) {
    baseName += ` ${metadata.dimensions}`;
  } else if (metadata.length && metadata.width) {
    baseName += ` ${metadata.length}×${metadata.width}`;
  }
  
  // Add material information
  if (metadata.material) {
    baseName += ` (${metadata.material}`;
    if (metadata.materialGrade) {
      baseName += ` ${metadata.materialGrade}`;
    }
    baseName += ')';
  }
  
  // Add threading information for fasteners
  if (metadata.threading && /Fastener|Bolt|Screw|Nut/.test(partType)) {
    baseName += ` ${metadata.threading}`;
  }
  
  // Add coating or finish information
  if (metadata.coating) {
    baseName += ` - ${metadata.coating}`;
  } else if (metadata.finish && metadata.finish !== metadata.material) {
    baseName += ` - ${metadata.finish}`;
  }
  
  return baseName;
}

function extractFromBOMTable(text: string, assemblyName: string): ParsedData['parts'] {
  const parts: ParsedData['parts'] = [];
  
  // Look for table-like structures in the text
  const lines = text.split(/[\n\r]+/);
  let inBOMSection = false;
  
  for (const line of lines) {
    const trimmedLine = line.trim();
    
    // Detect BOM table headers
    if (/(?:item|part|qty|quantity|description)/i.test(line) && /(?:number|no\.?|#)/i.test(line)) {
      inBOMSection = true;
      continue;
    }
    
    // Exit BOM section if we hit an empty line
    if (inBOMSection && !trimmedLine) {
      inBOMSection = false;
      continue;
    }
    
    // Parse BOM rows when in section and line has content
    if (inBOMSection && trimmedLine) {
      const bomMatch = trimmedLine.match(/(\d+)\s+([A-Z0-9\-]{3,15})\s+(\d+)\s+(.+)/i);
      if (bomMatch) {
        const [, item, partNumber, quantity, description] = bomMatch;
        parts.push({
          name: description.trim(),
          partNumber: partNumber.toUpperCase(),
          quantity: parseInt(quantity, 10),
          assemblyName,
        });
      }
    }
  }
  
  return parts;
}

function createIntelligentDefaults(filename: string, message?: string): ParsedData {
  const baseName = filename.replace(/\.[^/.]+$/, "");
  const randomSuffix = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  
  // Generate more realistic defaults based on filename patterns
  const filenameLower = filename.toLowerCase();
  let assemblyType = "Assembly";
  let componentTypes = ["Component A", "Component B", "Fastener"];
  
  // Intelligent defaults based on filename
  if (filenameLower.includes("housing") || filenameLower.includes("enclosure")) {
    assemblyType = "Housing Assembly";
    componentTypes = ["Housing Shell", "Housing Cover", "Mounting Bracket", "Seal"];
  } else if (filenameLower.includes("mechanical") || filenameLower.includes("mech")) {
    assemblyType = "Mechanical Assembly";
    componentTypes = ["Main Frame", "Drive Shaft", "Bearing", "Coupling"];
  } else if (filenameLower.includes("electrical") || filenameLower.includes("elec")) {
    assemblyType = "Electrical Assembly";
    componentTypes = ["PCB", "Connector", "Wire Harness", "Terminal Block"];
  }
  
  const assemblies: ParsedData['assemblies'] = [
    {
      name: `${baseName} ${assemblyType}`,
      level: 0,
      metadata: {
        drawingNumber: `DWG-${randomSuffix}`,
        revision: "A",
        scale: "1:1"
      }
    }
  ];
  
  const parts: ParsedData['parts'] = componentTypes.map((componentType, index) => ({
    name: componentType,
    partNumber: `${componentType.substring(0, 2).toUpperCase()}-${randomSuffix}-${(index + 1).toString().padStart(2, '0')}`,
    quantity: index === componentTypes.length - 1 ? Math.floor(Math.random() * 10) + 2 : 1, // Last component is usually fasteners
    assemblyName: assemblies[0].name,
    metadata: {
      material: index < 2 ? "Steel" : "Stainless Steel",
      dimensions: `${Math.floor(Math.random() * 100) + 10}x${Math.floor(Math.random() * 100) + 10}x${Math.floor(Math.random() * 50) + 5}`,
      tolerance: "±0.1mm",
      finish: index < 2 ? "Anodized" : "Passivated"
    }
  }));
  
  return { assemblies, parts };
}

function extractTextFromDxf(dxfData: any): string {
  let extractedText = '';
  
  try {
    // Iterate through the entities array
    const entities = dxfData.entities || [];
    
    for (const entity of entities) {
      switch (entity.type) {
        case 'TEXT':
          if (entity.text) {
            extractedText += entity.text + ' ';
          }
          break;
          
        case 'MTEXT':
          // Handle multiline text and normalize DXF control codes
          let mtextContent = entity.text || entity.value || '';
          mtextContent = mtextContent.replace(/\\P/g, ' '); // Replace paragraph markers with spaces
          mtextContent = mtextContent.replace(/\\[A-Za-z][0-9]*;?/g, ''); // Remove other DXF control codes
          if (mtextContent.trim()) {
            extractedText += mtextContent + ' ';
          }
          break;
          
        case 'DIMENSION':
          // Use dimension text if available and not auto-generated
          if (entity.text && entity.text !== '<>') {
            extractedText += entity.text + ' ';
          } else if (entity.actualMeasurement) {
            extractedText += entity.actualMeasurement + ' ';
          } else if (entity.dimText) {
            extractedText += entity.dimText + ' ';
          }
          break;
          
        case 'INSERT':
          // Extract text from block attributes
          const attributes = entity.attributes || entity.attribs || [];
          attributes.forEach((attr: any) => {
            const attrText = attr.text || attr.value || '';
            if (attrText.trim()) {
              extractedText += attrText + ' ';
            }
          });
          break;
          
        default:
          // Skip other entity types for now
          break;
      }
    }
    
    console.log(`Extracted ${extractedText.length} characters from ${entities.length} DXF entities`);
  } catch (error) {
    console.warn('Error extracting text from DXF entities:', error);
  }
  
  return extractedText.trim();
}

function createDefaultStructure(filename: string): ParsedData {
  // Keep the old function for backward compatibility
  return createIntelligentDefaults(filename);
}