import * as ExcelJS from 'exceljs';
import type { Assembly, Part, DwgFile } from '@shared/schema';

export interface ExcelExportData {
  dwgFiles: DwgFile[];
  assemblies: Assembly[];
  parts: Part[];
}

export async function generateMasterExcel(data: ExcelExportData): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  
  // Set workbook properties
  workbook.creator = 'DWG BOM Generator';
  workbook.lastModifiedBy = 'DWG BOM Generator';
  workbook.created = new Date();
  workbook.modified = new Date();

  // DWG Files sheet
  const dwgSheet = workbook.addWorksheet('DWG Files');
  dwgSheet.columns = [
    { header: 'ID', key: 'id', width: 36 },
    { header: 'Filename', key: 'filename', width: 30 },
    { header: 'File Path', key: 'filePath', width: 50 },
    { header: 'File Size (bytes)', key: 'fileSize', width: 15 },
    { header: 'Parse Status', key: 'parseStatus', width: 15 },
    { header: 'Upload Date', key: 'uploadDate', width: 20 },
    { header: 'Metadata', key: 'metadata', width: 30 },
  ];

  data.dwgFiles.forEach(dwg => {
    dwgSheet.addRow({
      id: dwg.id,
      filename: dwg.filename,
      filePath: dwg.filePath,
      fileSize: dwg.fileSize,
      parseStatus: dwg.parseStatus,
      uploadDate: dwg.createdAt,
      metadata: JSON.stringify(dwg.extractedData),
    });
  });

  // Assemblies sheet
  const assemblySheet = workbook.addWorksheet('Assemblies');
  assemblySheet.columns = [
    { header: 'ID', key: 'id', width: 36 },
    { header: 'Name', key: 'name', width: 30 },
    { header: 'Description', key: 'description', width: 50 },
    { header: 'Status', key: 'status', width: 15 },
    { header: 'Level', key: 'level', width: 10 },
    { header: 'Parent ID', key: 'parentId', width: 36 },
    { header: 'DWG File ID', key: 'dwgFileId', width: 36 },
    { header: 'Is Expanded', key: 'isExpanded', width: 12 },
  ];

  data.assemblies.forEach(assembly => {
    assemblySheet.addRow({
      id: assembly.id,
      name: assembly.name,
      description: assembly.description,
      status: assembly.status,
      level: assembly.level,
      parentId: assembly.parentId,
      dwgFileId: '', // Not available in current schema
      isExpanded: assembly.isExpanded,
    });
  });

  // Parts sheet
  const partsSheet = workbook.addWorksheet('Parts');
  partsSheet.columns = [
    { header: 'ID', key: 'id', width: 36 },
    { header: 'Name', key: 'name', width: 30 },
    { header: 'Part Number', key: 'partNumber', width: 20 },
    { header: 'Description', key: 'description', width: 50 },
    { header: 'Status', key: 'status', width: 15 },
    { header: 'Assembly ID', key: 'assemblyId', width: 36 },
    { header: 'Quantity', key: 'quantity', width: 10 },
    { header: 'Unit', key: 'unit', width: 10 },
    { header: 'Material', key: 'material', width: 20 },
    { header: 'Supplier', key: 'supplier', width: 20 },
    { header: 'Cost', key: 'cost', width: 12 },
  ];

  data.parts.forEach(part => {
    partsSheet.addRow({
      id: part.id,
      name: part.name,
      partNumber: part.partNumber,
      description: part.description,
      status: part.status,
      assemblyId: part.assemblyId,
      quantity: part.quantity,
      unit: '', // Not available in current schema
      material: '', // Not available in current schema
      supplier: '', // Not available in current schema
      cost: 0, // Not available in current schema
    });
  });

  // Summary sheet
  const summarySheet = workbook.addWorksheet('Summary');
  summarySheet.columns = [
    { header: 'Category', key: 'category', width: 20 },
    { header: 'Count', key: 'count', width: 10 },
    { header: 'Details', key: 'details', width: 50 },
  ];

  // Add summary data
  summarySheet.addRow({
    category: 'DWG Files',
    count: data.dwgFiles.length,
    details: `${data.dwgFiles.filter(d => d.parseStatus === 'completed').length} completed, ${data.dwgFiles.filter(d => d.parseStatus === 'failed').length} failed`
  });

  summarySheet.addRow({
    category: 'Assemblies',
    count: data.assemblies.length,
    details: `${data.assemblies.filter(a => a.status === 'complete').length} complete, ${data.assemblies.filter(a => a.status === 'progress').length} in progress`
  });

  summarySheet.addRow({
    category: 'Parts',
    count: data.parts.length,
    details: `${data.parts.filter(p => p.status === 'complete').length} complete, ${data.parts.filter(p => p.status === 'progress').length} in progress`
  });

  summarySheet.addRow({
    category: 'Total File Size',
    count: data.dwgFiles.reduce((sum, f) => sum + (f.fileSize || 0), 0),
    details: 'bytes across all DWG files'
  });

  // Style the headers
  [dwgSheet, assemblySheet, partsSheet, summarySheet].forEach(sheet => {
    sheet.getRow(1).eachCell(cell => {
      cell.font = { bold: true };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFE0E0E0' }
      };
    });
  });

  // Generate buffer
  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}

export async function parseExcelData(buffer: Buffer): Promise<Partial<ExcelExportData>> {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(buffer);

  const result: Partial<ExcelExportData> = {
    dwgFiles: [],
    assemblies: [],
    parts: []
  };

  const safeJsonParse = (value: any): any => {
    if (!value) return {};
    try {
      return typeof value === 'string' ? JSON.parse(value) : value;
    } catch (error) {
      console.warn('Failed to parse JSON value:', value);
      return {};
    }
  };

  const safeStringValue = (value: any): string => {
    return value ? String(value) : '';
  };

  const safeNumberValue = (value: any): number => {
    const num = Number(value);
    return isNaN(num) ? 0 : num;
  };

  const safeDateValue = (value: any): Date | null => {
    if (!value) return null;
    if (value instanceof Date) return value;
    const date = new Date(value);
    return isNaN(date.getTime()) ? null : date;
  };

  // Parse DWG Files sheet
  const dwgSheet = workbook.getWorksheet('DWG Files');
  if (dwgSheet) {
    dwgSheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return; // Skip header

      const idValue = row.getCell(1).value;
      const filenameValue = row.getCell(2).value;
      
      if (!idValue || !filenameValue) return; // Skip invalid rows

      const dwgFile: Partial<DwgFile> = {
        id: safeStringValue(idValue),
        filename: safeStringValue(filenameValue),
        filePath: safeStringValue(row.getCell(3).value),
        fileSize: safeNumberValue(row.getCell(4).value) || null,
        parseStatus: safeStringValue(row.getCell(5).value) || 'pending',
        createdAt: safeDateValue(row.getCell(6).value),
        extractedData: safeJsonParse(row.getCell(7).value),
      };

      result.dwgFiles!.push(dwgFile as DwgFile);
    });
  }

  // Parse Assemblies sheet
  const assemblySheet = workbook.getWorksheet('Assemblies');
  if (assemblySheet) {
    assemblySheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return; // Skip header

      const idValue = row.getCell(1).value;
      const nameValue = row.getCell(2).value;
      
      if (!idValue || !nameValue) return; // Skip invalid rows

      const assembly: Partial<Assembly> = {
        id: safeStringValue(idValue),
        name: safeStringValue(nameValue),
        description: safeStringValue(row.getCell(3).value) || null,
        status: safeStringValue(row.getCell(4).value) || 'new',
        level: safeNumberValue(row.getCell(5).value),
        parentId: safeStringValue(row.getCell(6).value) || null,
        isExpanded: Boolean(row.getCell(8).value),
        thumbnailPath: null,
        createdAt: null,
      };

      result.assemblies!.push(assembly as Assembly);
    });
  }

  // Parse Parts sheet
  const partsSheet = workbook.getWorksheet('Parts');
  if (partsSheet) {
    partsSheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return; // Skip header

      const idValue = row.getCell(1).value;
      const nameValue = row.getCell(2).value;
      const partNumberValue = row.getCell(3).value;
      
      if (!idValue || !nameValue || !partNumberValue) return; // Skip invalid rows

      const part: Partial<Part> = {
        id: safeStringValue(idValue),
        name: safeStringValue(nameValue),
        partNumber: safeStringValue(partNumberValue),
        description: safeStringValue(row.getCell(4).value) || null,
        status: safeStringValue(row.getCell(5).value) || 'new',
        assemblyId: safeStringValue(row.getCell(6).value) || null,
        quantity: safeNumberValue(row.getCell(7).value) || 1,
        thumbnailPath: null,
        metadata: {},
        createdAt: null,
      };

      result.parts!.push(part as Part);
    });
  }

  return result;
}

export async function parseExcelBomData(buffer: Buffer): Promise<{ parts: any[], assemblies: any[] }> {
  console.log('parseExcelBomData: Starting BOM parsing...');
  console.log('parseExcelBomData: Buffer length:', buffer.length);
  
  if (buffer.length === 0) {
    throw new Error('Empty buffer received - file may not exist or download failed');
  }
  
  // Use the same Workbook creation pattern as other functions  
  const workbook = new (ExcelJS as any).default.Workbook();
  
  console.log('parseExcelBomData: Workbook created, loading buffer...');
  await workbook.xlsx.load(buffer);
  console.log('parseExcelBomData: Buffer loaded successfully');

  const result = {
    parts: [] as any[],
    assemblies: [] as any[]
  };

  // Look for BOM worksheet
  const bomWorksheet = workbook.getWorksheet('BOM');
  if (!bomWorksheet) {
    console.warn('BOM worksheet not found in Project Input.xlsx');
    return result;
  }

  const safeStringValue = (value: any): string => {
    return value ? String(value).trim() : '';
  };

  const safeNumberValue = (value: any): number => {
    if (!value) return 0;
    const num = Number(value);
    return isNaN(num) ? 0 : num;
  };

  // Parse BOM data starting from row 2 (assuming row 1 has headers)
  bomWorksheet.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return; // Skip header row

    const assemblyIdValue = safeStringValue(row.getCell(7).value);
    
    const rowData = {
      id: safeStringValue(row.getCell(1).value) || `bom-part-${rowNumber}`,
      name: safeStringValue(row.getCell(2).value),
      partNumber: safeStringValue(row.getCell(3).value),
      description: safeStringValue(row.getCell(4).value),
      quantity: safeNumberValue(row.getCell(5).value),
      status: safeStringValue(row.getCell(6).value) || 'pending',
      assemblyId: assemblyIdValue || null, // Set to null if empty
      material: safeStringValue(row.getCell(8).value),
      supplier: safeStringValue(row.getCell(9).value),
      cost: safeNumberValue(row.getCell(10).value)
    };

    // Debug logging for first few parts
    if (rowNumber <= 5) {
      console.log(`BOM Row ${rowNumber}:`, JSON.stringify(rowData, null, 2));
    }

    // Only add if we have meaningful data (at least a name or part number)
    if (rowData.name || rowData.partNumber) {
      result.parts.push(rowData);
    }
  });

  console.log(`Parsed ${result.parts.length} parts from BOM worksheet`);
  console.log('Sample parsed data:', JSON.stringify(result.parts.slice(0, 3), null, 2));
  return result;
}