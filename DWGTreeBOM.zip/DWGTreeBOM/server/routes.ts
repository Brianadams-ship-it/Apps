import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ObjectStorageService, ObjectNotFoundError } from "./objectStorage";
import { insertAssemblySchema, insertPartSchema, insertBomTemplateSchema, insertDwgFileSchema, insertWorkflowSchema, insertProcessStepSchema, insertStepDependencySchema, insertWorkflowAssignmentSchema } from "@shared/schema";
import { z } from "zod";
import { CollaborationManager } from "./websocket";
import { generateMasterExcel, parseExcelData, parseExcelBomData } from "./excelService";
import { uploadFileToGitHub, getFileFromGitHub } from "./githubService";

export async function registerRoutes(app: Express): Promise<Server> {
  const objectStorageService = new ObjectStorageService();
  const collaborationManager = new CollaborationManager();

  // File upload endpoint for DWG files
  app.post("/api/objects/upload", async (req, res) => {
    try {
      const uploadURL = await objectStorageService.getObjectEntityUploadURL();
      res.json({ uploadURL });
    } catch (error) {
      console.error("Error getting upload URL:", error);
      res.status(500).json({ error: "Failed to get upload URL" });
    }
  });

  // Serve uploaded objects
  app.get("/objects/:objectPath(*)", async (req, res) => {
    try {
      const objectFile = await objectStorageService.getObjectEntityFile(req.path);
      objectStorageService.downloadObject(objectFile, res);
    } catch (error) {
      console.error("Error accessing object:", error);
      if (error instanceof ObjectNotFoundError) {
        return res.sendStatus(404);
      }
      return res.sendStatus(500);
    }
  });

  // DWG file management
  app.post("/api/dwg-files", async (req, res) => {
    try {
      const validation = insertDwgFileSchema.parse(req.body);
      const dwgFile = await storage.createDwgFile(validation);
      res.json(dwgFile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input", details: error.errors });
      }
      console.error("Error creating DWG file:", error);
      res.status(500).json({ error: "Failed to create DWG file" });
    }
  });

  app.get("/api/dwg-files", async (req, res) => {
    try {
      const dwgFiles = await storage.getDwgFiles();
      res.json(dwgFiles);
    } catch (error) {
      console.error("Error fetching DWG files:", error);
      res.status(500).json({ error: "Failed to fetch DWG files" });
    }
  });

  app.put("/api/dwg-files/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const dwgFile = await storage.updateDwgFile(id, updates);
      if (!dwgFile) {
        return res.status(404).json({ error: "DWG file not found" });
      }
      res.json(dwgFile);
    } catch (error) {
      console.error("Error updating DWG file:", error);
      res.status(500).json({ error: "Failed to update DWG file" });
    }
  });

  // Process DWG file and generate BOM
  app.post("/api/dwg-files/:id/process", async (req, res) => {
    try {
      const { id } = req.params;
      const dwgFile = await storage.getDwgFile(id);
      
      if (!dwgFile) {
        return res.status(404).json({ error: "DWG file not found" });
      }

      // Update status to processing
      await storage.updateDwgFile(id, { parseStatus: "processing" });

      try {
        // Parse the PDF content
        const { parsePdfDwg } = await import('./pdfParser');
        let parsedData;
        
        try {
          // Try to fetch the file from object storage and parse it
          const objectFile = await objectStorageService.getObjectEntityFile(dwgFile.filePath);
          const buffer = await objectStorageService.getObjectAsBuffer(objectFile);
          parsedData = await parsePdfDwg(buffer, dwgFile.filename);
        } catch (objectError) {
          // If file doesn't exist in storage (testing scenario), parse based on filename only
          console.log(`File not found in storage for ${dwgFile.filename}, using filename-based parsing`);
          parsedData = await parsePdfDwg(Buffer.alloc(0), dwgFile.filename);
        }
        
        // Create assemblies and parts in the database
        const createdAssemblies = [];
        const createdParts = [];
        const assemblyNameToId = new Map<string, string>();
        
        // Add a unique suffix to prevent conflicts
        const timestamp = Date.now().toString().slice(-6);
        
        // Create assemblies first (without parent relationships)
        for (const assemblyData of parsedData.assemblies) {
          const assembly = await storage.createAssembly({
            name: assemblyData.name,
            level: assemblyData.level,
            parentId: null, // Will be resolved after all assemblies are created
            description: `Generated from ${dwgFile.filename}`,
            isExpanded: true,
            thumbnailPath: null
          });
          createdAssemblies.push(assembly);
          assemblyNameToId.set(assembly.name, assembly.id);
        }
        
        // Resolve parent relationships using parentName from parser
        for (let i = 0; i < parsedData.assemblies.length; i++) {
          const assemblyData = parsedData.assemblies[i];
          const assembly = createdAssemblies[i];
          
          if (assemblyData.parentName) {
            const parentId = assemblyNameToId.get(assemblyData.parentName);
            if (parentId) {
              await storage.updateAssembly(assembly.id, { parentId });
              // Update the local copy for consistency
              assembly.parentId = parentId;
            } else {
              console.warn(`Parent assembly "${assemblyData.parentName}" not found for "${assembly.name}"`);
            }
          }
        }
        
        // Create parts and link to assemblies
        for (const partData of parsedData.parts) {
          const assemblyId = partData.assemblyName ? assemblyNameToId.get(partData.assemblyName) : null;
          
          // Make part numbers unique by adding timestamp suffix
          const uniquePartNumber = `${partData.partNumber}-${timestamp}`;
          
          const part = await storage.createPart({
            name: partData.name,
            partNumber: uniquePartNumber,
            quantity: partData.quantity,
            assemblyId: assemblyId || null,
            status: "new",
            description: `Generated from ${dwgFile.filename}`,
            thumbnailPath: null,
            metadata: null
          });
          createdParts.push(part);
        }
        
        // Update DWG file with successful parsing
        await storage.updateDwgFile(id, {
          parseStatus: "completed",
          extractedData: {
            assemblies: parsedData.assemblies,
            parts: parsedData.parts,
            processedAt: new Date().toISOString()
          }
        });
        
        res.json({
          message: "DWG file processed successfully",
          assemblies: createdAssemblies,
          parts: createdParts,
          extractedData: parsedData
        });
        
      } catch (parseError) {
        console.error("Error parsing DWG file:", parseError);
        await storage.updateDwgFile(id, { parseStatus: "failed" });
        res.status(500).json({ error: "Failed to parse DWG file", details: parseError instanceof Error ? parseError.message : String(parseError) });
      }
      
    } catch (error) {
      console.error("Error processing DWG file:", error);
      res.status(500).json({ error: "Failed to process DWG file" });
    }
  });

  // Assembly management
  app.get("/api/assemblies", async (req, res) => {
    try {
      const assemblies = await storage.getAssemblies();
      res.json(assemblies);
    } catch (error) {
      console.error("Error fetching assemblies:", error);
      res.status(500).json({ error: "Failed to fetch assemblies" });
    }
  });

  app.post("/api/assemblies", async (req, res) => {
    try {
      const validation = insertAssemblySchema.parse(req.body);
      const assembly = await storage.createAssembly(validation);
      res.json(assembly);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input", details: error.errors });
      }
      console.error("Error creating assembly:", error);
      res.status(500).json({ error: "Failed to create assembly" });
    }
  });

  app.put("/api/assemblies/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const assembly = await storage.updateAssembly(id, updates);
      if (!assembly) {
        return res.status(404).json({ error: "Assembly not found" });
      }
      res.json(assembly);
    } catch (error) {
      console.error("Error updating assembly:", error);
      res.status(500).json({ error: "Failed to update assembly" });
    }
  });

  app.delete("/api/assemblies/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteAssembly(id);
      if (!deleted) {
        return res.status(404).json({ error: "Assembly not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting assembly:", error);
      res.status(500).json({ error: "Failed to delete assembly" });
    }
  });

  // Part management
  app.get("/api/parts", async (req, res) => {
    try {
      const { assemblyId } = req.query;
      let parts;
      if (assemblyId && typeof assemblyId === "string") {
        parts = await storage.getPartsByAssembly(assemblyId);
      } else {
        parts = await storage.getParts();
      }
      res.json(parts);
    } catch (error) {
      console.error("Error fetching parts:", error);
      res.status(500).json({ error: "Failed to fetch parts" });
    }
  });

  app.post("/api/parts", async (req, res) => {
    try {
      const validation = insertPartSchema.parse(req.body);
      const part = await storage.createPart(validation);
      res.json(part);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input", details: error.errors });
      }
      console.error("Error creating part:", error);
      res.status(500).json({ error: "Failed to create part" });
    }
  });

  app.put("/api/parts/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const part = await storage.updatePart(id, updates);
      if (!part) {
        return res.status(404).json({ error: "Part not found" });
      }
      res.json(part);
    } catch (error) {
      console.error("Error updating part:", error);
      res.status(500).json({ error: "Failed to update part" });
    }
  });

  app.delete("/api/parts/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deletePart(id);
      if (!deleted) {
        return res.status(404).json({ error: "Part not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting part:", error);
      res.status(500).json({ error: "Failed to delete part" });
    }
  });

  // BOM Template management
  app.get("/api/bom-templates", async (req, res) => {
    try {
      const templates = await storage.getBomTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching BOM templates:", error);
      res.status(500).json({ error: "Failed to fetch BOM templates" });
    }
  });

  app.post("/api/bom-templates", async (req, res) => {
    try {
      const validation = insertBomTemplateSchema.parse(req.body);
      const template = await storage.createBomTemplate(validation);
      res.json(template);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input", details: error.errors });
      }
      console.error("Error creating BOM template:", error);
      res.status(500).json({ error: "Failed to create BOM template" });
    }
  });

  app.post("/api/bom-templates/:id/apply", async (req, res) => {
    try {
      const { id } = req.params;
      const template = await storage.getBomTemplate(id);
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }

      const templateData = template.templateData as any;
      const createdAssemblies: any[] = [];
      const createdParts: any[] = [];

      // Create assemblies from template
      if (templateData.assemblies) {
        for (const assemblyData of templateData.assemblies) {
          const assembly = await storage.createAssembly({
            name: assemblyData.name,
            description: `Generated from template: ${template.name}`,
            level: assemblyData.level || 0,
            parentId: null, // Will be updated in a second pass for hierarchy
            isExpanded: true,
          });
          createdAssemblies.push(assembly);
        }
      }

      // Create parts from template
      if (templateData.parts) {
        for (const partData of templateData.parts) {
          // Find assembly by name
          const assembly = createdAssemblies.find(a => a.name === partData.assemblyName);
          const part = await storage.createPart({
            name: partData.name,
            partNumber: partData.partNumber,
            description: `Generated from template: ${template.name}`,
            assemblyId: assembly?.id || null,
            quantity: partData.quantity || 1,
            status: "new",
          });
          createdParts.push(part);
        }
      }

      res.json({ 
        message: "Template applied successfully", 
        assemblies: createdAssemblies, 
        parts: createdParts 
      });
    } catch (error) {
      console.error("Error applying template:", error);
      res.status(500).json({ error: "Failed to apply template" });
    }
  });

  // Workflow management
  app.get("/api/workflows", async (req, res) => {
    try {
      const workflows = await storage.getWorkflows();
      res.json(workflows);
    } catch (error) {
      console.error("Error fetching workflows:", error);
      res.status(500).json({ error: "Failed to fetch workflows" });
    }
  });

  app.post("/api/workflows", async (req, res) => {
    try {
      const validation = insertWorkflowSchema.parse(req.body);
      const workflow = await storage.createWorkflow(validation);
      res.json(workflow);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input", details: error.errors });
      }
      console.error("Error creating workflow:", error);
      res.status(500).json({ error: "Failed to create workflow" });
    }
  });

  app.put("/api/workflows/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const workflow = await storage.updateWorkflow(id, updates);
      if (!workflow) {
        return res.status(404).json({ error: "Workflow not found" });
      }
      res.json(workflow);
    } catch (error) {
      console.error("Error updating workflow:", error);
      res.status(500).json({ error: "Failed to update workflow" });
    }
  });

  app.delete("/api/workflows/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteWorkflow(id);
      if (!deleted) {
        return res.status(404).json({ error: "Workflow not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting workflow:", error);
      res.status(500).json({ error: "Failed to delete workflow" });
    }
  });

  // Process Step management
  app.get("/api/process-steps", async (req, res) => {
    try {
      const { workflowId } = req.query;
      let processSteps;
      if (workflowId && typeof workflowId === "string") {
        processSteps = await storage.getProcessStepsByWorkflow(workflowId);
      } else {
        processSteps = await storage.getProcessSteps();
      }
      res.json(processSteps);
    } catch (error) {
      console.error("Error fetching process steps:", error);
      res.status(500).json({ error: "Failed to fetch process steps" });
    }
  });

  app.post("/api/process-steps", async (req, res) => {
    try {
      const validation = insertProcessStepSchema.parse(req.body);
      const processStep = await storage.createProcessStep(validation);
      
      // Trigger automated workflow state recalculation
      await storage.recalculateWorkflowStepStates(processStep.workflowId);
      
      res.json(processStep);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input", details: error.errors });
      }
      console.error("Error creating process step:", error);
      res.status(500).json({ error: "Failed to create process step" });
    }
  });

  app.put("/api/process-steps/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      // Validate updates if they contain specific fields
      if (updates.status && !['pending', 'active', 'completed', 'blocked'].includes(updates.status)) {
        return res.status(400).json({ error: "Invalid status value" });
      }
      
      const processStep = await storage.updateProcessStep(id, updates);
      if (!processStep) {
        return res.status(404).json({ error: "Process step not found" });
      }
      
      // Trigger automated workflow state recalculation
      await storage.recalculateWorkflowStepStates(processStep.workflowId);
      
      res.json(processStep);
    } catch (error) {
      console.error("Error updating process step:", error);
      res.status(500).json({ error: "Failed to update process step" });
    }
  });

  app.delete("/api/process-steps/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteProcessStep(id);
      if (!deleted) {
        return res.status(404).json({ error: "Process step not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting process step:", error);
      res.status(500).json({ error: "Failed to delete process step" });
    }
  });

  // Step Dependency management
  app.get("/api/step-dependencies", async (req, res) => {
    try {
      const { stepId } = req.query;
      let stepDependencies;
      if (stepId && typeof stepId === "string") {
        stepDependencies = await storage.getStepDependenciesByStep(stepId);
      } else {
        stepDependencies = await storage.getStepDependencies();
      }
      res.json(stepDependencies);
    } catch (error) {
      console.error("Error fetching step dependencies:", error);
      res.status(500).json({ error: "Failed to fetch step dependencies" });
    }
  });

  app.post("/api/step-dependencies", async (req, res) => {
    try {
      const validation = insertStepDependencySchema.parse(req.body);
      const stepDependency = await storage.createStepDependency(validation);
      res.json(stepDependency);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input", details: error.errors });
      }
      console.error("Error creating step dependency:", error);
      res.status(500).json({ error: "Failed to create step dependency" });
    }
  });

  app.delete("/api/step-dependencies/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteStepDependency(id);
      if (!deleted) {
        return res.status(404).json({ error: "Step dependency not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting step dependency:", error);
      res.status(500).json({ error: "Failed to delete step dependency" });
    }
  });

  // Workflow Assignment management
  app.get("/api/workflow-assignments", async (req, res) => {
    try {
      const { workflowId, targetType, targetId } = req.query;
      let workflowAssignments;
      
      if (workflowId && typeof workflowId === "string") {
        workflowAssignments = await storage.getWorkflowAssignmentsByWorkflow(workflowId);
      } else if (targetType && targetId && typeof targetType === "string" && typeof targetId === "string") {
        workflowAssignments = await storage.getWorkflowAssignmentsByTarget(targetType, targetId);
      } else {
        workflowAssignments = await storage.getWorkflowAssignments();
      }
      res.json(workflowAssignments);
    } catch (error) {
      console.error("Error fetching workflow assignments:", error);
      res.status(500).json({ error: "Failed to fetch workflow assignments" });
    }
  });

  app.post("/api/workflow-assignments", async (req, res) => {
    try {
      const validation = insertWorkflowAssignmentSchema.parse(req.body);
      const workflowAssignment = await storage.createWorkflowAssignment(validation);
      res.json(workflowAssignment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid input", details: error.errors });
      }
      console.error("Error creating workflow assignment:", error);
      res.status(500).json({ error: "Failed to create workflow assignment" });
    }
  });

  app.put("/api/workflow-assignments/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const workflowAssignment = await storage.updateWorkflowAssignment(id, updates);
      if (!workflowAssignment) {
        return res.status(404).json({ error: "Workflow assignment not found" });
      }
      res.json(workflowAssignment);
    } catch (error) {
      console.error("Error updating workflow assignment:", error);
      res.status(500).json({ error: "Failed to update workflow assignment" });
    }
  });

  app.delete("/api/workflow-assignments/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteWorkflowAssignment(id);
      if (!deleted) {
        return res.status(404).json({ error: "Workflow assignment not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting workflow assignment:", error);
      res.status(500).json({ error: "Failed to delete workflow assignment" });
    }
  });

  // Workflow state recalculation
  app.post("/api/workflows/:id/recalculate", async (req, res) => {
    try {
      const { id } = req.params;
      const workflow = await storage.getWorkflow(id);
      if (!workflow) {
        return res.status(404).json({ error: "Workflow not found" });
      }
      
      await storage.recalculateWorkflowStepStates(id);
      res.json({ success: true, message: "Workflow states recalculated successfully" });
    } catch (error) {
      console.error("Error recalculating workflow states:", error);
      res.status(500).json({ error: "Failed to recalculate workflow states" });
    }
  });

  // Export BOM
  app.get("/api/export/bom", async (req, res) => {
    try {
      const assemblies = await storage.getAssemblies();
      const parts = await storage.getParts();

      const bomData = {
        metadata: {
          generatedAt: new Date().toISOString(),
          totalAssemblies: assemblies.length,
          totalParts: parts.length,
        },
        assemblies,
        parts,
      };

      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename="bom-export.json"');
      res.json(bomData);
    } catch (error) {
      console.error("Error exporting BOM:", error);
      res.status(500).json({ error: "Failed to export BOM" });
    }
  });

  // Add collaboration endpoints
  app.get("/api/collaboration/sessions", async (req, res) => {
    try {
      const sessions = collaborationManager.getAllSessions();
      res.json(sessions);
    } catch (error) {
      console.error("Error fetching collaboration sessions:", error);
      res.status(500).json({ error: "Failed to fetch sessions" });
    }
  });

  app.get("/api/collaboration/sessions/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const sessionInfo = collaborationManager.getSessionInfo(sessionId);
      if (!sessionInfo) {
        return res.status(404).json({ error: "Session not found" });
      }
      res.json(sessionInfo);
    } catch (error) {
      console.error("Error fetching session info:", error);
      res.status(500).json({ error: "Failed to fetch session info" });
    }
  });

  const httpServer = createServer(app);
  
  // Set up WebSocket handling
  httpServer.on('upgrade', (request, socket, head) => {
    const pathname = new URL(request.url || '', 'ws://localhost').pathname;
    
    if (pathname === '/ws') {
      collaborationManager.handleUpgrade(request, socket, head);
    } else {
      socket.destroy();
    }
  });

  // Excel export endpoint
  app.get("/api/export/excel", async (req, res) => {
    try {
      const [dwgFiles, assemblies, parts] = await Promise.all([
        storage.getDwgFiles(),
        storage.getAssemblies(),
        storage.getParts()
      ]);

      const excelBuffer = await generateMasterExcel({
        dwgFiles,
        assemblies,
        parts
      });

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename="BOM_Master_File.xlsx"');
      res.send(excelBuffer);
    } catch (error) {
      console.error("Error generating Excel:", error);
      res.status(500).json({ error: "Failed to generate Excel file" });
    }
  });

  // Secure GitHub master file endpoints - restricted to specific repository
  const ALLOWED_GITHUB_REPO = {
    owner: "Brianadams-ship-it",
    repo: "Apps",
    path: "project-data.xlsx"
  };

  app.post("/api/master-file/export", async (req, res) => {
    try {
      const { message } = req.body;

      const [dwgFiles, assemblies, parts] = await Promise.all([
        storage.getDwgFiles(),
        storage.getAssemblies(),
        storage.getParts()
      ]);

      const excelBuffer = await generateMasterExcel({
        dwgFiles,
        assemblies,
        parts
      });

      const result = await uploadFileToGitHub(
        ALLOWED_GITHUB_REPO.owner,
        ALLOWED_GITHUB_REPO.repo,
        ALLOWED_GITHUB_REPO.path,
        excelBuffer,
        message || `Update BOM master file - ${new Date().toISOString()}`
      );

      res.json({
        success: true,
        fileUrl: result.htmlUrl,
        downloadUrl: result.url,
        sha: result.sha,
        repository: `${ALLOWED_GITHUB_REPO.owner}/${ALLOWED_GITHUB_REPO.repo}`,
        filePath: ALLOWED_GITHUB_REPO.path
      });
    } catch (error) {
      console.error("Error uploading master file to GitHub:", error);
      res.status(500).json({ error: "Failed to upload master file to GitHub" });
    }
  });

  app.post("/api/master-file/import", async (req, res) => {
    try {
      const fileData = await getFileFromGitHub(
        ALLOWED_GITHUB_REPO.owner,
        ALLOWED_GITHUB_REPO.repo,
        ALLOWED_GITHUB_REPO.path
      );

      const parsedData = await parseExcelData(fileData.content);
      
      // Persist the imported data to storage
      let importResults = {
        dwgFiles: { created: 0, updated: 0, errors: 0 },
        assemblies: { created: 0, updated: 0, errors: 0 },
        parts: { created: 0, updated: 0, errors: 0 }
      };

      // Import DWG Files
      if (parsedData.dwgFiles) {
        for (const dwgFile of parsedData.dwgFiles) {
          try {
            const existing = await storage.getDwgFile(dwgFile.id);
            const dwgData = {
              filename: dwgFile.filename,
              filePath: dwgFile.filePath,
              fileSize: dwgFile.fileSize,
              parseStatus: dwgFile.parseStatus,
              extractedData: dwgFile.extractedData as any,
            };
            
            if (existing) {
              await storage.updateDwgFile(dwgFile.id, dwgData);
              importResults.dwgFiles.updated++;
            } else {
              await storage.createDwgFile(dwgData);
              importResults.dwgFiles.created++;
            }
          } catch (error) {
            console.error(`Error importing DWG file ${dwgFile.id}:`, error);
            importResults.dwgFiles.errors++;
          }
        }
      }

      // Import Assemblies
      if (parsedData.assemblies) {
        for (const assembly of parsedData.assemblies) {
          try {
            const existing = await storage.getAssembly(assembly.id);
            if (existing) {
              await storage.updateAssembly(assembly.id, assembly);
              importResults.assemblies.updated++;
            } else {
              await storage.createAssembly(assembly);
              importResults.assemblies.created++;
            }
          } catch (error) {
            console.error(`Error importing assembly ${assembly.id}:`, error);
            importResults.assemblies.errors++;
          }
        }
      }

      // Import Parts
      if (parsedData.parts) {
        for (const part of parsedData.parts) {
          try {
            const existing = await storage.getPart(part.id);
            const partData = {
              name: part.name,
              partNumber: part.partNumber,
              description: part.description,
              status: part.status,
              thumbnailPath: part.thumbnailPath,
              assemblyId: part.assemblyId,
              quantity: part.quantity,
              metadata: part.metadata as any,
            };
            
            if (existing) {
              await storage.updatePart(part.id, partData);
              importResults.parts.updated++;
            } else {
              await storage.createPart(partData);
              importResults.parts.created++;
            }
          } catch (error) {
            console.error(`Error importing part ${part.id}:`, error);
            importResults.parts.errors++;
          }
        }
      }
      
      res.json({
        success: true,
        importResults,
        fileInfo: {
          sha: fileData.sha,
          downloadUrl: fileData.downloadUrl,
          htmlUrl: fileData.htmlUrl
        },
        repository: `${ALLOWED_GITHUB_REPO.owner}/${ALLOWED_GITHUB_REPO.repo}`,
        filePath: ALLOWED_GITHUB_REPO.path
      });
    } catch (error) {
      console.error("Error importing master file from GitHub:", error);
      res.status(500).json({ error: "Failed to import master file from GitHub" });
    }
  });

  app.get("/api/master-file/status", async (req, res) => {
    try {
      res.json({
        success: true,
        repository: {
          owner: ALLOWED_GITHUB_REPO.owner,
          repo: ALLOWED_GITHUB_REPO.repo,
          path: ALLOWED_GITHUB_REPO.path,
          url: `https://github.com/${ALLOWED_GITHUB_REPO.owner}/${ALLOWED_GITHUB_REPO.repo}/blob/main/${ALLOWED_GITHUB_REPO.path}`
        },
        inputFile: {
          owner: ALLOWED_GITHUB_REPO.owner,
          repo: ALLOWED_GITHUB_REPO.repo,
          path: "Project Input.xlsx",
          url: `https://github.com/${ALLOWED_GITHUB_REPO.owner}/${ALLOWED_GITHUB_REPO.repo}/blob/main/Project%20Input.xlsx`
        }
      });
    } catch (error) {
      console.error("Error getting master file status:", error);
      res.status(500).json({ error: "Failed to get master file status" });
    }
  });

  // Import BOM items from Project Input.xlsx
  app.post("/api/master-file/import-bom", async (req, res) => {
    try {
      console.log('Attempting to download Project Input.xlsx from GitHub...');
      const fileData = await getFileFromGitHub(
        ALLOWED_GITHUB_REPO.owner,
        ALLOWED_GITHUB_REPO.repo,
        "Project Input.xlsx"
      );
      console.log('File downloaded, content length:', fileData.content?.length || 0);

      const parsedData = await parseExcelBomData(fileData.content);
      
      // Persist the imported BOM data to storage
      let importResults = {
        parts: { created: 0, updated: 0, errors: 0 },
        assemblies: { created: 0, updated: 0, errors: 0 }
      };

      // Extract unique assembly names from parts and create assemblies automatically
      const uniqueAssemblyNames = new Set<string>();
      if (parsedData.parts) {
        parsedData.parts.forEach(part => {
          if (part.assemblyId && part.assemblyId.trim()) {
            uniqueAssemblyNames.add(part.assemblyId.trim());
          }
        });
      }

      // Create assemblies for all referenced assembly names
      if (uniqueAssemblyNames.size > 0) {
        console.log(`Creating ${uniqueAssemblyNames.size} assemblies from part references: ${Array.from(uniqueAssemblyNames).join(', ')}`);
        for (const assemblyName of uniqueAssemblyNames) {
          try {
            // Check if assembly already exists by ID or name
            const existingAssemblies = await storage.getAssemblies();
            const existing = existingAssemblies.find(a => a.id === assemblyName || a.name === assemblyName);
            
            if (!existing) {
              // Create new assembly with the name as both ID and name
              await storage.createAssembly({
                id: assemblyName,
                name: assemblyName,
                description: `Auto-generated assembly for BOM import`,
                status: 'new',
                parentId: null,
                dwgFileId: null,
                bomTemplateId: null,
                createdAt: null
              });
              importResults.assemblies.created++;
              console.log(`Created assembly: ${assemblyName}`);
            } else {
              console.log(`Assembly already exists: ${assemblyName}`);
            }
          } catch (error) {
            console.error(`Error creating assembly ${assemblyName}:`, error);
            importResults.assemblies.errors++;
          }
        }
      }

      // Import explicit Assemblies from BOM data (if any)
      if (parsedData.assemblies && parsedData.assemblies.length > 0) {
        console.log(`Importing ${parsedData.assemblies.length} explicit assemblies...`);
        for (const assembly of parsedData.assemblies) {
          try {
            const existing = await storage.getAssembly(assembly.id);
            if (existing) {
              await storage.updateAssembly(assembly.id, assembly);
              importResults.assemblies.updated++;
            } else {
              await storage.createAssembly(assembly);
              importResults.assemblies.created++;
            }
          } catch (error) {
            console.error(`Error importing BOM assembly ${assembly.id}:`, error);
            importResults.assemblies.errors++;
          }
        }
      }

      // Import Parts from BOM AFTER assemblies exist
      if (parsedData.parts) {
        console.log(`Importing ${parsedData.parts.length} parts after assemblies...`);
        for (const part of parsedData.parts) {
          try {
            const partData = {
              name: part.name,
              partNumber: part.partNumber,
              description: part.description,
              status: part.status,
              ...(part.assemblyId ? { assemblyId: part.assemblyId } : {}), // Only include if not null
              quantity: part.quantity
            };
            
            // Check if part exists by ID first
            const existingById = await storage.getPart(part.id);
            if (existingById) {
              await storage.updatePart(part.id, partData);
              importResults.parts.updated++;
              continue;
            }
            
            // Check if part exists by part number (for duplicate handling)
            if (part.partNumber && part.partNumber.trim()) {
              const allParts = await storage.getParts();
              const existingByPartNumber = allParts.find(p => p.partNumber === part.partNumber);
              if (existingByPartNumber) {
                console.log(`Updating existing part with number ${part.partNumber}`);
                await storage.updatePart(existingByPartNumber.id, partData);
                importResults.parts.updated++;
                continue;
              }
            } else {
              // For parts with empty part numbers, generate a unique part number
              partData.partNumber = `AUTO-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
              console.log(`Generated part number ${partData.partNumber} for part with empty part number`);
            }
            
            // Create new part if no duplicates found
            await storage.createPart(partData);
            importResults.parts.created++;
            
          } catch (error) {
            console.error(`Error importing BOM part ${part.id}:`, error);
            importResults.parts.errors++;
          }
        }
      }

      res.json({
        success: true,
        importResults,
        message: `Successfully imported BOM data: ${importResults.parts.created + importResults.parts.updated} parts, ${importResults.assemblies.created + importResults.assemblies.updated} assemblies`
      });
    } catch (error) {
      console.error("Error importing BOM from GitHub:", error);
      res.status(500).json({ error: "Failed to import BOM from GitHub" });
    }
  });

  return httpServer;
}
