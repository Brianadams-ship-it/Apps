import { Octokit } from '@octokit/rest';

let connectionSettings: any;

async function getAccessToken() {
  if (connectionSettings && connectionSettings.settings.expires_at && new Date(connectionSettings.settings.expires_at).getTime() > Date.now()) {
    return connectionSettings.settings.access_token;
  }
  
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=github',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  const accessToken = connectionSettings?.settings?.access_token || connectionSettings.settings?.oauth?.credentials?.access_token;

  if (!connectionSettings || !accessToken) {
    throw new Error('GitHub not connected');
  }
  return accessToken;
}

// WARNING: Never cache this client.
// Access tokens expire, so a new client must be created each time.
// Always call this function again to get a fresh client.
export async function getUncachableGitHubClient() {
  const accessToken = await getAccessToken();
  return new Octokit({ auth: accessToken });
}

export async function uploadFileToGitHub(
  owner: string,
  repo: string,
  path: string,
  content: Buffer,
  message: string,
  branch: string = 'main'
) {
  const octokit = await getUncachableGitHubClient();
  
  try {
    // Try to get the existing file to get its SHA
    let sha: string | undefined;
    try {
      const { data: existingFile } = await octokit.rest.repos.getContent({
        owner,
        repo,
        path,
        ref: branch,
      });
      
      if ('sha' in existingFile) {
        sha = existingFile.sha;
      }
    } catch (error) {
      // File doesn't exist, that's fine
    }

    // Create or update the file
    const { data } = await octokit.rest.repos.createOrUpdateFileContents({
      owner,
      repo,
      path,
      message,
      content: content.toString('base64'),
      branch,
      ...(sha && { sha }),
    });

    return {
      success: true,
      url: data.content?.download_url,
      sha: data.content?.sha,
      htmlUrl: data.content?.html_url,
    };
  } catch (error) {
    console.error('Error uploading to GitHub:', error);
    throw error;
  }
}

export async function getFileFromGitHub(
  owner: string,
  repo: string,
  path: string,
  branch: string = 'main'
) {
  const octokit = await getUncachableGitHubClient();
  
  try {
    const { data } = await octokit.rest.repos.getContent({
      owner,
      repo,
      path,
      ref: branch,
    });
    
    if ('content' in data) {
      console.log(`File data: size=${data.size}, encoding=${data.encoding}`);
      
      // Handle large files (>1MB) that have encoding: "none"
      if (data.encoding === 'none' || data.size > 1000000) {
        console.log('Large file detected, downloading raw content...');
        
        // For large files, download raw content directly
        const accessToken = await getAccessToken();
        const rawUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${encodeURIComponent(path)}`;
        
        const rawResponse = await fetch(rawUrl, {
          headers: {
            'Authorization': `token ${accessToken}`,
            'Accept': 'application/vnd.github.v3.raw',
            'User-Agent': 'DWG-BOM-Generator'
          }
        });
        
        if (!rawResponse.ok) {
          throw new Error(`GitHub raw API error: ${rawResponse.status} ${rawResponse.statusText}`);
        }
        
        const arrayBuffer = await rawResponse.arrayBuffer();
        const content = Buffer.from(arrayBuffer);
        console.log(`Raw content downloaded, size: ${content.length} bytes`);
        
        return {
          success: true,
          content,
          sha: data.sha,
          downloadUrl: data.download_url,
          htmlUrl: data.html_url,
        };
      } else {
        // Decode base64 content for smaller files
        console.log('Small file, decoding base64 content...');
        return {
          success: true,
          content: Buffer.from(data.content, 'base64'),
          sha: data.sha,
          downloadUrl: data.download_url,
          htmlUrl: data.html_url,
        };
      }
    } else {
      throw new Error('Path is a directory, not a file');
    }
  } catch (error) {
    console.error('Error getting file from GitHub:', error);
    throw error;
  }
}