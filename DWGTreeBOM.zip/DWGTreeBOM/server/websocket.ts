import { WebSocketServer } from 'ws';
import { IncomingMessage } from 'http';
import { nanoid } from 'nanoid';

export interface User {
  id: string;
  name: string;
  color: string;
  avatar?: string;
}

export interface CollaborativeSession {
  id: string;
  users: Map<string, User>;
  activeDocument?: string;
  lastActivity: Date;
}

export interface WebSocketMessage {
  type: 'user-join' | 'user-leave' | 'cursor-update' | 'edit-action' | 'presence-update' | 'document-change' | 'lock-request' | 'lock-release' | 'entity-locked' | 'entity-unlocked' | 'session-state' | 'edit-conflict' | 'lock-denied' | 'lock-granted';
  sessionId: string;
  userId: string;
  timestamp: number;
  data?: any;
}

export class CollaborationManager {
  private wss: WebSocketServer;
  private sessions = new Map<string, CollaborativeSession>();
  private userSockets = new Map<string, any>(); // WebSocket connections by userId
  private documentLocks = new Map<string, { userId: string; timestamp: number; type: 'assembly' | 'part' | 'bom'; entityId: string }>();

  constructor() {
    this.wss = new WebSocketServer({ 
      noServer: true,
      clientTracking: true 
    });
    this.setupWebSocketHandlers();
    this.startCleanupTask();
  }

  private setupWebSocketHandlers() {
    this.wss.on('connection', (ws, request: IncomingMessage) => {
      const url = new URL(request.url || '', 'ws://localhost');
      const sessionId = url.searchParams.get('sessionId') || 'default';
      const userId = url.searchParams.get('userId') || nanoid();
      const userName = url.searchParams.get('userName') || `User ${userId.slice(0, 6)}`;

      // Generate a unique color for the user
      const userColor = this.generateUserColor(userId);
      
      const user: User = {
        id: userId,
        name: userName,
        color: userColor
      };

      // Register user in session
      if (!this.sessions.has(sessionId)) {
        this.sessions.set(sessionId, {
          id: sessionId,
          users: new Map(),
          lastActivity: new Date()
        });
      }

      const session = this.sessions.get(sessionId)!;
      session.users.set(userId, user);
      session.lastActivity = new Date();
      
      this.userSockets.set(userId, ws);

      // Set up WebSocket message handling
      ws.on('message', (data) => {
        try {
          const message: WebSocketMessage = JSON.parse(data.toString());
          this.handleMessage(message, ws, sessionId, userId);
        } catch (error) {
          console.error('Invalid WebSocket message format:', error);
        }
      });

      ws.on('close', () => {
        this.handleUserDisconnect(sessionId, userId);
      });

      ws.on('error', (error) => {
        console.error('WebSocket error for user', userId, ':', error);
        this.handleUserDisconnect(sessionId, userId);
      });

      // Notify others about user joining
      this.broadcastToSession(sessionId, {
        type: 'user-join',
        sessionId,
        userId,
        timestamp: Date.now(),
        data: { user }
      }, userId);

      // Send current session state to the new user
      ws.send(JSON.stringify({
        type: 'session-state',
        sessionId,
        userId,
        timestamp: Date.now(),
        data: {
          users: Array.from(session.users.values()),
          locks: Array.from(this.documentLocks.entries()).map(([key, lock]) => ({ 
            entityType: lock.type, 
            entityId: lock.entityId, 
            userId: lock.userId, 
            timestamp: lock.timestamp 
          }))
        }
      }));

      console.log(`User ${userName} (${userId}) joined session ${sessionId}`);
    });
  }

  private handleMessage(message: WebSocketMessage, ws: any, sessionId: string, userId: string) {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    session.lastActivity = new Date();

    switch (message.type) {
      case 'cursor-update':
        this.broadcastToSession(sessionId, message, userId);
        break;

      case 'edit-action':
        // Handle collaborative editing actions (add, update, delete)
        this.handleEditAction(message, sessionId, userId);
        break;

      case 'presence-update':
        // Update user presence information
        this.handlePresenceUpdate(message, sessionId, userId);
        break;

      case 'document-change':
        // Handle real-time document synchronization
        this.broadcastToSession(sessionId, message, userId);
        break;

      case 'lock-request':
        this.handleLockRequest(message, sessionId, userId, ws);
        break;

      case 'lock-release':
        this.handleLockRelease(message, sessionId, userId);
        break;

      default:
        console.warn('Unknown message type:', message.type);
    }
  }

  private handleEditAction(message: WebSocketMessage, sessionId: string, userId: string) {
    // Add conflict detection and resolution logic here
    const { action, entityType, entityId, changes } = message.data;
    
    // Check if the entity is currently locked by another user
    const lockKey = `${entityType}-${entityId}`;
    const existingLock = this.documentLocks.get(lockKey);
    
    if (existingLock && existingLock.userId !== userId) {
      // Entity is locked by another user - reject the edit
      const userSocket = this.userSockets.get(userId);
      if (userSocket) {
        userSocket.send(JSON.stringify({
          type: 'edit-conflict',
          sessionId,
          userId,
          timestamp: Date.now(),
          data: {
            entityType,
            entityId,
            lockedBy: existingLock.userId,
            message: 'This item is currently being edited by another user'
          }
        }));
      }
      return;
    }

    // If no conflict, broadcast the edit to all users
    this.broadcastToSession(sessionId, {
      ...message,
      data: {
        ...message.data,
        timestamp: Date.now(),
        user: this.sessions.get(sessionId)?.users.get(userId)
      }
    }, userId);
  }

  private handlePresenceUpdate(message: WebSocketMessage, sessionId: string, userId: string) {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    const user = session.users.get(userId);
    if (user && message.data) {
      // Update user presence data (current page, active element, etc.)
      Object.assign(user, message.data);
    }

    this.broadcastToSession(sessionId, message, userId);
  }

  private handleLockRequest(message: WebSocketMessage, sessionId: string, userId: string, ws: any) {
    const { entityType, entityId } = message.data;
    const lockKey = `${entityType}-${entityId}`;
    const existingLock = this.documentLocks.get(lockKey);
    
    if (existingLock && existingLock.userId !== userId) {
      // Lock denied - already locked by another user
      ws.send(JSON.stringify({
        type: 'lock-denied',
        sessionId,
        userId,
        timestamp: Date.now(),
        data: {
          entityType,
          entityId,
          lockedBy: existingLock.userId,
          message: 'This item is currently locked by another user'
        }
      }));
    } else {
      // Grant the lock
      this.documentLocks.set(lockKey, {
        userId,
        timestamp: Date.now(),
        type: entityType,
        entityId
      });

      // Notify the user that lock was granted
      ws.send(JSON.stringify({
        type: 'lock-granted',
        sessionId,
        userId,
        timestamp: Date.now(),
        data: { entityType, entityId }
      }));

      // Notify other users about the lock
      this.broadcastToSession(sessionId, {
        type: 'entity-locked',
        sessionId,
        userId,
        timestamp: Date.now(),
        data: { entityType, entityId, lockedBy: userId }
      }, userId);
    }
  }

  private handleLockRelease(message: WebSocketMessage, sessionId: string, userId: string) {
    const { entityType, entityId } = message.data;
    const lockKey = `${entityType}-${entityId}`;
    const existingLock = this.documentLocks.get(lockKey);
    
    if (existingLock && existingLock.userId === userId) {
      this.documentLocks.delete(lockKey);
      
      // Notify all users that the lock was released
      this.broadcastToSession(sessionId, {
        type: 'entity-unlocked',
        sessionId,
        userId,
        timestamp: Date.now(),
        data: { entityType, entityId }
      });
    }
  }

  private handleUserDisconnect(sessionId: string, userId: string) {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    // Release all locks held by this user
    for (const [lockKey, lock] of Array.from(this.documentLocks.entries())) {
      if (lock.userId === userId) {
        this.documentLocks.delete(lockKey);
        this.broadcastToSession(sessionId, {
          type: 'entity-unlocked',
          sessionId,
          userId,
          timestamp: Date.now(),
          data: { entityType: lock.type, entityId: lock.entityId }
        });
      }
    }

    // Remove user from session
    session.users.delete(userId);
    this.userSockets.delete(userId);

    // Notify others about user leaving
    this.broadcastToSession(sessionId, {
      type: 'user-leave',
      sessionId,
      userId,
      timestamp: Date.now(),
      data: { userId }
    });

    // Clean up empty sessions
    if (session.users.size === 0) {
      this.sessions.delete(sessionId);
    }

    console.log(`User ${userId} left session ${sessionId}`);
  }

  private broadcastToSession(sessionId: string, message: WebSocketMessage, excludeUserId?: string) {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    for (const userId of Array.from(session.users.keys())) {
      if (excludeUserId && userId === excludeUserId) continue;
      
      const ws = this.userSockets.get(userId);
      if (ws && ws.readyState === ws.OPEN) {
        try {
          ws.send(JSON.stringify(message));
        } catch (error) {
          console.error(`Failed to send message to user ${userId}:`, error);
          this.handleUserDisconnect(sessionId, userId);
        }
      }
    }
  }

  private generateUserColor(userId: string): string {
    // Generate a consistent color based on user ID
    const colors = [
      '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7',
      '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9',
      '#F8C471', '#82E0AA', '#F1948A', '#85C1E9', '#D2B4DE'
    ];
    
    let hash = 0;
    for (let i = 0; i < userId.length; i++) {
      hash = userId.charCodeAt(i) + ((hash << 5) - hash);
    }
    
    return colors[Math.abs(hash) % colors.length];
  }

  private startCleanupTask() {
    // Clean up inactive sessions every 5 minutes
    setInterval(() => {
      const cutoff = new Date(Date.now() - 30 * 60 * 1000); // 30 minutes ago
      
      for (const [sessionId, session] of Array.from(this.sessions.entries())) {
        if (session.lastActivity < cutoff && session.users.size === 0) {
          this.sessions.delete(sessionId);
          console.log(`Cleaned up inactive session: ${sessionId}`);
        }
      }

      // Clean up old locks (5 minutes)
      const lockCutoff = Date.now() - 5 * 60 * 1000;
      for (const [lockKey, lock] of Array.from(this.documentLocks.entries())) {
        if (lock.timestamp < lockCutoff) {
          this.documentLocks.delete(lockKey);
          console.log(`Cleaned up stale lock: ${lockKey}`);
        }
      }
    }, 5 * 60 * 1000);
  }

  // Public methods for HTTP server integration
  public handleUpgrade(request: IncomingMessage, socket: any, head: Buffer) {
    this.wss.handleUpgrade(request, socket, head, (ws) => {
      this.wss.emit('connection', ws, request);
    });
  }

  public getSessionInfo(sessionId: string) {
    const session = this.sessions.get(sessionId);
    if (!session) return null;

    return {
      id: session.id,
      users: Array.from(session.users.values()),
      activeDocument: session.activeDocument,
      lastActivity: session.lastActivity,
      locks: Array.from(this.documentLocks.entries())
        .filter(([key]) => key.startsWith(sessionId))
        .map(([key, lock]) => ({ key, ...lock }))
    };
  }

  public getAllSessions() {
    return Array.from(this.sessions.values()).map(session => ({
      id: session.id,
      userCount: session.users.size,
      lastActivity: session.lastActivity
    }));
  }
}