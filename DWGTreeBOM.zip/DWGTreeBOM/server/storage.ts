import { type Assembly, type InsertAssembly, type Part, type InsertPart, type BomTemplate, type InsertBomTemplate, type DwgFile, type InsertDwgFile, type Workflow, type InsertWorkflow, type ProcessStep, type InsertProcessStep, type StepDependency, type InsertStepDependency, type WorkflowAssignment, type InsertWorkflowAssignment, assemblies, parts, bomTemplates, dwgFiles, workflows, processSteps, stepDependencies, workflowAssignments } from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq, isNull, and } from "drizzle-orm";

export interface IStorage {
  // Assembly operations
  getAssembly(id: string): Promise<Assembly | undefined>;
  getAssemblies(): Promise<Assembly[]>;
  getAssembliesByParent(parentId: string | null): Promise<Assembly[]>;
  createAssembly(assembly: InsertAssembly): Promise<Assembly>;
  updateAssembly(id: string, assembly: Partial<Assembly>): Promise<Assembly | undefined>;
  deleteAssembly(id: string): Promise<boolean>;

  // Part operations
  getPart(id: string): Promise<Part | undefined>;
  getParts(): Promise<Part[]>;
  getPartsByAssembly(assemblyId: string): Promise<Part[]>;
  createPart(part: InsertPart): Promise<Part>;
  updatePart(id: string, part: Partial<Part>): Promise<Part | undefined>;
  deletePart(id: string): Promise<boolean>;

  // BOM Template operations
  getBomTemplate(id: string): Promise<BomTemplate | undefined>;
  getBomTemplates(): Promise<BomTemplate[]>;
  createBomTemplate(template: InsertBomTemplate): Promise<BomTemplate>;
  deleteBomTemplate(id: string): Promise<boolean>;

  // DWG File operations
  getDwgFile(id: string): Promise<DwgFile | undefined>;
  getDwgFiles(): Promise<DwgFile[]>;
  createDwgFile(dwgFile: InsertDwgFile): Promise<DwgFile>;
  updateDwgFile(id: string, dwgFile: Partial<DwgFile>): Promise<DwgFile | undefined>;
  deleteDwgFile(id: string): Promise<boolean>;

  // Workflow operations
  getWorkflow(id: string): Promise<Workflow | undefined>;
  getWorkflows(): Promise<Workflow[]>;
  createWorkflow(workflow: InsertWorkflow): Promise<Workflow>;
  updateWorkflow(id: string, workflow: Partial<Workflow>): Promise<Workflow | undefined>;
  deleteWorkflow(id: string): Promise<boolean>;

  // Process Step operations
  getProcessStep(id: string): Promise<ProcessStep | undefined>;
  getProcessSteps(): Promise<ProcessStep[]>;
  getProcessStepsByWorkflow(workflowId: string): Promise<ProcessStep[]>;
  createProcessStep(processStep: InsertProcessStep): Promise<ProcessStep>;
  updateProcessStep(id: string, processStep: Partial<ProcessStep>): Promise<ProcessStep | undefined>;
  deleteProcessStep(id: string): Promise<boolean>;

  // Step Dependency operations
  getStepDependency(id: string): Promise<StepDependency | undefined>;
  getStepDependencies(): Promise<StepDependency[]>;
  getStepDependenciesByStep(stepId: string): Promise<StepDependency[]>;
  createStepDependency(stepDependency: InsertStepDependency): Promise<StepDependency>;
  deleteStepDependency(id: string): Promise<boolean>;

  // Workflow Assignment operations
  getWorkflowAssignment(id: string): Promise<WorkflowAssignment | undefined>;
  getWorkflowAssignments(): Promise<WorkflowAssignment[]>;
  getWorkflowAssignmentsByTarget(targetType: string, targetId: string): Promise<WorkflowAssignment[]>;
  getWorkflowAssignmentsByWorkflow(workflowId: string): Promise<WorkflowAssignment[]>;
  createWorkflowAssignment(workflowAssignment: InsertWorkflowAssignment): Promise<WorkflowAssignment>;
  updateWorkflowAssignment(id: string, workflowAssignment: Partial<WorkflowAssignment>): Promise<WorkflowAssignment | undefined>;
  deleteWorkflowAssignment(id: string): Promise<boolean>;
}


export class DatabaseStorage implements IStorage {
  constructor() {
    this.initializeTemplates();
  }

  private async initializeTemplates() {
    // Check if templates already exist
    const existingTemplates = await this.getBomTemplates();
    if (existingTemplates.length > 0) return;

    // Initialize default BOM templates
    const templates: InsertBomTemplate[] = [
      {
        name: "Standard Assembly BOM",
        description: "Standard mechanical assembly with housing, motor, and hardware",
        templateData: {
          assemblies: [
            { name: "Main Assembly", level: 0, children: ["Housing Assembly", "Motor Assembly"] },
            { name: "Housing Assembly", level: 1, children: [] },
            { name: "Motor Assembly", level: 1, children: [] }
          ],
          parts: [
            { name: "Housing Cover", partNumber: "HSG-001", assemblyName: "Housing Assembly", quantity: 1 },
            { name: "Housing Base", partNumber: "HSG-002", assemblyName: "Housing Assembly", quantity: 1 },
            { name: "Motor", partNumber: "MTR-001", assemblyName: "Motor Assembly", quantity: 1 },
            { name: "Mounting Bolts", partNumber: "HW-M8x20", assemblyName: "Main Assembly", quantity: 8 }
          ]
        }
      },
      {
        name: "Mechanical Assembly",
        description: "Complex mechanical assembly with gears and shafts",
        templateData: {
          assemblies: [
            { name: "Main Assembly", level: 0, children: ["Gear Assembly", "Shaft Assembly"] },
            { name: "Gear Assembly", level: 1, children: [] },
            { name: "Shaft Assembly", level: 1, children: [] }
          ],
          parts: [
            { name: "Drive Gear", partNumber: "GR-001", assemblyName: "Gear Assembly", quantity: 1 },
            { name: "Driven Gear", partNumber: "GR-002", assemblyName: "Gear Assembly", quantity: 1 },
            { name: "Input Shaft", partNumber: "SHF-001", assemblyName: "Shaft Assembly", quantity: 1 },
            { name: "Output Shaft", partNumber: "SHF-002", assemblyName: "Shaft Assembly", quantity: 1 }
          ]
        }
      }
    ];

    for (const template of templates) {
      await this.createBomTemplate(template);
    }
  }

  // Assembly operations
  async getAssembly(id: string): Promise<Assembly | undefined> {
    const [assembly] = await db.select().from(assemblies).where(eq(assemblies.id, id));
    return assembly || undefined;
  }

  async getAssemblies(): Promise<Assembly[]> {
    return await db.select().from(assemblies).orderBy(assemblies.level, assemblies.name);
  }

  async getAssembliesByParent(parentId: string | null): Promise<Assembly[]> {
    const condition = parentId === null ? isNull(assemblies.parentId) : eq(assemblies.parentId, parentId);
    return await db.select().from(assemblies).where(condition).orderBy(assemblies.name);
  }

  async createAssembly(insertAssembly: InsertAssembly): Promise<Assembly> {
    const [assembly] = await db.insert(assemblies).values(insertAssembly).returning();
    return assembly;
  }

  async updateAssembly(id: string, updates: Partial<Assembly>): Promise<Assembly | undefined> {
    const [assembly] = await db.update(assemblies).set(updates).where(eq(assemblies.id, id)).returning();
    return assembly || undefined;
  }

  async deleteAssembly(id: string): Promise<boolean> {
    const result = await db.delete(assemblies).where(eq(assemblies.id, id));
    return result.rowCount! > 0;
  }

  // Part operations
  async getPart(id: string): Promise<Part | undefined> {
    const [part] = await db.select().from(parts).where(eq(parts.id, id));
    return part || undefined;
  }

  async getParts(): Promise<Part[]> {
    return await db.select().from(parts).orderBy(parts.name);
  }

  async getPartsByAssembly(assemblyId: string): Promise<Part[]> {
    return await db.select().from(parts).where(eq(parts.assemblyId, assemblyId)).orderBy(parts.name);
  }

  async createPart(insertPart: InsertPart): Promise<Part> {
    const [part] = await db.insert(parts).values(insertPart).returning();
    return part;
  }

  async updatePart(id: string, updates: Partial<Part>): Promise<Part | undefined> {
    const [part] = await db.update(parts).set(updates).where(eq(parts.id, id)).returning();
    return part || undefined;
  }

  async deletePart(id: string): Promise<boolean> {
    const result = await db.delete(parts).where(eq(parts.id, id));
    return result.rowCount! > 0;
  }

  // BOM Template operations
  async getBomTemplate(id: string): Promise<BomTemplate | undefined> {
    const [template] = await db.select().from(bomTemplates).where(eq(bomTemplates.id, id));
    return template || undefined;
  }

  async getBomTemplates(): Promise<BomTemplate[]> {
    return await db.select().from(bomTemplates).orderBy(bomTemplates.name);
  }

  async createBomTemplate(insertTemplate: InsertBomTemplate): Promise<BomTemplate> {
    const [template] = await db.insert(bomTemplates).values(insertTemplate).returning();
    return template;
  }

  async deleteBomTemplate(id: string): Promise<boolean> {
    const result = await db.delete(bomTemplates).where(eq(bomTemplates.id, id));
    return result.rowCount! > 0;
  }

  // DWG File operations
  async getDwgFile(id: string): Promise<DwgFile | undefined> {
    const [dwgFile] = await db.select().from(dwgFiles).where(eq(dwgFiles.id, id));
    return dwgFile || undefined;
  }

  async getDwgFiles(): Promise<DwgFile[]> {
    return await db.select().from(dwgFiles).orderBy(dwgFiles.createdAt);
  }

  async createDwgFile(insertDwgFile: InsertDwgFile): Promise<DwgFile> {
    const [dwgFile] = await db.insert(dwgFiles).values(insertDwgFile).returning();
    return dwgFile;
  }

  async updateDwgFile(id: string, updates: Partial<DwgFile>): Promise<DwgFile | undefined> {
    const [dwgFile] = await db.update(dwgFiles).set(updates).where(eq(dwgFiles.id, id)).returning();
    return dwgFile || undefined;
  }

  async deleteDwgFile(id: string): Promise<boolean> {
    const result = await db.delete(dwgFiles).where(eq(dwgFiles.id, id));
    return result.rowCount! > 0;
  }

  // Workflow operations
  async getWorkflow(id: string): Promise<Workflow | undefined> {
    const [workflow] = await db.select().from(workflows).where(eq(workflows.id, id));
    return workflow || undefined;
  }

  async getWorkflows(): Promise<Workflow[]> {
    return await db.select().from(workflows).orderBy(workflows.name);
  }

  async createWorkflow(insertWorkflow: InsertWorkflow): Promise<Workflow> {
    const [workflow] = await db.insert(workflows).values(insertWorkflow).returning();
    return workflow;
  }

  async updateWorkflow(id: string, updates: Partial<Workflow>): Promise<Workflow | undefined> {
    const [workflow] = await db.update(workflows).set(updates).where(eq(workflows.id, id)).returning();
    return workflow || undefined;
  }

  async deleteWorkflow(id: string): Promise<boolean> {
    const result = await db.delete(workflows).where(eq(workflows.id, id));
    return result.rowCount! > 0;
  }

  // Process Step operations
  async getProcessStep(id: string): Promise<ProcessStep | undefined> {
    const [processStep] = await db.select().from(processSteps).where(eq(processSteps.id, id));
    return processStep || undefined;
  }

  async getProcessSteps(): Promise<ProcessStep[]> {
    return await db.select().from(processSteps).orderBy(processSteps.position);
  }

  async getProcessStepsByWorkflow(workflowId: string): Promise<ProcessStep[]> {
    return await db.select().from(processSteps).where(eq(processSteps.workflowId, workflowId)).orderBy(processSteps.position);
  }

  async createProcessStep(insertProcessStep: InsertProcessStep): Promise<ProcessStep> {
    const [processStep] = await db.insert(processSteps).values(insertProcessStep).returning();
    return processStep;
  }

  async updateProcessStep(id: string, updates: Partial<ProcessStep>): Promise<ProcessStep | undefined> {
    const [processStep] = await db.update(processSteps).set(updates).where(eq(processSteps.id, id)).returning();
    return processStep || undefined;
  }

  async deleteProcessStep(id: string): Promise<boolean> {
    const result = await db.delete(processSteps).where(eq(processSteps.id, id));
    return result.rowCount! > 0;
  }

  // Step Dependency operations
  async getStepDependency(id: string): Promise<StepDependency | undefined> {
    const [stepDependency] = await db.select().from(stepDependencies).where(eq(stepDependencies.id, id));
    return stepDependency || undefined;
  }

  async getStepDependencies(): Promise<StepDependency[]> {
    return await db.select().from(stepDependencies);
  }

  async getStepDependenciesByStep(stepId: string): Promise<StepDependency[]> {
    return await db.select().from(stepDependencies).where(eq(stepDependencies.stepId, stepId));
  }

  async createStepDependency(insertStepDependency: InsertStepDependency): Promise<StepDependency> {
    const [stepDependency] = await db.insert(stepDependencies).values(insertStepDependency).returning();
    return stepDependency;
  }

  async deleteStepDependency(id: string): Promise<boolean> {
    const result = await db.delete(stepDependencies).where(eq(stepDependencies.id, id));
    return result.rowCount! > 0;
  }

  // Workflow Assignment operations
  async getWorkflowAssignment(id: string): Promise<WorkflowAssignment | undefined> {
    const [workflowAssignment] = await db.select().from(workflowAssignments).where(eq(workflowAssignments.id, id));
    return workflowAssignment || undefined;
  }

  async getWorkflowAssignments(): Promise<WorkflowAssignment[]> {
    return await db.select().from(workflowAssignments).orderBy(workflowAssignments.createdAt);
  }

  async getWorkflowAssignmentsByTarget(targetType: string, targetId: string): Promise<WorkflowAssignment[]> {
    return await db.select().from(workflowAssignments)
      .where(and(
        eq(workflowAssignments.targetType, targetType),
        eq(workflowAssignments.targetId, targetId)
      ));
  }

  async getWorkflowAssignmentsByWorkflow(workflowId: string): Promise<WorkflowAssignment[]> {
    return await db.select().from(workflowAssignments).where(eq(workflowAssignments.workflowId, workflowId));
  }

  async createWorkflowAssignment(insertWorkflowAssignment: InsertWorkflowAssignment): Promise<WorkflowAssignment> {
    const [workflowAssignment] = await db.insert(workflowAssignments).values(insertWorkflowAssignment).returning();
    return workflowAssignment;
  }

  async updateWorkflowAssignment(id: string, updates: Partial<WorkflowAssignment>): Promise<WorkflowAssignment | undefined> {
    const [workflowAssignment] = await db.update(workflowAssignments).set(updates).where(eq(workflowAssignments.id, id)).returning();
    return workflowAssignment || undefined;
  }

  async deleteWorkflowAssignment(id: string): Promise<boolean> {
    const result = await db.delete(workflowAssignments).where(eq(workflowAssignments.id, id));
    return result.rowCount! > 0;
  }

  // Automated workflow state management
  async recalculateWorkflowStepStates(workflowId: string): Promise<void> {
    const steps = await this.getProcessStepsByWorkflow(workflowId);
    const dependencies = await this.getStepDependencies();
    
    // Group dependencies by step
    const dependenciesByStep = dependencies.reduce((acc, dep) => {
      if (!acc[dep.stepId]) acc[dep.stepId] = [];
      acc[dep.stepId].push(dep);
      return acc;
    }, {} as Record<string, typeof dependencies>);

    // Calculate new states for each step
    for (const step of steps) {
      const stepDependencies = dependenciesByStep[step.id] || [];
      let newStatus = step.status;

      // Check if all dependencies are completed
      const allDependenciesCompleted = stepDependencies.every(dep => {
        const dependencyStep = steps.find(s => s.id === dep.dependsOnStepId);
        return dependencyStep?.status === "completed";
      });

      // Apply transition rules
      if (stepDependencies.length > 0 && !allDependenciesCompleted) {
        // Has incomplete dependencies - should be blocked
        if (step.status === "active" || step.status === "pending") {
          newStatus = "blocked";
        }
      } else if (step.status === "blocked" && allDependenciesCompleted) {
        // Dependencies completed - unblock to pending
        newStatus = "pending";
      }

      // Auto-activate first available step if none are active
      const hasActiveSteps = steps.some(s => s.status === "active");
      if (!hasActiveSteps && newStatus === "pending" && allDependenciesCompleted) {
        // Find the first step by position that can be activated
        const sortedSteps = steps
          .filter(s => s.status === "pending" || (s.id === step.id && newStatus === "pending"))
          .sort((a, b) => a.position - b.position);
        
        if (sortedSteps[0]?.id === step.id) {
          newStatus = "active";
        }
      }

      // Update step status if changed
      if (newStatus !== step.status) {
        await this.updateProcessStep(step.id, { status: newStatus });
      }
    }
  }

  async getStepWithDependencies(stepId: string): Promise<{ step: ProcessStep, dependencies: StepDependency[] } | null> {
    const step = await this.getProcessStep(stepId);
    if (!step) return null;
    
    const dependencies = await this.getStepDependenciesByStep(stepId);
    return { step, dependencies };
  }
}

export const storage = new DatabaseStorage();
