import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { 
  Github, FileSpreadsheet, Upload, Download, ExternalLink, 
  RefreshCw, CheckCircle, AlertCircle, Clock, Database 
} from "lucide-react";

interface MasterFileStatus {
  repository: {
    owner: string;
    repo: string;
    path: string;
    url: string;
  };
  inputFile: {
    owner: string;
    repo: string;
    path: string;
    url: string;
  };
}

interface ImportResults {
  dwgFiles: { created: number; updated: number; errors: number };
  assemblies: { created: number; updated: number; errors: number };
  parts: { created: number; updated: number; errors: number };
}

export default function MasterFileManager() {
  const [commitMessage, setCommitMessage] = useState("");
  const [lastExportUrl, setLastExportUrl] = useState<string | null>(null);
  const [importResults, setImportResults] = useState<ImportResults | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get master file status
  const { data: masterFileStatus, isLoading: statusLoading } = useQuery<MasterFileStatus>({
    queryKey: ["/api/master-file/status"],
  });

  // Export mutation
  const exportMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await fetch('/api/master-file/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      });
      
      if (!response.ok) {
        throw new Error('Export failed');
      }
      
      return response.json();
    },
    onSuccess: (result) => {
      setLastExportUrl(result.fileUrl);
      toast({
        title: "Successfully exported to GitHub",
        description: `Master file updated at ${result.repository}/${result.filePath}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Export failed",
        description: "Failed to export master file to GitHub. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Import mutation
  const importMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/master-file/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      
      if (!response.ok) {
        throw new Error('Import failed');
      }
      
      return response.json();
    },
    onSuccess: (result) => {
      setImportResults(result.importResults);
      
      // Invalidate all relevant queries to refresh the UI
      queryClient.invalidateQueries({ queryKey: ["/api/dwg-files"] });
      queryClient.invalidateQueries({ queryKey: ["/api/assemblies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/parts"] });
      
      toast({
        title: "Successfully imported from GitHub",
        description: `Data synchronized from ${result.repository}/${result.filePath}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Import failed",
        description: "Failed to import master file from GitHub. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleExport = () => {
    exportMutation.mutate(commitMessage || `Update BOM master file - ${new Date().toLocaleString()}`);
  };

  const handleImport = () => {
    importMutation.mutate();
  };

  // BOM Import mutation
  const bomImportMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/master-file/import-bom', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      
      if (!response.ok) {
        throw new Error('BOM import failed');
      }
      
      return response.json();
    },
    onSuccess: (result) => {
      // Invalidate all relevant queries to refresh the UI
      queryClient.invalidateQueries({ queryKey: ["/api/assemblies"] });
      queryClient.invalidateQueries({ queryKey: ["/api/parts"] });
      
      toast({
        title: "Successfully imported BOM data",
        description: result.message || "BOM data has been imported from Project Input.xlsx",
      });
    },
    onError: (error) => {
      toast({
        title: "BOM import failed",
        description: "Failed to import BOM data from Project Input.xlsx. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleBomImport = () => {
    bomImportMutation.mutate();
  };

  const getTotalChanges = (results: ImportResults) => {
    return Object.values(results).reduce((total, category) => 
      total + category.created + category.updated, 0
    );
  };

  const getTotalErrors = (results: ImportResults) => {
    return Object.values(results).reduce((total, category) => 
      total + category.errors, 0
    );
  };

  if (statusLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="h-6 w-6 animate-spin mr-2" />
        <span>Loading master file status...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold">Master File Manager</h2>
        <p className="text-muted-foreground">
          Sync your BOM data with the master Excel file stored on GitHub
        </p>
      </div>

      {/* Repository Info */}
      {masterFileStatus && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Github className="h-5 w-5" />
              <span>GitHub Repository</span>
            </CardTitle>
            <CardDescription>
              Master file location and repository details
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-medium">Repository:</span>
                <Badge variant="outline">{masterFileStatus.repository.owner}/{masterFileStatus.repository.repo}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">File Path:</span>
                <Badge variant="outline">{masterFileStatus.repository.path}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-medium">Direct Link:</span>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => window.open(masterFileStatus.repository.url, '_blank')}
                  data-testid="button-view-master-file"
                >
                  <ExternalLink className="h-3 w-3 mr-1" />
                  View on GitHub
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Export Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Upload className="h-5 w-5" />
            <span>Export to Master File</span>
          </CardTitle>
          <CardDescription>
            Export current BOM data to the GitHub master file
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="commit-message">Commit Message</Label>
            <Textarea
              id="commit-message"
              value={commitMessage}
              onChange={(e) => setCommitMessage(e.target.value)}
              placeholder="Describe the changes being made to the master file..."
              data-testid="textarea-commit-message"
            />
          </div>

          {lastExportUrl && (
            <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium text-green-700 dark:text-green-300">
                  Last export successful!
                </span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open(lastExportUrl, '_blank')}
                data-testid="button-view-last-export"
              >
                <ExternalLink className="h-3 w-3 mr-1" />
                View Updated File
              </Button>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button 
            onClick={handleExport}
            disabled={exportMutation.isPending}
            data-testid="button-export-master-file"
          >
            <Upload className="h-4 w-4 mr-2" />
            {exportMutation.isPending ? "Exporting..." : "Export to GitHub"}
          </Button>
        </CardFooter>
      </Card>

      {/* Import Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Download className="h-5 w-5" />
            <span>Import from Master File</span>
          </CardTitle>
          <CardDescription>
            Import and sync data from the GitHub master file to update the app
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {importResults && (
            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className="flex items-center space-x-2 mb-3">
                <Database className="h-4 w-4 text-blue-600" />
                <span className="font-medium text-blue-700 dark:text-blue-300">
                  Last Import Results
                </span>
              </div>
              
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <div className="font-medium">DWG Files</div>
                  <div className="text-muted-foreground">
                    {importResults.dwgFiles.created} created, {importResults.dwgFiles.updated} updated
                    {importResults.dwgFiles.errors > 0 && (
                      <span className="text-red-500">, {importResults.dwgFiles.errors} errors</span>
                    )}
                  </div>
                </div>
                <div>
                  <div className="font-medium">Assemblies</div>
                  <div className="text-muted-foreground">
                    {importResults.assemblies.created} created, {importResults.assemblies.updated} updated
                    {importResults.assemblies.errors > 0 && (
                      <span className="text-red-500">, {importResults.assemblies.errors} errors</span>
                    )}
                  </div>
                </div>
                <div>
                  <div className="font-medium">Parts</div>
                  <div className="text-muted-foreground">
                    {importResults.parts.created} created, {importResults.parts.updated} updated
                    {importResults.parts.errors > 0 && (
                      <span className="text-red-500">, {importResults.parts.errors} errors</span>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="mt-3 pt-3 border-t border-blue-200 dark:border-blue-800">
                <div className="flex items-center justify-between text-sm">
                  <span>Total Changes: {getTotalChanges(importResults)}</span>
                  {getTotalErrors(importResults) > 0 && (
                    <span className="text-red-500">Errors: {getTotalErrors(importResults)}</span>
                  )}
                </div>
              </div>
            </div>
          )}

          <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <AlertCircle className="h-4 w-4 text-amber-600" />
              <span className="text-sm font-medium text-amber-700 dark:text-amber-300">
                Important Note
              </span>
            </div>
            <p className="text-sm text-amber-700 dark:text-amber-300">
              This will import data from the master file and update your current BOM data. 
              The app will automatically refresh to show the latest data.
            </p>
          </div>
        </CardContent>
        <CardFooter>
          <Dialog>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                disabled={importMutation.isPending}
                data-testid="button-import-master-file"
              >
                <Download className="h-4 w-4 mr-2" />
                {importMutation.isPending ? "Importing..." : "Import from GitHub"}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Import Master File</DialogTitle>
                <DialogDescription>
                  This will import data from your GitHub master file and update your current BOM data. 
                  <strong className="text-destructive"> Any conflicting data will be overwritten.</strong>
                </DialogDescription>
              </DialogHeader>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => {}}>Cancel</Button>
                <Button onClick={handleImport} disabled={importMutation.isPending}>
                  {importMutation.isPending ? "Importing..." : "Confirm Import"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardFooter>
      </Card>

      {/* BOM Input Section */}
      {masterFileStatus?.inputFile && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileSpreadsheet className="h-5 w-5" />
              <span>Import BOM Items</span>
            </CardTitle>
            <CardDescription>
              Import BOM items from Project Input.xlsx file on GitHub
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <div className="flex items-center space-x-2 text-blue-700 dark:text-blue-300">
                  <FileSpreadsheet className="h-4 w-4" />
                  <span className="font-medium">Input File: {masterFileStatus.inputFile.path}</span>
                </div>
                <p className="text-sm text-blue-600 dark:text-blue-400 mt-1">
                  This will import BOM data from the "BOM" tab in the Project Input file.
                </p>
              </div>

              <div className="flex items-center space-x-3">
                <Button
                  onClick={handleBomImport}
                  disabled={bomImportMutation.isPending}
                  data-testid="button-import-bom"
                >
                  <Download className="h-4 w-4 mr-2" />
                  {bomImportMutation.isPending ? "Importing BOM..." : "Import BOM Items"}
                </Button>

                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => window.open(masterFileStatus.inputFile.url, '_blank')}
                  data-testid="button-view-input-file"
                >
                  <ExternalLink className="h-3 w-3 mr-1" />
                  View Input File
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}