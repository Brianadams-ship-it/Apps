import { useState } from "react";
import { format, addDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth, getDaysInMonth } from "date-fns";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ChevronLeft, ChevronRight, Calendar, Users, Clock } from "lucide-react";
import type { Part, Assembly } from "@shared/schema";

interface ScheduleViewProps {
  parts: Part[];
  assemblies: Assembly[];
  isLoading: boolean;
}

interface ScheduleTask {
  id: string;
  name: string;
  partNumber: string;
  status: string;
  startDate: Date;
  endDate: Date;
  duration: number;
  progress: number;
  assignee?: string;
  dependencies: string[];
  type: 'part' | 'assembly';
}

export default function ScheduleView({ parts, assemblies, isLoading }: ScheduleViewProps) {
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [viewType, setViewType] = useState<"week" | "month">("week");
  const [selectedResource, setSelectedResource] = useState<string>("all");

  // Convert parts and assemblies to schedule tasks
  const createScheduleTasks = (): ScheduleTask[] => {
    const tasks: ScheduleTask[] = [];
    const baseDate = startOfWeek(currentWeek);

    // Create tasks from parts with realistic dependencies
    parts.forEach((part, index) => {
      const startDate = addDays(baseDate, index % 7);
      const duration = getTaskDuration(part.status);
      const endDate = addDays(startDate, duration);
      
      // Create realistic dependencies based on part types
      const dependencies: string[] = [];
      if (part.name.toLowerCase().includes('housing') && parts.length > 1) {
        // Housing parts depend on frame parts
        const framePart = parts.find(p => p.name.toLowerCase().includes('frame') && p.id !== part.id);
        if (framePart) dependencies.push(framePart.id);
      }
      if (part.name.toLowerCase().includes('fastener') && parts.length > 2) {
        // Fasteners depend on the components they're fastening
        const componentParts = parts.filter(p => 
          (p.name.toLowerCase().includes('component') || p.name.toLowerCase().includes('housing')) && p.id !== part.id
        ).slice(0, 2);
        dependencies.push(...componentParts.map(p => p.id));
      }
      
      tasks.push({
        id: part.id,
        name: part.name,
        partNumber: part.partNumber,
        status: part.status,
        startDate,
        endDate,
        duration,
        progress: getProgressByStatus(part.status),
        assignee: getAssigneeByType(part.name),
        dependencies,
        type: 'part'
      });
    });

    // Create tasks from assemblies with enhanced dependencies
    assemblies.forEach((assembly, index) => {
      const startDate = addDays(baseDate, (index + parts.length) % 7);
      const duration = 7; // Assemblies typically take longer
      const endDate = addDays(startDate, duration);
      
      // Enhanced assembly dependencies
      const dependencies: string[] = [];
      
      // Parent assembly dependency
      if (assembly.parentId) {
        dependencies.push(assembly.parentId);
      }
      
      // Assembly depends on relevant parts
      const relevantParts = parts.filter(part => {
        if (assembly.name.toLowerCase().includes('housing')) {
          return part.name.toLowerCase().includes('housing') || part.name.toLowerCase().includes('frame');
        }
        if (assembly.name.toLowerCase().includes('main')) {
          return part.name.toLowerCase().includes('frame') || part.name.toLowerCase().includes('component');
        }
        return false;
      }).slice(0, 2); // Limit to 2 dependencies
      
      dependencies.push(...relevantParts.map(p => p.id));
      
      tasks.push({
        id: assembly.id,
        name: assembly.name,
        partNumber: `ASM-${index + 1}`,
        status: 'progress', // Assemblies are typically in progress
        startDate,
        endDate,
        duration,
        progress: 50,
        assignee: 'Assembly Team',
        dependencies,
        type: 'assembly'
      });
    });

    return tasks;
  };

  const getTaskDuration = (status: string): number => {
    switch (status) {
      case 'new': return 3;
      case 'progress': return 5;
      case 'complete': return 1;
      case 'issue': return 7;
      default: return 3;
    }
  };

  const getProgressByStatus = (status: string): number => {
    switch (status) {
      case 'new': return 0;
      case 'progress': return 50;
      case 'complete': return 100;
      case 'issue': return 25;
      default: return 0;
    }
  };

  const getAssigneeByType = (name: string): string => {
    if (name.toLowerCase().includes('mechanical')) return 'Mechanical Team';
    if (name.toLowerCase().includes('housing')) return 'Housing Team';
    if (name.toLowerCase().includes('frame')) return 'Structure Team';
    return 'General Team';
  };

  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'new': return 'bg-blue-500';
      case 'progress': return 'bg-orange-500';
      case 'complete': return 'bg-green-500';
      case 'issue': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const navigateWeek = (direction: 'prev' | 'next') => {
    const days = viewType === "week" ? 7 : getDaysInMonth(currentWeek);
    setCurrentWeek(prev => addDays(prev, direction === 'next' ? days : -days));
  };

  const tasks = createScheduleTasks();
  const timeStart = viewType === "week" ? startOfWeek(currentWeek) : startOfMonth(currentWeek);
  const timeEnd = viewType === "week" ? endOfWeek(currentWeek) : endOfMonth(currentWeek);
  const timeDays = viewType === "week" 
    ? Array.from({ length: 7 }, (_, i) => addDays(timeStart, i))
    : Array.from({ length: getDaysInMonth(currentWeek) }, (_, i) => addDays(timeStart, i));

  // Filter tasks by selected resource
  const filteredTasks = selectedResource === 'all' 
    ? tasks 
    : tasks.filter(task => task.assignee === selectedResource);

  // Get unique assignees for resource filter
  const assignees = Array.from(new Set(tasks.map(task => task.assignee).filter((assignee): assignee is string => Boolean(assignee))));

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64" data-testid="schedule-loading">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
          <p className="text-muted-foreground">Loading schedule...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="schedule-view">
      {/* Schedule Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold mb-2">Schedule View</h2>
          <p className="text-muted-foreground">
            Timeline view with task scheduling, dependencies, and resource allocation
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Resource Filter */}
          <Select value={selectedResource} onValueChange={setSelectedResource}>
            <SelectTrigger className="w-48" data-testid="select-resource">
              <Users className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Resources</SelectItem>
              {assignees.map(assignee => (
                <SelectItem key={assignee} value={assignee}>
                  {assignee}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* View Type Toggle */}
          <Select value={viewType} onValueChange={(value: "week" | "month") => setViewType(value)}>
            <SelectTrigger className="w-32" data-testid="select-view-type">
              <Calendar className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Week</SelectItem>
              <SelectItem value="month">Month</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Timeline Navigation */}
      <div className="flex items-center justify-between bg-card border border-border rounded-lg p-4">
        <Button 
          variant="outline" 
          onClick={() => navigateWeek('prev')}
          data-testid="button-prev-week"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        
        <div className="text-center">
          <h3 className="font-semibold text-lg" data-testid="text-current-week">
            {viewType === "week" 
              ? `${format(timeStart, 'MMM d')} - ${format(timeEnd, 'MMM d, yyyy')}`
              : format(currentWeek, 'MMMM yyyy')
            }
          </h3>
          <p className="text-sm text-muted-foreground">
            {filteredTasks.length} tasks scheduled
          </p>
        </div>
        
        <Button 
          variant="outline" 
          onClick={() => navigateWeek('next')}
          data-testid="button-next-week"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Timeline Grid */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        {/* Header Row */}
        <div className={viewType === "week" ? "grid grid-cols-8" : "grid"} style={viewType === "month" ? { gridTemplateColumns: `200px repeat(${Math.min(timeDays.length, 31)}, 1fr)` } : {}}>
          <div className="p-3 border-r border-border font-medium bg-muted/50">Task</div>
          {timeDays.map(day => (
            <div key={day.toISOString()} className="p-1 border-r border-border text-center font-medium bg-muted/50">
              <div className="text-xs">{viewType === "week" ? format(day, 'EEE') : format(day, 'd')}</div>
              {viewType === "week" && (
                <div className="text-xs text-muted-foreground">{format(day, 'MMM d')}</div>
              )}
            </div>
          ))}
        </div>

        {/* Task Rows */}
        <div className="max-h-96 overflow-y-auto">
          {filteredTasks.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground" data-testid="text-no-tasks">
              No tasks found for the selected time period and resource filter.
            </div>
          ) : (
            filteredTasks.map((task) => {
              const taskDependencies = task.dependencies.length > 0 
                ? tasks.filter(t => task.dependencies.includes(t.id))  // Use full task set, not filtered
                : [];
              const isBlocked = taskDependencies.some(dep => dep.endDate > task.startDate);
              
              return (
                <div key={task.id} className={viewType === "week" ? "grid grid-cols-8 border-b border-border hover:bg-muted/50 transition-colors" : "grid border-b border-border hover:bg-muted/50 transition-colors"} style={viewType === "month" ? { gridTemplateColumns: `200px repeat(${Math.min(timeDays.length, 31)}, 1fr)` } : {}} data-testid={`task-row-${task.id}`}>
                  {/* Task Info Column */}
                  <div className="p-3 border-r border-border">
                    <div className="font-medium text-sm truncate" title={task.name}>
                      {task.name}
                    </div>
                    <div className="text-xs text-muted-foreground">{task.partNumber}</div>
                    <div className="flex items-center mt-1 space-x-2">
                      <span className={`inline-block w-2 h-2 rounded-full ${getStatusColor(task.status)}`}></span>
                      <span className="text-xs capitalize">{task.status}</span>
                      {task.assignee && (
                        <span className="text-xs text-muted-foreground">• {task.assignee}</span>
                      )}
                    </div>
                    {/* Dependencies */}
                    {task.dependencies.length > 0 && (
                      <div className="mt-1">
                        <span className={`inline-block px-1 py-0.5 text-xs rounded ${isBlocked ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'}`}>
                          {isBlocked ? '🚫 Blocked' : `↗ ${taskDependencies.length} deps`}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Timeline Columns */}
                  {timeDays.map(day => {
                  const dayStart = day.getTime();
                  const dayEnd = addDays(day, 1).getTime();
                  const taskStart = task.startDate.getTime();
                  const taskEnd = task.endDate.getTime();
                  
                  const isTaskDay = taskStart <= dayEnd && taskEnd >= dayStart;
                  const isStartDay = taskStart >= dayStart && taskStart < dayEnd;
                  const isEndDay = taskEnd > dayStart && taskEnd <= dayEnd;
                  
                  return (
                    <div key={day.toISOString()} className="p-1 border-r border-border relative h-16 flex items-center">
                      {isTaskDay && (
                        <div 
                          className={`
                            ${getStatusColor(task.status)} 
                            h-6 w-full rounded opacity-80 relative overflow-hidden
                            ${isStartDay ? 'rounded-l' : ''}
                            ${isEndDay ? 'rounded-r' : ''}
                          `}
                          title={`${task.name} (${task.progress}% complete)`}
                        >
                          {/* Progress bar */}
                          <div 
                            className="absolute inset-0 bg-white/20 h-full transition-all"
                            style={{ width: `${task.progress}%` }}
                          ></div>
                          
                          {/* Task details on start day */}
                          {isStartDay && (
                            <div className="absolute inset-0 flex items-center px-2">
                              <Clock className="h-3 w-3 text-white mr-1" />
                              <span className="text-xs text-white font-medium truncate">
                                {task.duration}d
                              </span>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                  })}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-primary mb-1" data-testid="text-total-tasks">
            {filteredTasks.length}
          </div>
          <div className="text-sm text-muted-foreground">Total Tasks</div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-orange-600 mb-1" data-testid="text-active-tasks">
            {filteredTasks.filter(t => t.status === 'progress').length}
          </div>
          <div className="text-sm text-muted-foreground">Active Tasks</div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-green-600 mb-1" data-testid="text-completed-tasks">
            {filteredTasks.filter(t => t.status === 'complete').length}
          </div>
          <div className="text-sm text-muted-foreground">Completed</div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-blue-600 mb-1" data-testid="text-avg-progress">
            {filteredTasks.length > 0 ? Math.round(filteredTasks.reduce((sum, t) => sum + t.progress, 0) / filteredTasks.length) : 0}%
          </div>
          <div className="text-sm text-muted-foreground">Avg Progress</div>
        </div>
      </div>
    </div>
  );
}