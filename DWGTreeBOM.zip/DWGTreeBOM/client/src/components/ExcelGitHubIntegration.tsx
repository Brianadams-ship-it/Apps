import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Download, Upload, ExternalLink, Github, FileSpreadsheet } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Textarea } from "@/components/ui/textarea";

interface GitHubConfig {
  owner: string;
  repo: string;
  path: string;
  message?: string;
}

export default function ExcelGitHubIntegration() {
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [gitHubConfig, setGitHubConfig] = useState<GitHubConfig>({
    owner: "Brianadams-ship-it",
    repo: "Apps",
    path: "BOM_Master_File.xlsx",
    message: "",
  });
  const [githubFileUrl, setGithubFileUrl] = useState<string | null>(null);
  const { toast } = useToast();

  const handleExcelDownload = async () => {
    try {
      setIsExporting(true);
      const response = await fetch('/api/export/excel');
      
      if (!response.ok) {
        throw new Error('Failed to generate Excel file');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'BOM_Master_File.xlsx';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Excel file downloaded",
        description: "Your BOM master file has been downloaded successfully.",
      });
    } catch (error) {
      console.error('Export error:', error);
      toast({
        title: "Export failed",
        description: "Failed to generate Excel file. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleGitHubExport = async () => {
    try {
      setIsExporting(true);
      
      const response = await fetch('/api/export/github', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          owner: gitHubConfig.owner,
          repo: gitHubConfig.repo,
          path: gitHubConfig.path,
          message: gitHubConfig.message || `Update BOM master file - ${new Date().toLocaleString()}`,
        }),
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const result = await response.json();
      if (result.success) {
        setGithubFileUrl(result.fileUrl);
        toast({
          title: "Successfully uploaded to GitHub",
          description: `File uploaded to ${gitHubConfig.owner}/${gitHubConfig.repo}`,
        });
      } else {
        throw new Error('Upload failed');
      }
    } catch (error) {
      console.error('GitHub export error:', error);
      toast({
        title: "GitHub upload failed",
        description: "Failed to upload file to GitHub. Please check your repository settings.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleGitHubImport = async () => {
    try {
      setIsImporting(true);
      
      const params = new URLSearchParams({
        owner: gitHubConfig.owner,
        repo: gitHubConfig.repo,
        path: gitHubConfig.path,
      });

      const response = await fetch(`/api/import/github?${params}`);
      
      if (!response.ok) {
        throw new Error('Import failed');
      }

      const result = await response.json();
      if (result.success) {
        toast({
          title: "Successfully imported from GitHub",
          description: `Imported data from ${gitHubConfig.owner}/${gitHubConfig.repo}`,
        });
        
        // Refresh the page to show updated data
        window.location.reload();
      } else {
        throw new Error('Import failed');
      }
    } catch (error) {
      console.error('GitHub import error:', error);
      toast({
        title: "GitHub import failed",
        description: "Failed to import file from GitHub. Please check the file path and permissions.",
        variant: "destructive",
      });
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Excel Export/Download */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <FileSpreadsheet className="h-5 w-5" />
            <span>Excel Master File</span>
          </CardTitle>
          <CardDescription>
            Export all BOM data (DWG files, assemblies, and parts) to a comprehensive Excel spreadsheet
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            The Excel file will contain separate sheets for DWG files, assemblies, parts, and a summary overview.
          </p>
        </CardContent>
        <CardFooter>
          <Button 
            onClick={handleExcelDownload} 
            disabled={isExporting}
            data-testid="button-export-excel"
          >
            <Download className="h-4 w-4 mr-2" />
            {isExporting ? "Generating..." : "Download Excel File"}
          </Button>
        </CardFooter>
      </Card>

      {/* GitHub Integration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Github className="h-5 w-5" />
            <span>GitHub Integration</span>
          </CardTitle>
          <CardDescription>
            Store and sync your BOM master file with GitHub repository
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="github-owner">Repository Owner</Label>
              <Input
                id="github-owner"
                value={gitHubConfig.owner}
                onChange={(e) => setGitHubConfig(prev => ({ ...prev, owner: e.target.value }))}
                placeholder="username or organization"
                data-testid="input-github-owner"
              />
            </div>
            <div>
              <Label htmlFor="github-repo">Repository Name</Label>
              <Input
                id="github-repo"
                value={gitHubConfig.repo}
                onChange={(e) => setGitHubConfig(prev => ({ ...prev, repo: e.target.value }))}
                placeholder="repository-name"
                data-testid="input-github-repo"
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="github-path">File Path in Repository</Label>
            <Input
              id="github-path"
              value={gitHubConfig.path}
              onChange={(e) => setGitHubConfig(prev => ({ ...prev, path: e.target.value }))}
              placeholder="path/to/BOM_Master_File.xlsx"
              data-testid="input-github-path"
            />
          </div>

          <div>
            <Label htmlFor="github-message">Commit Message (optional)</Label>
            <Textarea
              id="github-message"
              value={gitHubConfig.message}
              onChange={(e) => setGitHubConfig(prev => ({ ...prev, message: e.target.value }))}
              placeholder="Update BOM master file"
              data-testid="input-github-message"
            />
          </div>

          {githubFileUrl && (
            <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <p className="text-sm text-green-700 dark:text-green-300 mb-2">
                File successfully uploaded to GitHub!
              </p>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open(githubFileUrl, '_blank')}
                data-testid="button-view-github-file"
              >
                <ExternalLink className="h-3 w-3 mr-1" />
                View on GitHub
              </Button>
            </div>
          )}
        </CardContent>
        <CardFooter className="space-x-2">
          <Button 
            onClick={handleGitHubExport} 
            disabled={isExporting || !gitHubConfig.owner || !gitHubConfig.repo || !gitHubConfig.path}
            data-testid="button-upload-github"
          >
            <Upload className="h-4 w-4 mr-2" />
            {isExporting ? "Uploading..." : "Upload to GitHub"}
          </Button>
          
          <Dialog>
            <DialogTrigger asChild>
              <Button 
                variant="outline" 
                disabled={isImporting || !gitHubConfig.owner || !gitHubConfig.repo || !gitHubConfig.path}
                data-testid="button-import-github"
              >
                <Download className="h-4 w-4 mr-2" />
                {isImporting ? "Importing..." : "Import from GitHub"}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Import from GitHub</DialogTitle>
                <DialogDescription>
                  This will import data from the Excel file stored in your GitHub repository and update your current BOM data. 
                  <strong className="text-destructive"> This action will refresh the page.</strong>
                </DialogDescription>
              </DialogHeader>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => {}}>Cancel</Button>
                <Button onClick={handleGitHubImport} disabled={isImporting}>
                  {isImporting ? "Importing..." : "Confirm Import"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardFooter>
      </Card>
    </div>
  );
}