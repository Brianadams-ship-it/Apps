import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertWorkflowSchema, insertProcessStepSchema } from "@shared/schema";
import { 
  Play, 
  Pause, 
  CheckCircle, 
  AlertCircle, 
  Plus, 
  ArrowRight, 
  Clock, 
  Users, 
  Settings,
  Workflow,
  GitBranch,
  ChevronRight
} from "lucide-react";
import type { 
  Workflow as WorkflowType, 
  ProcessStep, 
  StepDependency, 
  WorkflowAssignment,
  Part,
  Assembly 
} from "@shared/schema";

// Form schemas using shared schemas
const workflowFormSchema = insertWorkflowSchema;

const processStepFormSchema = insertProcessStepSchema.extend({
  estimatedDuration: z.coerce.number().min(1, "Duration must be at least 1 minute"),
});

type WorkflowFormData = z.infer<typeof workflowFormSchema>;
type ProcessStepFormData = z.infer<typeof processStepFormSchema>;

interface ProcessStepsViewProps {
  parts: Part[];
  assemblies: Assembly[];
}

const statusConfig = {
  pending: { 
    label: "Pending", 
    color: "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300",
    icon: Clock
  },
  active: { 
    label: "Active", 
    color: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300",
    icon: Play
  },
  completed: { 
    label: "Completed", 
    color: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
    icon: CheckCircle
  },
  blocked: { 
    label: "Blocked", 
    color: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
    icon: AlertCircle
  },
};

export function ProcessStepsView({ parts, assemblies }: ProcessStepsViewProps) {
  const { toast } = useToast();
  const [selectedWorkflow, setSelectedWorkflow] = useState<string | null>(null);
  const [isWorkflowDialogOpen, setIsWorkflowDialogOpen] = useState(false);
  const [isStepDialogOpen, setIsStepDialogOpen] = useState(false);

  // Fetch workflows
  const { data: workflows = [], isLoading: workflowsLoading } = useQuery<WorkflowType[]>({
    queryKey: ["/api/workflows"],
  });

  // Fetch process steps for selected workflow
  const { data: processSteps = [], isLoading: stepsLoading } = useQuery<ProcessStep[]>({
    queryKey: ["/api/process-steps", selectedWorkflow],
    queryFn: () => fetch(`/api/process-steps?workflowId=${selectedWorkflow}`, {
      headers: { 'Accept': 'application/json' }
    }).then(res => res.json()),
    enabled: !!selectedWorkflow,
  });

  // Fetch step dependencies
  const { data: stepDependencies = [] } = useQuery<StepDependency[]>({
    queryKey: ["/api/step-dependencies"],
  });

  // Fetch workflow assignments
  const { data: workflowAssignments = [] } = useQuery<WorkflowAssignment[]>({
    queryKey: ["/api/workflow-assignments"],
  });

  // Create workflow mutation
  const createWorkflowMutation = useMutation({
    mutationFn: (data: WorkflowFormData) => apiRequest("POST", "/api/workflows", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workflows"] });
      setIsWorkflowDialogOpen(false);
      workflowForm.reset();
      toast({
        title: "Workflow Created",
        description: "New workflow has been created successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create workflow. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Create process step mutation
  const createProcessStepMutation = useMutation({
    mutationFn: (data: ProcessStepFormData) => apiRequest("POST", "/api/process-steps", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/process-steps", selectedWorkflow] });
      queryClient.invalidateQueries({ queryKey: ["/api/workflows"] });
      setIsStepDialogOpen(false);
      stepForm.reset();
      toast({
        title: "Process Step Created",
        description: "New process step has been added to the workflow.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create process step. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update process step status mutation
  const updateStepStatusMutation = useMutation({
    mutationFn: ({ stepId, status }: { stepId: string, status: string }) => 
      apiRequest("PUT", `/api/process-steps/${stepId}`, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/process-steps", selectedWorkflow] });
      // Trigger workflow state recalculation
      queryClient.invalidateQueries({ queryKey: ["/api/workflows"] });
      toast({
        title: "Step Updated",
        description: "Process step status has been updated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update step status.",
        variant: "destructive",
      });
    },
  });

  const workflowForm = useForm<WorkflowFormData>({
    resolver: zodResolver(workflowFormSchema),
    defaultValues: {
      name: "",
      description: "",
      isActive: true,
    },
  });

  const stepForm = useForm<ProcessStepFormData>({
    resolver: zodResolver(processStepFormSchema),
    defaultValues: {
      workflowId: "",
      name: "",
      description: "",
      estimatedDuration: 60,
      position: 0,
    },
  });

  const onCreateWorkflow = (data: WorkflowFormData) => {
    createWorkflowMutation.mutate(data);
  };

  const onCreateProcessStep = (data: ProcessStepFormData) => {
    if (!selectedWorkflow) {
      toast({
        title: "Error",
        description: "No workflow selected. Please select a workflow first.",
        variant: "destructive",
      });
      return;
    }
    
    createProcessStepMutation.mutate({
      ...data,
      workflowId: selectedWorkflow,
      position: processSteps.length,
    });
  };

  const handleStepStatusChange = (stepId: string, newStatus: string) => {
    updateStepStatusMutation.mutate({ stepId, status: newStatus });
  };

  // Calculate workflow progress
  const getWorkflowProgress = (workflowId: string) => {
    const steps = processSteps.filter((step: ProcessStep) => step.workflowId === workflowId);
    if (steps.length === 0) return 0;
    const completedSteps = steps.filter((step: ProcessStep) => step.status === "completed");
    return Math.round((completedSteps.length / steps.length) * 100);
  };

  // Get step dependencies for a step
  const getStepDependencies = (stepId: string) => {
    return stepDependencies.filter((dep: StepDependency) => dep.stepId === stepId);
  };

  // Check if step can be started (dependencies completed)
  const canStartStep = (step: ProcessStep) => {
    const dependencies = getStepDependencies(step.id);
    if (dependencies.length === 0) return true;
    
    return dependencies.every((dep: StepDependency) => {
      const dependencyStep = processSteps.find((s: ProcessStep) => s.id === dep.dependsOnStepId);
      return dependencyStep?.status === "completed";
    });
  };

  if (workflowsLoading) {
    return (
      <div className="flex items-center justify-center h-64" data-testid="process-loading">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
          <p className="text-muted-foreground">Loading workflows...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="process-steps-view">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Workflow className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-semibold">Process Steps Designer</h2>
        </div>
        <Dialog open={isWorkflowDialogOpen} onOpenChange={setIsWorkflowDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-workflow">
              <Plus className="h-4 w-4 mr-2" />
              Create Workflow
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Workflow</DialogTitle>
              <DialogDescription>
                Design a new process workflow for manufacturing or assembly operations.
              </DialogDescription>
            </DialogHeader>
            <Form {...workflowForm}>
              <form onSubmit={workflowForm.handleSubmit(onCreateWorkflow)} className="space-y-4">
                <FormField
                  control={workflowForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Workflow Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Assembly Process" {...field} data-testid="input-workflow-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={workflowForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe the workflow purpose and scope"
                          {...field}
                          value={field.value || ''}
                          data-testid="input-workflow-description"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setIsWorkflowDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createWorkflowMutation.isPending} data-testid="button-save-workflow">
                    {createWorkflowMutation.isPending ? "Creating..." : "Create Workflow"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Workflow Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {workflows.map((workflow: WorkflowType) => {
          const progress = getWorkflowProgress(workflow.id);
          const workflowSteps = processSteps.filter((step: ProcessStep) => step.workflowId === workflow.id);
          const activeSteps = workflowSteps.filter((step: ProcessStep) => step.status === "active");
          
          return (
            <Card 
              key={workflow.id} 
              className={`cursor-pointer transition-all hover:shadow-md ${
                selectedWorkflow === workflow.id ? "ring-2 ring-primary" : ""
              }`}
              onClick={() => setSelectedWorkflow(workflow.id)}
              data-testid={`workflow-card-${workflow.id}`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">{workflow.name}</CardTitle>
                  <Badge variant={workflow.isActive ? "default" : "secondary"}>
                    {workflow.isActive ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <CardDescription className="text-sm">
                  {workflow.description || "No description provided"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="font-medium">{progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 dark:bg-gray-700">
                    <div 
                      className="bg-primary h-2 rounded-full transition-all" 
                      style={{ width: `${progress}%` }}
                    ></div>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{workflowSteps.length} steps</span>
                    <span>{activeSteps.length} active</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Selected Workflow Details */}
      {selectedWorkflow && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium">Workflow Steps</h3>
            <Dialog open={isStepDialogOpen} onOpenChange={setIsStepDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" data-testid="button-add-step">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Step
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Process Step</DialogTitle>
                  <DialogDescription>
                    Create a new step in the selected workflow.
                  </DialogDescription>
                </DialogHeader>
                <Form {...stepForm}>
                  <form onSubmit={stepForm.handleSubmit(onCreateProcessStep)} className="space-y-4">
                    <FormField
                      control={stepForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Step Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Material Preparation" {...field} data-testid="input-step-name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={stepForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe what happens in this step"
                              {...field}
                              value={field.value || ''}
                              data-testid="input-step-description"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={stepForm.control}
                      name="estimatedDuration"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Estimated Duration (minutes)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="1"
                              {...field}
                              onChange={(e) => {
                                const value = e.target.value === '' ? '' : parseInt(e.target.value, 10);
                                field.onChange(value);
                              }}
                              data-testid="input-step-duration"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="flex justify-end space-x-2">
                      <Button type="button" variant="outline" onClick={() => setIsStepDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button type="submit" disabled={createProcessStepMutation.isPending} data-testid="button-save-step">
                        {createProcessStepMutation.isPending ? "Creating..." : "Add Step"}
                      </Button>
                    </div>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          {/* Process Steps Flow */}
          {stepsLoading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
            </div>
          ) : processSteps.length === 0 ? (
            <Card>
              <CardContent className="flex items-center justify-center h-32 text-center">
                <div>
                  <GitBranch className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No process steps defined</p>
                  <p className="text-sm text-muted-foreground">Add your first step to get started</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {processSteps.map((step: ProcessStep, index: number) => {
                const StatusIcon = statusConfig[step.status as keyof typeof statusConfig]?.icon || Clock;
                const statusStyle = statusConfig[step.status as keyof typeof statusConfig];
                const dependencies = getStepDependencies(step.id);
                const canStart = canStartStep(step);
                
                return (
                  <Card key={step.id} className="relative" data-testid={`step-card-${step.id}`}>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 text-primary font-semibold">
                            {index + 1}
                          </div>
                          <div>
                            <CardTitle className="text-base">{step.name}</CardTitle>
                            <CardDescription className="text-sm">
                              {step.description || "No description provided"}
                            </CardDescription>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={statusStyle?.color}>
                            <StatusIcon className="h-3 w-3 mr-1" />
                            {statusStyle?.label}
                          </Badge>
                          <Select
                            value={step.status}
                            onValueChange={(value) => handleStepStatusChange(step.id, value)}
                            disabled={!canStart && step.status === "pending"}
                          >
                            <SelectTrigger className="w-32" data-testid={`select-status-${step.id}`}>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="pending">Pending</SelectItem>
                              <SelectItem value="active">Active</SelectItem>
                              <SelectItem value="completed">Completed</SelectItem>
                              <SelectItem value="blocked">Blocked</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            {step.estimatedDuration} min
                          </div>
                          {dependencies.length > 0 && (
                            <div className="flex items-center">
                              <GitBranch className="h-4 w-4 mr-1" />
                              {dependencies.length} dependencies
                            </div>
                          )}
                        </div>
                        {!canStart && step.status === "pending" && (
                          <Badge variant="outline" className="text-orange-600 border-orange-600">
                            Waiting for dependencies
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                    
                    {/* Connection line to next step */}
                    {index < processSteps.length - 1 && (
                      <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 z-10">
                        <div className="flex items-center justify-center w-8 h-8 bg-background rounded-full border-2 border-muted">
                          <ChevronRight className="h-4 w-4 text-muted-foreground" />
                        </div>
                      </div>
                    )}
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      )}

      {workflows.length === 0 && (
        <Card>
          <CardContent className="flex items-center justify-center h-64 text-center">
            <div>
              <Workflow className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No Workflows Found</h3>
              <p className="text-muted-foreground mb-4">
                Create your first workflow to start designing process steps for your manufacturing operations.
              </p>
              <Button onClick={() => setIsWorkflowDialogOpen(true)} data-testid="button-create-first-workflow">
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Workflow
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}