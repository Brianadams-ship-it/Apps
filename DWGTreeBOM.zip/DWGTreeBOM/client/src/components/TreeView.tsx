import { useState } from "react";
import { ChevronDown, ChevronRight, Box, Layers, ArrowLeftFromLine, Import } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import type { Assembly, Part } from "@shared/schema";

interface TreeViewProps {
  assemblies: Assembly[];
  parts: Part[];
  isLoading: boolean;
}

interface TreeNode {
  id: string;
  name: string;
  type: "assembly" | "part";
  level: number;
  isExpanded: boolean;
  children: TreeNode[];
  partCount?: number;
  status?: string;
  partNumber?: string;
}

export default function TreeView({ assemblies, parts, isLoading }: TreeViewProps) {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());

  const buildTreeStructure = (): TreeNode[] => {
    const assemblyMap = new Map<string, Assembly>();
    const partsMap = new Map<string, Part[]>();

    // Create maps for quick lookup
    assemblies.forEach(assembly => {
      assemblyMap.set(assembly.id, assembly);
    });

    // Group parts by assembly
    parts.forEach(part => {
      if (part.assemblyId) {
        if (!partsMap.has(part.assemblyId)) {
          partsMap.set(part.assemblyId, []);
        }
        partsMap.get(part.assemblyId)!.push(part);
      }
    });

    const buildNode = (assembly: Assembly): TreeNode => {
      const assemblyParts = partsMap.get(assembly.id) || [];
      const childAssemblies = assemblies.filter(a => a.parentId === assembly.id);
      
      const children: TreeNode[] = [
        ...childAssemblies.map(buildNode),
        ...assemblyParts.map(part => ({
          id: part.id,
          name: part.name,
          type: "part" as const,
          level: assembly.level + 1,
          isExpanded: false,
          children: [],
          status: part.status,
          partNumber: part.partNumber,
        }))
      ];

      const totalParts = assemblyParts.length + 
        childAssemblies.reduce((sum, child) => sum + (partsMap.get(child.id)?.length || 0), 0);

      return {
        id: assembly.id,
        name: assembly.name,
        type: "assembly",
        level: assembly.level,
        isExpanded: expandedNodes.has(assembly.id) || assembly.isExpanded,
        children,
        partCount: totalParts,
      };
    };

    // Start with root assemblies (no parent)
    return assemblies
      .filter(assembly => !assembly.parentId)
      .map(buildNode);
  };

  const toggleNode = (nodeId: string) => {
    setExpandedNodes(prev => {
      const newSet = new Set(prev);
      if (newSet.has(nodeId)) {
        newSet.delete(nodeId);
      } else {
        newSet.add(nodeId);
      }
      return newSet;
    });
  };

  const expandAll = () => {
    const allAssemblyIds = assemblies.map(a => a.id);
    setExpandedNodes(new Set(allAssemblyIds));
  };

  const collapseAll = () => {
    setExpandedNodes(new Set());
  };

  const renderTreeNode = (node: TreeNode): React.ReactNode => {
    const isExpanded = expandedNodes.has(node.id) || node.isExpanded;
    const hasChildren = node.children.length > 0;
    const indent = `${node.level * 20}px`;

    const getStatusColor = (status: string) => {
      switch (status) {
        case "new": return "bg-blue-100 text-blue-700";
        case "progress": return "bg-orange-100 text-orange-700";
        case "complete": return "bg-green-100 text-green-700";
        case "issue": return "bg-red-100 text-red-700";
        default: return "bg-secondary text-secondary-foreground";
      }
    };

    if (node.type === "assembly") {
      return (
        <div key={node.id}>
          <div 
            className="flex items-center p-2 hover:bg-secondary rounded cursor-pointer"
            style={{ marginLeft: indent }}
            onClick={() => hasChildren && toggleNode(node.id)}
            data-testid={`tree-assembly-${node.id}`}
          >
            {hasChildren ? (
              isExpanded ? (
                <ChevronDown className="h-4 w-4 mr-2 text-muted-foreground" />
              ) : (
                <ChevronRight className="h-4 w-4 mr-2 text-muted-foreground" />
              )
            ) : (
              <div className="w-4 h-4 mr-2" />
            )}
            <div className="w-8 h-8 bg-primary/10 rounded border mr-2 flex items-center justify-center">
              <Layers className="h-4 w-4 text-primary" />
            </div>
            <span className="font-medium">{node.name}</span>
            {node.partCount !== undefined && (
              <span className="ml-auto text-xs bg-secondary px-2 py-1 rounded">
                {node.partCount} parts
              </span>
            )}
          </div>
          {isExpanded && (
            <div>
              {node.children.map(child => renderTreeNode(child))}
            </div>
          )}
        </div>
      );
    } else {
      return (
        <div 
          key={node.id}
          className="flex items-center p-2 hover:bg-secondary rounded cursor-pointer"
          style={{ marginLeft: indent }}
          data-testid={`tree-part-${node.id}`}
        >
          <div className="w-4 h-4 mr-2" />
          <div className="w-6 h-6 bg-blue-100 rounded border mr-2 flex items-center justify-center ml-4">
            <Box className="h-3 w-3 text-blue-600" />
          </div>
          <span className="text-sm">{node.name}</span>
          <span className="ml-auto text-xs text-muted-foreground">
            {node.partNumber}
          </span>
          {node.status && (
            <span className={`ml-2 text-xs px-2 py-1 rounded ${getStatusColor(node.status)}`}>
              {node.status}
            </span>
          )}
        </div>
      );
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-2">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold">Assembly Tree</h3>
          <div className="flex space-x-2">
            <Skeleton className="h-6 w-6" />
            <Skeleton className="h-6 w-6" />
          </div>
        </div>
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex items-center p-2">
            <Skeleton className="h-4 w-4 mr-2" />
            <Skeleton className="h-8 w-8 mr-2" />
            <Skeleton className="h-4 flex-1" />
          </div>
        ))}
      </div>
    );
  }

  const treeNodes = buildTreeStructure();

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold">Assembly Tree</h3>
        <div className="flex space-x-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={expandAll}
            title="Expand All"
            data-testid="button-expand-all"
          >
            <ArrowLeftFromLine className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={collapseAll}
            title="Collapse All"
            data-testid="button-collapse-all"
          >
            <Import className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="space-y-1" data-testid="tree-view-container">
        {treeNodes.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground" data-testid="text-no-assemblies">
            No assemblies found. Upload a DWG file or select a template to get started.
          </div>
        ) : (
          treeNodes.map(node => renderTreeNode(node))
        )}
      </div>
    </div>
  );
}
