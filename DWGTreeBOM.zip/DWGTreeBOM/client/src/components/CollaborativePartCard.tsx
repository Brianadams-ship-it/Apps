import { useState, useEffect } from 'react';
import { Lock, Users } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useCollaborationContext } from '@/contexts/CollaborationContext';
import PartCard from './PartCard';
import type { Part } from '@shared/schema';

interface CollaborativePartCardProps {
  part: Part;
  onEdit?: (part: Part) => void;
  onDelete?: (id: string) => void;
  className?: string;
}

export function CollaborativePartCard({ part, onEdit, onDelete, className }: CollaborativePartCardProps) {
  const collaboration = useCollaborationContext();
  const [isEditing, setIsEditing] = useState(false);
  
  const isLocked = collaboration.isEntityLocked('part', part.id);
  const lock = collaboration.getEntityLock('part', part.id);
  const lockingUser = lock ? collaboration.users.get(lock.userId) : null;

  const handleEdit = async () => {
    if (isLocked) {
      // Show locked message or toast
      return;
    }

    // Request lock before editing
    const lockAcquired = await collaboration.requestLock('part', part.id);
    if (lockAcquired) {
      setIsEditing(true);
      onEdit?.(part);
    }
  };

  const handleEditComplete = () => {
    setIsEditing(false);
    collaboration.releaseLock('part', part.id);
  };

  const handleEditCancel = () => {
    setIsEditing(false);
    collaboration.releaseLock('part', part.id);
  };

  // Clean up lock on unmount
  useEffect(() => {
    return () => {
      if (isEditing) {
        collaboration.releaseLock('part', part.id);
      }
    };
  }, [isEditing, collaboration, part.id]);

  return (
    <div className={`relative ${className || ''}`} data-testid={`card-part-${part.id}`}>
      {/* Lock Indicator */}
      {isLocked && lockingUser && (
        <div className="absolute top-2 right-2 z-10 flex items-center gap-1 bg-yellow-100 dark:bg-yellow-900 px-2 py-1 rounded-md border" data-testid={`lock-indicator-${part.id}`}>
          <Lock className="h-3 w-3 text-yellow-600 dark:text-yellow-400" />
          <Avatar className="h-4 w-4">
            <AvatarFallback 
              className="text-xs"
              style={{ backgroundColor: lockingUser.color }}
            >
              {lockingUser.name.slice(0, 1).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <span className="text-xs text-yellow-700 dark:text-yellow-300">
            {lockingUser.name}
          </span>
        </div>
      )}

      {/* Editing Indicator */}
      {isEditing && (
        <div className="absolute top-2 left-2 z-10 bg-blue-100 dark:bg-blue-900 px-2 py-1 rounded-md border" data-testid={`editing-indicator-${part.id}`}>
          <span className="text-xs text-blue-700 dark:text-blue-300">Editing...</span>
        </div>
      )}

      {/* Regular Part Card with collaborative overlay */}
      <div className={`${isLocked && !isEditing ? 'opacity-75 cursor-not-allowed' : ''}`}>
        <PartCard part={part} />
      </div>
    </div>
  );
}