import { useState } from "react";
import { MoreVertical, Box, Circle, Cog, Bolt } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import type { Part } from "@shared/schema";

interface PartCardProps {
  part: Part;
}

export default function PartCard({ part }: PartCardProps) {
  const [isDragging, setIsDragging] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const updatePartMutation = useMutation({
    mutationFn: async (updates: Partial<Part>) => {
      const response = await apiRequest("PUT", `/api/parts/${part.id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/parts"] });
      toast({
        title: "Part updated",
        description: "The part has been updated successfully.",
      });
    },
    onError: (error) => {
      console.error("Error updating part:", error);
      toast({
        title: "Update failed",
        description: "Failed to update the part. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getStatusInfo = (status: string) => {
    switch (status) {
      case "new":
        return {
          className: "status-new",
          borderColor: "border-l-blue-500",
          statusBadge: "bg-blue-100 text-blue-700",
          statusText: "Planning",
          dotColor: "bg-blue-500",
        };
      case "progress":
        return {
          className: "status-progress",
          borderColor: "border-l-orange-500",
          statusBadge: "bg-orange-100 text-orange-700",
          statusText: "Manufacturing",
          dotColor: "bg-orange-500",
        };
      case "complete":
        return {
          className: "status-complete",
          borderColor: "border-l-green-500",
          statusBadge: "bg-green-100 text-green-700",
          statusText: "Complete",
          dotColor: "bg-green-500",
        };
      case "issue":
        return {
          className: "status-issue",
          borderColor: "border-l-red-500",
          statusBadge: "bg-red-100 text-red-700",
          statusText: "Design Review",
          dotColor: "bg-red-500",
        };
      default:
        return {
          className: "",
          borderColor: "border-l-gray-500",
          statusBadge: "bg-gray-100 text-gray-700",
          statusText: "Unknown",
          dotColor: "bg-gray-500",
        };
    }
  };

  const getPartIcon = () => {
    const iconClass = "h-6 w-6";
    if (part.name.toLowerCase().includes("motor")) {
      return <Circle className={`${iconClass} text-blue-600`} />;
    } else if (part.name.toLowerCase().includes("bearing")) {
      return <Bolt className={`${iconClass} text-red-600`} />;
    } else if (part.name.toLowerCase().includes("shaft") || part.name.toLowerCase().includes("gear")) {
      return <Cog className={`${iconClass} text-blue-600`} />;
    }
    return <Box className={`${iconClass} text-blue-600`} />;
  };

  const statusInfo = getStatusInfo(part.status);

  const handleStatusChange = (newStatus: string) => {
    updatePartMutation.mutate({ status: newStatus });
  };

  const handleDragStart = (e: React.DragEvent) => {
    setIsDragging(true);
    e.dataTransfer.setData("text/plain", part.id);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragEnd = () => {
    setIsDragging(false);
  };

  return (
    <Card
      className={`part-card transition-all duration-200 cursor-grab hover:shadow-md ${statusInfo.className} ${statusInfo.borderColor} ${
        isDragging ? "opacity-50 cursor-grabbing" : ""
      }`}
      draggable
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      data-testid={`card-part-${part.id}`}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="w-12 h-12 bg-blue-100 rounded-lg border flex items-center justify-center">
            {getPartIcon()}
          </div>
          <div className="flex space-x-1">
            <span className={`w-2 h-2 rounded-full ${statusInfo.dotColor}`} />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-auto w-auto p-1"
                  data-testid={`button-part-menu-${part.id}`}
                >
                  <MoreVertical className="h-4 w-4 text-muted-foreground" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => handleStatusChange("new")}>
                  Set to Planning
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleStatusChange("progress")}>
                  Set to In Progress
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleStatusChange("complete")}>
                  Set to Complete
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleStatusChange("issue")}>
                  Set to Review
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
        
        <h4 className="font-medium mb-1" data-testid={`text-part-name-${part.id}`}>
          {part.name}
        </h4>
        <p className="text-sm text-muted-foreground mb-2" data-testid={`text-part-number-${part.id}`}>
          Part: {part.partNumber}
        </p>
        
        <div className="flex items-center justify-between text-xs">
          <Badge className={statusInfo.statusBadge} data-testid={`badge-status-${part.id}`}>
            {statusInfo.statusText}
          </Badge>
          <span className="text-muted-foreground" data-testid={`text-quantity-${part.id}`}>
            Qty: {part.quantity}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
