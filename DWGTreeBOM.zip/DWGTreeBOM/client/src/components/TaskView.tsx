import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MoreHorizontal, User, Clock, Package, Layers, Filter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Part, Assembly } from "@shared/schema";

interface TaskViewProps {
  parts: Part[];
  assemblies: Assembly[];
  isLoading: boolean;
}

interface TaskCard {
  id: string;
  title: string;
  partNumber: string;
  description: string | null;
  status: string;
  type: 'part' | 'assembly';
  assignee: string;
  priority: 'low' | 'medium' | 'high';
  estimatedDays: number;
  metadata?: any;
}

const statusConfig = {
  new: {
    label: 'New/Planning',
    color: 'bg-blue-500',
    textColor: 'text-blue-700',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200'
  },
  progress: {
    label: 'In Progress',
    color: 'bg-orange-500',
    textColor: 'text-orange-700',
    bgColor: 'bg-orange-50',
    borderColor: 'border-orange-200'
  },
  complete: {
    label: 'Complete',
    color: 'bg-green-500',
    textColor: 'text-green-700',
    bgColor: 'bg-green-50',
    borderColor: 'border-green-200'
  },
  issue: {
    label: 'Issues/Review',
    color: 'bg-red-500',
    textColor: 'text-red-700',
    bgColor: 'bg-red-50',
    borderColor: 'border-red-200'
  }
};

export default function TaskView({ parts, assemblies, isLoading }: TaskViewProps) {
  const [draggedCard, setDraggedCard] = useState<TaskCard | null>(null);
  const [filterBy, setFilterBy] = useState<string>("all");
  const [sortBy, setSortBy] = useState<"priority" | "type" | "assignee">("priority");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Convert parts and assemblies to task cards
  const createTaskCards = (): TaskCard[] => {
    const cards: TaskCard[] = [];

    // Convert parts to task cards
    parts.forEach(part => {
      cards.push({
        id: part.id,
        title: part.name,
        partNumber: part.partNumber,
        description: part.description,
        status: part.status,
        type: 'part',
        assignee: getAssigneeByType(part.name),
        priority: getPriorityByStatus(part.status),
        estimatedDays: getEstimatedDays(part.status),
        metadata: part.metadata
      });
    });

    // Convert assemblies to task cards
    assemblies.forEach(assembly => {
      cards.push({
        id: assembly.id,
        title: assembly.name,
        partNumber: `ASM-${assembly.id.slice(0, 6)}`,
        description: assembly.description,
        status: assembly.status || 'new', // Use actual assembly status
        type: 'assembly',
        assignee: 'Assembly Team',
        priority: getPriorityByStatus(assembly.status || 'new'),
        estimatedDays: getEstimatedDays(assembly.status || 'new'),
        metadata: {}
      });
    });

    return cards;
  };

  const getAssigneeByType = (name: string): string => {
    if (name.toLowerCase().includes('mechanical')) return 'Mechanical Team';
    if (name.toLowerCase().includes('housing')) return 'Housing Team';
    if (name.toLowerCase().includes('frame')) return 'Structure Team';
    if (name.toLowerCase().includes('fastener')) return 'Assembly Team';
    return 'General Team';
  };

  const getPriorityByStatus = (status: string): 'low' | 'medium' | 'high' => {
    switch (status) {
      case 'issue': return 'high';
      case 'progress': return 'medium';
      case 'new': return 'medium';
      case 'complete': return 'low';
      default: return 'medium';
    }
  };

  const getEstimatedDays = (status: string): number => {
    switch (status) {
      case 'new': return 3;
      case 'progress': return 5;
      case 'complete': return 1;
      case 'issue': return 7;
      default: return 3;
    }
  };

  const getPriorityColor = (priority: string): string => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getAvatarInitials = (assignee: string): string => {
    return assignee.split(' ').map(word => word[0]).join('').toUpperCase().slice(0, 2);
  };

  // Update task status mutation
  const updateTaskStatusMutation = useMutation({
    mutationFn: async ({ taskId, newStatus, type }: { taskId: string, newStatus: string, type: 'part' | 'assembly' }) => {
      const endpoint = type === 'part' ? `/api/parts/${taskId}` : `/api/assemblies/${taskId}`;
      return apiRequest('PUT', endpoint, { status: newStatus });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/parts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/assemblies'] });
      toast({
        title: "Task Updated",
        description: "Task status has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update task status. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleDragStart = (e: React.DragEvent, card: TaskCard) => {
    setDraggedCard(card);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent, newStatus: string) => {
    e.preventDefault();
    if (draggedCard && draggedCard.status !== newStatus) {
      updateTaskStatusMutation.mutate({
        taskId: draggedCard.id,
        newStatus,
        type: draggedCard.type
      });
    }
    setDraggedCard(null);
  };

  const handleDragEnd = () => {
    setDraggedCard(null);
  };

  const tasks = createTaskCards();

  // Filter and sort tasks
  const filteredTasks = tasks.filter(task => {
    if (filterBy === 'all') return true;
    if (filterBy === 'parts') return task.type === 'part';
    if (filterBy === 'assemblies') return task.type === 'assembly';
    return task.assignee === filterBy;
  });

  const sortedTasks = [...filteredTasks].sort((a, b) => {
    if (sortBy === 'priority') {
      const priorityOrder = { high: 3, medium: 2, low: 1 };
      return priorityOrder[b.priority] - priorityOrder[a.priority];
    }
    if (sortBy === 'type') {
      return a.type.localeCompare(b.type);
    }
    if (sortBy === 'assignee') {
      return a.assignee.localeCompare(b.assignee);
    }
    return 0;
  });

  // Group tasks by status
  const tasksByStatus = Object.keys(statusConfig).reduce((acc, status) => {
    acc[status] = sortedTasks.filter(task => task.status === status);
    return acc;
  }, {} as Record<string, TaskCard[]>);

  // Get unique assignees for filter
  const assignees = Array.from(new Set(tasks.map(task => task.assignee)));

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64" data-testid="task-loading">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
          <p className="text-muted-foreground">Loading tasks...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="task-view">
      {/* Task Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold mb-2">Task View</h2>
          <p className="text-muted-foreground">
            Kanban-style board with drag-and-drop task management and status workflows
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Filter */}
          <Select value={filterBy} onValueChange={setFilterBy}>
            <SelectTrigger className="w-48" data-testid="select-filter">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Tasks</SelectItem>
              <SelectItem value="parts">Parts Only</SelectItem>
              <SelectItem value="assemblies">Assemblies Only</SelectItem>
              {assignees.map(assignee => (
                <SelectItem key={assignee} value={assignee}>
                  {assignee}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Sort */}
          <Select value={sortBy} onValueChange={(value: "priority" | "type" | "assignee") => setSortBy(value)}>
            <SelectTrigger className="w-32" data-testid="select-sort">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="priority">Priority</SelectItem>
              <SelectItem value="type">Type</SelectItem>
              <SelectItem value="assignee">Assignee</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Kanban Board */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 min-h-[600px]">
        {Object.entries(statusConfig).map(([status, config]) => (
          <div
            key={status}
            className={`${config.bgColor} ${config.borderColor} border-2 rounded-lg p-4`}
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, status)}
            data-testid={`column-${status}`}
          >
            {/* Column Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${config.color}`}></div>
                <h3 className={`font-semibold ${config.textColor}`}>
                  {config.label}
                </h3>
              </div>
              <Badge variant="secondary" className="text-xs">
                {tasksByStatus[status]?.length || 0}
              </Badge>
            </div>

            {/* Task Cards */}
            <div className="space-y-3 min-h-[500px]">
              {tasksByStatus[status]?.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground text-sm" data-testid={`empty-${status}`}>
                  No tasks in {config.label.toLowerCase()}
                </div>
              ) : (
                tasksByStatus[status]?.map((task) => (
                  <Card
                    key={task.id}
                    className={`cursor-move hover:shadow-md transition-shadow ${
                      draggedCard?.id === task.id ? 'opacity-50' : ''
                    }`}
                    draggable
                    onDragStart={(e) => handleDragStart(e, task)}
                    onDragEnd={handleDragEnd}
                    data-testid={`task-card-${task.id}`}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-sm font-medium truncate pr-2">
                          {task.title}
                        </CardTitle>
                        <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0">
                          <MoreHorizontal className="h-3 w-3" />
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground">{task.partNumber}</p>
                    </CardHeader>
                    
                    <CardContent className="pt-0">
                      {task.description && (
                        <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                          {task.description}
                        </p>
                      )}
                      
                      {/* Task Details */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-1">
                            {task.type === 'part' ? (
                              <Package className="h-3 w-3 text-muted-foreground" />
                            ) : (
                              <Layers className="h-3 w-3 text-muted-foreground" />
                            )}
                            <span className="text-xs capitalize">{task.type}</span>
                          </div>
                          <Badge className={`text-xs ${getPriorityColor(task.priority)}`}>
                            {task.priority}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-1">
                            <Clock className="h-3 w-3 text-muted-foreground" />
                            <span className="text-xs">{task.estimatedDays}d</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Avatar className="h-5 w-5">
                              <AvatarFallback className="text-xs">
                                {getAvatarInitials(task.assignee)}
                              </AvatarFallback>
                            </Avatar>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-primary mb-1" data-testid="text-total-tasks">
            {filteredTasks.length}
          </div>
          <div className="text-sm text-muted-foreground">Total Tasks</div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-red-600 mb-1" data-testid="text-high-priority">
            {filteredTasks.filter(t => t.priority === 'high').length}
          </div>
          <div className="text-sm text-muted-foreground">High Priority</div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-orange-600 mb-1" data-testid="text-in-progress">
            {filteredTasks.filter(t => t.status === 'progress').length}
          </div>
          <div className="text-sm text-muted-foreground">In Progress</div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-green-600 mb-1" data-testid="text-completed">
            {filteredTasks.filter(t => t.status === 'complete').length}
          </div>
          <div className="text-sm text-muted-foreground">Completed</div>
        </div>
      </div>
    </div>
  );
}