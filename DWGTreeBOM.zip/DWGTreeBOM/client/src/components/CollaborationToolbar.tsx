import { useState } from 'react';
import { Users, Wifi, WifiOff, Settings } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useCollaborationContext } from '@/contexts/CollaborationContext';
import { useToast } from '@/hooks/use-toast';

export function CollaborationToolbar() {
  const { toast } = useToast();
  const [showSettings, setShowSettings] = useState(false);
  const collaboration = useCollaborationContext();

  const users = Array.from(collaboration.users.values());
  const currentUser = collaboration.currentUser;

  return (
    <div className="flex items-center gap-2 p-2 bg-background border-b" data-testid="toolbar-collaboration">
      {/* Connection Status */}
      <div className="flex items-center gap-1" data-testid="status-connection">
        {collaboration.connected ? (
          <Wifi className="h-4 w-4 text-green-500" />
        ) : (
          <WifiOff className="h-4 w-4 text-red-500" />
        )}
        <span className="text-sm text-muted-foreground">
          {collaboration.connected ? 'Connected' : 'Disconnected'}
        </span>
      </div>

      {/* User Count */}
      <Badge variant="secondary" className="flex items-center gap-1" data-testid="badge-user-count">
        <Users className="h-3 w-3" />
        {users.length}
      </Badge>

      {/* Users List */}
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="ghost" size="sm" className="flex items-center gap-1" data-testid="button-show-users">
            <div className="flex -space-x-1">
              {users.slice(0, 3).map((user) => (
                <Avatar key={user.id} className="h-6 w-6 border-2 border-background">
                  <AvatarFallback 
                    className="text-xs"
                    style={{ backgroundColor: user.color }}
                  >
                    {user.name.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              ))}
              {users.length > 3 && (
                <div className="h-6 w-6 rounded-full bg-muted border-2 border-background flex items-center justify-center">
                  <span className="text-xs">+{users.length - 3}</span>
                </div>
              )}
            </div>
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-64" data-testid="popover-users">
          <div className="space-y-2">
            <h4 className="font-medium">Active Users</h4>
            <div className="space-y-2">
              {users.map((user) => (
                <div key={user.id} className="flex items-center gap-2" data-testid={`user-item-${user.id}`}>
                  <Avatar className="h-6 w-6">
                    <AvatarFallback 
                      className="text-xs"
                      style={{ backgroundColor: user.color }}
                    >
                      {user.name.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm flex-1">{user.name}</span>
                  {user.id === currentUser?.id && (
                    <Badge variant="outline" className="text-xs">You</Badge>
                  )}
                </div>
              ))}
            </div>
          </div>
        </PopoverContent>
      </Popover>

      {/* Settings */}
      <Popover open={showSettings} onOpenChange={setShowSettings}>
        <PopoverTrigger asChild>
          <Button variant="ghost" size="sm" data-testid="button-settings">
            <Settings className="h-4 w-4" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-64" data-testid="popover-settings">
          <div className="space-y-4">
            <h4 className="font-medium">Collaboration Settings</h4>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="locking-enabled" className="text-sm">
                Enable Locking
              </Label>
              <Switch
                id="locking-enabled"
                checked={collaboration.isLockingEnabled}
                onCheckedChange={(checked) => {
                  // This would update the locking preference
                  // For now, it's just visual
                }}
                data-testid="switch-locking"
              />
            </div>
            
            <div className="text-xs text-muted-foreground">
              <p>Session ID: main-session</p>
              <p>User ID: {currentUser?.id?.slice(0, 8)}...</p>
            </div>
          </div>
        </PopoverContent>
      </Popover>

      {/* Current User Info */}
      {currentUser && (
        <div className="flex items-center gap-2 ml-auto" data-testid="info-current-user">
          <Avatar className="h-6 w-6">
            <AvatarFallback 
              className="text-xs"
              style={{ backgroundColor: currentUser.color }}
            >
              {currentUser.name.slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <span className="text-sm">{currentUser.name}</span>
        </div>
      )}
    </div>
  );
}