import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function StatusLegend() {
  const statusItems = [
    {
      color: "bg-blue-500",
      label: "New/Planning",
    },
    {
      color: "bg-orange-500", 
      label: "In Progress",
    },
    {
      color: "bg-green-500",
      label: "Complete",
    },
    {
      color: "bg-red-500",
      label: "Issues/Review",
    },
  ];

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="text-base">Status Legend</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-4">
          {statusItems.map((item, index) => (
            <div key={index} className="flex items-center" data-testid={`legend-${item.label.toLowerCase().replace(/\s+/g, '-')}`}>
              <div className={`w-4 h-4 ${item.color} rounded mr-2`} />
              <span className="text-sm">{item.label}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
