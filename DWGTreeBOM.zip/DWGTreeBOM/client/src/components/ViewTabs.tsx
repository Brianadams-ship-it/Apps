import { Button } from "@/components/ui/button";
import { Table, Calendar, CheckSquare, GitBranch, BarChart3, FileSpreadsheet } from "lucide-react";

interface ViewTabsProps {
  activeView: "tree" | "schedule" | "task" | "process" | "analytics" | "master";
  onViewChange: (view: "tree" | "schedule" | "task" | "process" | "analytics" | "master") => void;
}

export default function ViewTabs({ activeView, onViewChange }: ViewTabsProps) {
  const tabs = [
    {
      id: "tree" as const,
      label: "Tree View",
      icon: Table,
    },
    {
      id: "schedule" as const,
      label: "Schedule View",
      icon: Calendar,
    },
    {
      id: "task" as const,
      label: "Task View", 
      icon: CheckSquare,
    },
    {
      id: "process" as const,
      label: "Process Steps",
      icon: GitBranch,
    },
    {
      id: "analytics" as const,
      label: "Analytics",
      icon: BarChart3,
    },
    {
      id: "master" as const,
      label: "Master File",
      icon: FileSpreadsheet,
    },
  ];

  return (
    <div className="bg-card border-b border-border px-6 py-3">
      <nav className="flex space-x-6">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeView === tab.id;
          
          return (
            <Button
              key={tab.id}
              variant={isActive ? "default" : "ghost"}
              size="sm"
              onClick={() => onViewChange(tab.id)}
              className={
                isActive
                  ? "text-primary-foreground bg-primary/90"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              }
              data-testid={`tab-${tab.id}`}
            >
              <Icon className="mr-2 h-4 w-4" />
              {tab.label}
            </Button>
          );
        })}
      </nav>
    </div>
  );
}
