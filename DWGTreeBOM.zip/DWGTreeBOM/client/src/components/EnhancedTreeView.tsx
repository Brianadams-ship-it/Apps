import { useState, useMemo } from "react";
import { useQuery } from '@tanstack/react-query';
import { 
  ChevronDown, ChevronRight, Box, Layers, FileText, 
  ArrowLeftFromLine, Import, ExternalLink, Eye, Download 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import type { Assembly, Part, DwgFile } from "@shared/schema";

interface EnhancedTreeViewProps {
  assemblies: Assembly[];
  parts: Part[];
  isLoading: boolean;
}

interface TreeNode {
  id: string;
  name: string;
  type: "dwg" | "assembly" | "part";
  level: number;
  isExpanded: boolean;
  children: TreeNode[];
  partCount?: number;
  status?: string;
  partNumber?: string;
  filePath?: string;
  parseStatus?: string;
  fileSize?: number | null;
}

export default function EnhancedTreeView({ assemblies, parts, isLoading }: EnhancedTreeViewProps) {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
  const { toast } = useToast();

  // Fetch DWG files
  const { data: dwgFiles = [], isLoading: dwgLoading } = useQuery<DwgFile[]>({
    queryKey: ["/api/dwg-files"],
  });

  const buildTreeStructure = (): TreeNode[] => {
    const assemblyMap = new Map<string, Assembly>();
    const partsMap = new Map<string, Part[]>();

    // Create maps for quick lookup
    assemblies.forEach(assembly => {
      assemblyMap.set(assembly.id, assembly);
    });

    // Group parts by assembly
    parts.forEach(part => {
      if (part.assemblyId) {
        if (!partsMap.has(part.assemblyId)) {
          partsMap.set(part.assemblyId, []);
        }
        partsMap.get(part.assemblyId)!.push(part);
      }
    });

    const buildAssemblyNode = (assembly: Assembly): TreeNode => {
      const assemblyParts = partsMap.get(assembly.id) || [];
      const childAssemblies = assemblies.filter(a => a.parentId === assembly.id);
      
      const children: TreeNode[] = [
        ...childAssemblies.map(buildAssemblyNode),
        ...assemblyParts.map(part => ({
          id: part.id,
          name: part.name,
          type: "part" as const,
          level: assembly.level + 1,
          isExpanded: false,
          children: [],
          status: part.status,
          partNumber: part.partNumber,
        }))
      ];

      const totalParts = assemblyParts.length + 
        childAssemblies.reduce((sum, child) => sum + (partsMap.get(child.id)?.length || 0), 0);

      return {
        id: assembly.id,
        name: assembly.name,
        type: "assembly",
        level: assembly.level,
        isExpanded: false, // Will be managed by expandedNodes state
        children,
        partCount: totalParts,
        status: assembly.status,
      };
    };

    // Create DWG file nodes at the top level
    const dwgNodes: TreeNode[] = dwgFiles.map(dwg => ({
      id: dwg.id,
      name: dwg.filename,
      type: "dwg",
      level: 0,
      isExpanded: false, // Will be managed by expandedNodes state
      children: [],
      status: dwg.parseStatus,
      filePath: dwg.filePath,
      parseStatus: dwg.parseStatus,
      fileSize: dwg.fileSize,
    }));

    // Get root assemblies (no parent) and build their trees
    const assemblyNodes = assemblies
      .filter(assembly => !assembly.parentId)
      .map(buildAssemblyNode);

    // Return DWG files first, then assemblies
    return [...dwgNodes, ...assemblyNodes];
  };

  const toggleNode = (nodeId: string) => {
    setExpandedNodes(prev => {
      const newSet = new Set(prev);
      if (newSet.has(nodeId)) {
        newSet.delete(nodeId);
      } else {
        newSet.add(nodeId);
      }
      return newSet;
    });
  };

  const expandAll = () => {
    const allNodeIds = [
      ...dwgFiles.map(d => d.id),
      ...assemblies.map(a => a.id)
    ];
    setExpandedNodes(new Set(allNodeIds));
  };

  const collapseAll = () => {
    setExpandedNodes(new Set());
  };

  const handleDwgClick = async (dwgFile: TreeNode) => {
    if (!dwgFile.filePath) {
      toast({
        title: "File not available",
        description: "File path not found for this DWG file.",
        variant: "destructive",
      });
      return;
    }

    try {
      // First check if the file exists by making a HEAD request
      const fileUrl = `/objects${dwgFile.filePath}`;
      const checkResponse = await fetch(fileUrl, { method: 'HEAD' });
      
      if (checkResponse.ok) {
        // File exists, open it in a new tab
        window.open(fileUrl, '_blank');
        toast({
          title: "Opening file",
          description: `Opening ${dwgFile.name} in a new tab.`,
        });
      } else {
        // File doesn't exist in storage
        toast({
          title: "File not found",
          description: `${dwgFile.name} is not available in storage. The file may have been uploaded but not stored properly.`,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error accessing DWG file:", error);
      
      // Provide more specific error information
      if (dwgFile.parseStatus === 'failed') {
        toast({
          title: "File processing failed",
          description: `${dwgFile.name} failed to process correctly and may not be viewable.`,
          variant: "destructive",
        });
      } else if (dwgFile.parseStatus === 'pending' || dwgFile.parseStatus === 'processing') {
        toast({
          title: "File still processing",
          description: `${dwgFile.name} is still being processed. Please try again in a moment.`,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Unable to open file",
          description: `Cannot access ${dwgFile.name}. Please check if the file was uploaded correctly.`,
          variant: "destructive",
        });
      }
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new": return "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300";
      case "progress": return "bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300";
      case "complete": 
      case "completed": return "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300";
      case "issue": 
      case "failed": return "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300";
      case "processing": return "bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300";
      case "pending": return "bg-gray-100 text-gray-700 dark:bg-gray-900 dark:text-gray-300";
      default: return "bg-secondary text-secondary-foreground";
    }
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return "";
    const mb = bytes / (1024 * 1024);
    return mb > 1 ? `${mb.toFixed(1)} MB` : `${(bytes / 1024).toFixed(1)} KB`;
  };

  const renderTreeNode = (node: TreeNode): React.ReactNode => {
    const isExpanded = expandedNodes.has(node.id);
    const hasChildren = node.children.length > 0;
    const indent = `${node.level * 24}px`;

    if (node.type === "dwg") {
      const isViewable = node.parseStatus === 'completed' && node.filePath;
      
      return (
        <div key={node.id} className="border-b border-border/50">
          <div 
            className={`flex items-center p-3 hover:bg-secondary/50 group ${
              isViewable ? 'cursor-pointer' : 'cursor-default'
            }`}
            style={{ paddingLeft: `calc(12px + ${indent})` }}
            onClick={() => isViewable && handleDwgClick(node)}
            data-testid={`dwg-file-${node.id}`}
          >
            <FileText className="mr-3 h-4 w-4 text-blue-500 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2">
                <span className="font-medium text-sm truncate">{node.name}</span>
                {isViewable && (
                  <ExternalLink className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                )}
              </div>
              <div className="flex items-center space-x-2 mt-1">
                <Badge 
                  variant="secondary" 
                  className={`text-xs ${getStatusColor(node.parseStatus || 'unknown')}`}
                  data-testid={`badge-status-${node.parseStatus}`}
                >
                  {node.parseStatus || 'unknown'}
                </Badge>
                {node.fileSize && (
                  <span className="text-xs text-muted-foreground">
                    {formatFileSize(node.fileSize)}
                  </span>
                )}
              </div>
            </div>
            {isViewable && (
              <Button
                variant="ghost"
                size="sm"
                className="opacity-0 group-hover:opacity-100 ml-2"
                onClick={(e) => {
                  e.stopPropagation();
                  handleDwgClick(node);
                }}
                data-testid={`button-view-dwg-${node.id}`}
              >
                <Eye className="h-4 w-4" />
              </Button>
            )}
            {!isViewable && node.parseStatus === 'failed' && (
              <span className="text-xs text-red-500 ml-2">Unable to view</span>
            )}
            {!isViewable && (node.parseStatus === 'pending' || node.parseStatus === 'processing') && (
              <span className="text-xs text-yellow-600 ml-2">Processing...</span>
            )}
          </div>
        </div>
      );
    }

    if (node.type === "assembly") {
      return (
        <div key={node.id}>
          <div 
            className="flex items-center p-2 hover:bg-secondary/50 cursor-pointer"
            style={{ paddingLeft: `calc(12px + ${indent})` }}
            onClick={() => hasChildren && toggleNode(node.id)}
            data-testid={`assembly-${node.id}`}
          >
            {hasChildren ? (
              <Button variant="ghost" size="sm" className="w-4 h-4 p-0 mr-2">
                {isExpanded ? (
                  <ChevronDown className="h-3 w-3" />
                ) : (
                  <ChevronRight className="h-3 w-3" />
                )}
              </Button>
            ) : (
              <div className="w-6 h-4 mr-2" />
            )}
            
            <Layers className="mr-2 h-4 w-4 text-purple-500 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2">
                <span className="font-medium text-sm truncate">{node.name}</span>
                {node.partCount !== undefined && node.partCount > 0 && (
                  <Badge variant="outline" className="text-xs">
                    {node.partCount} parts
                  </Badge>
                )}
              </div>
              {node.status && (
                <Badge 
                  variant="secondary" 
                  className={`text-xs mt-1 ${getStatusColor(node.status)}`}
                >
                  {node.status}
                </Badge>
              )}
            </div>
          </div>
          
          {isExpanded && hasChildren && (
            <div>
              {node.children.map(renderTreeNode)}
            </div>
          )}
        </div>
      );
    }

    // Part node
    return (
      <div key={node.id}>
        <div 
          className="flex items-center p-2 hover:bg-secondary/50"
          style={{ paddingLeft: `calc(12px + ${indent})` }}
          data-testid={`part-${node.id}`}
        >
          <div className="w-6 h-4 mr-2" />
          <Box className="mr-2 h-4 w-4 text-green-500 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-2">
              <span className="text-sm truncate">{node.name}</span>
              {node.partNumber && (
                <span className="text-xs text-muted-foreground truncate">
                  #{node.partNumber}
                </span>
              )}
            </div>
            {node.status && (
              <Badge 
                variant="secondary" 
                className={`text-xs mt-1 ${getStatusColor(node.status)}`}
              >
                {node.status}
              </Badge>
            )}
          </div>
        </div>
      </div>
    );
  };

  const treeData = useMemo(() => buildTreeStructure(), [assemblies, parts, dwgFiles]);

  if (isLoading || dwgLoading) {
    return (
      <div className="space-y-2 p-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-semibold">BOM Tree</h3>
        </div>
        {[...Array(6)].map((_, i) => (
          <Skeleton key={i} className="h-12 w-full" />
        ))}
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col" data-testid="enhanced-tree-view">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-semibold">BOM Tree</h3>
          <div className="flex space-x-1">
            <Button variant="ghost" size="sm" onClick={expandAll} data-testid="button-expand-all">
              <Import className="h-3 w-3 mr-1" />
              Expand
            </Button>
            <Button variant="ghost" size="sm" onClick={collapseAll} data-testid="button-collapse-all">
              <ArrowLeftFromLine className="h-3 w-3 mr-1" />
              Collapse
            </Button>
          </div>
        </div>
        
        {/* Summary */}
        <div className="flex space-x-4 text-xs text-muted-foreground">
          <span>{dwgFiles.length} files</span>
          <span>{assemblies.length} assemblies</span>
          <span>{parts.length} parts</span>
        </div>
      </div>

      {/* Tree Content */}
      <div className="flex-1 overflow-y-auto">
        {treeData.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground" data-testid="text-no-data">
            <FileText className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>No files or assemblies found.</p>
            <p className="text-xs mt-1">Upload a DWG file to get started.</p>
          </div>
        ) : (
          <div className="pb-4">
            {treeData.map(renderTreeNode)}
          </div>
        )}
      </div>
    </div>
  );
}