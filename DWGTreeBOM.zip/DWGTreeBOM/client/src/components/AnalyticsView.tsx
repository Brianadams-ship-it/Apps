import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Area, AreaChart
} from 'recharts';
import { 
  TrendingUp, TrendingDown, Users, Clock, FileText, 
  CheckCircle, AlertTriangle, Package, DollarSign,
  Calendar, Target, Activity, Layers
} from 'lucide-react';
import type { Assembly, Part, DwgFile, ProcessStep, WorkflowAssignment } from '@shared/schema';

interface AnalyticsViewProps {
  assemblies: Assembly[];
  parts: Part[];
}

interface MetricCardProps {
  title: string;
  value: string | number;
  change?: string;
  trend?: 'up' | 'down' | 'neutral';
  icon: React.ReactNode;
  color?: string;
}

function MetricCard({ title, value, change, trend, icon, color = 'text-primary' }: MetricCardProps) {
  const trendIcon = trend === 'up' ? <TrendingUp className="h-4 w-4 text-green-500" /> :
                   trend === 'down' ? <TrendingDown className="h-4 w-4 text-red-500" /> : null;

  return (
    <Card data-testid={`metric-card-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className={color}>{icon}</div>
            <div>
              <p className="text-sm text-muted-foreground">{title}</p>
              <p className="text-2xl font-bold">{value}</p>
              {change && (
                <div className="flex items-center space-x-1 mt-1">
                  {trendIcon}
                  <span className="text-xs text-muted-foreground">{change}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export function AnalyticsView({ assemblies, parts }: AnalyticsViewProps) {
  const [selectedTimeRange, setSelectedTimeRange] = useState<'7d' | '30d' | '90d' | 'all'>('30d');

  // Fetch additional data for analytics
  const { data: dwgFiles } = useQuery<DwgFile[]>({ queryKey: ['/api/dwg-files'] });
  const { data: processSteps } = useQuery<ProcessStep[]>({ queryKey: ['/api/process-steps'] });
  const { data: workflowAssignments } = useQuery<WorkflowAssignment[]>({ queryKey: ['/api/workflow-assignments'] });

  // Calculate analytics data
  const analytics = useMemo(() => {
    // Status distribution
    const statusDistribution = {
      parts: [
        { name: 'New', value: parts.filter(p => p.status === 'new').length, color: '#0088FE' },
        { name: 'In Progress', value: parts.filter(p => p.status === 'progress').length, color: '#00C49F' },
        { name: 'Complete', value: parts.filter(p => p.status === 'complete').length, color: '#FFBB28' },
        { name: 'Issues', value: parts.filter(p => p.status === 'issue').length, color: '#FF8042' },
      ],
      assemblies: [
        { name: 'New', value: assemblies.filter(a => a.status === 'new').length, color: '#0088FE' },
        { name: 'In Progress', value: assemblies.filter(a => a.status === 'progress').length, color: '#00C49F' },
        { name: 'Complete', value: assemblies.filter(a => a.status === 'complete').length, color: '#FFBB28' },
        { name: 'Issues', value: assemblies.filter(a => a.status === 'issue').length, color: '#FF8042' },
      ]
    };

    // Assembly complexity analysis
    const complexityData = assemblies.map(assembly => {
      const assemblyParts = parts.filter(p => p.assemblyId === assembly.id);
      const totalQuantity = assemblyParts.reduce((sum, part) => sum + part.quantity, 0);
      const uniqueParts = assemblyParts.length;
      
      return {
        name: assembly.name.length > 15 ? assembly.name.substring(0, 15) + '...' : assembly.name,
        parts: uniqueParts,
        quantity: totalQuantity,
        level: assembly.level,
        status: assembly.status
      };
    }).sort((a, b) => b.parts - a.parts).slice(0, 10);

    // Part quantity distribution
    const quantityDistribution = parts.reduce((acc, part) => {
      const range = part.quantity <= 5 ? '1-5' :
                    part.quantity <= 10 ? '6-10' :
                    part.quantity <= 25 ? '11-25' :
                    part.quantity <= 50 ? '26-50' : '50+';
      acc[range] = (acc[range] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const quantityChart = Object.entries(quantityDistribution).map(([range, count]) => ({
      range,
      count
    }));

    // Timeline analysis (creation dates)
    const timelineData = parts.reduce((acc, part) => {
      if (part.createdAt) {
        const date = new Date(part.createdAt).toISOString().split('T')[0];
        acc[date] = (acc[date] || 0) + 1;
      }
      return acc;
    }, {} as Record<string, number>);

    const timeline = Object.entries(timelineData)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-30) // Last 30 days
      .map(([date, count]) => ({
        date: new Date(date).toLocaleDateString(),
        parts: count,
        assemblies: 0 // Could be extended to include assemblies
      }));

    // Cost estimation (using part quantities as proxy)
    const totalParts = parts.reduce((sum, part) => sum + part.quantity, 0);
    const avgCostPerPart = 25; // Placeholder - could be extracted from metadata
    const estimatedCost = totalParts * avgCostPerPart;

    // Progress metrics
    const completedParts = parts.filter(p => p.status === 'complete').length;
    const completedAssemblies = assemblies.filter(a => a.status === 'complete').length;
    const progressPercentage = parts.length > 0 ? Math.round((completedParts / parts.length) * 100) : 0;

    // File processing analytics
    const fileStats = dwgFiles ? {
      total: dwgFiles.length,
      completed: dwgFiles.filter(f => f.parseStatus === 'completed').length,
      failed: dwgFiles.filter(f => f.parseStatus === 'failed').length,
      processing: dwgFiles.filter(f => f.parseStatus === 'processing').length,
      totalSize: dwgFiles.reduce((sum, f) => sum + (f.fileSize || 0), 0)
    } : { total: 0, completed: 0, failed: 0, processing: 0, totalSize: 0 };

    return {
      statusDistribution,
      complexityData,
      quantityChart,
      timeline,
      estimatedCost,
      progressPercentage,
      totalParts,
      completedParts,
      completedAssemblies,
      fileStats
    };
  }, [assemblies, parts, dwgFiles]);

  return (
    <div className="p-6 space-y-6" data-testid="analytics-view">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Total Parts"
          value={analytics.totalParts}
          change="+12% this month"
          trend="up"
          icon={<Package className="h-5 w-5" />}
          color="text-blue-500"
        />
        <MetricCard
          title="Completed Parts"
          value={analytics.completedParts}
          change={`${analytics.progressPercentage}% complete`}
          trend="up"
          icon={<CheckCircle className="h-5 w-5" />}
          color="text-green-500"
        />
        <MetricCard
          title="Assemblies"
          value={assemblies.length}
          change={`${analytics.completedAssemblies} completed`}
          trend="neutral"
          icon={<Layers className="h-5 w-5" />}
          color="text-purple-500"
        />
        <MetricCard
          title="Estimated Cost"
          value={`$${analytics.estimatedCost.toLocaleString()}`}
          change="Based on quantities"
          trend="neutral"
          icon={<DollarSign className="h-5 w-5" />}
          color="text-orange-500"
        />
      </div>

      <Tabs defaultValue="overview" className="space-y-4" data-testid="analytics-tabs">
        <TabsList>
          <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
          <TabsTrigger value="progress" data-testid="tab-progress">Progress</TabsTrigger>
          <TabsTrigger value="complexity" data-testid="tab-complexity">Complexity</TabsTrigger>
          <TabsTrigger value="files" data-testid="tab-files">Files</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Status Distribution */}
            <Card data-testid="card-status-distribution">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="h-5 w-5 mr-2" />
                  Status Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-medium mb-2">Parts</h4>
                    <ResponsiveContainer width="100%" height={200}>
                      <PieChart>
                        <Pie
                          data={analytics.statusDistribution.parts}
                          cx="50%"
                          cy="50%"
                          innerRadius={40}
                          outerRadius={80}
                          dataKey="value"
                        >
                          {analytics.statusDistribution.parts.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div>
                    <h4 className="text-sm font-medium mb-2">Assemblies</h4>
                    <ResponsiveContainer width="100%" height={200}>
                      <PieChart>
                        <Pie
                          data={analytics.statusDistribution.assemblies}
                          cx="50%"
                          cy="50%"
                          innerRadius={40}
                          outerRadius={80}
                          dataKey="value"
                        >
                          {analytics.statusDistribution.assemblies.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Timeline */}
            <Card data-testid="card-timeline">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  Activity Timeline
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={analytics.timeline}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="parts" stackId="1" stroke="#8884d8" fill="#8884d8" />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="progress" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Progress Overview */}
            <Card data-testid="card-progress-overview">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="h-5 w-5 mr-2" />
                  Project Progress
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Overall Completion</span>
                    <span>{analytics.progressPercentage}%</span>
                  </div>
                  <Progress value={analytics.progressPercentage} className="h-2" />
                </div>
                
                <div className="grid grid-cols-2 gap-4 pt-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-500">{analytics.completedParts}</div>
                    <div className="text-sm text-muted-foreground">Parts Complete</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-500">{analytics.completedAssemblies}</div>
                    <div className="text-sm text-muted-foreground">Assemblies Complete</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quantity Distribution */}
            <Card data-testid="card-quantity-distribution">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Package className="h-5 w-5 mr-2" />
                  Quantity Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={analytics.quantityChart}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="range" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="complexity" className="space-y-4">
          <Card data-testid="card-assembly-complexity">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Layers className="h-5 w-5 mr-2" />
                Assembly Complexity Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={analytics.complexityData} layout="horizontal">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="name" type="category" width={120} />
                  <Tooltip />
                  <Bar dataKey="parts" fill="#8884d8" name="Unique Parts" />
                  <Bar dataKey="quantity" fill="#82ca9d" name="Total Quantity" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="files" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card data-testid="card-file-processing">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="h-5 w-5 mr-2" />
                  File Processing Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{analytics.fileStats.total}</div>
                    <div className="text-sm text-muted-foreground">Total Files</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-500">{analytics.fileStats.completed}</div>
                    <div className="text-sm text-muted-foreground">Processed</div>
                  </div>
                </div>
                
                {analytics.fileStats.failed > 0 && (
                  <div className="flex items-center justify-between p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <AlertTriangle className="h-5 w-5 text-red-500" />
                      <span className="text-sm">Processing Failures</span>
                    </div>
                    <Badge variant="destructive">{analytics.fileStats.failed}</Badge>
                  </div>
                )}
                
                <div className="text-center pt-2">
                  <div className="text-sm text-muted-foreground">Total Size</div>
                  <div className="text-lg font-semibold">
                    {(analytics.fileStats.totalSize / (1024 * 1024)).toFixed(1)} MB
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card data-testid="card-insights">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  Key Insights
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <div className="text-sm font-medium">Most Complex Assembly</div>
                  <div className="text-xs text-muted-foreground">
                    {analytics.complexityData[0]?.name || 'No data'} with {analytics.complexityData[0]?.parts || 0} unique parts
                  </div>
                </div>
                
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <div className="text-sm font-medium">Progress Rate</div>
                  <div className="text-xs text-muted-foreground">
                    {analytics.progressPercentage}% of parts completed
                  </div>
                </div>
                
                <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                  <div className="text-sm font-medium">Cost Estimate</div>
                  <div className="text-xs text-muted-foreground">
                    ${analytics.estimatedCost.toLocaleString()} based on {analytics.totalParts} parts
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}