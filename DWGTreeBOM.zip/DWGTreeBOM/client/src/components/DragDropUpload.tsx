import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { CloudUpload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ObjectUploader } from "./ObjectUploader";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { UploadResult } from "@uppy/core";

export default function DragDropUpload() {
  const [isDragOver, setIsDragOver] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createDwgFileMutation = useMutation({
    mutationFn: async (data: { filename: string; filePath: string; fileSize: number }) => {
      const response = await apiRequest("POST", "/api/dwg-files", data);
      return response.json();
    },
    onSuccess: async (dwgFile) => {
      queryClient.invalidateQueries({ queryKey: ["/api/dwg-files"] });
      
      toast({
        title: "File uploaded",
        description: "Processing DWG file to generate BOM...",
      });
      
      // Automatically trigger processing of the uploaded file
      try {
        const processResponse = await apiRequest("POST", `/api/dwg-files/${dwgFile.id}/process`, {});
        const processResult = await processResponse.json();
        
        // Invalidate assemblies and parts to refresh the UI
        queryClient.invalidateQueries({ queryKey: ["/api/assemblies"] });
        queryClient.invalidateQueries({ queryKey: ["/api/parts"] });
        
        toast({
          title: "File processed successfully",
          description: `Generated ${processResult.assemblies?.length || 0} assemblies and ${processResult.parts?.length || 0} parts from your DWG file.`,
        });
      } catch (processError) {
        console.error("Error processing DWG file:", processError);
        toast({
          title: "Processing failed",
          description: "File uploaded but failed to generate BOM. Please try again.",
          variant: "destructive",
        });
      }
    },
    onError: (error) => {
      console.error("Error creating DWG file record:", error);
      toast({
        title: "Upload failed",
        description: "Failed to save file information. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    // Handle files dropped directly on the dropzone
    acceptedFiles.forEach((file) => {
      if (file.type === "application/pdf" || file.name.toLowerCase().endsWith('.pdf')) {
        console.log("PDF file dropped:", file.name);
        // The actual upload will be handled by ObjectUploader
      } else {
        toast({
          title: "Invalid file type",
          description: "Please upload PDF files only.",
          variant: "destructive",
        });
      }
    });
  }, [toast]);

  const { getRootProps, getInputProps } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf']
    },
    onDragEnter: () => setIsDragOver(true),
    onDragLeave: () => setIsDragOver(false),
    onDropAccepted: () => setIsDragOver(false),
    onDropRejected: () => setIsDragOver(false),
  });

  const handleGetUploadParameters = async () => {
    const response = await fetch("/api/objects/upload", {
      method: "POST",
      credentials: "include",
    });
    
    if (!response.ok) {
      throw new Error("Failed to get upload URL");
    }
    
    const { uploadURL } = await response.json();
    return {
      method: "PUT" as const,
      url: uploadURL,
    };
  };

  const handleUploadComplete = (result: UploadResult<Record<string, unknown>, Record<string, unknown>>) => {
    if (result.successful && result.successful.length > 0) {
      const file = result.successful[0];
      const uploadURL = file.uploadURL as string;
      
      // Extract file info and create DWG file record
      createDwgFileMutation.mutate({
        filename: file.name || "unknown.pdf",
        filePath: uploadURL,
        fileSize: file.size || 0,
      });
    }
  };

  return (
    <div className="mb-4">
      <div
        {...getRootProps()}
        className={`drag-drop-area rounded-lg p-6 text-center mb-4 border-2 border-dashed transition-all duration-300 cursor-pointer ${
          isDragOver 
            ? "border-primary bg-primary/5" 
            : "border-border hover:border-primary hover:bg-primary/5"
        }`}
        data-testid="dropzone-dwg-upload"
      >
        <input {...getInputProps()} />
        <CloudUpload className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
        <p className="text-sm text-muted-foreground mb-2">
          Drag & drop PDF DWG files here to auto-generate BOM
        </p>
        <ObjectUploader
          maxNumberOfFiles={5}
          maxFileSize={50 * 1024 * 1024} // 50MB
          onGetUploadParameters={handleGetUploadParameters}
          onComplete={handleUploadComplete}
          buttonClassName="text-primary text-sm hover:underline bg-transparent border-none p-0 h-auto"
        >
          or browse files
        </ObjectUploader>
      </div>
    </div>
  );
}
