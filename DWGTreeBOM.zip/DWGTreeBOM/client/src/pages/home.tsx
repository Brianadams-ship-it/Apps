import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download, Settings, Compass } from "lucide-react";
import DragDropUpload from "@/components/DragDropUpload";
import TreeView from "@/components/TreeView";
import EnhancedTreeView from "@/components/EnhancedTreeView";
import { ResizableSidebar } from "@/components/ResizableSidebar";
import ScheduleView from "@/components/ScheduleView";
import TaskView from "@/components/TaskView";
import { ProcessStepsView } from "@/components/ProcessStepsView";
import { AnalyticsView } from "@/components/AnalyticsView";
import ViewTabs from "@/components/ViewTabs";
import StatusLegend from "@/components/StatusLegend";
import PartCard from "@/components/PartCard";
import { CollaborationToolbar } from "@/components/CollaborationToolbar";
import { CollaborativePartCard } from "@/components/CollaborativePartCard";
import { CollaborationProvider } from "@/contexts/CollaborationContext";
import MasterFileManager from "@/components/MasterFileManager";
import type { Assembly, Part, BomTemplate } from "@shared/schema";

export default function Home() {
  const [activeView, setActiveView] = useState<"tree" | "schedule" | "task" | "process" | "analytics" | "master">("tree");
  const [selectedTemplate, setSelectedTemplate] = useState<string>("");

  const { data: assemblies = [], isLoading: assembliesLoading } = useQuery<Assembly[]>({
    queryKey: ["/api/assemblies"],
  });

  const { data: parts = [], isLoading: partsLoading } = useQuery<Part[]>({
    queryKey: ["/api/parts"],
  });

  const { data: templates = [] } = useQuery<BomTemplate[]>({
    queryKey: ["/api/bom-templates"],
  });

  const handleExportBOM = async () => {
    try {
      const response = await fetch("/api/export/bom");
      if (!response.ok) throw new Error("Export failed");
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'bom-export.json';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error("Error exporting BOM:", error);
    }
  };

  const getStatusCounts = () => {
    const counts = parts.reduce((acc, part) => {
      acc[part.status] = (acc[part.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      total: parts.length,
      new: counts.new || 0,
      progress: counts.progress || 0,
      complete: counts.complete || 0,
      issue: counts.issue || 0,
    };
  };

  const statusCounts = getStatusCounts();

  return (
    <CollaborationProvider sessionId="main-session" userName="Current User">
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-2xl font-bold text-primary flex items-center">
              <Compass className="mr-2 h-6 w-6" />
              DWG BOM Generator
            </h1>
            <span className="text-sm text-muted-foreground bg-secondary px-2 py-1 rounded">
              Engineering Parts Management
            </span>
          </div>
          <div className="flex items-center space-x-4">
            <Button 
              onClick={handleExportBOM} 
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              data-testid="button-export-bom"
            >
              <Download className="mr-2 h-4 w-4" />
              Export BOM
            </Button>
            <Button variant="secondary" size="icon" data-testid="button-settings">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Collaboration Toolbar */}
      <CollaborationToolbar />

      <div className="flex h-[calc(100vh-115px)]">
        {/* Resizable Sidebar */}
        <ResizableSidebar defaultWidth={400} minWidth={300} maxWidth={600}>
          {/* File Upload Section */}
          <div className="p-6 border-b border-border">
            <h3 className="font-semibold mb-4">Upload DWG Files</h3>
            <DragDropUpload />
            
            {/* Template Selection */}
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">Or select template:</label>
              <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                <SelectTrigger className="w-full" data-testid="select-template">
                  <SelectValue placeholder="Choose a template" />
                </SelectTrigger>
                <SelectContent>
                  {templates.map((template) => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
          </div>

          {/* Enhanced Tree View */}
          <div className="flex-1 overflow-hidden">
            <EnhancedTreeView 
              assemblies={assemblies} 
              parts={parts} 
              isLoading={assembliesLoading || partsLoading} 
            />
          </div>
        </ResizableSidebar>

        {/* Main Content */}
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* View Tabs */}
          <ViewTabs activeView={activeView} onViewChange={setActiveView} />

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto p-6">
            <div className="max-w-7xl mx-auto">
              {activeView === "tree" && (
                <>
                  {/* View Header */}
                  <div className="mb-6">
                    <h2 className="text-xl font-semibold mb-2">Assembly Tree View</h2>
                    <p className="text-muted-foreground">
                      Hierarchical view of all assemblies and parts with expandable structure
                    </p>
                  </div>

                  {/* Status Legend */}
                  <StatusLegend />

                  {/* Parts Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {parts.map((part) => (
                      <PartCard key={part.id} part={part} />
                    ))}
                    {parts.length === 0 && !partsLoading && (
                      <div className="col-span-full text-center py-12 text-muted-foreground" data-testid="text-no-parts">
                        No parts found. Upload a DWG file or select a template to get started.
                      </div>
                    )}
                  </div>

                  {/* Statistics Panel */}
                  <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-card border border-border rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-primary mb-1" data-testid="text-total-parts">
                        {statusCounts.total}
                      </div>
                      <div className="text-sm text-muted-foreground">Total Parts</div>
                    </div>
                    <div className="bg-card border border-border rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-blue-600 mb-1" data-testid="text-planning-parts">
                        {statusCounts.new}
                      </div>
                      <div className="text-sm text-muted-foreground">Planning</div>
                    </div>
                    <div className="bg-card border border-border rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-orange-600 mb-1" data-testid="text-progress-parts">
                        {statusCounts.progress}
                      </div>
                      <div className="text-sm text-muted-foreground">In Progress</div>
                    </div>
                    <div className="bg-card border border-border rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-green-600 mb-1" data-testid="text-complete-parts">
                        {statusCounts.complete}
                      </div>
                      <div className="text-sm text-muted-foreground">Complete</div>
                    </div>
                  </div>
                </>
              )}

              {activeView === "schedule" && (
                <ScheduleView 
                  parts={parts} 
                  assemblies={assemblies} 
                  isLoading={partsLoading || assembliesLoading} 
                />
              )}

              {activeView === "task" && (
                <TaskView 
                  parts={parts} 
                  assemblies={assemblies} 
                  isLoading={partsLoading || assembliesLoading} 
                />
              )}

              {activeView === "process" && (
                <ProcessStepsView parts={parts} assemblies={assemblies} />
              )}
              {activeView === "analytics" && (
                <AnalyticsView assemblies={assemblies} parts={parts} />
              )}

              {activeView === "master" && (
                <MasterFileManager />
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
    </CollaborationProvider>
  );
}
