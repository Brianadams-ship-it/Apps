import * as pdfjsLib from "pdfjs-dist";
import { generateThumbnail } from "./thumbnailGenerator";

// Set up PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

interface ParsedData {
  assemblies: Array<{
    name: string;
    level: number;
    parentId?: string;
  }>;
  parts: Array<{
    name: string;
    partNumber: string;
    quantity: number;
    assemblyName?: string;
  }>;
}

export async function parsePdfDwg(file: File): Promise<ParsedData> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    
    const assemblies: ParsedData['assemblies'] = [];
    const parts: ParsedData['parts'] = [];
    
    // Parse each page
    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
      const page = await pdf.getPage(pageNum);
      const textContent = await page.getTextContent();
      
      // Extract text from the page
      const pageText = textContent.items
        .map((item: any) => item.str)
        .join(' ');
      
      // Generate thumbnail for this page
      const thumbnail = await generateThumbnail(page);
      
      // Parse assemblies and parts from text content
      const pageData = parseTextContent(pageText);
      
      // Add page-specific data
      assemblies.push(...pageData.assemblies);
      parts.push(...pageData.parts);
    }
    
    // If no structured data found, create a default structure
    if (assemblies.length === 0 && parts.length === 0) {
      return createDefaultStructure(file.name);
    }
    
    return { assemblies, parts };
  } catch (error) {
    console.error("Error parsing PDF:", error);
    // Fallback to default structure if parsing fails
    return createDefaultStructure(file.name);
  }
}

function parseTextContent(text: string): ParsedData {
  const assemblies: ParsedData['assemblies'] = [];
  const parts: ParsedData['parts'] = [];
  
  // Simple patterns to identify parts and assemblies
  const partNumberPattern = /([A-Z]{2,4}-\d{3,6})/g;
  const assemblyPattern = /(assembly|assy|sub-assembly|subassembly)/gi;
  
  // Split text into lines
  const lines = text.split(/[\n\r]+/).filter(line => line.trim().length > 0);
  
  let currentAssembly = "Main Assembly";
  
  lines.forEach((line, index) => {
    const trimmedLine = line.trim();
    
    // Check if this line indicates an assembly
    if (assemblyPattern.test(trimmedLine)) {
      const assemblyName = trimmedLine.replace(/\s+(assembly|assy|sub-assembly|subassembly).*$/gi, '').trim();
      if (assemblyName) {
        assemblies.push({
          name: assemblyName,
          level: trimmedLine.toLowerCase().includes('sub') ? 1 : 0,
        });
        currentAssembly = assemblyName;
      }
    }
    
    // Look for part numbers
    const partNumbers = trimmedLine.match(partNumberPattern);
    if (partNumbers) {
      partNumbers.forEach(partNumber => {
        // Extract part name (text before the part number)
        const partNameMatch = trimmedLine.split(partNumber)[0].trim();
        const partName = partNameMatch || `Part ${partNumber}`;
        
        // Extract quantity if present
        const quantityMatch = trimmedLine.match(/qty\s*:?\s*(\d+)|quantity\s*:?\s*(\d+)|(\d+)\s*pc|(\d+)\s*ea/i);
        const quantity = quantityMatch ? parseInt(quantityMatch[1] || quantityMatch[2] || quantityMatch[3] || quantityMatch[4]) : 1;
        
        parts.push({
          name: partName,
          partNumber,
          quantity,
          assemblyName: currentAssembly,
        });
      });
    }
  });
  
  return { assemblies, parts };
}

function createDefaultStructure(filename: string): ParsedData {
  const baseName = filename.replace(/\.[^/.]+$/, ""); // Remove extension
  
  return {
    assemblies: [
      {
        name: `${baseName} Assembly`,
        level: 0,
      },
      {
        name: "Housing Assembly",
        level: 1,
      },
      {
        name: "Motor Assembly", 
        level: 1,
      }
    ],
    parts: [
      {
        name: "Housing Cover",
        partNumber: "HSG-001",
        quantity: 1,
        assemblyName: "Housing Assembly",
      },
      {
        name: "Housing Base",
        partNumber: "HSG-002", 
        quantity: 1,
        assemblyName: "Housing Assembly",
      },
      {
        name: "Motor Unit",
        partNumber: "MTR-001",
        quantity: 1,
        assemblyName: "Motor Assembly",
      },
      {
        name: "Motor Shaft",
        partNumber: "MTR-002",
        quantity: 1,
        assemblyName: "Motor Assembly",
      },
      {
        name: "Mounting Bolts",
        partNumber: "HW-M8x20",
        quantity: 8,
        assemblyName: `${baseName} Assembly`,
      }
    ]
  };
}
