import type { PDFPageProxy } from "pdfjs-dist";

export async function generateThumbnail(page: PDFPageProxy, size: number = 100): Promise<string> {
  try {
    // Create canvas
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    
    if (!context) {
      throw new Error('Failed to get canvas context');
    }
    
    // Set canvas size
    const viewport = page.getViewport({ scale: 1 });
    const scale = size / Math.max(viewport.width, viewport.height);
    const scaledViewport = page.getViewport({ scale });
    
    canvas.width = scaledViewport.width;
    canvas.height = scaledViewport.height;
    
    // Render page to canvas
    const renderContext = {
      canvasContext: context,
      viewport: scaledViewport,
      canvas: canvas,
    };
    
    await page.render(renderContext).promise;
    
    // Convert canvas to data URL
    return canvas.toDataURL('image/png');
  } catch (error) {
    console.error('Error generating thumbnail:', error);
    // Return a default SVG thumbnail as fallback
    return generateDefaultThumbnail(size);
  }
}

export function generatePartThumbnail(partName: string, size: number = 100): string {
  // Create a simple SVG thumbnail based on part name
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');
  
  if (!context) {
    return generateDefaultThumbnail(size);
  }
  
  canvas.width = size;
  canvas.height = size;
  
  // Set background
  context.fillStyle = '#f0f9ff'; // bg-blue-50
  context.fillRect(0, 0, size, size);
  
  // Add border
  context.strokeStyle = '#e0e7ff'; // border color
  context.lineWidth = 1;
  context.strokeRect(0, 0, size, size);
  
  // Draw simple geometric shape based on part type
  context.fillStyle = '#3b82f6'; // blue-500
  context.strokeStyle = '#1d4ed8'; // blue-700
  context.lineWidth = 2;
  
  const centerX = size / 2;
  const centerY = size / 2;
  const radius = size * 0.3;
  
  if (partName.toLowerCase().includes('shaft') || partName.toLowerCase().includes('rod')) {
    // Draw rectangle for shaft-like parts
    const width = size * 0.6;
    const height = size * 0.2;
    context.fillRect(centerX - width/2, centerY - height/2, width, height);
    context.strokeRect(centerX - width/2, centerY - height/2, width, height);
  } else if (partName.toLowerCase().includes('gear') || partName.toLowerCase().includes('wheel')) {
    // Draw gear-like shape
    context.beginPath();
    for (let i = 0; i < 8; i++) {
      const angle = (i * Math.PI) / 4;
      const outerRadius = radius * 1.2;
      const innerRadius = radius * 0.8;
      const x1 = centerX + Math.cos(angle) * outerRadius;
      const y1 = centerY + Math.sin(angle) * outerRadius;
      const x2 = centerX + Math.cos(angle + Math.PI/8) * innerRadius;
      const y2 = centerY + Math.sin(angle + Math.PI/8) * innerRadius;
      
      if (i === 0) {
        context.moveTo(x1, y1);
      } else {
        context.lineTo(x1, y1);
      }
      context.lineTo(x2, y2);
    }
    context.closePath();
    context.fill();
    context.stroke();
  } else if (partName.toLowerCase().includes('housing') || partName.toLowerCase().includes('cover')) {
    // Draw rectangular housing
    const width = size * 0.7;
    const height = size * 0.5;
    context.fillRect(centerX - width/2, centerY - height/2, width, height);
    context.strokeRect(centerX - width/2, centerY - height/2, width, height);
    
    // Add inner rectangle
    const innerWidth = width * 0.6;
    const innerHeight = height * 0.6;
    context.strokeRect(centerX - innerWidth/2, centerY - innerHeight/2, innerWidth, innerHeight);
  } else {
    // Default: draw circle
    context.beginPath();
    context.arc(centerX, centerY, radius, 0, 2 * Math.PI);
    context.fill();
    context.stroke();
  }
  
  return canvas.toDataURL('image/png');
}

function generateDefaultThumbnail(size: number): string {
  // Generate a simple SVG as fallback
  const svg = `
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">
      <rect width="${size}" height="${size}" fill="#f0f9ff" stroke="#e0e7ff" stroke-width="1"/>
      <circle cx="${size/2}" cy="${size/2}" r="${size*0.3}" fill="#3b82f6" stroke="#1d4ed8" stroke-width="2"/>
    </svg>
  `;
  
  return `data:image/svg+xml;base64,${btoa(svg)}`;
}
