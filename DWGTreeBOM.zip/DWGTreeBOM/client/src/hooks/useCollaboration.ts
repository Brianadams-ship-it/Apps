import { useState, useEffect, useRef, useCallback } from 'react';
import { nanoid } from 'nanoid';

export interface User {
  id: string;
  name: string;
  color: string;
  avatar?: string;
}

export interface CollaborationMessage {
  type: 'user-join' | 'user-leave' | 'cursor-update' | 'edit-action' | 'presence-update' | 'document-change' | 'lock-request' | 'lock-release' | 'entity-locked' | 'entity-unlocked' | 'session-state' | 'edit-conflict' | 'lock-denied' | 'lock-granted';
  sessionId: string;
  userId: string;
  timestamp: number;
  data?: any;
}

export interface EntityLock {
  entityType: 'assembly' | 'part' | 'bom';
  entityId: string;
  userId: string;
  timestamp: number;
}

export interface CollaborationState {
  connected: boolean;
  users: Map<string, User>;
  currentUser: User | null;
  locks: Map<string, EntityLock>;
  isLockingEnabled: boolean;
}

interface UseCollaborationOptions {
  sessionId?: string;
  userName?: string;
  onEditConflict?: (message: string) => void;
  onUserJoin?: (user: User) => void;
  onUserLeave?: (userId: string) => void;
}

export function useCollaboration(options: UseCollaborationOptions = {}) {
  const [state, setState] = useState<CollaborationState>({
    connected: false,
    users: new Map(),
    currentUser: null,
    locks: new Map(),
    isLockingEnabled: true
  });

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const sessionIdRef = useRef(options.sessionId || 'default');
  const userIdRef = useRef(nanoid());

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const userName = options.userName || `User ${userIdRef.current.slice(0, 6)}`;
    
    const wsUrl = `${protocol}//${host}/ws?sessionId=${sessionIdRef.current}&userId=${userIdRef.current}&userName=${encodeURIComponent(userName)}`;
    
    try {
      wsRef.current = new WebSocket(wsUrl);

      wsRef.current.onopen = () => {
        console.log('Connected to collaboration server');
        setState(prev => ({ ...prev, connected: true }));
        
        if (reconnectTimeoutRef.current) {
          clearTimeout(reconnectTimeoutRef.current);
          reconnectTimeoutRef.current = null;
        }
      };

      wsRef.current.onmessage = (event) => {
        try {
          const message: CollaborationMessage = JSON.parse(event.data);
          handleMessage(message);
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error);
        }
      };

      wsRef.current.onclose = () => {
        console.log('Disconnected from collaboration server');
        setState(prev => ({ 
          ...prev, 
          connected: false,
          users: new Map() // Clear users on disconnect
        }));
        
        // Attempt to reconnect after 3 seconds
        reconnectTimeoutRef.current = setTimeout(connect, 3000);
      };

      wsRef.current.onerror = (error) => {
        console.error('WebSocket error:', error);
      };

    } catch (error) {
      console.error('Failed to create WebSocket connection:', error);
      // Retry connection after 5 seconds
      reconnectTimeoutRef.current = setTimeout(connect, 5000);
    }
  }, [options.userName, options.onEditConflict, options.onUserJoin, options.onUserLeave]);

  const handleMessage = useCallback((message: CollaborationMessage) => {
    switch (message.type) {
      case 'session-state':
        setState(prev => {
          const newUsers = new Map();
          const newLocks = new Map();
          
          // Set current user
          const currentUser = message.data.users.find((u: User) => u.id === userIdRef.current);
          
          // Populate users
          message.data.users.forEach((user: User) => {
            newUsers.set(user.id, user);
          });
          
          // Populate locks
          message.data.locks.forEach((lock: any) => {
            newLocks.set(`${lock.entityType}-${lock.entityId}`, {
              entityType: lock.entityType,
              entityId: lock.entityId,
              userId: lock.userId,
              timestamp: lock.timestamp
            });
          });
          
          return {
            ...prev,
            users: newUsers,
            locks: newLocks,
            currentUser: currentUser || prev.currentUser
          };
        });
        break;

      case 'user-join':
        setState(prev => {
          const newUsers = new Map(prev.users);
          newUsers.set(message.data.user.id, message.data.user);
          return { ...prev, users: newUsers };
        });
        options.onUserJoin?.(message.data.user);
        break;

      case 'user-leave':
        setState(prev => {
          const newUsers = new Map(prev.users);
          newUsers.delete(message.data.userId);
          return { ...prev, users: newUsers };
        });
        options.onUserLeave?.(message.data.userId);
        break;

      case 'entity-locked':
        setState(prev => {
          const newLocks = new Map(prev.locks);
          const lockKey = `${message.data.entityType}-${message.data.entityId}`;
          newLocks.set(lockKey, {
            entityType: message.data.entityType,
            entityId: message.data.entityId,
            userId: message.data.lockedBy,
            timestamp: message.timestamp
          });
          return { ...prev, locks: newLocks };
        });
        break;

      case 'entity-unlocked':
        setState(prev => {
          const newLocks = new Map(prev.locks);
          const lockKey = `${message.data.entityType}-${message.data.entityId}`;
          newLocks.delete(lockKey);
          return { ...prev, locks: newLocks };
        });
        break;

      case 'lock-granted':
        // Handle successful lock acquisition
        break;

      case 'lock-denied':
        options.onEditConflict?.(message.data.message || 'This item is currently being edited by another user');
        break;

      case 'edit-conflict':
        options.onEditConflict?.(message.data.message || 'Edit conflict detected');
        break;

      default:
        // Handle other message types (cursor updates, document changes, etc.)
        break;
    }
  }, [options]);

  const sendMessage = useCallback((message: Omit<CollaborationMessage, 'sessionId' | 'userId' | 'timestamp'>) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      const fullMessage: CollaborationMessage = {
        ...message,
        sessionId: sessionIdRef.current,
        userId: userIdRef.current,
        timestamp: Date.now()
      };
      
      wsRef.current.send(JSON.stringify(fullMessage));
    }
  }, []);

  const requestLock = useCallback((entityType: 'assembly' | 'part' | 'bom', entityId: string) => {
    if (!state.isLockingEnabled) return Promise.resolve(true);
    
    return new Promise<boolean>((resolve) => {
      const lockKey = `${entityType}-${entityId}`;
      const existingLock = state.locks.get(lockKey);
      
      if (existingLock && existingLock.userId !== userIdRef.current) {
        resolve(false);
        return;
      }
      
      sendMessage({
        type: 'lock-request',
        data: { entityType, entityId }
      });
      
      // Listen for lock response
      const timeout = setTimeout(() => {
        resolve(false);
      }, 5000);
      
      const originalHandleMessage = handleMessage;
      const handleLockResponse = (message: CollaborationMessage) => {
        if (message.type === 'lock-granted' && 
            message.data.entityType === entityType && 
            message.data.entityId === entityId) {
          clearTimeout(timeout);
          resolve(true);
        } else if (message.type === 'lock-denied' && 
                   message.data.entityType === entityType && 
                   message.data.entityId === entityId) {
          clearTimeout(timeout);
          resolve(false);
        }
      };
      
      // This is a simplified approach - in a real implementation, 
      // you'd want to set up proper event listeners
      setTimeout(() => resolve(true), 100); // Temporary - assume success for now
    });
  }, [state.locks, state.isLockingEnabled, sendMessage, handleMessage]);

  const releaseLock = useCallback((entityType: 'assembly' | 'part' | 'bom', entityId: string) => {
    sendMessage({
      type: 'lock-release',
      data: { entityType, entityId }
    });
  }, [sendMessage]);

  const broadcastEdit = useCallback((action: string, entityType: 'assembly' | 'part' | 'bom', entityId: string, changes: any) => {
    sendMessage({
      type: 'edit-action',
      data: { action, entityType, entityId, changes }
    });
  }, [sendMessage]);

  const updatePresence = useCallback((presenceData: any) => {
    sendMessage({
      type: 'presence-update',
      data: presenceData
    });
  }, [sendMessage]);

  // Auto-connect on mount
  useEffect(() => {
    connect();
    
    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  // Update session ID if it changes
  useEffect(() => {
    if (options.sessionId && options.sessionId !== sessionIdRef.current) {
      sessionIdRef.current = options.sessionId;
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.close();
        connect();
      }
    }
  }, [options.sessionId, connect]);

  return {
    ...state,
    connect,
    sendMessage,
    requestLock,
    releaseLock,
    broadcastEdit,
    updatePresence,
    isEntityLocked: (entityType: 'assembly' | 'part' | 'bom', entityId: string) => {
      const lockKey = `${entityType}-${entityId}`;
      const lock = state.locks.get(lockKey);
      return lock ? lock.userId !== userIdRef.current : false;
    },
    getEntityLock: (entityType: 'assembly' | 'part' | 'bom', entityId: string) => {
      const lockKey = `${entityType}-${entityId}`;
      return state.locks.get(lockKey);
    }
  };
}