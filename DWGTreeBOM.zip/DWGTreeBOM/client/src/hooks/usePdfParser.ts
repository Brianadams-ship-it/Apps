import { useState, useCallback } from "react";
import { parsePdfDwg } from "@/lib/pdfParser";

interface ParsedData {
  assemblies: Array<{
    name: string;
    level: number;
    parentId?: string;
  }>;
  parts: Array<{
    name: string;
    partNumber: string;
    quantity: number;
    assemblyName?: string;
  }>;
}

export function usePdfParser() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [parsedData, setParsedData] = useState<ParsedData | null>(null);

  const parsePdf = useCallback(async (file: File) => {
    setIsLoading(true);
    setError(null);
    setParsedData(null);

    try {
      const data = await parsePdfDwg(file);
      setParsedData(data);
      return data;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to parse PDF";
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const reset = useCallback(() => {
    setIsLoading(false);
    setError(null);
    setParsedData(null);
  }, []);

  return {
    parsePdf,
    isLoading,
    error,
    parsedData,
    reset,
  };
}
