import { createContext, useContext, type ReactNode } from 'react';
import { useCollaboration } from '@/hooks/useCollaboration';
import type { User, EntityLock, CollaborationState } from '@/hooks/useCollaboration';

interface CollaborationContextType {
  connected: boolean;
  users: Map<string, User>;
  currentUser: User | null;
  locks: Map<string, EntityLock>;
  isLockingEnabled: boolean;
  sendMessage: (message: any) => void;
  requestLock: (entityType: 'assembly' | 'part' | 'bom', entityId: string) => Promise<boolean>;
  releaseLock: (entityType: 'assembly' | 'part' | 'bom', entityId: string) => void;
  broadcastEdit: (action: string, entityType: 'assembly' | 'part' | 'bom', entityId: string, changes: any) => void;
  updatePresence: (presenceData: any) => void;
  isEntityLocked: (entityType: 'assembly' | 'part' | 'bom', entityId: string) => boolean;
  getEntityLock: (entityType: 'assembly' | 'part' | 'bom', entityId: string) => EntityLock | undefined;
}

const CollaborationContext = createContext<CollaborationContextType | null>(null);

interface CollaborationProviderProps {
  children: ReactNode;
  sessionId?: string;
  userName?: string;
}

export function CollaborationProvider({ children, sessionId = 'main-session', userName = 'Current User' }: CollaborationProviderProps) {
  const collaboration = useCollaboration({
    sessionId,
    userName,
  });

  return (
    <CollaborationContext.Provider value={collaboration}>
      {children}
    </CollaborationContext.Provider>
  );
}

export function useCollaborationContext() {
  const context = useContext(CollaborationContext);
  if (!context) {
    throw new Error('useCollaborationContext must be used within a CollaborationProvider');
  }
  return context;
}