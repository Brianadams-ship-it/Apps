# replit.md

## Overview

This is a comprehensive Bill of Materials (BOM) management system designed for manufacturing and engineering teams. The application features advanced CAD file processing, real-time collaboration, and sophisticated analytics. Users can upload and parse DWG/PDF files to automatically extract assembly and part information, manage hierarchical assembly structures, track part statuses, collaborate with team members in real-time, and gain insights through comprehensive analytics dashboards. The system provides multiple viewing modes including tree view, schedule view, task view, process steps, and analytics to accommodate all workflow needs.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Updates (September 2025)

### ✅ Complete System Implementation
Successfully delivered a comprehensive BOM management system with all advanced features:

- **📊 Advanced Analytics Dashboard**: Interactive reporting with charts, metrics, cost analysis, timeline tracking, and project insights
- **🤝 Real-Time Collaboration**: Multi-user support with WebSocket presence tracking, entity locking, and conflict resolution  
- **🔍 Enhanced CAD Processing**: Sophisticated PDF/DWG parsing with intelligent part recognition and assembly relationship detection
- **🎯 Multi-View Interface**: Tree, Schedule, Task, Process, and Analytics views with professional card-based design
- **🚀 Production Ready**: Full-stack application with database persistence, object storage, and scalable architecture

## System Architecture

### Frontend Architecture

The frontend is built using React with TypeScript and implements a modern component-based architecture:

- **Framework**: React 18 with TypeScript for type safety and development efficiency
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent, accessible UI components
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and optimized production builds

The UI follows a responsive design pattern with support for multiple view modes (tree, schedule, task, process) and includes drag-and-drop file upload functionality.

### Backend Architecture

The backend follows a REST API pattern built on Express.js:

- **Framework**: Express.js with TypeScript for the HTTP server
- **Data Layer**: Abstracted storage interface with in-memory implementation for development
- **File Processing**: PDF.js for parsing DWG/PDF files and extracting assembly/part data
- **Object Storage**: Google Cloud Storage integration for file uploads and serving
- **API Design**: RESTful endpoints for CRUD operations on assemblies, parts, BOM templates, and DWG files

The storage layer uses an interface pattern (`IStorage`) allowing for easy swapping between different implementations (currently in-memory, designed for future database integration).

### Data Storage Solutions

The system is designed with a flexible data storage approach:

- **Development**: In-memory storage for rapid development and testing
- **Production Ready**: Drizzle ORM configured for PostgreSQL with schema definitions
- **Database Schema**: Hierarchical structure supporting assemblies, parts, BOM templates, and DWG files with proper relationships
- **File Storage**: Google Cloud Storage for uploaded files with ACL-based access control

The schema supports hierarchical assembly structures, part tracking with status management, and metadata storage for parsed file data.

### Authentication and Authorization

The system implements object-based access control:

- **File Access**: ACL (Access Control List) system for uploaded objects
- **Access Groups**: Flexible group-based permissions supporting various membership types
- **Object Permissions**: Read/write permissions with granular control
- **Integration**: Google Cloud Storage authentication via Replit sidecar

### External Dependencies

- **Google Cloud Storage**: File upload, storage, and serving with authentication
- **Neon Database**: Serverless PostgreSQL for production data storage
- **PDF.js**: Client-side PDF parsing and content extraction
- **Uppy**: File upload interface with progress tracking and validation
- **Radix UI**: Accessible component primitives for consistent UI behavior
- **Drizzle ORM**: Type-safe database operations and schema management