import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const assemblies = pgTable("assemblies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  parentId: varchar("parent_id"),
  level: integer("level").notNull().default(0),
  isExpanded: boolean("is_expanded").notNull().default(true),
  status: text("status").notNull().default("new"), // new, progress, complete, issue
  thumbnailPath: text("thumbnail_path"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const parts = pgTable("parts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  partNumber: text("part_number").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  assemblyId: varchar("assembly_id").references(() => assemblies.id),
  quantity: integer("quantity").notNull().default(1),
  status: text("status").notNull().default("new"), // new, progress, complete, issue
  thumbnailPath: text("thumbnail_path"),
  metadata: jsonb("metadata"), // Additional part data from PDF parsing
  createdAt: timestamp("created_at").defaultNow(),
});

export const bomTemplates = pgTable("bom_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  templateData: jsonb("template_data").notNull(), // Structure for assemblies and parts
  createdAt: timestamp("created_at").defaultNow(),
});

export const dwgFiles = pgTable("dwg_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  filename: text("filename").notNull(),
  filePath: text("file_path").notNull(),
  fileSize: integer("file_size"),
  parseStatus: text("parse_status").notNull().default("pending"), // pending, processing, completed, failed
  extractedData: jsonb("extracted_data"), // Parsed assembly/parts data
  createdAt: timestamp("created_at").defaultNow(),
});

export const workflows = pgTable("workflows", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const processSteps = pgTable("process_steps", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workflowId: varchar("workflow_id").notNull().references(() => workflows.id),
  name: text("name").notNull(),
  description: text("description"),
  status: text("status").notNull().default("pending"), // pending, active, completed, blocked
  estimatedDuration: integer("estimated_duration").notNull().default(60), // minutes
  actualDuration: integer("actual_duration"), // minutes
  position: integer("position").notNull().default(0), // for ordering steps
  metadata: jsonb("metadata"), // Additional step-specific data
  createdAt: timestamp("created_at").defaultNow(),
});

export const stepDependencies = pgTable("step_dependencies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  stepId: varchar("step_id").notNull().references(() => processSteps.id),
  dependsOnStepId: varchar("depends_on_step_id").notNull().references(() => processSteps.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const workflowAssignments = pgTable("workflow_assignments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workflowId: varchar("workflow_id").notNull().references(() => workflows.id),
  targetType: text("target_type").notNull(), // 'part' or 'assembly'
  targetId: varchar("target_id").notNull(), // references parts.id or assemblies.id
  status: text("status").notNull().default("not_started"), // not_started, in_progress, completed
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertAssemblySchema = createInsertSchema(assemblies).omit({
  id: true,
  createdAt: true,
});

export const insertPartSchema = createInsertSchema(parts).omit({
  id: true,
  createdAt: true,
});

export const insertBomTemplateSchema = createInsertSchema(bomTemplates).omit({
  id: true,
  createdAt: true,
});

export const insertDwgFileSchema = createInsertSchema(dwgFiles).omit({
  id: true,
  createdAt: true,
});

export const insertWorkflowSchema = createInsertSchema(workflows).omit({
  id: true,
  createdAt: true,
});

export const insertProcessStepSchema = createInsertSchema(processSteps).omit({
  id: true,
  createdAt: true,
});

export const insertStepDependencySchema = createInsertSchema(stepDependencies).omit({
  id: true,
  createdAt: true,
});

export const insertWorkflowAssignmentSchema = createInsertSchema(workflowAssignments).omit({
  id: true,
  createdAt: true,
});

// Types
export type Assembly = typeof assemblies.$inferSelect;
export type InsertAssembly = z.infer<typeof insertAssemblySchema>;
export type Part = typeof parts.$inferSelect;
export type InsertPart = z.infer<typeof insertPartSchema>;
export type BomTemplate = typeof bomTemplates.$inferSelect;
export type InsertBomTemplate = z.infer<typeof insertBomTemplateSchema>;
export type DwgFile = typeof dwgFiles.$inferSelect;
export type InsertDwgFile = z.infer<typeof insertDwgFileSchema>;
export type Workflow = typeof workflows.$inferSelect;
export type InsertWorkflow = z.infer<typeof insertWorkflowSchema>;
export type ProcessStep = typeof processSteps.$inferSelect;
export type InsertProcessStep = z.infer<typeof insertProcessStepSchema>;
export type StepDependency = typeof stepDependencies.$inferSelect;
export type InsertStepDependency = z.infer<typeof insertStepDependencySchema>;
export type WorkflowAssignment = typeof workflowAssignments.$inferSelect;
export type InsertWorkflowAssignment = z.infer<typeof insertWorkflowAssignmentSchema>;

// Status enums
export const PartStatus = {
  NEW: "new",
  PROGRESS: "progress", 
  COMPLETE: "complete",
  ISSUE: "issue",
} as const;

export const ParseStatus = {
  PENDING: "pending",
  PROCESSING: "processing",
  COMPLETED: "completed",
  FAILED: "failed",
} as const;

export const ProcessStepStatus = {
  PENDING: "pending",
  ACTIVE: "active",
  COMPLETED: "completed",
  BLOCKED: "blocked",
} as const;

export const WorkflowAssignmentStatus = {
  NOT_STARTED: "not_started",
  IN_PROGRESS: "in_progress",
  COMPLETED: "completed",
} as const;
