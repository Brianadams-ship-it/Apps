import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { PbsItem, InsertPbsItem, RequirementPbsMapping, InsertRequirementPbsMapping } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export function usePbsItems(projectId: string) {
  return useQuery<PbsItem[]>({
    queryKey: ["/api/projects", projectId, "pbs-items"],
    enabled: !!projectId,
  });
}

export function useCreatePbsItem() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (pbsItem: InsertPbsItem) => {
      const response = await apiRequest("POST", "/api/pbs-items", pbsItem);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/projects", data.projectId, "pbs-items"] 
      });
    },
  });
}

export function useUpdatePbsItem() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertPbsItem> }) => {
      const response = await apiRequest("PUT", `/api/pbs-items/${id}`, data);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/projects", data.projectId, "pbs-items"] 
      });
    },
  });
}

export function useRequirementPbsMappings(requirementId: string) {
  return useQuery<RequirementPbsMapping[]>({
    queryKey: ["/api/requirements", requirementId, "pbs-mappings"],
    enabled: !!requirementId,
  });
}

export function useProjectPbsMappings(projectId: string) {
  return useQuery<RequirementPbsMapping[]>({
    queryKey: ["/api/projects", projectId, "pbs-mappings"],
    enabled: !!projectId,
  });
}

export function useCreateRequirementPbsMapping() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (mapping: InsertRequirementPbsMapping) => {
      const response = await apiRequest("POST", "/api/requirement-pbs-mappings", mapping);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/requirements", data.requirementId, "pbs-mappings"] 
      });
    },
  });
}

export function useDeleteRequirementPbsMapping() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ requirementId, pbsItemId }: { requirementId: string; pbsItemId: string }) => {
      await apiRequest("DELETE", `/api/requirement-pbs-mappings/${requirementId}/${pbsItemId}`);
      return { requirementId, pbsItemId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/requirements", data.requirementId, "pbs-mappings"] 
      });
    },
  });
}
