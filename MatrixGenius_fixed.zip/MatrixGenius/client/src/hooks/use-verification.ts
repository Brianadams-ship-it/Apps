import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { VerificationItem, InsertVerificationItem } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export function useVerificationItemsByProject(projectId: string) {
  return useQuery<VerificationItem[]>({
    queryKey: ["/api/projects", projectId, "verification-items"],
    enabled: !!projectId,
  });
}

export function useVerificationItemsByRequirement(requirementId: string) {
  return useQuery<VerificationItem[]>({
    queryKey: ["/api/requirements", requirementId, "verification-items"],
    enabled: !!requirementId,
  });
}

export function useCreateVerificationItem() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (item: InsertVerificationItem) => {
      const response = await apiRequest("POST", "/api/verification-items", item);
      return response.json();
    },
    onSuccess: (data) => {
      // Invalidate both project and requirement verification queries
      queryClient.invalidateQueries({ 
        queryKey: ["/api/projects"] 
      });
      queryClient.invalidateQueries({ 
        queryKey: ["/api/requirements", data.requirementId, "verification-items"] 
      });
    },
  });
}

export function useUpdateVerificationItem() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertVerificationItem> }) => {
      const response = await apiRequest("PUT", `/api/verification-items/${id}`, data);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/projects"] 
      });
      queryClient.invalidateQueries({ 
        queryKey: ["/api/requirements", data.requirementId, "verification-items"] 
      });
    },
  });
}

export function useDeleteVerificationItem() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/verification-items/${id}`);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/projects"] 
      });
    },
  });
}