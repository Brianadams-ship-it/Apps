import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Requirement, InsertRequirement, RequirementRelationship, InsertRequirementRelationship } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export function useRequirements(projectId: string) {
  return useQuery<Requirement[]>({
    queryKey: ["/api/projects", projectId, "requirements"],
    enabled: !!projectId,
  });
}

export function useCreateRequirement() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (requirement: InsertRequirement) => {
      const response = await apiRequest("POST", "/api/requirements", requirement);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/projects", data.projectId, "requirements"] 
      });
    },
  });
}

export function useUpdateRequirement() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<InsertRequirement> }) => {
      const response = await apiRequest("PUT", `/api/requirements/${id}`, data);
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/projects", data.projectId, "requirements"] 
      });
    },
  });
}

export function useDeleteRequirement() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/requirements/${id}`);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: ["/api/projects"] 
      });
    },
  });
}

// Requirement Relationships
export function useRequirementRelationships(requirementId: string) {
  return useQuery<RequirementRelationship[]>({
    queryKey: ["/api/requirements", requirementId, "relationships"],
    enabled: !!requirementId,
  });
}

export function useCreateRequirementRelationship() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (relationship: InsertRequirementRelationship) => {
      const response = await apiRequest("POST", "/api/requirement-relationships", relationship);
      return response.json();
    },
    onSuccess: (data) => {
      // Invalidate relationship queries for both source and target requirements
      queryClient.invalidateQueries({ 
        queryKey: ["/api/requirements", data.sourceRequirementId, "relationships"] 
      });
      queryClient.invalidateQueries({ 
        queryKey: ["/api/requirements", data.targetRequirementId, "relationships"] 
      });
    },
  });
}

export function useDeleteRequirementRelationship() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/requirement-relationships/${id}`);
      return id;
    },
    onSuccess: () => {
      // Invalidate all relationship queries since we don't know which ones are affected
      queryClient.invalidateQueries({ 
        queryKey: ["/api/requirements"] 
      });
    },
  });
}
