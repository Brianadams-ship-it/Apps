import { Link, useLocation } from "wouter";
import { FileText, Table, ChartGantt, ClipboardCheck, ChartLine, Upload, Download, Settings, CheckCircle, Clock, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import { Project } from "@shared/schema";

export default function Sidebar() {
  const [location] = useLocation();
  
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const currentProject = projects[0]; // For demo, use first project

  const navigation = [
    { name: "Requirements", href: "/requirements", icon: FileText, count: 247, active: true },
    { name: "PBS Structure", href: "/pbs-mapping", icon: Table, count: 42 },
    { name: "Traceability", href: "/traceability", icon: ChartGantt },
    { name: "Verification", href: "/verification", icon: ClipboardCheck, count: 89 },
    { name: "Analytics", href: "/", icon: ChartLine },
  ];

  const tools = [
    { name: "Import Specs", href: "#", icon: Upload },
    { name: "Export Reports", href: "#", icon: Download },
    { name: "Settings", href: "#", icon: Settings },
  ];

  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col" data-testid="sidebar">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <FileText className="w-4 h-4 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-semibold">ReqMatrix</h1>
            <p className="text-xs text-muted-foreground">v2.1.0</p>
          </div>
        </div>
      </div>

      {/* Project Selector */}
      <div className="p-4 border-b border-border">
        <div className="relative">
          <select 
            className="w-full px-3 py-2 bg-input border border-border rounded-md text-sm appearance-none"
            data-testid="project-selector"
          >
            <option>{currentProject?.name || "Select Project"}</option>
            {projects.map((project) => (
              <option key={project.id} value={project.id}>
                {project.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-1">
          {navigation.map((item) => {
            const isActive = location === item.href || (item.href === "/requirements" && location === "/");
            return (
              <li key={item.name}>
                <Link href={item.href}>
                  <div
                    className={`flex items-center gap-3 px-3 py-2 text-sm rounded-md transition-colors ${
                      isActive
                        ? "bg-accent text-accent-foreground"
                        : "hover:bg-accent hover:text-accent-foreground"
                    }`}
                    data-testid={`nav-${item.name.toLowerCase().replace(" ", "-")}`}
                  >
                    <item.icon className="w-4 h-4" />
                    <span>{item.name}</span>
                    {item.count && (
                      <Badge
                        variant={isActive ? "default" : "secondary"}
                        className="ml-auto text-xs"
                      >
                        {item.count}
                      </Badge>
                    )}
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>

        <div className="mt-8">
          <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
            Tools
          </h3>
          <ul className="space-y-1">
            {tools.map((item) => (
              <li key={item.name}>
                <a
                  href={item.href}
                  className="flex items-center gap-3 px-3 py-2 text-sm rounded-md hover:bg-accent hover:text-accent-foreground transition-colors"
                  data-testid={`tool-${item.name.toLowerCase().replace(" ", "-")}`}
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </a>
              </li>
            ))}
          </ul>
        </div>
      </nav>

      {/* Project Health */}
      <div className="p-4 border-t border-border">
        <div className="bg-muted rounded-lg p-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Project Health</span>
            <span className="text-green-600 text-sm font-medium">87%</span>
          </div>
          <Progress value={87} className="h-2 mb-2" />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>214 Complete</span>
            <span>33 Pending</span>
          </div>
        </div>
      </div>
    </aside>
  );
}
