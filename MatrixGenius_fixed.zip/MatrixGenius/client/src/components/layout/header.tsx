import { Search, Filter, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface HeaderProps {
  title?: string;
  subtitle?: string;
  onSearch?: (query: string) => void;
  onNewRequirement?: () => void;
}

export default function Header({ 
  title = "Requirements Management", 
  subtitle = "Specification analysis and compliance tracking",
  onSearch,
  onNewRequirement 
}: HeaderProps) {
  return (
    <header className="bg-card border-b border-border px-6 py-4" data-testid="header">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">{title}</h2>
          <p className="text-sm text-muted-foreground">{subtitle}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search requirements, PBS items..."
              className="w-80 pl-10"
              onChange={(e) => onSearch?.(e.target.value)}
              data-testid="search-input"
            />
            <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
          </div>
          <Button variant="secondary" size="sm" data-testid="filter-button">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
          <Button size="sm" onClick={onNewRequirement} data-testid="new-requirement-button">
            <Plus className="w-4 h-4 mr-2" />
            New Requirement
          </Button>
        </div>
      </div>
    </header>
  );
}
