import { useState } from "react";
import { useDrop } from "react-dnd";
import { Edit, Link as LinkIcon, MoreVertical, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Requirement } from "@shared/schema";
import { ItemTypes, DragItem } from "@/types";
import { useCreateRequirementPbsMapping, useDeleteRequirementPbsMapping, useRequirementPbsMappings } from "@/hooks/use-pbs";
import { usePbsItems } from "@/hooks/use-pbs";
import { useDeleteRequirement } from "@/hooks/use-requirements";
import { useToast } from "@/hooks/use-toast";

interface RequirementsTableProps {
  requirements: Requirement[];
  onEdit: (id: string) => void;
  isLoading?: boolean;
}

function RequirementRow({ requirement, onEdit, pbsItems }: {
  requirement: Requirement;
  onEdit: (id: string) => void;
  pbsItems: any[];
}) {
  const { toast } = useToast();
  const { data: mappings = [] } = useRequirementPbsMappings(requirement.id);
  const createMapping = useCreateRequirementPbsMapping();
  const deleteMapping = useDeleteRequirementPbsMapping();
  const deleteRequirement = useDeleteRequirement();

  const [{ isOver }, drop] = useDrop(() => ({
    accept: ItemTypes.PBS_ITEM,
    drop: (item: DragItem) => {
      const existingMapping = mappings.find(m => m.pbsItemId === item.id);
      if (!existingMapping) {
        createMapping.mutate({
          requirementId: requirement.id,
          pbsItemId: item.id,
        });
        toast({
          title: "PBS mapping created",
          description: `${item.pbsId} mapped to ${requirement.reqId}`,
        });
      }
    },
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  }));

  const mappedPbsItems = mappings.map(m => {
    const pbs = pbsItems.find(p => p.id === m.pbsItemId);
    return pbs;
  }).filter(Boolean);

  const getStatusBadge = (status: string) => {
    const variants: Record<string, any> = {
      "Open": "default",
      "In Progress": "secondary",
      "Closed": "default",
      "Blocked": "destructive",
    };
    
    const colors: Record<string, string> = {
      "Open": "bg-blue-100 text-blue-800",
      "In Progress": "bg-amber-100 text-amber-800",
      "Closed": "bg-green-100 text-green-800",
      "Blocked": "bg-red-100 text-red-800",
    };

    return (
      <Badge className={colors[status] || "bg-gray-100 text-gray-800"}>
        {status}
      </Badge>
    );
  };

  const getVerificationBadge = (verification: string) => {
    const colors: Record<string, string> = {
      "Test": "bg-blue-100 text-blue-800",
      "Analysis": "bg-purple-100 text-purple-800",
      "Inspection": "bg-green-100 text-green-800",
      "Demonstration": "bg-orange-100 text-orange-800",
      "TBD": "bg-gray-100 text-gray-800",
    };

    return (
      <Badge className={colors[verification] || "bg-gray-100 text-gray-800"}>
        {verification}
      </Badge>
    );
  };

  return (
    <TableRow className="hover:bg-accent/50" data-testid={`requirement-row-${requirement.reqId}`}>
      <TableCell>
        <Checkbox />
      </TableCell>
      <TableCell>
        <span className="font-mono text-sm text-primary">{requirement.reqId}</span>
      </TableCell>
      <TableCell className="max-w-md">
        <div>
          <p className="text-sm font-medium">{requirement.text}</p>
          {requirement.source && (
            <p className="text-xs text-muted-foreground mt-1">{requirement.source}</p>
          )}
        </div>
      </TableCell>
      <TableCell>
        <div
          ref={drop}
          className={`drag-zone border-2 border-dashed rounded-md p-2 min-h-8 flex flex-wrap gap-1 ${
            isOver ? "border-primary bg-blue-50" : "border-border"
          }`}
          data-testid={`pbs-drop-zone-${requirement.reqId}`}
        >
          {mappedPbsItems.length > 0 ? (
            mappedPbsItems.map((pbs) => (
              <Badge
                key={pbs.id}
                variant="outline"
                className="text-xs"
              >
                {pbs.pbsId}
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-auto p-0 ml-1"
                  onClick={() => deleteMapping.mutate({ requirementId: requirement.id, pbsItemId: pbs.id })}
                >
                  ×
                </Button>
              </Badge>
            ))
          ) : (
            <span className="text-xs text-muted-foreground">Drop PBS item</span>
          )}
        </div>
      </TableCell>
      <TableCell>
        {getVerificationBadge(requirement.verification || "TBD")}
      </TableCell>
      <TableCell>
        {getStatusBadge(requirement.status || "Open")}
      </TableCell>
      <TableCell>
        {requirement.owner && (
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-blue-500 rounded-full text-white text-xs flex items-center justify-center">
              {requirement.owner.charAt(0).toUpperCase()}
            </div>
            <span className="text-sm">{requirement.owner}</span>
          </div>
        )}
      </TableCell>
      <TableCell>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onEdit(requirement.id)}
            data-testid={`edit-requirement-${requirement.reqId}`}
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <LinkIcon className="w-4 h-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => deleteRequirement.mutate(requirement.id)}
            data-testid={`delete-requirement-${requirement.reqId}`}
          >
            <Trash2 className="w-4 h-4 text-destructive" />
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
}

export default function RequirementsTable({ requirements, onEdit, isLoading }: RequirementsTableProps) {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [verificationFilter, setVerificationFilter] = useState<string>("all");
  
  const { data: pbsItems = [] } = usePbsItems("project-1");

  const filteredRequirements = requirements.filter(req => {
    if (statusFilter !== "all" && req.status !== statusFilter) return false;
    if (verificationFilter !== "all" && req.verification !== verificationFilter) return false;
    return true;
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Loading requirements...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="requirements-table">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Requirements Matrix</CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </div>
        </div>
        
        {/* Filters */}
        <div className="flex items-center gap-3">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="All Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="Open">Open</SelectItem>
              <SelectItem value="In Progress">In Progress</SelectItem>
              <SelectItem value="Closed">Closed</SelectItem>
              <SelectItem value="Blocked">Blocked</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={verificationFilter} onValueChange={setVerificationFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="All Verification" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Verification</SelectItem>
              <SelectItem value="Test">Test</SelectItem>
              <SelectItem value="Analysis">Analysis</SelectItem>
              <SelectItem value="Inspection">Inspection</SelectItem>
              <SelectItem value="Demonstration">Demonstration</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">
                  <Checkbox />
                </TableHead>
                <TableHead>ID</TableHead>
                <TableHead>Requirement</TableHead>
                <TableHead>PBS</TableHead>
                <TableHead>Verification</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredRequirements.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-6 text-muted-foreground">
                    No requirements found. Import a specification or create requirements manually.
                  </TableCell>
                </TableRow>
              ) : (
                filteredRequirements.map((requirement) => (
                  <RequirementRow
                    key={requirement.id}
                    requirement={requirement}
                    onEdit={onEdit}
                    pbsItems={pbsItems}
                  />
                ))
              )}
            </TableBody>
          </Table>
        </div>
        
        {/* Pagination */}
        <div className="p-4 border-t border-border flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            Showing {filteredRequirements.length} of {requirements.length} requirements
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="default" size="sm">1</Button>
            <Button variant="outline" size="sm">2</Button>
            <Button variant="outline" size="sm">3</Button>
            <Button variant="outline" size="sm">
              Next
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
