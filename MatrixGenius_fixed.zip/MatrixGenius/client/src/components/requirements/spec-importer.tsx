import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Upload, Link as LinkIcon, FileText, Download, File, Users, Hash, BookOpen } from "lucide-react";
import { extractRequirements } from "@/lib/requirement-extractor";
import { useCreateRequirement } from "@/hooks/use-requirements";
import { useToast } from "@/hooks/use-toast";
import { ExtractedRequirement, ExtractionConfig } from "@/types";

interface SpecImporterProps {
  projectId: string;
  onClose: () => void;
}

export default function SpecImporter({ projectId, onClose }: SpecImporterProps) {
  const { toast } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const createRequirement = useCreateRequirement();
  
  const [specText, setSpecText] = useState("");
  const [url, setUrl] = useState("");
  const [extractedRequirements, setExtractedRequirements] = useState<ExtractedRequirement[]>([]);
  const [selectedRequirements, setSelectedRequirements] = useState<Set<string>>(new Set());
  const [isImporting, setIsImporting] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [parsedDocument, setParsedDocument] = useState<any | null>(null);
  const [parseMode, setParseMode] = useState<'basic' | 'advanced'>('basic');
  
  const [config, setConfig] = useState<ExtractionConfig>({
    idPrefix: "REQ-",
    includeShould: true,
    minLen: 20,
    captureContext: true,
  });

  const handleFileUpload = async (file: File) => {
    if (!file) return;
    
    const ext = file.name.toLowerCase().split(".").pop();
    const supportedFormats = ["txt", "md", "csv", "json", "html", "pdf", "docx", "xlsx", "xls"];
    
    if (!supportedFormats.includes(ext || "")) {
      toast({
        title: "Unsupported file type",
        description: "Please upload .txt, .md, .pdf, .docx, .xlsx, .xls, .csv, .json, .html or other supported files.",
        variant: "destructive",
      });
      return;
    }

    setIsParsing(true);
    setParsedDocument(null);
    
    try {
      if (["pdf", "docx", "xlsx", "xls", "csv", "json", "html"].includes(ext || "")) {
        // Use server-side parsing for structured documents
        const formData = new FormData();
        formData.append('file', file);
        
        const response = await fetch('/api/documents/parse', {
          method: 'POST',
          body: formData,
        });
        
        if (!response.ok) {
          throw new Error(`Server error: ${response.status}`);
        }
        
        const result = await response.json();
        setParsedDocument(result.document);
        setSpecText(result.document.text);
        setParseMode('advanced');
        
        const docType = ext?.toUpperCase();
        const sections = result.document.sections?.length || 0;
        const tables = result.document.tables?.length || 0;
        
        let message = `Extracted content from ${docType}`;
        if (sections > 0) message += ` with ${sections} sections`;
        if (tables > 0) message += ` and ${tables} tables`;
        message += '.';
        
        toast({
          title: "Document parsed successfully",
          description: message,
        });
      } else {
        // Basic text file handling
        const text = await file.text();
        setSpecText(text);
        setParseMode('basic');
        setParsedDocument(null);
        
        toast({
          title: "File uploaded",
          description: "Text content has been loaded.",
        });
      }
    } catch (error) {
      console.error("File parsing error:", error);
      toast({
        title: "Parsing failed",
        description: `Failed to parse ${ext?.toUpperCase()} file. Please try a different file or try again.`,
        variant: "destructive",
      });
    } finally {
      setIsParsing(false);
    }
  };

  const handleUrlFetch = async () => {
    if (!url) return;
    
    try {
      const response = await fetch(url);
      const text = await response.text();
      setSpecText(text);
      toast({
        title: "Specification fetched",
        description: "Content has been loaded from the URL.",
      });
    } catch (error) {
      toast({
        title: "Fetch failed",
        description: "Couldn't fetch the URL. Please check the URL or paste the content manually.",
        variant: "destructive",
      });
    }
  };

  const handleExtract = async () => {
    if (!specText.trim()) return;

    let extracted: ExtractedRequirement[] = [];
    
    if (parseMode === 'advanced' && parsedDocument) {
      // Use server-side advanced extraction
      try {
        const response = await fetch('/api/documents/extract-requirements', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            document: parsedDocument,
            config: config
          }),
        });

        if (!response.ok) {
          throw new Error(`Server error: ${response.status}`);
        }

        const result = await response.json();
        extracted = result.requirements;
      } catch (error) {
        console.error("Advanced extraction error:", error);
        toast({
          title: "Advanced extraction failed",
          description: "Falling back to basic text extraction.",
          variant: "destructive",
        });
        // Fallback to basic extraction
        extracted = extractRequirements(specText, config);
      }
    } else {
      // Use basic extraction for text
      extracted = extractRequirements(specText, config);
    }
    
    setExtractedRequirements(extracted);
    setSelectedRequirements(new Set(extracted.map(r => r.id)));
    
    const method = parseMode === 'advanced' ? 'Advanced' : 'Basic';
    toast({
      title: "Requirements extracted",
      description: `${method} extraction found ${extracted.length} potential requirements.`,
    });
  };

  const handleImport = async () => {
    setIsImporting(true);
    
    try {
      const requirementsToImport = extractedRequirements.filter(r => 
        selectedRequirements.has(r.id)
      );
      
      for (const req of requirementsToImport) {
        await createRequirement.mutateAsync({
          projectId,
          reqId: req.id,
          text: req.text,
          source: req.source,
          compliance: req.compliance,
          verification: req.verification,
          owner: req.owner,
          status: req.status,
          evidence: req.evidence,
          notes: req.notes,
        });
      }
      
      toast({
        title: "Import successful",
        description: `Imported ${requirementsToImport.length} requirements.`,
      });
      
      onClose();
    } catch (error) {
      toast({
        title: "Import failed",
        description: "Failed to import requirements. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsImporting(false);
    }
  };

  const toggleRequirement = (id: string) => {
    const newSelection = new Set(selectedRequirements);
    if (newSelection.has(id)) {
      newSelection.delete(id);
    } else {
      newSelection.add(id);
    }
    setSelectedRequirements(newSelection);
  };

  const toggleAll = () => {
    if (selectedRequirements.size === extractedRequirements.length) {
      setSelectedRequirements(new Set());
    } else {
      setSelectedRequirements(new Set(extractedRequirements.map(r => r.id)));
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto" data-testid="spec-importer-modal">
        <DialogHeader>
          <DialogTitle>Import Specification</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-5 gap-6">
          {/* Left Panel - Input */}
          <div className="col-span-2 space-y-4">
            {/* URL Input */}
            <div>
              <Label>Fetch from URL</Label>
              <div className="flex gap-2 mt-1">
                <Input
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://example.com/spec.txt"
                  data-testid="url-input"
                />
                <Button onClick={handleUrlFetch} variant="outline" size="sm">
                  <LinkIcon className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* File Upload */}
            <div>
              <Label>Upload File</Label>
              <div
                onClick={() => fileRef.current?.click()}
                className="border-2 border-dashed border-border rounded-lg p-4 text-center hover:bg-accent cursor-pointer mt-1"
                data-testid="file-upload-area"
              >
                <Upload className="w-5 h-5 mx-auto mb-2" />
                <div className="text-sm">Click to upload .txt, .md, .pdf, .docx, .xlsx, .xls, .csv, .json, .html, or other supported files</div>
                <input
                  ref={fileRef}
                  type="file"
                  hidden
                  onChange={(e) => handleFileUpload(e.target.files?.[0]!)}
                  accept=".txt,.md,.csv,.json,.html,.pdf,.docx,.xlsx,.xls"
                />
              </div>
            </div>

            {/* Text Input */}
            <div>
              <Label>Paste Text</Label>
              <Textarea
                rows={8}
                value={specText}
                onChange={(e) => setSpecText(e.target.value)}
                placeholder="Paste the specification text here..."
                className="mt-1 font-mono text-sm"
                data-testid="spec-text-input"
              />
            </div>

            {/* Extraction Config */}
            <div className="space-y-3">
              <Label>Extraction Settings</Label>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-sm">ID Prefix</Label>
                  <Input
                    value={config.idPrefix}
                    onChange={(e) => setConfig(prev => ({ ...prev, idPrefix: e.target.value }))}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label className="text-sm">Min Length</Label>
                  <Input
                    type="number"
                    value={config.minLen}
                    onChange={(e) => setConfig(prev => ({ ...prev, minLen: Number(e.target.value) }))}
                    className="mt-1"
                  />
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includeShould"
                  checked={config.includeShould}
                  onCheckedChange={(checked) => setConfig(prev => ({ ...prev, includeShould: !!checked }))}
                />
                <Label htmlFor="includeShould" className="text-sm">
                  Include "should" as requirement indicator
                </Label>
              </div>
            </div>

            <Button 
              onClick={handleExtract} 
              disabled={!specText.trim()}
              className="w-full"
              data-testid="extract-button"
            >
              <FileText className="w-4 h-4 mr-2" />
              Extract Requirements
            </Button>
          </div>

          {/* Right Panel - Results */}
          <div className="col-span-3 space-y-4">
            {extractedRequirements.length > 0 && (
              <>
                <div className="flex items-center justify-between">
                  <Label>Extracted Requirements ({extractedRequirements.length})</Label>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={toggleAll}>
                      {selectedRequirements.size === extractedRequirements.length ? "Deselect All" : "Select All"}
                    </Button>
                    <Button 
                      onClick={handleImport}
                      disabled={selectedRequirements.size === 0 || isImporting}
                      size="sm"
                      data-testid="import-button"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Import Selected ({selectedRequirements.size})
                    </Button>
                  </div>
                </div>

                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {extractedRequirements.map((req) => (
                    <div
                      key={req.id}
                      className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                        selectedRequirements.has(req.id) 
                          ? "border-primary bg-primary/5" 
                          : "border-border hover:border-primary/50"
                      }`}
                      onClick={() => toggleRequirement(req.id)}
                      data-testid={`extracted-requirement-${req.id}`}
                    >
                      <div className="flex items-start gap-3">
                        <Checkbox 
                          checked={selectedRequirements.has(req.id)}
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="outline" className="text-xs font-mono">
                              {req.id}
                            </Badge>
                            <Badge variant="secondary" className="text-xs">
                              {req.verification}
                            </Badge>
                          </div>
                          <p className="text-sm font-medium mb-1">{req.text}</p>
                          {req.source && (
                            <p className="text-xs text-muted-foreground">{req.source}</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}

            {extractedRequirements.length === 0 && specText && (
              <div className="text-center py-8 text-muted-foreground">
                <FileText className="w-8 h-8 mx-auto mb-2" />
                <p>Click "Extract Requirements" to analyze the specification text.</p>
              </div>
            )}

            {!specText && (
              <div className="text-center py-8 text-muted-foreground">
                <Upload className="w-8 h-8 mx-auto mb-2" />
                <p>Upload a file, fetch from URL, or paste text to get started.</p>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
