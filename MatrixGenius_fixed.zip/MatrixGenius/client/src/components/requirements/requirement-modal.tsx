import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useRequirements, useCreateRequirement, useUpdateRequirement } from "@/hooks/use-requirements";
import { useToast } from "@/hooks/use-toast";

interface RequirementModalProps {
  requirementId: string | null;
  projectId: string;
  onClose: () => void;
}

export default function RequirementModal({ requirementId, projectId, onClose }: RequirementModalProps) {
  const { toast } = useToast();
  const { data: requirements = [] } = useRequirements(projectId);
  const createRequirement = useCreateRequirement();
  const updateRequirement = useUpdateRequirement();
  
  const requirement = requirementId ? requirements.find(r => r.id === requirementId) : null;
  const isEditing = !!requirementId;

  const [formData, setFormData] = useState({
    reqId: "",
    text: "",
    source: "",
    compliance: "TBD",
    verification: "TBD",
    owner: "",
    status: "Open",
    evidence: "",
    notes: "",
  });

  useEffect(() => {
    if (requirement) {
      setFormData({
        reqId: requirement.reqId,
        text: requirement.text,
        source: requirement.source || "",
        compliance: requirement.compliance || "TBD",
        verification: requirement.verification || "TBD",
        owner: requirement.owner || "",
        status: requirement.status || "Open",
        evidence: requirement.evidence || "",
        notes: requirement.notes || "",
      });
    } else {
      // Generate next requirement ID
      const existingReqIds = requirements.map(r => r.reqId).filter(id => id.startsWith("REQ-"));
      const maxNumber = existingReqIds.reduce((max, id) => {
        const num = parseInt(id.split("-")[1], 10);
        return isNaN(num) ? max : Math.max(max, num);
      }, 0);
      const nextReqId = `REQ-${String(maxNumber + 1).padStart(3, "0")}`;
      
      setFormData(prev => ({ ...prev, reqId: nextReqId }));
    }
  }, [requirement, requirements]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (isEditing && requirementId) {
        await updateRequirement.mutateAsync({
          id: requirementId,
          data: formData,
        });
        toast({
          title: "Requirement updated",
          description: `${formData.reqId} has been updated successfully.`,
        });
      } else {
        await createRequirement.mutateAsync({
          ...formData,
          projectId,
        });
        toast({
          title: "Requirement created",
          description: `${formData.reqId} has been created successfully.`,
        });
      }
      onClose();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save requirement. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="requirement-modal">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? `Edit Requirement - ${formData.reqId}` : "Create New Requirement"}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div>
              <Label htmlFor="reqId">Requirement ID</Label>
              <Input
                id="reqId"
                value={formData.reqId}
                onChange={(e) => setFormData(prev => ({ ...prev, reqId: e.target.value }))}
                required
                data-testid="requirement-id-input"
              />
            </div>
            <div>
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}>
                <SelectTrigger data-testid="status-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Open">Open</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="Closed">Closed</SelectItem>
                  <SelectItem value="Blocked">Blocked</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label htmlFor="text">Requirement Text</Label>
            <Textarea
              id="text"
              rows={4}
              value={formData.text}
              onChange={(e) => setFormData(prev => ({ ...prev, text: e.target.value }))}
              required
              data-testid="requirement-text-input"
            />
          </div>
          
          <div>
            <Label htmlFor="source">Source</Label>
            <Input
              id="source"
              value={formData.source}
              onChange={(e) => setFormData(prev => ({ ...prev, source: e.target.value }))}
              placeholder="e.g., Flight Control Specification v2.1 - Section 3.2.1"
              data-testid="source-input"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-6">
            <div>
              <Label htmlFor="verification">Verification Method</Label>
              <Select value={formData.verification} onValueChange={(value) => setFormData(prev => ({ ...prev, verification: value }))}>
                <SelectTrigger data-testid="verification-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Test">Test</SelectItem>
                  <SelectItem value="Analysis">Analysis</SelectItem>
                  <SelectItem value="Inspection">Inspection</SelectItem>
                  <SelectItem value="Demonstration">Demonstration</SelectItem>
                  <SelectItem value="TBD">TBD</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="compliance">Compliance</Label>
              <Select value={formData.compliance} onValueChange={(value) => setFormData(prev => ({ ...prev, compliance: value }))}>
                <SelectTrigger data-testid="compliance-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Yes">Yes</SelectItem>
                  <SelectItem value="No">No</SelectItem>
                  <SelectItem value="Partial">Partial</SelectItem>
                  <SelectItem value="TBD">TBD</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label htmlFor="owner">Owner</Label>
            <Input
              id="owner"
              value={formData.owner}
              onChange={(e) => setFormData(prev => ({ ...prev, owner: e.target.value }))}
              placeholder="e.g., J. Smith"
              data-testid="owner-input"
            />
          </div>
          
          <div>
            <Label htmlFor="evidence">Evidence/Notes</Label>
            <Textarea
              id="evidence"
              rows={3}
              value={formData.evidence}
              onChange={(e) => setFormData(prev => ({ ...prev, evidence: e.target.value }))}
              placeholder="Add verification evidence, test results, or additional notes..."
              data-testid="evidence-input"
            />
          </div>
          
          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={onClose} data-testid="cancel-button">
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={createRequirement.isPending || updateRequirement.isPending}
              data-testid="save-button"
            >
              {isEditing ? "Update Requirement" : "Create Requirement"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
