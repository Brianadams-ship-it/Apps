import { useState, useMemo } from "react";
import { ExternalLink, AlertTriangle, CheckCircle, Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useRequirements, useRequirementRelationships } from "@/hooks/use-requirements";
import { usePbsItems, useProjectPbsMappings } from "@/hooks/use-pbs";
import { useVerificationItemsByProject } from "@/hooks/use-verification";
import { Requirement, PbsItem, VerificationItem, RequirementPbsMapping, RequirementRelationship } from "@shared/schema";
import RequirementRelationships from "./requirement-relationships";

interface TraceabilityMatrixProps {
  projectId: string;
}

interface TraceabilityRow {
  requirement: Requirement;
  pbsItems: PbsItem[];
  verificationItems: VerificationItem[];
  relationships: RequirementRelationship[];
  coverage: {
    hasPbs: boolean;
    hasVerification: boolean;
    verificationComplete: boolean;
    hasRelationships: boolean;
  };
}

export default function TraceabilityMatrix({ projectId }: TraceabilityMatrixProps) {
  const { data: requirements = [] } = useRequirements(projectId);
  const { data: pbsItems = [] } = usePbsItems(projectId);
  const { data: pbsMappings = [] } = useProjectPbsMappings(projectId);
  const { data: verificationItems = [] } = useVerificationItemsByProject(projectId);
  const [searchTerm, setSearchTerm] = useState("");

  // Build traceability data structure
  const traceabilityData = useMemo(() => {
    const data: TraceabilityRow[] = [];

    requirements.forEach(requirement => {
      // Find PBS mappings for this requirement
      const requirementMappings = pbsMappings.filter(
        mapping => mapping.requirementId === requirement.id
      );
      
      // Get the actual PBS items from the mappings
      const requirementPbsItems = requirementMappings.map(mapping => 
        pbsItems.find(pbs => pbs.id === mapping.pbsItemId)
      ).filter(Boolean) as PbsItem[];
      
      // Find verification items for this requirement
      const requirementVerificationItems = verificationItems.filter(
        vi => vi.requirementId === requirement.id
      );

      // Calculate coverage
      const hasPbs = requirementPbsItems.length > 0;
      const hasVerification = requirementVerificationItems.length > 0;
      const verificationComplete = requirementVerificationItems.some(
        vi => vi.status === "Complete"
      );
      
      // For now, set relationships to empty array and hasRelationships to false
      // We'll fetch relationships individually when needed
      const requirementRelationships: RequirementRelationship[] = [];
      const hasRelationships = requirementRelationships.length > 0;

      data.push({
        requirement,
        pbsItems: requirementPbsItems,
        verificationItems: requirementVerificationItems,
        relationships: requirementRelationships,
        coverage: {
          hasPbs,
          hasVerification,
          verificationComplete,
          hasRelationships,
        },
      });
    });

    return data;
  }, [requirements, pbsItems, pbsMappings, verificationItems]);

  // Filter data based on search
  const filteredData = useMemo(() => {
    if (!searchTerm) return traceabilityData;
    
    return traceabilityData.filter(row => 
      row.requirement.reqId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      row.requirement.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
      row.pbsItems.some(pbs => 
        pbs.pbsId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        pbs.name.toLowerCase().includes(searchTerm.toLowerCase())
      ) ||
      row.verificationItems.some(vi =>
        vi.title.toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  }, [traceabilityData, searchTerm]);

  // Calculate coverage statistics
  const coverageStats = useMemo(() => {
    const total = traceabilityData.length;
    const withPbs = traceabilityData.filter(row => row.coverage.hasPbs).length;
    const withVerification = traceabilityData.filter(row => row.coverage.hasVerification).length;
    const verificationComplete = traceabilityData.filter(row => row.coverage.verificationComplete).length;
    
    return {
      total,
      withPbs,
      withVerification,
      verificationComplete,
      pbsCoverage: total > 0 ? Math.round((withPbs / total) * 100) : 0,
      verificationCoverage: total > 0 ? Math.round((withVerification / total) * 100) : 0,
      completionRate: total > 0 ? Math.round((verificationComplete / total) * 100) : 0,
    };
  }, [traceabilityData]);

  const getCoverageIcon = (coverage: TraceabilityRow['coverage']) => {
    if (coverage.verificationComplete) {
      return <CheckCircle className="w-4 h-4 text-green-600" />;
    } else if (coverage.hasVerification && coverage.hasPbs) {
      return <AlertTriangle className="w-4 h-4 text-amber-600" />;
    } else {
      return <AlertTriangle className="w-4 h-4 text-red-600" />;
    }
  };

  const getCoverageStatus = (coverage: TraceabilityRow['coverage']) => {
    if (coverage.verificationComplete) {
      return { text: "Complete", color: "bg-green-100 text-green-800" };
    } else if (coverage.hasVerification && coverage.hasPbs) {
      return { text: "In Progress", color: "bg-amber-100 text-amber-800" };
    } else if (coverage.hasPbs) {
      return { text: "PBS Only", color: "bg-blue-100 text-blue-800" };
    } else {
      return { text: "Not Traced", color: "bg-red-100 text-red-800" };
    }
  };

  return (
    <div className="space-y-6">
      {/* Coverage Statistics */}
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">PBS Coverage</p>
                <p className="text-2xl font-bold" data-testid="pbs-coverage">{coverageStats.pbsCoverage}%</p>
              </div>
              <div className="text-sm text-muted-foreground">
                {coverageStats.withPbs}/{coverageStats.total}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Verification Coverage</p>
                <p className="text-2xl font-bold" data-testid="verification-coverage">{coverageStats.verificationCoverage}%</p>
              </div>
              <div className="text-sm text-muted-foreground">
                {coverageStats.withVerification}/{coverageStats.total}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Completion Rate</p>
                <p className="text-2xl font-bold" data-testid="completion-rate">{coverageStats.completionRate}%</p>
              </div>
              <div className="text-sm text-muted-foreground">
                {coverageStats.verificationComplete}/{coverageStats.total}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Requirements</p>
                <p className="text-2xl font-bold" data-testid="total-requirements">{coverageStats.total}</p>
              </div>
              <div className="text-sm text-muted-foreground">
                Requirements
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Traceability Matrix */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Traceability Matrix</CardTitle>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search requirements, PBS items, verification..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-80 pl-10"
                  data-testid="search-traceability"
                />
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent>
          <TooltipProvider>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-32">Status</TableHead>
                  <TableHead>Requirement</TableHead>
                  <TableHead>PBS Items</TableHead>
                  <TableHead>Verification Items</TableHead>
                  <TableHead>Relationships</TableHead>
                  <TableHead className="w-32">Coverage</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredData.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      {traceabilityData.length === 0 
                        ? "No requirements found. Create requirements to see traceability."
                        : "No items match your search criteria."
                      }
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredData.map((row) => {
                    const status = getCoverageStatus(row.coverage);
                    return (
                      <TableRow key={row.requirement.id} data-testid={`traceability-row-${row.requirement.id}`}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {getCoverageIcon(row.coverage)}
                            <Badge variant="outline" className={status.color}>
                              {status.text}
                            </Badge>
                          </div>
                        </TableCell>

                        <TableCell>
                          <div>
                            <div className="font-medium">{row.requirement.reqId}</div>
                            <div className="text-sm text-muted-foreground mt-1">
                              {row.requirement.text.length > 100 
                                ? `${row.requirement.text.substring(0, 100)}...`
                                : row.requirement.text
                              }
                            </div>
                            <div className="flex gap-2 mt-2">
                              <Badge variant="outline" className="text-xs">
                                {row.requirement.verification || "TBD"}
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                {row.requirement.status}
                              </Badge>
                            </div>
                          </div>
                        </TableCell>

                        <TableCell>
                          {row.pbsItems.length > 0 ? (
                            <div className="space-y-1">
                              {row.pbsItems.map(pbs => (
                                <div key={pbs.id} className="flex items-center gap-2">
                                  <Badge variant="outline">{pbs.pbsId}</Badge>
                                  <span className="text-sm">{pbs.name}</span>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <AlertTriangle className="w-4 h-4" />
                              <span className="text-sm">No PBS mapping</span>
                            </div>
                          )}
                        </TableCell>

                        <TableCell>
                          {row.verificationItems.length > 0 ? (
                            <div className="space-y-1">
                              {row.verificationItems.map(vi => (
                                <div key={vi.id} className="flex items-center justify-between">
                                  <div>
                                    <div className="text-sm font-medium">{vi.title}</div>
                                    <div className="flex gap-2 mt-1">
                                      <Badge variant="outline" className="text-xs">{vi.method}</Badge>
                                      <Badge 
                                        variant="outline" 
                                        className={`text-xs ${
                                          vi.status === "Complete" ? "bg-green-100 text-green-800" :
                                          vi.status === "In Progress" ? "bg-blue-100 text-blue-800" :
                                          vi.status === "Failed" ? "bg-red-100 text-red-800" :
                                          "bg-gray-100 text-gray-800"
                                        }`}
                                      >
                                        {vi.status}
                                      </Badge>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <AlertTriangle className="w-4 h-4" />
                              <span className="text-sm">No verification</span>
                            </div>
                          )}
                        </TableCell>

                        <TableCell>
                          <div className="max-w-xs">
                            <RequirementRelationships 
                              projectId={projectId}
                              requirementId={row.requirement.id}
                              requirementReqId={row.requirement.reqId}
                            />
                          </div>
                        </TableCell>

                        <TableCell>
                          <Tooltip>
                            <TooltipTrigger>
                              <div className="flex items-center gap-1">
                                {row.coverage.hasPbs && (
                                  <CheckCircle className="w-4 h-4 text-green-600" />
                                )}
                                {row.coverage.hasVerification && (
                                  <CheckCircle className="w-4 h-4 text-blue-600" />
                                )}
                                {!row.coverage.hasPbs && !row.coverage.hasVerification && (
                                  <AlertTriangle className="w-4 h-4 text-red-600" />
                                )}
                              </div>
                            </TooltipTrigger>
                            <TooltipContent>
                              <div className="text-sm">
                                <div>PBS Mapped: {row.coverage.hasPbs ? "Yes" : "No"}</div>
                                <div>Verification: {row.coverage.hasVerification ? "Yes" : "No"}</div>
                                <div>Complete: {row.coverage.verificationComplete ? "Yes" : "No"}</div>
                              </div>
                            </TooltipContent>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </TooltipProvider>
        </CardContent>
      </Card>
    </div>
  );
}