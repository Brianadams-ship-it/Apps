import { useState } from "react";
import { Link2, Plus, Trash2, ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertRequirementRelationshipSchema, type InsertRequirementRelationship } from "@shared/schema";
import { useRequirementRelationships, useCreateRequirementRelationship, useDeleteRequirementRelationship, useRequirements } from "@/hooks/use-requirements";
import { useToast } from "@/hooks/use-toast";

// Relationship types for requirement linking
const RELATIONSHIP_TYPES = [
  { value: "depends-on", label: "Depends On" },
  { value: "relates-to", label: "Related To" },
  { value: "conflicts-with", label: "Conflicts With" },
  { value: "derives-from", label: "Derives From" },
  { value: "refines", label: "Refines" },
  { value: "implements", label: "Implements" },
  { value: "satisfies", label: "Satisfies" },
  { value: "allocated-to", label: "Allocated To" },
] as const;

interface RequirementRelationshipsProps {
  projectId: string;
  requirementId: string;
  requirementReqId: string;
}

export default function RequirementRelationships({ 
  projectId, 
  requirementId, 
  requirementReqId 
}: RequirementRelationshipsProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  // Fetch data
  const { data: relationships = [] } = useRequirementRelationships(requirementId);
  const { data: allRequirements = [] } = useRequirements(projectId);
  
  // Mutations
  const createRelationship = useCreateRequirementRelationship();
  const deleteRelationship = useDeleteRequirementRelationship();

  // Form setup
  const form = useForm<InsertRequirementRelationship>({
    resolver: zodResolver(insertRequirementRelationshipSchema),
    defaultValues: {
      sourceRequirementId: requirementId,
      targetRequirementId: "",
      relationshipType: "implements",
      description: "",
      createdBy: null,
    },
  });

  // Get available requirements for selection (exclude current requirement)
  const availableRequirements = allRequirements.filter(req => req.id !== requirementId);

  // Helper function to get requirement by ID
  const getRequirementById = (id: string) => {
    return allRequirements.find(req => req.id === id);
  };

  // Helper function to get relationship type label
  const getRelationshipTypeLabel = (type: string) => {
    return RELATIONSHIP_TYPES.find((rt) => rt.value === type)?.label || type;
  };

  const handleCreateRelationship = async (data: InsertRequirementRelationship) => {
    try {
      await createRelationship.mutateAsync(data);
      form.reset();
      setIsDialogOpen(false);
      toast({
        title: "Success",
        description: "Requirement relationship created successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create relationship",
        variant: "destructive",
      });
    }
  };

  const handleDeleteRelationship = async (id: string) => {
    try {
      await deleteRelationship.mutateAsync(id);
      toast({
        title: "Success", 
        description: "Requirement relationship deleted successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete relationship",
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Link2 className="w-5 h-5" />
            Requirement Relationships
          </CardTitle>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" data-testid="button-add-relationship">
                <Plus className="w-4 h-4 mr-2" />
                Add Relationship
              </Button>
            </DialogTrigger>
            
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Requirement Relationship</DialogTitle>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleCreateRelationship)} className="space-y-4">
                  <div className="text-sm text-muted-foreground">
                    Source: <strong>{requirementReqId}</strong>
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="targetRequirementId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Target Requirement</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-target-requirement">
                              <SelectValue placeholder="Select target requirement" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {availableRequirements.map((req) => (
                              <SelectItem key={req.id} value={req.id}>
                                <div>
                                  <div className="font-medium">{req.reqId}</div>
                                  <div className="text-sm text-muted-foreground">
                                    {req.text.length > 60 ? `${req.text.substring(0, 60)}...` : req.text}
                                  </div>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="relationshipType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Relationship Type</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-relationship-type">
                              <SelectValue placeholder="Select relationship type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {RELATIONSHIP_TYPES.map((relType) => (
                              <SelectItem key={relType.value} value={relType.value}>
                                {relType.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description (Optional)</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Describe the relationship..."
                            {...field}
                            value={field.value || ""}
                            data-testid="input-relationship-description"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-end gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsDialogOpen(false)}
                      data-testid="button-cancel-relationship"
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createRelationship.isPending}
                      data-testid="button-create-relationship"
                    >
                      {createRelationship.isPending ? "Creating..." : "Create Relationship"}
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      
      <CardContent>
        {relationships.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground" data-testid="no-relationships-message">
            <Link2 className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No requirement relationships found.</p>
            <p className="text-sm">Add relationships to track dependencies and connections.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {relationships.map((relationship) => {
              const isSource = relationship.sourceRequirementId === requirementId;
              const relatedReqId = isSource ? relationship.targetRequirementId : relationship.sourceRequirementId;
              const relatedReq = getRequirementById(relatedReqId);
              
              if (!relatedReq) return null;
              
              return (
                <div
                  key={relationship.id}
                  className="flex items-center gap-3 p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                  data-testid={`relationship-${relationship.id}`}
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline" className="shrink-0">
                        {requirementReqId}
                      </Badge>
                      <ArrowRight className="w-4 h-4 text-muted-foreground" />
                      <Badge variant="outline" className="shrink-0">
                        {relatedReq.reqId}
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        {getRelationshipTypeLabel(relationship.relationshipType)}
                      </Badge>
                    </div>
                    
                    <div className="text-sm text-muted-foreground truncate">
                      {relatedReq.text}
                    </div>
                    
                    {relationship.description && (
                      <div className="text-xs text-muted-foreground mt-1 italic">
                        {relationship.description}
                      </div>
                    )}
                  </div>
                  
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleDeleteRelationship(relationship.id)}
                    disabled={deleteRelationship.isPending}
                    data-testid={`button-delete-relationship-${relationship.id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}