import { useState } from "react";
import { Edit, Trash2, Calendar, User, FileCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { useDeleteVerificationItem } from "@/hooks/use-verification";
import { useRequirements } from "@/hooks/use-requirements";
import { VerificationItem } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface VerificationTableProps {
  verificationItems: VerificationItem[];
  projectId: string;
  onEdit: (item: VerificationItem) => void;
  isLoading?: boolean;
}

export default function VerificationTable({ verificationItems, projectId, onEdit, isLoading }: VerificationTableProps) {
  const { toast } = useToast();
  const { data: requirements = [] } = useRequirements(projectId);
  const deleteVerificationItem = useDeleteVerificationItem();

  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [methodFilter, setMethodFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");

  // Filter verification items
  const filteredItems = verificationItems.filter(item => {
    const matchesStatus = statusFilter === "all" || item.status === statusFilter;
    const matchesMethod = methodFilter === "all" || item.method === methodFilter;
    const matchesSearch = searchTerm === "" || 
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.assignee?.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesStatus && matchesMethod && matchesSearch;
  });

  const getStatusBadge = (status: string) => {
    const variants: Record<string, any> = {
      "Planned": "secondary",
      "In Progress": "default",
      "Complete": "default", 
      "Failed": "destructive",
    };
    
    const colors: Record<string, string> = {
      "Planned": "bg-gray-100 text-gray-800",
      "In Progress": "bg-blue-100 text-blue-800",
      "Complete": "bg-green-100 text-green-800",
      "Failed": "bg-red-100 text-red-800",
    };

    return (
      <Badge variant={variants[status]} className={colors[status]}>
        {status}
      </Badge>
    );
  };

  const getMethodBadge = (method: string) => {
    const colors: Record<string, string> = {
      "Test": "bg-blue-100 text-blue-800",
      "Analysis": "bg-purple-100 text-purple-800",
      "Inspection": "bg-green-100 text-green-800",
      "Demonstration": "bg-orange-100 text-orange-800",
    };

    return (
      <Badge variant="outline" className={colors[method]}>
        {method}
      </Badge>
    );
  };

  const getRequirementInfo = (requirementId: string) => {
    const requirement = requirements.find(r => r.id === requirementId);
    return requirement ? `${requirement.reqId}` : "Unknown";
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteVerificationItem.mutateAsync(id);
      toast({
        title: "Success",
        description: "Verification item deleted successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete verification item",
        variant: "destructive",
      });
    }
  };

  const formatDueDate = (dueDate: Date | string | null) => {
    if (!dueDate) return "No due date";
    const date = typeof dueDate === 'string' ? new Date(dueDate) : dueDate;
    const now = new Date();
    const isOverdue = date < now;
    const formattedDate = formatDistanceToNow(date, { addSuffix: true });
    
    return (
      <span className={isOverdue ? "text-red-600 font-medium" : "text-muted-foreground"}>
        {formattedDate}
      </span>
    );
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center py-8">
            <div className="text-muted-foreground">Loading verification items...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Verification Items</CardTitle>
        
        {/* Filters */}
        <div className="flex gap-4 items-center">
          <Input
            placeholder="Search verification items..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-sm"
            data-testid="search-verification"
          />
          
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40" data-testid="filter-status">
              <SelectValue placeholder="All Statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="Planned">Planned</SelectItem>
              <SelectItem value="In Progress">In Progress</SelectItem>
              <SelectItem value="Complete">Complete</SelectItem>
              <SelectItem value="Failed">Failed</SelectItem>
            </SelectContent>
          </Select>

          <Select value={methodFilter} onValueChange={setMethodFilter}>
            <SelectTrigger className="w-40" data-testid="filter-method">
              <SelectValue placeholder="All Methods" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Methods</SelectItem>
              <SelectItem value="Test">Test</SelectItem>
              <SelectItem value="Analysis">Analysis</SelectItem>
              <SelectItem value="Inspection">Inspection</SelectItem>
              <SelectItem value="Demonstration">Demonstration</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      
      <CardContent>
        {filteredItems.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            {verificationItems.length === 0 
              ? "No verification items yet. Create your first verification item to get started."
              : "No verification items match your current filters."
            }
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Requirement</TableHead>
                <TableHead>Method</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Assignee</TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredItems.map((item) => (
                <TableRow key={item.id} data-testid={`verification-row-${item.id}`}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{item.title}</div>
                      {item.description && (
                        <div className="text-sm text-muted-foreground mt-1">
                          {item.description.length > 80 
                            ? `${item.description.substring(0, 80)}...` 
                            : item.description
                          }
                        </div>
                      )}
                    </div>
                  </TableCell>
                  
                  <TableCell>
                    <Badge variant="outline" data-testid={`requirement-${item.requirementId}`}>
                      {getRequirementInfo(item.requirementId)}
                    </Badge>
                  </TableCell>
                  
                  <TableCell>
                    {getMethodBadge(item.method)}
                  </TableCell>
                  
                  <TableCell>
                    {getStatusBadge(item.status || "Planned")}
                  </TableCell>
                  
                  <TableCell>
                    {item.assignee ? (
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-muted-foreground" />
                        <span>{item.assignee}</span>
                      </div>
                    ) : (
                      <span className="text-muted-foreground">Unassigned</span>
                    )}
                  </TableCell>
                  
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      {formatDueDate(item.dueDate)}
                    </div>
                  </TableCell>
                  
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onEdit(item)}
                        data-testid={`edit-verification-${item.id}`}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            data-testid={`delete-verification-${item.id}`}
                          >
                            <Trash2 className="w-4 h-4 text-red-600" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Verification Item</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete this verification item? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction 
                              onClick={() => handleDelete(item.id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}