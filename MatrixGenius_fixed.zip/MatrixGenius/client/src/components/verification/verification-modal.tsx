import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useRequirements } from "@/hooks/use-requirements";
import { useCreateVerificationItem, useUpdateVerificationItem } from "@/hooks/use-verification";
import { useToast } from "@/hooks/use-toast";
import { VerificationItem } from "@shared/schema";

interface VerificationModalProps {
  verificationItem: VerificationItem | null;
  projectId: string;
  onClose: () => void;
}

export default function VerificationModal({ verificationItem, projectId, onClose }: VerificationModalProps) {
  const { toast } = useToast();
  const { data: requirements = [] } = useRequirements(projectId);
  const createVerificationItem = useCreateVerificationItem();
  const updateVerificationItem = useUpdateVerificationItem();
  
  const isEditing = !!verificationItem;

  const [formData, setFormData] = useState({
    requirementId: "",
    title: "",
    description: "",
    method: "Test",
    status: "Planned",
    assignee: "",
    dueDate: "",
    evidence: "",
    notes: "",
  });

  useEffect(() => {
    if (verificationItem) {
      setFormData({
        requirementId: verificationItem.requirementId,
        title: verificationItem.title,
        description: verificationItem.description || "",
        method: verificationItem.method,
        status: verificationItem.status || "Planned",
        assignee: verificationItem.assignee || "",
        dueDate: verificationItem.dueDate ? new Date(verificationItem.dueDate).toISOString().split('T')[0] : "",
        evidence: verificationItem.evidence || "",
        notes: verificationItem.notes || "",
      });
    } else {
      setFormData({
        requirementId: "",
        title: "",
        description: "",
        method: "Test",
        status: "Planned",
        assignee: "",
        dueDate: "",
        evidence: "",
        notes: "",
      });
    }
  }, [verificationItem]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.requirementId || !formData.title) {
      toast({
        title: "Error",
        description: "Requirement and title are required",
        variant: "destructive",
      });
      return;
    }

    try {
      const data = {
        ...formData,
        dueDate: formData.dueDate ? new Date(formData.dueDate) : null,
      };

      if (isEditing && verificationItem) {
        await updateVerificationItem.mutateAsync({
          id: verificationItem.id,
          data,
        });
        toast({
          title: "Success",
          description: "Verification item updated successfully",
        });
      } else {
        await createVerificationItem.mutateAsync(data);
        toast({
          title: "Success",
          description: "Verification item created successfully",
        });
      }
      
      onClose();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save verification item",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={true} onOpenChange={() => onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Edit Verification Item" : "Create Verification Item"}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="requirement">Requirement *</Label>
              <Select 
                value={formData.requirementId} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, requirementId: value }))}
              >
                <SelectTrigger data-testid="select-requirement">
                  <SelectValue placeholder="Select requirement" />
                </SelectTrigger>
                <SelectContent>
                  {requirements.map(req => (
                    <SelectItem key={req.id} value={req.id}>
                      {req.reqId} - {req.text.substring(0, 50)}...
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="method">Verification Method</Label>
              <Select 
                value={formData.method} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, method: value }))}
              >
                <SelectTrigger data-testid="select-method">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Test">Test</SelectItem>
                  <SelectItem value="Analysis">Analysis</SelectItem>
                  <SelectItem value="Inspection">Inspection</SelectItem>
                  <SelectItem value="Demonstration">Demonstration</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Enter verification item title"
              data-testid="input-title"
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Enter detailed description"
              data-testid="textarea-description"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="status">Status</Label>
              <Select 
                value={formData.status} 
                onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
              >
                <SelectTrigger data-testid="select-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Planned">Planned</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="Complete">Complete</SelectItem>
                  <SelectItem value="Failed">Failed</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="assignee">Assignee</Label>
              <Input
                id="assignee"
                value={formData.assignee}
                onChange={(e) => setFormData(prev => ({ ...prev, assignee: e.target.value }))}
                placeholder="Enter assignee name"
                data-testid="input-assignee"
              />
            </div>

            <div>
              <Label htmlFor="dueDate">Due Date</Label>
              <Input
                id="dueDate"
                type="date"
                value={formData.dueDate}
                onChange={(e) => setFormData(prev => ({ ...prev, dueDate: e.target.value }))}
                data-testid="input-due-date"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="evidence">Evidence</Label>
            <Textarea
              id="evidence"
              value={formData.evidence}
              onChange={(e) => setFormData(prev => ({ ...prev, evidence: e.target.value }))}
              placeholder="Enter evidence or test results"
              data-testid="textarea-evidence"
            />
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Additional notes or comments"
              data-testid="textarea-notes"
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={createVerificationItem.isPending || updateVerificationItem.isPending}
              data-testid="button-save"
            >
              {isEditing ? "Update" : "Create"} Verification Item
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}