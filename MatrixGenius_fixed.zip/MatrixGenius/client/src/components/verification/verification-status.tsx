import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, AlertTriangle, FileText, Microscope, Eye, Play } from "lucide-react";
import { useRequirements } from "@/hooks/use-requirements";

interface VerificationStatusProps {
  projectId: string;
}

interface VerificationMethod {
  name: string;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  total: number;
  completed: number;
  inProgress: number;
  blocked: number;
}

export default function VerificationStatus({ projectId }: VerificationStatusProps) {
  const { data: requirements = [] } = useRequirements(projectId);

  // Calculate verification method statistics
  const verificationMethods: VerificationMethod[] = [
    {
      name: "Test Procedures",
      icon: FileText,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
      total: 0,
      completed: 0,
      inProgress: 0,
      blocked: 0,
    },
    {
      name: "Analysis Reports", 
      icon: Microscope,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
      total: 0,
      completed: 0,
      inProgress: 0,
      blocked: 0,
    },
    {
      name: "Inspections",
      icon: Eye,
      color: "text-green-600",
      bgColor: "bg-green-100",
      total: 0,
      completed: 0,
      inProgress: 0,
      blocked: 0,
    },
    {
      name: "Demonstrations",
      icon: Play,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
      total: 0,
      completed: 0,
      inProgress: 0,
      blocked: 0,
    },
  ];

  // Populate statistics from requirements data
  requirements.forEach(req => {
    const methodIndex = (() => {
      switch (req.verification) {
        case "Test": return 0;
        case "Analysis": return 1;
        case "Inspection": return 2;
        case "Demonstration": return 3;
        default: return -1;
      }
    })();

    if (methodIndex >= 0) {
      verificationMethods[methodIndex].total++;
      
      switch (req.status) {
        case "Closed":
          verificationMethods[methodIndex].completed++;
          break;
        case "In Progress":
          verificationMethods[methodIndex].inProgress++;
          break;
        case "Blocked":
          verificationMethods[methodIndex].blocked++;
          break;
      }
    }
  });

  // Overall statistics
  const totalRequirements = requirements.length;
  const completedRequirements = requirements.filter(r => r.status === "Closed").length;
  const inProgressRequirements = requirements.filter(r => r.status === "In Progress").length;
  const blockedRequirements = requirements.filter(r => r.status === "Blocked").length;
  
  const overallProgress = totalRequirements > 0 
    ? Math.round((completedRequirements / totalRequirements) * 100)
    : 0;

  return (
    <div className="space-y-4" data-testid="verification-status">
      {/* Overall Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-600" />
            Overall Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Completion Rate</span>
              <span className="text-lg font-bold text-green-600">{overallProgress}%</span>
            </div>
            <Progress value={overallProgress} className="h-3" />
            
            <div className="grid grid-cols-3 gap-3 text-center text-sm">
              <div>
                <div className="flex items-center justify-center gap-1 mb-1">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-muted-foreground">Complete</span>
                </div>
                <div className="font-semibold">{completedRequirements}</div>
              </div>
              <div>
                <div className="flex items-center justify-center gap-1 mb-1">
                  <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                  <span className="text-muted-foreground">In Progress</span>
                </div>
                <div className="font-semibold">{inProgressRequirements}</div>
              </div>
              <div>
                <div className="flex items-center justify-center gap-1 mb-1">
                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                  <span className="text-muted-foreground">Blocked</span>
                </div>
                <div className="font-semibold">{blockedRequirements}</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Verification Methods Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Verification Methods</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {verificationMethods.map((method, index) => {
              const completionRate = method.total > 0 
                ? Math.round((method.completed / method.total) * 100)
                : 0;
              
              return (
                <div key={index} className="space-y-2" data-testid={`verification-method-${method.name.toLowerCase().replace(/\s+/g, '-')}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 ${method.bgColor} rounded-lg flex items-center justify-center`}>
                        <method.icon className={`w-4 h-4 ${method.color}`} />
                      </div>
                      <div>
                        <span className="text-sm font-medium">{method.name}</span>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {method.completed}/{method.total}
                          </Badge>
                          {method.inProgress > 0 && (
                            <Badge variant="secondary" className="text-xs">
                              <Clock className="w-3 h-3 mr-1" />
                              {method.inProgress}
                            </Badge>
                          )}
                          {method.blocked > 0 && (
                            <Badge variant="destructive" className="text-xs">
                              <AlertTriangle className="w-3 h-3 mr-1" />
                              {method.blocked}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    <span className="text-sm font-semibold">{completionRate}%</span>
                  </div>
                  
                  {method.total > 0 && (
                    <Progress value={completionRate} className="h-2" />
                  )}
                  
                  {method.total === 0 && (
                    <div className="text-xs text-muted-foreground">
                      No requirements using this verification method
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <button className="w-full text-left p-2 text-sm hover:bg-accent rounded-md transition-colors">
              📋 Generate Test Procedures
            </button>
            <button className="w-full text-left p-2 text-sm hover:bg-accent rounded-md transition-colors">
              📊 Export Verification Matrix
            </button>
            <button className="w-full text-left p-2 text-sm hover:bg-accent rounded-md transition-colors">
              📝 Create Verification Plan
            </button>
            <button className="w-full text-left p-2 text-sm hover:bg-accent rounded-md transition-colors">
              ⚠️ Review Blocked Items
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
