import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Edit, Users, Calendar, Target, TrendingUp, X } from "lucide-react";
import { usePbsItems, useRequirementPbsMappings, useDeleteRequirementPbsMapping } from "@/hooks/use-pbs";
import { useRequirements } from "@/hooks/use-requirements";
import { useToast } from "@/hooks/use-toast";

interface PbsItemDetailsProps {
  pbsItemId: string;
}

export default function PbsItemDetails({ pbsItemId }: PbsItemDetailsProps) {
  const { toast } = useToast();
  const { data: pbsItems = [] } = usePbsItems("project-1");
  const { data: requirements = [] } = useRequirements("project-1");
  const deleteMapping = useDeleteRequirementPbsMapping();

  const pbsItem = pbsItems.find(item => item.id === pbsItemId);
  
  // Get all mappings for this PBS item
  const allMappings = requirements.flatMap(req => {
    const { data: mappings = [] } = useRequirementPbsMappings(req.id);
    return mappings.filter(mapping => mapping.pbsItemId === pbsItemId)
      .map(mapping => ({ ...mapping, requirement: req }));
  });

  if (!pbsItem) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-muted-foreground">
            PBS item not found.
          </div>
        </CardContent>
      </Card>
    );
  }

  const mappedRequirements = allMappings.map(mapping => mapping.requirement);
  const completedRequirements = mappedRequirements.filter(req => req.status === "Closed").length;
  const inProgressRequirements = mappedRequirements.filter(req => req.status === "In Progress").length;
  const blockedRequirements = mappedRequirements.filter(req => req.status === "Blocked").length;
  
  const completionRate = mappedRequirements.length > 0 
    ? Math.round((completedRequirements / mappedRequirements.length) * 100)
    : 0;

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      "Open": "bg-blue-100 text-blue-800",
      "In Progress": "bg-amber-100 text-amber-800", 
      "Closed": "bg-green-100 text-green-800",
      "Blocked": "bg-red-100 text-red-800",
    };

    return (
      <Badge className={colors[status] || "bg-gray-100 text-gray-800"}>
        {status}
      </Badge>
    );
  };

  const getVerificationBadge = (verification: string) => {
    const colors: Record<string, string> = {
      "Test": "bg-blue-100 text-blue-800",
      "Analysis": "bg-purple-100 text-purple-800",
      "Inspection": "bg-green-100 text-green-800",
      "Demonstration": "bg-orange-100 text-orange-800",
      "TBD": "bg-gray-100 text-gray-800",
    };

    return (
      <Badge className={colors[verification] || "bg-gray-100 text-gray-800"}>
        {verification}
      </Badge>
    );
  };

  const handleRemoveMapping = async (requirementId: string) => {
    try {
      await deleteMapping.mutateAsync({ requirementId, pbsItemId });
      toast({
        title: "Mapping removed",
        description: "Requirement mapping has been removed from PBS item.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to remove mapping. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-4" data-testid="pbs-item-details">
      {/* PBS Item Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                  <span className="text-sm">📦</span>
                </div>
                <div>
                  <CardTitle className="text-xl">{pbsItem.name}</CardTitle>
                  <Badge variant="outline" className="font-mono text-sm">
                    {pbsItem.pbsId}
                  </Badge>
                </div>
              </div>
              {pbsItem.description && (
                <p className="text-muted-foreground">{pbsItem.description}</p>
              )}
            </div>
            <Button variant="outline" size="sm">
              <Edit className="w-4 h-4 mr-2" />
              Edit
            </Button>
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="grid grid-cols-4 gap-4">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Owner</p>
                <p className="font-medium">{pbsItem.owner || "Unassigned"}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Status</p>
                <Badge variant={pbsItem.status === "Active" ? "default" : "secondary"}>
                  {pbsItem.status}
                </Badge>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Progress</p>
                <p className="font-medium">{pbsItem.progress || 0}%</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Level</p>
                <p className="font-medium">Level {pbsItem.level}</p>
              </div>
            </div>
          </div>
          
          <Separator className="my-4" />
          
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Overall Progress</span>
              <span className="text-sm font-medium">{completionRate}%</span>
            </div>
            <Progress value={completionRate} className="h-2" />
          </div>
        </CardContent>
      </Card>

      {/* Requirements Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Requirements Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-4 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">{mappedRequirements.length}</div>
              <div className="text-sm text-muted-foreground">Total</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{completedRequirements}</div>
              <div className="text-sm text-muted-foreground">Completed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-600">{inProgressRequirements}</div>
              <div className="text-sm text-muted-foreground">In Progress</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{blockedRequirements}</div>
              <div className="text-sm text-muted-foreground">Blocked</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Mapped Requirements */}
      <Card>
        <CardHeader>
          <CardTitle>Mapped Requirements ({mappedRequirements.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {mappedRequirements.length > 0 ? (
            <div className="space-y-3">
              {mappedRequirements.map((req) => (
                <div
                  key={req.id}
                  className="border rounded-lg p-3 hover:bg-accent/50 transition-colors"
                  data-testid={`mapped-requirement-${req.reqId}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline" className="font-mono text-xs">
                          {req.reqId}
                        </Badge>
                        {getStatusBadge(req.status || "Open")}
                        {getVerificationBadge(req.verification || "TBD")}
                      </div>
                      <p className="text-sm font-medium mb-1">{req.text}</p>
                      {req.source && (
                        <p className="text-xs text-muted-foreground">{req.source}</p>
                      )}
                      {req.owner && (
                        <div className="flex items-center gap-2 mt-2">
                          <div className="w-5 h-5 bg-blue-500 rounded-full text-white text-xs flex items-center justify-center">
                            {req.owner.charAt(0).toUpperCase()}
                          </div>
                          <span className="text-xs text-muted-foreground">{req.owner}</span>
                        </div>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveMapping(req.id)}
                      className="text-destructive hover:text-destructive"
                      data-testid={`remove-mapping-${req.reqId}`}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Target className="w-8 h-8 mx-auto mb-2" />
              <p>No requirements mapped to this PBS item.</p>
              <p className="text-sm">Drag requirements from the table to create mappings.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
