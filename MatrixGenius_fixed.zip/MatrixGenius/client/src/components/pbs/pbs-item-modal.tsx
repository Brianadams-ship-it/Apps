import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useCreatePbsItem, usePbsItems } from "@/hooks/use-pbs";

interface PbsItemModalProps {
  projectId: string;
  onClose: () => void;
}

export default function PbsItemModal({ projectId, onClose }: PbsItemModalProps) {
  const { toast } = useToast();
  const { data: pbsItems = [] } = usePbsItems(projectId);
  const createPbsItem = useCreatePbsItem();

  const [formData, setFormData] = useState({
    pbsId: "",
    name: "",
    description: "",
    parentId: "none",
    level: 1,
    icon: "cube",
    color: "blue",
    owner: "",
    status: "Active",
    progress: 0,
  });

  useEffect(() => {
    // Generate next PBS ID
    const existingPbsIds = pbsItems.map(p => p.pbsId).filter(id => id.includes("-"));
    const prefixes = ["FC", "NAV", "PWR", "COM", "SYS", "TEST"];
    
    // Find the next available ID - try TEST prefix first for new items
    const testIds = existingPbsIds.filter(id => id.startsWith("TEST-"));
    const maxTestNumber = testIds.reduce((max, id) => {
      const num = parseInt(id.split("-")[1], 10);
      return isNaN(num) ? max : Math.max(max, num);
    }, 0);
    const nextPbsId = `TEST-${String(maxTestNumber + 1).padStart(3, "0")}`;
    
    setFormData(prev => ({ ...prev, pbsId: nextPbsId }));
  }, [pbsItems]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.pbsId.trim() || !formData.name.trim()) {
      toast({
        title: "Validation Error",
        description: "PBS ID and Name are required.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      await createPbsItem.mutateAsync({
        ...formData,
        projectId,
        parentId: formData.parentId === "none" ? null : formData.parentId,
        level: formData.parentId && formData.parentId !== "none" ? 2 : 1, // Set level based on parent
      });
      
      toast({
        title: "PBS Item created",
        description: `${formData.pbsId} has been created successfully.`,
      });
      onClose();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create PBS item. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const availableParents = pbsItems.filter(item => !item.parentId); // Only root items as parents

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create PBS Item</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="pbsId">PBS ID *</Label>
              <Input
                id="pbsId"
                value={formData.pbsId}
                onChange={(e) => handleInputChange("pbsId", e.target.value)}
                placeholder="TEST-001"
                data-testid="input-pbs-id"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                placeholder="Component name"
                data-testid="input-pbs-name"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange("description", e.target.value)}
              placeholder="Describe the PBS item..."
              className="min-h-[80px]"
              data-testid="input-description"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="parentId">Parent Item</Label>
              <Select value={formData.parentId} onValueChange={(value) => handleInputChange("parentId", value)}>
                <SelectTrigger data-testid="select-parent">
                  <SelectValue placeholder="Select parent (optional)" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None (Root Level)</SelectItem>
                  {availableParents.map((parent) => (
                    <SelectItem key={parent.id} value={parent.id}>
                      {parent.name} ({parent.pbsId})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="owner">Owner</Label>
              <Input
                id="owner"
                value={formData.owner}
                onChange={(e) => handleInputChange("owner", e.target.value)}
                placeholder="Responsible person"
                data-testid="input-owner"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="icon">Icon</Label>
              <Select value={formData.icon} onValueChange={(value) => handleInputChange("icon", value)}>
                <SelectTrigger data-testid="select-icon">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cube">🧊 Cube</SelectItem>
                  <SelectItem value="microchip">🔧 Microchip</SelectItem>
                  <SelectItem value="cog">⚙️ Cog</SelectItem>
                  <SelectItem value="satellite">📡 Satellite</SelectItem>
                  <SelectItem value="bolt">⚡ Bolt</SelectItem>
                  <SelectItem value="battery-three-quarters">🔋 Battery</SelectItem>
                  <SelectItem value="plug">🔌 Plug</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="color">Color</Label>
              <Select value={formData.color} onValueChange={(value) => handleInputChange("color", value)}>
                <SelectTrigger data-testid="select-color">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="blue">Blue</SelectItem>
                  <SelectItem value="green">Green</SelectItem>
                  <SelectItem value="purple">Purple</SelectItem>
                  <SelectItem value="amber">Amber</SelectItem>
                  <SelectItem value="red">Red</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(value) => handleInputChange("status", value)}>
                <SelectTrigger data-testid="select-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Inactive">Inactive</SelectItem>
                  <SelectItem value="Complete">Complete</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={createPbsItem.isPending}
              data-testid="button-save"
            >
              {createPbsItem.isPending ? "Creating..." : "Create PBS Item"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}