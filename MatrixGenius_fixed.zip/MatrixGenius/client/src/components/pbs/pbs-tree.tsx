import { useState } from "react";
import { useDrag } from "react-dnd";
import { ChevronDown, ChevronRight, Plus, GripVertical } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { usePbsItems } from "@/hooks/use-pbs";
import { PbsItem } from "@shared/schema";
import { ItemTypes } from "@/types";
import PbsItemModal from "./pbs-item-modal";

interface PbsTreeProps {
  projectId: string;
  onItemSelect?: (itemId: string) => void;
  selectedItem?: string | null;
}

interface PbsNodeProps {
  item: PbsItem;
  children: PbsItem[];
  level: number;
  onSelect?: (itemId: string) => void;
  isSelected?: boolean;
}

function PbsNode({ item, children, level, onSelect, isSelected }: PbsNodeProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  
  const [{ isDragging }, drag] = useDrag(() => ({
    type: ItemTypes.PBS_ITEM,
    item: {
      type: ItemTypes.PBS_ITEM,
      id: item.id,
      pbsId: item.pbsId,
      name: item.name,
    },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }));

  const getIcon = (iconName: string) => {
    // Map icon names to actual components or return default
    const iconMap: Record<string, string> = {
      cube: "🧊",
      microchip: "🔧",
      cog: "⚙️",
      satellite: "📡",
      bolt: "⚡",
      "battery-three-quarters": "🔋",
      plug: "🔌",
    };
    
    return iconMap[iconName] || "📄";
  };

  const getColorClass = (color: string) => {
    const colorMap: Record<string, string> = {
      blue: "text-blue-600",
      green: "text-green-600",
      purple: "text-purple-600",
      amber: "text-amber-600",
      red: "text-red-600",
    };
    
    return colorMap[color] || "text-gray-600";
  };

  return (
    <div className={`${level > 1 ? 'ml-4' : ''}`}>
      <div
        ref={drag}
        className={`flex items-center gap-2 p-2 rounded-md cursor-pointer transition-colors ${
          isSelected 
            ? "bg-blue-50 border border-blue-200" 
            : "hover:bg-accent"
        } ${isDragging ? "opacity-50" : ""}`}
        onClick={() => onSelect?.(item.id)}
        data-testid={`pbs-item-${item.pbsId}`}
      >
        {children.length > 0 && (
          <Button
            variant="ghost"
            size="sm"
            className="h-auto p-0 w-3"
            onClick={(e) => {
              e.stopPropagation();
              setIsExpanded(!isExpanded);
            }}
          >
            {isExpanded ? (
              <ChevronDown className="w-3 h-3" />
            ) : (
              <ChevronRight className="w-3 h-3" />
            )}
          </Button>
        )}
        
        {children.length === 0 && (
          <GripVertical className="w-3 h-3 text-muted-foreground" />
        )}
        
        <span className={`text-sm ${getColorClass(item.color || "blue")}`}>
          {getIcon(item.icon || "cube")}
        </span>
        
        <span className="text-sm font-medium flex-1">{item.name}</span>
        
        <Badge variant="outline" className="text-xs font-mono">
          {item.pbsId}
        </Badge>
      </div>
      
      {isExpanded && children.length > 0 && (
        <div className="space-y-1 mt-1">
          {children.map((child) => (
            <PbsTreeNode
              key={child.id}
              itemId={child.id}
              projectId={item.projectId}
              level={level + 1}
              onSelect={onSelect}
              isSelected={isSelected}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function PbsTreeNode({ 
  itemId, 
  projectId, 
  level, 
  onSelect, 
  isSelected 
}: { 
  itemId: string; 
  projectId: string; 
  level: number; 
  onSelect?: (itemId: string) => void;
  isSelected?: boolean;
}) {
  const { data: pbsItems = [] } = usePbsItems(projectId);
  
  const item = pbsItems.find(i => i.id === itemId);
  const children = pbsItems.filter(i => i.parentId === itemId);
  
  if (!item) return null;
  
  return (
    <PbsNode
      item={item}
      children={children}
      level={level}
      onSelect={onSelect}
      isSelected={isSelected}
    />
  );
}

export default function PbsTree({ projectId, onItemSelect, selectedItem }: PbsTreeProps) {
  const { data: pbsItems = [], isLoading } = usePbsItems(projectId);
  const [showCreateModal, setShowCreateModal] = useState(false);
  
  const rootItems = pbsItems.filter(item => !item.parentId);

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="text-center">Loading PBS structure...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="pbs-tree">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">PBS Structure</CardTitle>
          <Button 
            variant="ghost" 
            size="sm" 
            data-testid="add-pbs-item"
            onClick={() => setShowCreateModal(true)}
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>
        <p className="text-sm text-muted-foreground">Drag items to requirements</p>
      </CardHeader>
      
      <CardContent className="p-4">
        <div className="space-y-2">
          {rootItems.map((item) => (
            <PbsTreeNode
              key={item.id}
              itemId={item.id}
              projectId={projectId}
              level={1}
              onSelect={onItemSelect}
              isSelected={selectedItem === item.id}
            />
          ))}
          
          {rootItems.length === 0 && (
            <div className="text-center py-4 text-muted-foreground">
              <p>No PBS items found.</p>
              <Button variant="outline" size="sm" className="mt-2">
                <Plus className="w-4 h-4 mr-2" />
                Create PBS Structure
              </Button>
            </div>
          )}
        </div>
      </CardContent>
      
      {showCreateModal && (
        <PbsItemModal
          projectId={projectId}
          onClose={() => setShowCreateModal(false)}
        />
      )}
    </Card>
  );
}
