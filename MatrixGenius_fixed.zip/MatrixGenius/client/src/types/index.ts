// Re-export from shared schema for client use
export type { ExtractedRequirement, ExtractionConfig } from "@shared/schema";

export interface DragItem {
  type: string;
  id: string;
  pbsId: string;
  name: string;
}

export interface DropResult {
  requirementId: string;
  pbsItemId: string;
}

export const ItemTypes = {
  PBS_ITEM: 'pbs_item',
} as const;

export interface ProjectStats {
  totalRequirements: number;
  verifiedRequirements: number;
  inProgressRequirements: number;
  issuesCount: number;
  completionRate: number;
}
