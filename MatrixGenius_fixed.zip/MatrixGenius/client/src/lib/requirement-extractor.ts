import { ExtractedRequirement, ExtractionConfig } from "@/types";

// Utility: generate incremental IDs like REQ-001
const makeIdGen = (prefix = "REQ-", pad = 3) => {
  let n = 1;
  return () => `${prefix}${String(n++).padStart(pad, "0")}`;
};

// Very lightweight heuristic requirement extractor
export const extractRequirements = (rawText: string, options: ExtractionConfig): ExtractedRequirement[] => {
  const {
    includeShould = true,
    minLen = 20,
    captureContext = true,
    idPrefix = "REQ-",
  } = options;

  if (!rawText) return [];

  const idGen = makeIdGen(idPrefix);
  const lines = rawText
    .replace(/\r/g, "\n")
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);

  const ctxStack: string[] = [];
  const out: ExtractedRequirement[] = [];
  const reqRegex = includeShould
    ? /(\bshall\b|\bmust\b|\brequired\b|\bshould\b)/i
    : /(\bshall\b|\bmust\b|\brequired\b)/i;

  const headingRegex = /^(\d+(?:\.\d+)*|[A-Z]\.|[IVXLC]+\.)\s+(.+)/; // 1, 1.2, A., I.

  lines.forEach((line, idx) => {
    const headingMatch = line.match(headingRegex);
    if (captureContext && headingMatch) {
      const label = headingMatch[1];
      const title = headingMatch[2];
      ctxStack.push(`${label} ${title}`);
      // Trim stack to last 6 to avoid bloat
      if (ctxStack.length > 6) ctxStack.shift();
    }

    const isReq = reqRegex.test(line) && line.replace(/\s+/g, " ").length >= minLen;
    if (isReq) {
      const id = idGen();
      const context = captureContext ? ctxStack.slice(-3).join(" › ") : "";
      out.push({
        id,
        text: line,
        source: context || `Line ${idx + 1}`,
        compliance: "TBD",
        verification: suggestVerification(line),
        owner: "",
        status: "Open",
        evidence: "",
        notes: "",
      });
    }
  });

  // If we found nothing, try a paragraph-based fallback with SHALL-only
  if (out.length === 0) {
    const paras = rawText.split(/\n\s*\n/).map((p) => p.trim());
    paras.forEach((p, i) => {
      if (/(\bshall\b|\bmust\b)/i.test(p) && p.length >= minLen) {
        out.push({
          id: idGen(),
          text: p.replace(/\s+/g, " ").trim(),
          source: `Para ${i + 1}`,
          compliance: "TBD",
          verification: suggestVerification(p),
          owner: "",
          status: "Open",
          evidence: "",
          notes: "",
        });
      }
    });
  }

  return out;
};

// Very simple verification classifier
function suggestVerification(text: string): string {
  const t = text.toLowerCase();
  if (/test|demonstrate|perform|validate|measure/.test(t)) return "Test";
  if (/analy(s|z)e|model|simulate|calc/.test(t)) return "Analysis";
  if (/inspect|visual|conform/.test(t)) return "Inspection";
  if (/show|prove|operate|function/.test(t)) return "Demonstration";
  return "TBD";
}
