import Header from "@/components/layout/header";
import TraceabilityMatrix from "@/components/traceability/traceability-matrix";

// Using fixed project ID for demo purposes
const PROJECT_ID = "project-1";

export default function Traceability() {
  return (
    <div className="flex-1 flex flex-col">
      <Header 
        title="Traceability Matrix"
        subtitle="End-to-end requirement traceability"
      />
      
      <div className="flex-1 p-6 overflow-auto">
        <TraceabilityMatrix projectId={PROJECT_ID} />
      </div>
    </div>
  );
}
