import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LogOut, Settings, User } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { user } = useAuth();

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const getInitials = (firstName?: string | null, lastName?: string | null) => {
    const first = firstName?.charAt(0)?.toUpperCase() || "";
    const last = lastName?.charAt(0)?.toUpperCase() || "";
    return first + last || "U";
  };

  const getDisplayName = (firstName?: string | null, lastName?: string | null, email?: string | null) => {
    if (firstName || lastName) {
      return `${firstName || ""} ${lastName || ""}`.trim();
    }
    return email || "User";
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Welcome to ReqMatrix</h1>
            <p className="text-gray-600">Requirements management and compliance tracking platform</p>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <Avatar data-testid="user-avatar">
                <AvatarImage src={user?.profileImageUrl || ""} alt="Profile" />
                <AvatarFallback>
                  {getInitials(user?.firstName, user?.lastName)}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium" data-testid="user-name">
                  {getDisplayName(user?.firstName, user?.lastName, user?.email)}
                </p>
                <p className="text-sm text-gray-500" data-testid="user-email">
                  {user?.email}
                </p>
              </div>
            </div>
            
            <Button variant="outline" onClick={handleLogout} data-testid="logout-button">
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>

        {/* Quick Navigation */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Link href="/dashboard">
            <Card className="cursor-pointer hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                    <div className="w-4 h-4 bg-blue-600 rounded"></div>
                  </div>
                  Dashboard
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Project overview and analytics
                </p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/requirements">
            <Card className="cursor-pointer hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                    <div className="w-4 h-4 bg-green-600 rounded"></div>
                  </div>
                  Requirements
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Manage and track requirements
                </p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/verification">
            <Card className="cursor-pointer hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                    <div className="w-4 h-4 bg-purple-600 rounded"></div>
                  </div>
                  Verification
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  Test planning and verification tracking
                </p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/traceability">
            <Card className="cursor-pointer hover:shadow-md transition-shadow">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                    <div className="w-4 h-4 bg-orange-600 rounded"></div>
                  </div>
                  Traceability
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600">
                  End-to-end requirement traceability
                </p>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Welcome Message */}
        <Card>
          <CardHeader>
            <CardTitle>Getting Started</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">
              Welcome to your requirements management workspace! Here are the key features available to you:
            </p>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li><strong>Dashboard:</strong> View project health metrics, recent activity, and PBS structure overview</li>
              <li><strong>Requirements:</strong> Import specifications, extract requirements, and manage compliance status</li>
              <li><strong>PBS Mapping:</strong> Create Product Breakdown Structure and map requirements to components</li>
              <li><strong>Verification:</strong> Plan verification activities and track test procedures</li>
              <li><strong>Traceability:</strong> Monitor end-to-end traceability from requirements to verification</li>
            </ul>
            <div className="mt-6">
              <Link href="/dashboard">
                <Button data-testid="get-started-button">
                  Go to Dashboard
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}