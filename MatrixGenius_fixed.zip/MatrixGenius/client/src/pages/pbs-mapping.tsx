import Header from "@/components/layout/header";
import PbsTree from "@/components/pbs/pbs-tree";
import PbsItemDetails from "@/components/pbs/pbs-item-details";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useState } from "react";

export default function PbsMapping() {
  const [selectedPbsItem, setSelectedPbsItem] = useState<string | null>(null);
  const projectId = "project-1"; // Demo project ID

  return (
    <div className="flex-1 flex flex-col">
      <Header 
        title="PBS Structure & Mapping"
        subtitle="Product breakdown structure and requirement mapping"
      />
      
      <div className="flex-1 p-6 overflow-auto">
        <div className="grid grid-cols-3 gap-6">
          {/* PBS Tree */}
          <div className="col-span-1">
            <PbsTree 
              projectId={projectId} 
              onItemSelect={setSelectedPbsItem}
              selectedItem={selectedPbsItem}
            />
          </div>

          {/* PBS Item Details */}
          <div className="col-span-2">
            {selectedPbsItem ? (
              <PbsItemDetails pbsItemId={selectedPbsItem} />
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Select a PBS Item</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Select a PBS item from the tree to view its details, mapped requirements, and progress.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
