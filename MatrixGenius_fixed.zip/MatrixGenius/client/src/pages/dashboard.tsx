import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { FileText, CheckCircle, Clock, AlertTriangle, TrendingUp, Shield, Target, Calendar, Activity, Users } from "lucide-react";
import Header from "@/components/layout/header";
import { useQuery } from "@tanstack/react-query";
import { Requirement, PbsItem, VerificationItem, RequirementStatus, VerificationStatus, CriticalRequirementKeywords } from "@shared/schema";
import { formatDistanceToNow, addDays, isBefore, isAfter } from "date-fns";

export default function Dashboard() {
  const projectId = "project-1"; // Demo project ID

  const { data: requirements = [], isLoading: isLoadingReqs, error: reqError } = useQuery<Requirement[]>({
    queryKey: ["/api/projects", projectId, "requirements"],
  });

  const { data: pbsItems = [], isLoading: isLoadingPbs, error: pbsError } = useQuery<PbsItem[]>({
    queryKey: ["/api/projects", projectId, "pbs-items"],
  });

  const { data: verificationItems = [], isLoading: isLoadingVerif, error: verifError } = useQuery<VerificationItem[]>({
    queryKey: ["/api/projects", projectId, "verification-items"],
  });

  const isLoading = isLoadingReqs || isLoadingPbs || isLoadingVerif;
  const hasError = reqError || pbsError || verifError;

  const stats = {
    totalRequirements: requirements.length,
    verifiedRequirements: requirements.filter(r => r.status === RequirementStatus.CLOSED).length,
    inProgressRequirements: requirements.filter(r => r.status === RequirementStatus.IN_PROGRESS).length,
    issuesCount: requirements.filter(r => r.status === RequirementStatus.BLOCKED).length,
    newRequirements: requirements.filter(r => r.status === RequirementStatus.OPEN).length,
    reviewRequirements: requirements.filter(r => r.status === RequirementStatus.REVIEW).length,
  };

  // Enhanced compliance metrics
  const complianceMetrics = React.useMemo(() => {
    const totalVerificationItems = verificationItems.length;
    const completedVerifications = verificationItems.filter(v => v.status === VerificationStatus.PASSED).length;
    const failedVerifications = verificationItems.filter(v => v.status === VerificationStatus.FAILED).length;
    const pendingVerifications = verificationItems.filter(v => v.status === VerificationStatus.PENDING).length;
    
    // Enhanced critical requirements detection using defined keywords
    const criticalRequirements = requirements.filter(r => {
      const textLower = r.text?.toLowerCase() || '';
      const verificationLower = r.verification?.toLowerCase() || '';
      const sourceLower = r.source?.toLowerCase() || '';
      const notesLower = r.notes?.toLowerCase() || '';
      
      return CriticalRequirementKeywords.some(keyword => 
        textLower.includes(keyword) ||
        verificationLower.includes(keyword) ||
        sourceLower.includes(keyword) ||
        notesLower.includes(keyword)
      );
    });
    const completedCriticalReqs = criticalRequirements.filter(r => r.status === RequirementStatus.CLOSED);
    
    // Milestone tracking (simulated based on requirement completion rates)
    const currentDate = new Date();
    const projectStartDate = addDays(currentDate, -90); // 90 days ago
    const projectEndDate = addDays(currentDate, 60); // 60 days from now
    const expectedProgress = Math.min(90, Math.max(0, 
      ((currentDate.getTime() - projectStartDate.getTime()) / (projectEndDate.getTime() - projectStartDate.getTime())) * 100
    ));
    const actualProgress = stats.totalRequirements > 0 
      ? (stats.verifiedRequirements / stats.totalRequirements) * 100 
      : 0;

    return {
      totalVerificationItems,
      completedVerifications,
      failedVerifications, 
      pendingVerifications,
      verificationRate: totalVerificationItems > 0 ? (completedVerifications / totalVerificationItems) * 100 : 0,
      criticalRequirements: criticalRequirements.length,
      completedCriticalReqs: completedCriticalReqs.length,
      criticalComplianceRate: criticalRequirements.length > 0 ? (completedCriticalReqs.length / criticalRequirements.length) * 100 : 100,
      expectedProgress: Math.round(expectedProgress),
      actualProgress: Math.round(actualProgress),
      scheduleVariance: Math.round(actualProgress - expectedProgress),
      riskLevel: (() => {
        // Enhanced risk calculation considering multiple factors
        let riskScore = 0;
        
        // Failed verifications contribute heavily to risk
        riskScore += failedVerifications * 3;
        
        // Blocked critical requirements are high risk
        const blockedCriticalReqs = criticalRequirements.filter(r => r.status === RequirementStatus.BLOCKED).length;
        riskScore += blockedCriticalReqs * 4;
        
        // Large number of pending verifications indicates process risk
        riskScore += Math.max(0, pendingVerifications - 3) * 1;
        
        // Low completion rate of critical requirements increases risk
        if (criticalRequirements.length > 0 && (completedCriticalReqs.length / criticalRequirements.length) < 0.5) {
          riskScore += 2;
        }
        
        // High percentage of blocked requirements
        const blockedRate = stats.totalRequirements > 0 ? (stats.issuesCount / stats.totalRequirements) : 0;
        if (blockedRate > 0.2) riskScore += 3;
        else if (blockedRate > 0.1) riskScore += 1;
        
        // Determine risk level based on score
        if (riskScore >= 8) return 'High';
        if (riskScore >= 4) return 'Medium';
        return 'Low';
      })()
    };
  }, [requirements, verificationItems, stats]);

  const completionRate = stats.totalRequirements > 0 
    ? Math.round((stats.verifiedRequirements / stats.totalRequirements) * 100)
    : 0;

  // Calculate project health based on requirements completion and PBS progress
  const projectHealth = React.useMemo(() => {
    if (stats.totalRequirements === 0) return 0;
    
    const requirementHealth = (stats.verifiedRequirements / stats.totalRequirements) * 0.6; // 60% weight
    const pbsHealth = pbsItems.length > 0 
      ? (pbsItems.reduce((sum, item) => sum + (item.progress || 0), 0) / pbsItems.length / 100) * 0.4 // 40% weight
      : 0;
    
    return Math.round((requirementHealth + pbsHealth) * 100);
  }, [stats.verifiedRequirements, stats.totalRequirements, pbsItems]);

  // Group PBS items by hierarchy and calculate real progress
  const pbsStructure = React.useMemo(() => {
    const rootItems = pbsItems.filter(item => !item.parentId);
    return rootItems.map(root => {
      const children = pbsItems.filter(item => item.parentId === root.id);
      const totalProgress = children.length > 0 
        ? children.reduce((sum, child) => sum + (child.progress || 0), 0) / children.length
        : root.progress || 0;
      
      return {
        id: root.id,
        name: root.name,
        progress: totalProgress,
        childCount: children.length,
        status: root.status
      };
    });
  }, [pbsItems]);

  // Generate recent activity from actual data changes
  const recentActivity = React.useMemo(() => {
    const activities: Array<{
      id: string;
      type: string;
      message: string;
      timestamp: Date | string | null;
      color: string;
    }> = [];
    
    // Add requirement-based activities using proper enums
    requirements.forEach(req => {
      if (req.status === RequirementStatus.CLOSED) {
        activities.push({
          id: `req-${req.id}`,
          type: "verification",
          message: `${req.reqId} verified and closed`,
          timestamp: req.updatedAt,
          color: "green"
        });
      } else if (req.status === RequirementStatus.IN_PROGRESS) {
        activities.push({
          id: `req-progress-${req.id}`,
          type: "progress",
          message: `${req.reqId} status changed to In Progress`,
          timestamp: req.updatedAt,
          color: "amber"
        });
      } else if (req.status === RequirementStatus.BLOCKED) {
        activities.push({
          id: `req-blocked-${req.id}`,
          type: "issue",
          message: `${req.reqId} blocked - needs attention`,
          timestamp: req.updatedAt,
          color: "red"
        });
      }
    });

    // Add PBS-based activities
    pbsItems.forEach(pbs => {
      activities.push({
        id: `pbs-${pbs.id}`,
        type: "pbs",
        message: `PBS item ${pbs.pbsId} (${pbs.name}) created`,
        timestamp: pbs.createdAt,
        color: "blue"
      });
    });

    // Filter out activities with null timestamps and sort by timestamp (most recent first) and take top 5
    return activities
      .filter(activity => activity.timestamp != null)
      .sort((a, b) => new Date(b.timestamp!).getTime() - new Date(a.timestamp!).getTime())
      .slice(0, 5);
  }, [requirements, pbsItems]);

  // Loading state
  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col">
        <Header 
          title="Analytics Dashboard"
          subtitle="Project overview and compliance metrics"
        />
        <div className="flex-1 p-6 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading dashboard data...</p>
          </div>
        </div>
      </div>
    );
  }

  // Error state
  if (hasError) {
    return (
      <div className="flex-1 flex flex-col">
        <Header 
          title="Analytics Dashboard"
          subtitle="Project overview and compliance metrics"
        />
        <div className="flex-1 p-6 flex items-center justify-center">
          <div className="text-center">
            <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <p className="text-muted-foreground">Failed to load dashboard data. Please try refreshing the page.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header 
        title="Analytics Dashboard"
        subtitle="Project overview and compliance metrics"
      />
      
      <div className="flex-1 p-6 overflow-auto">
        {/* Enhanced Stats Overview */}
        <div className="grid grid-cols-5 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Requirements</p>
                  <p className="text-2xl font-bold text-foreground">{stats.totalRequirements}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <FileText className="w-6 h-6 text-blue-600" />
                </div>
              </div>
              <div className="mt-2 flex items-center text-sm">
                <span className="text-muted-foreground">Active requirements</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Verified</p>
                  <p className="text-2xl font-bold text-foreground">{stats.verifiedRequirements}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
              </div>
              <div className="mt-2 flex items-center text-sm">
                <span className="text-green-600">{completionRate}%</span>
                <span className="text-muted-foreground ml-1">completion rate</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">In Progress</p>
                  <p className="text-2xl font-bold text-foreground">{stats.inProgressRequirements}</p>
                </div>
                <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-amber-600" />
                </div>
              </div>
              <div className="mt-2 flex items-center text-sm">
                <span className="text-amber-600">Due this week</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Issues</p>
                  <p className="text-2xl font-bold text-foreground">{stats.issuesCount}</p>
                </div>
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-red-600" />
                </div>
              </div>
              <div className="mt-2 flex items-center text-sm">
                <span className="text-red-600">Needs attention</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Project Health</p>
                  <p className="text-2xl font-bold text-foreground" data-testid="project-health-metric">{projectHealth}%</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-purple-600" />
                </div>
              </div>
              <div className="mt-2 flex items-center text-sm">
                <span className={`${
                  projectHealth >= 80 ? "text-green-600" : 
                  projectHealth >= 60 ? "text-amber-600" : "text-red-600"
                }`}>
                  {projectHealth >= 80 ? "Excellent" : 
                   projectHealth >= 60 ? "Good" : "Needs attention"}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Compliance Status */}
        <div className="grid grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Shield className="w-5 h-5 text-blue-600" />
                Compliance Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Overall Compliance</span>
                  <span className="text-sm font-bold" data-testid="overall-compliance-rate">{completionRate}%</span>
                </div>
                <Progress value={completionRate} className="h-2" data-testid="compliance-progress" />
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Critical Requirements</span>
                  <Badge variant={complianceMetrics.criticalComplianceRate >= 90 ? "default" : 
                                 complianceMetrics.criticalComplianceRate >= 70 ? "secondary" : "destructive"}
                         data-testid="critical-requirements-badge">
                    {complianceMetrics.completedCriticalReqs}/{complianceMetrics.criticalRequirements}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Verification Rate</span>
                  <span className="text-sm">{Math.round(complianceMetrics.verificationRate)}%</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Target className="w-5 h-5 text-green-600" />
                Milestone Tracking
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Expected Progress</span>
                  <span className="text-sm font-bold">{complianceMetrics.expectedProgress}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Actual Progress</span>
                  <span className="text-sm font-bold">{complianceMetrics.actualProgress}%</span>
                </div>
                <Progress value={complianceMetrics.actualProgress} className="h-2" />
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Schedule Variance</span>
                  <Badge variant={complianceMetrics.scheduleVariance >= 0 ? "default" : "destructive"}
                         data-testid="schedule-variance-badge">
                    {complianceMetrics.scheduleVariance >= 0 ? '+' : ''}{complianceMetrics.scheduleVariance}%
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600" />
                Risk Assessment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Risk Level</span>
                  <Badge variant={complianceMetrics.riskLevel === 'Low' ? "default" : 
                                 complianceMetrics.riskLevel === 'Medium' ? "secondary" : "destructive"}>
                    {complianceMetrics.riskLevel}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Failed Verifications</span>
                  <span className="text-sm font-bold text-red-600">{complianceMetrics.failedVerifications}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Blocked Requirements</span>
                  <span className="text-sm font-bold text-amber-600">{stats.issuesCount}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Pending Verifications</span>
                  <span className="text-sm">{complianceMetrics.pendingVerifications}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Analytics */}
        <div className="grid grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentActivity.length > 0 ? (
                  recentActivity.map((activity) => (
                    <div key={activity.id} className="flex items-center gap-3" data-testid={`activity-${activity.type}`}>
                      <div className={`w-2 h-2 rounded-full ${
                        activity.color === "green" ? "bg-green-500" :
                        activity.color === "blue" ? "bg-blue-500" :
                        activity.color === "amber" ? "bg-amber-500" :
                        activity.color === "red" ? "bg-red-500" : "bg-gray-500"
                      }`}></div>
                      <span className="text-sm">{activity.message}</span>
                      <span className="text-xs text-muted-foreground ml-auto">
                        {formatDistanceToNow(new Date(activity.timestamp!), { addSuffix: true })}
                      </span>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">No recent activity</p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>PBS Structure Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Total PBS Items</span>
                  <span className="text-sm font-medium" data-testid="pbs-total-count">{pbsItems.length} items</span>
                </div>
                {pbsStructure.length > 0 ? (
                  pbsStructure.map((pbs) => (
                    <div key={pbs.id} className="flex justify-between items-center" data-testid={`pbs-item-${pbs.id}`}>
                      <span className="text-sm">
                        {pbs.name}
                        {pbs.childCount > 0 && (
                          <span className="text-xs text-muted-foreground ml-1">({pbs.childCount} sub-items)</span>
                        )}
                      </span>
                      <span className={`text-sm ${
                        pbs.progress >= 80 ? "text-green-600" :
                        pbs.progress >= 60 ? "text-amber-600" : "text-red-600"
                      }`}>
                        {Math.round(pbs.progress)}% complete
                      </span>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">No PBS items found</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
