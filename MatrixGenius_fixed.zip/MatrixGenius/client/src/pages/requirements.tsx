import { useState } from "react";
import Header from "@/components/layout/header";
import RequirementsTable from "@/components/requirements/requirements-table";
import RequirementModal from "@/components/requirements/requirement-modal";
import SpecImporter from "@/components/requirements/spec-importer";
import PbsTree from "@/components/pbs/pbs-tree";
import VerificationStatus from "@/components/verification/verification-status";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Upload, Download, RefreshCw, Filter } from "lucide-react";
import { useRequirements, useCreateRequirement } from "@/hooks/use-requirements";
import { usePbsItems } from "@/hooks/use-pbs";
import { exportComplianceMatrix } from "@/lib/export-utils";
import { useToast } from "@/hooks/use-toast";

export default function Requirements() {
  const [showModal, setShowModal] = useState(false);
  const [showImporter, setShowImporter] = useState(false);
  const [selectedRequirement, setSelectedRequirement] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  
  const { toast } = useToast();
  const projectId = "project-1"; // Demo project ID
  
  const { data: requirements = [], isLoading, refetch } = useRequirements(projectId);
  const { data: pbsItems = [] } = usePbsItems(projectId);
  const createRequirement = useCreateRequirement();

  const handleNewRequirement = () => {
    setSelectedRequirement(null);
    setShowModal(true);
  };

  const handleEditRequirement = (id: string) => {
    setSelectedRequirement(id);
    setShowModal(true);
  };

  const handleExportCSV = async () => {
    try {
      await exportComplianceMatrix(projectId);
      toast({
        title: "Export successful",
        description: "Compliance matrix has been downloaded.",
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Failed to export compliance matrix.",
        variant: "destructive",
      });
    }
  };

  const filteredRequirements = requirements.filter(req =>
    searchQuery === "" ||
    req.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
    req.reqId.toLowerCase().includes(searchQuery.toLowerCase()) ||
    req.owner?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 flex flex-col">
      <Header 
        title="Requirements Management"
        subtitle="Specification analysis and compliance tracking"
        onSearch={setSearchQuery}
        onNewRequirement={handleNewRequirement}
      />
      
      {/* Content Tabs */}
      <div className="bg-card border-b border-border">
        <div className="px-6">
          <Tabs defaultValue="matrix" className="w-full">
            <TabsList className="h-auto p-0 bg-transparent">
              <TabsTrigger 
                value="matrix" 
                className="py-4 px-1 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent rounded-none"
              >
                Requirements Matrix
              </TabsTrigger>
              <TabsTrigger 
                value="pbs" 
                className="py-4 px-1 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent rounded-none"
              >
                PBS Mapping
              </TabsTrigger>
              <TabsTrigger 
                value="verification" 
                className="py-4 px-1 border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent rounded-none"
              >
                Verification Plan
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      <div className="flex-1 p-6 overflow-auto">
        {/* Quick Actions Bar */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>{requirements.length} requirements</span>
              <span>•</span>
              <span>{pbsItems.length} PBS items</span>
              <span>•</span>
              <span>{requirements.filter(r => r.status === "Closed").length} verified</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setShowImporter(true)}
              data-testid="import-spec-button"
            >
              <Upload className="w-4 h-4 mr-2" />
              Import Spec
            </Button>
            <Button variant="outline" size="sm" onClick={handleExportCSV} data-testid="export-button">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
            <Button variant="outline" size="sm" onClick={() => refetch()} data-testid="refresh-button">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-12 gap-6">
          {/* Requirements Table */}
          <div className="col-span-8">
            <RequirementsTable
              requirements={filteredRequirements}
              onEdit={handleEditRequirement}
              isLoading={isLoading}
            />
          </div>

          {/* Sidebar */}
          <div className="col-span-4 space-y-4">
            <PbsTree projectId={projectId} />
            <VerificationStatus projectId={projectId} />
          </div>
        </div>
      </div>

      {/* Modals */}
      {showModal && (
        <RequirementModal
          requirementId={selectedRequirement}
          projectId={projectId}
          onClose={() => setShowModal(false)}
        />
      )}

      {showImporter && (
        <SpecImporter
          projectId={projectId}
          onClose={() => setShowImporter(false)}
        />
      )}
    </div>
  );
}
