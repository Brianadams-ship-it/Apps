import { useState } from "react";
import { Plus } from "lucide-react";
import Header from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import VerificationStatus from "@/components/verification/verification-status";
import VerificationTable from "@/components/verification/verification-table";
import VerificationModal from "@/components/verification/verification-modal";
import { useVerificationItemsByProject } from "@/hooks/use-verification";
import { VerificationItem } from "@shared/schema";

// Using fixed project ID for demo purposes
const PROJECT_ID = "project-1";

export default function Verification() {
  const { data: verificationItems = [], isLoading } = useVerificationItemsByProject(PROJECT_ID);
  const [selectedItem, setSelectedItem] = useState<VerificationItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleCreateNew = () => {
    setSelectedItem(null);
    setIsModalOpen(true);
  };

  const handleEdit = (item: VerificationItem) => {
    setSelectedItem(item);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setSelectedItem(null);
    setIsModalOpen(false);
  };

  return (
    <div className="flex-1 flex flex-col">
      <Header 
        title="Verification Management"
        subtitle="Test planning and verification tracking"
      />
      
      <div className="flex-1 p-6 overflow-auto space-y-6">
        {/* Verification Status Overview */}
        <VerificationStatus projectId={PROJECT_ID} />
        
        {/* Actions */}
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Verification Items</h2>
          <Button 
            onClick={handleCreateNew}
            data-testid="create-verification-item"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Verification Item
          </Button>
        </div>

        {/* Verification Table */}
        <VerificationTable
          verificationItems={verificationItems}
          projectId={PROJECT_ID}
          onEdit={handleEdit}
          isLoading={isLoading}
        />

        {/* Modal */}
        {isModalOpen && (
          <VerificationModal
            verificationItem={selectedItem}
            projectId={PROJECT_ID}
            onClose={handleCloseModal}
          />
        )}
      </div>
    </div>
  );
}
