import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, FileText, BarChart3, Users } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="max-w-6xl w-full">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-4">
            ReqMatrix
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-8">
            Comprehensive Requirements Management & Compliance Tracking
          </p>
          <p className="text-lg text-gray-500 mb-8 max-w-3xl mx-auto">
            End-to-end traceability from requirements through Product Breakdown Structure mapping 
            to verification and qualification planning for complex engineering projects.
          </p>
          <Button 
            onClick={handleLogin}
            size="lg"
            className="px-8 py-3 text-lg"
            data-testid="login-button"
          >
            Sign In to Get Started
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <Card className="bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <FileText className="w-8 h-8 text-blue-600 mb-2" />
              <CardTitle className="text-lg">Requirements Management</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Import, analyze, and manage requirements with advanced document parsing and structured extraction.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <BarChart3 className="w-8 h-8 text-green-600 mb-2" />
              <CardTitle className="text-lg">PBS Mapping</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Visual Product Breakdown Structure mapping with drag-and-drop requirement-to-component associations.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <Shield className="w-8 h-8 text-purple-600 mb-2" />
              <CardTitle className="text-lg">Verification Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Complete verification and qualification planning with test procedure generation and progress monitoring.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <Users className="w-8 h-8 text-orange-600 mb-2" />
              <CardTitle className="text-lg">Team Collaboration</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Multi-user workflows with approval chains, role-based access, and real-time collaboration features.
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <p className="text-gray-500 text-sm">
            Built for aerospace, defense, and highly regulated industries where requirement traceability is critical.
          </p>
        </div>
      </div>
    </div>
  );
}