import { 
  Project, InsertProject,
  Requirement, InsertRequirement,
  PbsItem, InsertPbsItem,
  RequirementPbsMapping, InsertRequirementPbsMapping,
  RequirementRelationship, InsertRequirementRelationship,
  VerificationItem, InsertVerificationItem,
  Specification, InsertSpecification,
  User, UpsertUser,
  projects,
  requirements,
  pbsItems,
  requirementPbsMappings,
  requirementRelationships,
  verificationItems,
  specifications,
  users
} from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db";
import { eq, and, or } from "drizzle-orm";

export interface IStorage {
  // Projects
  getProject(id: string): Promise<Project | undefined>;
  getProjects(): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, project: Partial<InsertProject>): Promise<Project | undefined>;
  
  // Requirements
  getRequirement(id: string): Promise<Requirement | undefined>;
  getRequirementsByProject(projectId: string): Promise<Requirement[]>;
  createRequirement(requirement: InsertRequirement): Promise<Requirement>;
  updateRequirement(id: string, requirement: Partial<InsertRequirement>): Promise<Requirement | undefined>;
  deleteRequirement(id: string): Promise<boolean>;
  
  // PBS Items
  getPbsItem(id: string): Promise<PbsItem | undefined>;
  getPbsItemsByProject(projectId: string): Promise<PbsItem[]>;
  createPbsItem(pbsItem: InsertPbsItem): Promise<PbsItem>;
  updatePbsItem(id: string, pbsItem: Partial<InsertPbsItem>): Promise<PbsItem | undefined>;
  deletePbsItem(id: string): Promise<boolean>;
  
  // Requirement-PBS Mappings
  getRequirementPbsMappings(requirementId: string): Promise<RequirementPbsMapping[]>;
  getPbsMappingsByProject(projectId: string): Promise<RequirementPbsMapping[]>;
  createRequirementPbsMapping(mapping: InsertRequirementPbsMapping): Promise<RequirementPbsMapping>;
  deleteRequirementPbsMapping(requirementId: string, pbsItemId: string): Promise<boolean>;
  
  // Requirement Relationships
  getRequirementRelationships(requirementId: string): Promise<RequirementRelationship[]>;
  createRequirementRelationship(relationship: InsertRequirementRelationship): Promise<RequirementRelationship>;
  deleteRequirementRelationship(id: string): Promise<boolean>;
  
  // Verification Items
  getVerificationItemsByRequirement(requirementId: string): Promise<VerificationItem[]>;
  getVerificationItemsByProject(projectId: string): Promise<VerificationItem[]>;
  createVerificationItem(item: InsertVerificationItem): Promise<VerificationItem>;
  updateVerificationItem(id: string, item: Partial<InsertVerificationItem>): Promise<VerificationItem | undefined>;
  deleteVerificationItem(id: string): Promise<boolean>;
  
  // Specifications
  getSpecificationsByProject(projectId: string): Promise<Specification[]>;
  createSpecification(spec: InsertSpecification): Promise<Specification>;
  deleteSpecification(id: string): Promise<boolean>;
  
  // User operations (IMPORTANT: mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
}

export class MemStorage implements IStorage {
  private projects: Map<string, Project> = new Map();
  private requirements: Map<string, Requirement> = new Map();
  private pbsItems: Map<string, PbsItem> = new Map();
  private requirementPbsMappings: Map<string, RequirementPbsMapping> = new Map();
  private requirementRelationships: Map<string, RequirementRelationship> = new Map();
  private verificationItems: Map<string, VerificationItem> = new Map();
  private specifications: Map<string, Specification> = new Map();
  private users: Map<string, User> = new Map();

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Create a sample project
    const project: Project = {
      id: "project-1",
      name: "Project Alpha - Avionics System",
      description: "Advanced avionics system for commercial aircraft",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.projects.set(project.id, project);

    // Create sample PBS items
    const pbsItems: PbsItem[] = [
      {
        id: "pbs-1",
        projectId: "project-1",
        pbsId: "AVS-001",
        name: "Avionics System",
        description: "Main avionics system",
        parentId: null,
        level: 1,
        icon: "cube",
        color: "blue",
        owner: "Systems Team",
        status: "Active",
        progress: 75,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "pbs-2",
        projectId: "project-1",
        pbsId: "FC-001",
        name: "Flight Control System",
        description: "Primary flight control system",
        parentId: "pbs-1",
        level: 2,
        icon: "microchip",
        color: "green",
        owner: "Flight Controls Team",
        status: "Active",
        progress: 85,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "pbs-3",
        projectId: "project-1",
        pbsId: "FC-ALT-001",
        name: "Altitude Control",
        description: "Altitude control subsystem",
        parentId: "pbs-2",
        level: 3,
        icon: "cog",
        color: "blue",
        owner: "Flight Controls Team",
        status: "Active",
        progress: 90,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    pbsItems.forEach(item => this.pbsItems.set(item.id, item));

    // Create sample requirements
    const requirements: Requirement[] = [
      {
        id: "req-1",
        projectId: "project-1",
        reqId: "REQ-001",
        text: "The system shall maintain altitude within ±50 feet of commanded altitude during normal flight operations.",
        source: "Flight Control Specification v2.1 - Section 3.2.1",
        compliance: "Yes",
        verification: "Test",
        owner: "J. Smith",
        status: "Closed",
        evidence: "",
        notes: "",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "req-2",
        projectId: "project-1",
        reqId: "REQ-002",
        text: "The navigation system must provide position accuracy within 10 meters CEP during GPS operations.",
        source: "Navigation Specification v1.3 - Section 2.1",
        compliance: "TBD",
        verification: "Analysis",
        owner: "M. Johnson",
        status: "In Progress",
        evidence: "",
        notes: "",
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    requirements.forEach(req => this.requirements.set(req.id, req));

    // Create sample mapping
    const mapping: RequirementPbsMapping = {
      id: "mapping-1",
      requirementId: "req-1",
      pbsItemId: "pbs-3",
      createdAt: new Date(),
    };
    this.requirementPbsMappings.set(mapping.id, mapping);
  }

  // Projects
  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async createProject(project: InsertProject): Promise<Project> {
    const id = randomUUID();
    const newProject: Project = {
      ...project,
      id,
      description: project.description ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.projects.set(id, newProject);
    return newProject;
  }

  async updateProject(id: string, project: Partial<InsertProject>): Promise<Project | undefined> {
    const existing = this.projects.get(id);
    if (!existing) return undefined;
    
    const updated: Project = {
      id: existing.id,
      name: project.name ?? existing.name,
      description: project.description ?? existing.description,
      createdAt: existing.createdAt,
      updatedAt: new Date(),
    };
    this.projects.set(id, updated);
    return updated;
  }

  // Requirements
  async getRequirement(id: string): Promise<Requirement | undefined> {
    return this.requirements.get(id);
  }

  async getRequirementsByProject(projectId: string): Promise<Requirement[]> {
    return Array.from(this.requirements.values()).filter(req => req.projectId === projectId);
  }

  async createRequirement(requirement: InsertRequirement): Promise<Requirement> {
    const id = randomUUID();
    const newRequirement: Requirement = {
      ...requirement,
      id,
      source: requirement.source ?? null,
      compliance: requirement.compliance ?? null,
      verification: requirement.verification ?? null,
      owner: requirement.owner ?? null,
      status: requirement.status ?? null,
      evidence: requirement.evidence ?? null,
      notes: requirement.notes ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.requirements.set(id, newRequirement);
    return newRequirement;
  }

  async updateRequirement(id: string, requirement: Partial<InsertRequirement>): Promise<Requirement | undefined> {
    const existing = this.requirements.get(id);
    if (!existing) return undefined;
    
    const updated: Requirement = {
      id: existing.id,
      projectId: requirement.projectId ?? existing.projectId,
      reqId: requirement.reqId ?? existing.reqId,
      text: requirement.text ?? existing.text,
      source: requirement.source ?? existing.source,
      compliance: requirement.compliance ?? existing.compliance,
      verification: requirement.verification ?? existing.verification,
      owner: requirement.owner ?? existing.owner,
      status: requirement.status ?? existing.status,
      evidence: requirement.evidence ?? existing.evidence,
      notes: requirement.notes ?? existing.notes,
      createdAt: existing.createdAt,
      updatedAt: new Date(),
    };
    this.requirements.set(id, updated);
    return updated;
  }

  async deleteRequirement(id: string): Promise<boolean> {
    return this.requirements.delete(id);
  }

  // PBS Items
  async getPbsItem(id: string): Promise<PbsItem | undefined> {
    return this.pbsItems.get(id);
  }

  async getPbsItemsByProject(projectId: string): Promise<PbsItem[]> {
    return Array.from(this.pbsItems.values()).filter(item => item.projectId === projectId);
  }

  async createPbsItem(pbsItem: InsertPbsItem): Promise<PbsItem> {
    const id = randomUUID();
    const newPbsItem: PbsItem = {
      ...pbsItem,
      id,
      description: pbsItem.description ?? null,
      parentId: pbsItem.parentId ?? null,
      level: pbsItem.level ?? 1,
      icon: pbsItem.icon ?? null,
      color: pbsItem.color ?? null,
      owner: pbsItem.owner ?? null,
      status: pbsItem.status ?? null,
      progress: pbsItem.progress ?? 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.pbsItems.set(id, newPbsItem);
    return newPbsItem;
  }

  async updatePbsItem(id: string, pbsItem: Partial<InsertPbsItem>): Promise<PbsItem | undefined> {
    const existing = this.pbsItems.get(id);
    if (!existing) return undefined;
    
    const updated: PbsItem = {
      id: existing.id,
      projectId: pbsItem.projectId ?? existing.projectId,
      pbsId: pbsItem.pbsId ?? existing.pbsId,
      name: pbsItem.name ?? existing.name,
      description: pbsItem.description ?? existing.description,
      parentId: pbsItem.parentId ?? existing.parentId,
      level: pbsItem.level ?? existing.level,
      icon: pbsItem.icon ?? existing.icon,
      color: pbsItem.color ?? existing.color,
      owner: pbsItem.owner ?? existing.owner,
      status: pbsItem.status ?? existing.status,
      progress: pbsItem.progress ?? existing.progress,
      createdAt: existing.createdAt,
      updatedAt: new Date(),
    };
    this.pbsItems.set(id, updated);
    return updated;
  }

  async deletePbsItem(id: string): Promise<boolean> {
    return this.pbsItems.delete(id);
  }

  // Requirement-PBS Mappings
  async getRequirementPbsMappings(requirementId: string): Promise<RequirementPbsMapping[]> {
    return Array.from(this.requirementPbsMappings.values()).filter(mapping => mapping.requirementId === requirementId);
  }

  async getPbsMappingsByProject(projectId: string): Promise<RequirementPbsMapping[]> {
    // Get all requirements for this project first
    const projectRequirements = Array.from(this.requirements.values()).filter(req => req.projectId === projectId);
    const requirementIds = projectRequirements.map(req => req.id);
    
    // Return all mappings for those requirements
    return Array.from(this.requirementPbsMappings.values()).filter(mapping => 
      requirementIds.includes(mapping.requirementId)
    );
  }

  async createRequirementPbsMapping(mapping: InsertRequirementPbsMapping): Promise<RequirementPbsMapping> {
    const id = randomUUID();
    const newMapping: RequirementPbsMapping = {
      ...mapping,
      id,
      createdAt: new Date(),
    };
    this.requirementPbsMappings.set(id, newMapping);
    return newMapping;
  }

  async deleteRequirementPbsMapping(requirementId: string, pbsItemId: string): Promise<boolean> {
    const mapping = Array.from(this.requirementPbsMappings.values()).find(
      m => m.requirementId === requirementId && m.pbsItemId === pbsItemId
    );
    if (mapping) {
      return this.requirementPbsMappings.delete(mapping.id);
    }
    return false;
  }

  // Requirement Relationships
  async getRequirementRelationships(requirementId: string): Promise<RequirementRelationship[]> {
    return Array.from(this.requirementRelationships.values()).filter(
      r => r.sourceRequirementId === requirementId || r.targetRequirementId === requirementId
    );
  }

  async createRequirementRelationship(relationship: InsertRequirementRelationship): Promise<RequirementRelationship> {
    const newRelationship: RequirementRelationship = {
      id: randomUUID(),
      sourceRequirementId: relationship.sourceRequirementId,
      targetRequirementId: relationship.targetRequirementId,
      relationshipType: relationship.relationshipType,
      description: relationship.description ?? null,
      createdBy: relationship.createdBy ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.requirementRelationships.set(newRelationship.id, newRelationship);
    return newRelationship;
  }

  async deleteRequirementRelationship(id: string): Promise<boolean> {
    return this.requirementRelationships.delete(id);
  }

  // Verification Items
  async getVerificationItemsByRequirement(requirementId: string): Promise<VerificationItem[]> {
    return Array.from(this.verificationItems.values()).filter(item => item.requirementId === requirementId);
  }

  async getVerificationItemsByProject(projectId: string): Promise<VerificationItem[]> {
    const projectRequirements = await this.getRequirementsByProject(projectId);
    const requirementIds = new Set(projectRequirements.map(r => r.id));
    return Array.from(this.verificationItems.values()).filter(item => requirementIds.has(item.requirementId));
  }

  async createVerificationItem(item: InsertVerificationItem): Promise<VerificationItem> {
    const id = randomUUID();
    const newItem: VerificationItem = {
      ...item,
      id,
      description: item.description ?? null,
      status: item.status ?? null,
      assignee: item.assignee ?? null,
      dueDate: item.dueDate ?? null,
      completedAt: item.completedAt ?? null,
      evidence: item.evidence ?? null,
      notes: item.notes ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.verificationItems.set(id, newItem);
    return newItem;
  }

  async updateVerificationItem(id: string, item: Partial<InsertVerificationItem>): Promise<VerificationItem | undefined> {
    const existing = this.verificationItems.get(id);
    if (!existing) return undefined;
    
    const updated: VerificationItem = {
      id: existing.id,
      requirementId: item.requirementId ?? existing.requirementId,
      title: item.title ?? existing.title,
      description: item.description ?? existing.description,
      method: item.method ?? existing.method,
      status: item.status ?? existing.status,
      assignee: item.assignee ?? existing.assignee,
      dueDate: item.dueDate ?? existing.dueDate,
      completedAt: item.completedAt ?? existing.completedAt,
      evidence: item.evidence ?? existing.evidence,
      notes: item.notes ?? existing.notes,
      createdAt: existing.createdAt,
      updatedAt: new Date(),
    };
    this.verificationItems.set(id, updated);
    return updated;
  }

  async deleteVerificationItem(id: string): Promise<boolean> {
    return this.verificationItems.delete(id);
  }

  // Specifications
  async getSpecificationsByProject(projectId: string): Promise<Specification[]> {
    return Array.from(this.specifications.values()).filter(spec => spec.projectId === projectId);
  }

  async createSpecification(spec: InsertSpecification): Promise<Specification> {
    const id = randomUUID();
    const newSpec: Specification = {
      ...spec,
      id,
      url: spec.url ?? null,
      extractionConfig: spec.extractionConfig ?? null,
      createdAt: new Date(),
    };
    this.specifications.set(id, newSpec);
    return newSpec;
  }

  async deleteSpecification(id: string): Promise<boolean> {
    return this.specifications.delete(id);
  }

  // User operations (IMPORTANT: mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existingUser = this.users.get(userData.id!);
    const user: User = {
      id: userData.id || randomUUID(),
      email: userData.email || null,
      firstName: userData.firstName || null,
      lastName: userData.lastName || null,
      profileImageUrl: userData.profileImageUrl || null,
      createdAt: existingUser?.createdAt || new Date(),
      updatedAt: new Date(),
    };
    this.users.set(user.id, user);
    return user;
  }
}

export class PostgresStorage implements IStorage {
  
  async seedData() {
    // Check if already seeded
    const existingProjects = await this.getProjects();
    if (existingProjects.length > 0) return;

    // Create a sample project with fixed ID for demo purposes
    const project = await db.insert(projects).values({
      id: "project-1",
      name: "Project Alpha - Avionics System",
      description: "Advanced avionics system for commercial aircraft",
    }).returning().then(res => res[0]);

    // Create sample PBS items
    const pbsItem1 = await this.createPbsItem({
      projectId: project.id,
      pbsId: "AVS-001",
      name: "Avionics System",
      description: "Main avionics system",
      parentId: null,
      level: 1,
      icon: "cube",
      color: "blue",
      owner: "Systems Team",
      status: "Active",
      progress: 75,
    });

    const pbsItem2 = await this.createPbsItem({
      projectId: project.id,
      pbsId: "FC-001",
      name: "Flight Control System",
      description: "Primary flight control system",
      parentId: pbsItem1.id,
      level: 2,
      icon: "microchip",
      color: "green",
      owner: "Flight Controls Team",
      status: "Active",
      progress: 85,
    });

    const pbsItem3 = await this.createPbsItem({
      projectId: project.id,
      pbsId: "FC-ALT-001",
      name: "Altitude Control",
      description: "Altitude control subsystem",
      parentId: pbsItem2.id,
      level: 3,
      icon: "cog",
      color: "blue",
      owner: "Flight Controls Team",
      status: "Active",
      progress: 90,
    });

    // Create sample requirements
    const req1 = await this.createRequirement({
      projectId: project.id,
      reqId: "REQ-001",
      text: "The avionics system shall operate within a temperature range of -40°C to +70°C",
      source: "System Requirements Document",
      compliance: "TBD",
      verification: "Test",
      owner: "Systems Engineer",
      status: "Open",
      evidence: "",
      notes: "Environmental testing required",
    });

    const req2 = await this.createRequirement({
      projectId: project.id,
      reqId: "REQ-002",
      text: "The flight control system shall have a response time of less than 10ms",
      source: "Performance Specification",
      compliance: "TBD",
      verification: "Test",
      owner: "Flight Controls Engineer",
      status: "In Progress",
      evidence: "",
      notes: "Timing analysis in progress",
    });

    const req3 = await this.createRequirement({
      projectId: project.id,
      reqId: "REQ-003",
      text: "The system shall provide redundant control paths for all critical functions",
      source: "Safety Requirements",
      compliance: "Yes",
      verification: "Analysis",
      owner: "Safety Engineer",
      status: "Closed",
      evidence: "Redundancy analysis complete",
      notes: "Dual redundancy implemented",
    });

    // Create sample requirement-PBS mappings
    await this.createRequirementPbsMapping({
      requirementId: req1.id,
      pbsItemId: pbsItem1.id,
    });

    await this.createRequirementPbsMapping({
      requirementId: req2.id,
      pbsItemId: pbsItem2.id,
    });

    await this.createRequirementPbsMapping({
      requirementId: req3.id,
      pbsItemId: pbsItem2.id,
    });

    console.log("Database seeded successfully");
  }

  // Projects
  async getProject(id: string): Promise<Project | undefined> {
    const result = await db.select().from(projects).where(eq(projects.id, id));
    return result[0];
  }

  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects);
  }

  async createProject(project: InsertProject): Promise<Project> {
    const result = await db.insert(projects).values(project).returning();
    return result[0];
  }

  async updateProject(id: string, project: Partial<InsertProject>): Promise<Project | undefined> {
    const result = await db.update(projects)
      .set({ ...project, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return result[0];
  }

  // Requirements
  async getRequirement(id: string): Promise<Requirement | undefined> {
    const result = await db.select().from(requirements).where(eq(requirements.id, id));
    return result[0];
  }

  async getRequirementsByProject(projectId: string): Promise<Requirement[]> {
    return await db.select().from(requirements).where(eq(requirements.projectId, projectId));
  }

  async createRequirement(requirement: InsertRequirement): Promise<Requirement> {
    const result = await db.insert(requirements).values(requirement).returning();
    return result[0];
  }

  async updateRequirement(id: string, requirement: Partial<InsertRequirement>): Promise<Requirement | undefined> {
    const result = await db.update(requirements)
      .set({ ...requirement, updatedAt: new Date() })
      .where(eq(requirements.id, id))
      .returning();
    return result[0];
  }

  async deleteRequirement(id: string): Promise<boolean> {
    const result = await db.delete(requirements).where(eq(requirements.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // PBS Items
  async getPbsItem(id: string): Promise<PbsItem | undefined> {
    const result = await db.select().from(pbsItems).where(eq(pbsItems.id, id));
    return result[0];
  }

  async getPbsItemsByProject(projectId: string): Promise<PbsItem[]> {
    return await db.select().from(pbsItems).where(eq(pbsItems.projectId, projectId));
  }

  async createPbsItem(pbsItem: InsertPbsItem): Promise<PbsItem> {
    const result = await db.insert(pbsItems).values(pbsItem).returning();
    return result[0];
  }

  async updatePbsItem(id: string, pbsItem: Partial<InsertPbsItem>): Promise<PbsItem | undefined> {
    const result = await db.update(pbsItems)
      .set({ ...pbsItem, updatedAt: new Date() })
      .where(eq(pbsItems.id, id))
      .returning();
    return result[0];
  }

  async deletePbsItem(id: string): Promise<boolean> {
    const result = await db.delete(pbsItems).where(eq(pbsItems.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Requirement-PBS Mappings
  async getRequirementPbsMappings(requirementId: string): Promise<RequirementPbsMapping[]> {
    return await db.select().from(requirementPbsMappings)
      .where(eq(requirementPbsMappings.requirementId, requirementId));
  }

  async getPbsMappingsByProject(projectId: string): Promise<RequirementPbsMapping[]> {
    // Join with requirements table to get mappings for project
    return await db.select({
      id: requirementPbsMappings.id,
      requirementId: requirementPbsMappings.requirementId,
      pbsItemId: requirementPbsMappings.pbsItemId,
      createdAt: requirementPbsMappings.createdAt,
    })
    .from(requirementPbsMappings)
    .innerJoin(requirements, eq(requirementPbsMappings.requirementId, requirements.id))
    .where(eq(requirements.projectId, projectId));
  }

  async createRequirementPbsMapping(mapping: InsertRequirementPbsMapping): Promise<RequirementPbsMapping> {
    const result = await db.insert(requirementPbsMappings).values(mapping).returning();
    return result[0];
  }

  async deleteRequirementPbsMapping(requirementId: string, pbsItemId: string): Promise<boolean> {
    const result = await db.delete(requirementPbsMappings)
      .where(and(
        eq(requirementPbsMappings.requirementId, requirementId),
        eq(requirementPbsMappings.pbsItemId, pbsItemId)
      ));
    return (result.rowCount ?? 0) > 0;
  }

  // Requirement Relationships
  async getRequirementRelationships(requirementId: string): Promise<RequirementRelationship[]> {
    const result = await db.select()
      .from(requirementRelationships)
      .where(or(
        eq(requirementRelationships.sourceRequirementId, requirementId),
        eq(requirementRelationships.targetRequirementId, requirementId)
      ));
    return result;
  }

  async createRequirementRelationship(relationship: InsertRequirementRelationship): Promise<RequirementRelationship> {
    const result = await db.insert(requirementRelationships)
      .values(relationship)
      .returning();
    return result[0];
  }

  async deleteRequirementRelationship(id: string): Promise<boolean> {
    const result = await db.delete(requirementRelationships)
      .where(eq(requirementRelationships.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Verification Items
  async getVerificationItemsByRequirement(requirementId: string): Promise<VerificationItem[]> {
    return await db.select().from(verificationItems)
      .where(eq(verificationItems.requirementId, requirementId));
  }

  async getVerificationItemsByProject(projectId: string): Promise<VerificationItem[]> {
    // Join with requirements to filter by project
    const results = await db.select({
      verificationItem: verificationItems
    }).from(verificationItems)
      .innerJoin(requirements, eq(verificationItems.requirementId, requirements.id))
      .where(eq(requirements.projectId, projectId));
    return results.map(r => r.verificationItem);
  }

  async createVerificationItem(item: InsertVerificationItem): Promise<VerificationItem> {
    const result = await db.insert(verificationItems).values(item).returning();
    return result[0];
  }

  async updateVerificationItem(id: string, item: Partial<InsertVerificationItem>): Promise<VerificationItem | undefined> {
    const result = await db.update(verificationItems)
      .set({ ...item, updatedAt: new Date() })
      .where(eq(verificationItems.id, id))
      .returning();
    return result[0];
  }

  async deleteVerificationItem(id: string): Promise<boolean> {
    const result = await db.delete(verificationItems).where(eq(verificationItems.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Specifications
  async getSpecificationsByProject(projectId: string): Promise<Specification[]> {
    return await db.select().from(specifications).where(eq(specifications.projectId, projectId));
  }

  async createSpecification(spec: InsertSpecification): Promise<Specification> {
    const result = await db.insert(specifications).values(spec).returning();
    return result[0];
  }

  async deleteSpecification(id: string): Promise<boolean> {
    const result = await db.delete(specifications).where(eq(specifications.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // User operations (IMPORTANT: mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }
}

export const storage = new PostgresStorage();

export async function initializeStorage() {
  await storage.seedData();
}
