import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertRequirementSchema, insertPbsItemSchema, insertRequirementPbsMappingSchema, insertRequirementRelationshipSchema, insertVerificationItemSchema, insertSpecificationSchema, insertProjectSchema, ExtractedRequirement, ExtractionConfig } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import { ServerDocumentParser } from "./documentParser";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes (public)
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Protect all data API routes (everything under /api except auth-related routes)
  app.use('/api', (req, res, next) => {
    // Allow public auth-related routes
    if (req.path.startsWith('/auth') || 
        req.path === '/login' || 
        req.path === '/logout' || 
        req.path === '/callback') {
      return next();
    }
    // Require authentication for all other API routes
    return isAuthenticated(req, res, next);
  });

  // Configure multer for file uploads
  const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 10 * 1024 * 1024, // 10MB limit
    },
    /**
     * Accept a broader range of MIME types to better support user
     * uploads.  Some browsers and platforms label PDF and other
     * document types with non-standard MIME strings such as
     * `application/octet-stream` or `application/x-pdf`.  Rather than
     * relying on an exact match, we allow known types and also
     * gracefully accept variants that include the file extension.
     */
    fileFilter: (req, file, cb) => {
      const mime = (file.mimetype || '').toLowerCase();
      const allowedExact = new Set([
        'text/plain',
        'text/markdown',
        'application/pdf',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel',
        'text/csv',
        'application/json',
        'text/html'
      ]);
      // Accept common non-standard variants for PDF and office docs
      const isPdfLike = mime.includes('pdf');
      const isDocxLike = mime.includes('wordprocessingml');
      const isXlsxLike = mime.includes('spreadsheetml') || mime.includes('ms-excel');
      const isCsvLike = mime.includes('csv');
      const isJsonLike = mime.includes('json');
      const isHtmlLike = mime.includes('html');
      const isPlainLike = mime.startsWith('text/');
      if (
        allowedExact.has(mime) ||
        isPdfLike ||
        isDocxLike ||
        isXlsxLike ||
        isCsvLike ||
        isJsonLike ||
        isHtmlLike ||
        isPlainLike
      ) {
        cb(null, true);
      } else {
        cb(new Error('Unsupported file type'));
      }
    }
  });

  // Document parsing endpoints
  app.post('/api/documents/parse', upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
      }

      const document = await ServerDocumentParser.parseDocument(
        req.file.buffer, 
        req.file.originalname, 
        req.file.mimetype
      );

      res.json({
        success: true,
        document: {
          text: document.text,
          metadata: document.metadata,
          sections: document.sections,
          tables: document.tables
        }
      });
    } catch (error) {
      console.error('Document parsing error:', error);
      res.status(500).json({ 
        message: 'Failed to parse document',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.post('/api/documents/extract-requirements', async (req, res) => {
    try {
      const { document, config } = req.body as {
        document: any;
        config: ExtractionConfig;
      };

      if (!document || !config) {
        return res.status(400).json({ message: 'Document and config are required' });
      }

      const requirements = ServerDocumentParser.extractRequirementsFromDocument(
        document,
        config
      );

      res.json({
        success: true,
        requirements
      });
    } catch (error) {
      console.error('Requirement extraction error:', error);
      res.status(500).json({ 
        message: 'Failed to extract requirements',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Projects
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const projectData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(projectData);
      res.json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid project data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create project" });
      }
    }
  });

  // Requirements
  app.get("/api/projects/:projectId/requirements", async (req, res) => {
    try {
      const requirements = await storage.getRequirementsByProject(req.params.projectId);
      res.json(requirements);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch requirements" });
    }
  });

  app.post("/api/requirements", async (req, res) => {
    try {
      const requirementData = insertRequirementSchema.parse(req.body);
      const requirement = await storage.createRequirement(requirementData);
      res.json(requirement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid requirement data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create requirement" });
      }
    }
  });

  app.put("/api/requirements/:id", async (req, res) => {
    try {
      const updateData = insertRequirementSchema.partial().parse(req.body);
      const requirement = await storage.updateRequirement(req.params.id, updateData);
      if (!requirement) {
        return res.status(404).json({ message: "Requirement not found" });
      }
      res.json(requirement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid requirement data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update requirement" });
      }
    }
  });

  app.delete("/api/requirements/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteRequirement(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Requirement not found" });
      }
      res.json({ message: "Requirement deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete requirement" });
    }
  });

  // PBS Items
  app.get("/api/projects/:projectId/pbs-items", async (req, res) => {
    try {
      const pbsItems = await storage.getPbsItemsByProject(req.params.projectId);
      res.json(pbsItems);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch PBS items" });
    }
  });

  app.post("/api/pbs-items", async (req, res) => {
    try {
      const pbsItemData = insertPbsItemSchema.parse(req.body);
      const pbsItem = await storage.createPbsItem(pbsItemData);
      res.json(pbsItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid PBS item data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create PBS item" });
      }
    }
  });

  app.put("/api/pbs-items/:id", async (req, res) => {
    try {
      const updateData = insertPbsItemSchema.partial().parse(req.body);
      const pbsItem = await storage.updatePbsItem(req.params.id, updateData);
      if (!pbsItem) {
        return res.status(404).json({ message: "PBS item not found" });
      }
      res.json(pbsItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid PBS item data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update PBS item" });
      }
    }
  });

  // Requirement-PBS Mappings
  app.get("/api/requirements/:requirementId/pbs-mappings", async (req, res) => {
    try {
      const mappings = await storage.getRequirementPbsMappings(req.params.requirementId);
      res.json(mappings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch PBS mappings" });
    }
  });

  app.get("/api/projects/:projectId/pbs-mappings", async (req, res) => {
    try {
      const mappings = await storage.getPbsMappingsByProject(req.params.projectId);
      res.json(mappings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch project PBS mappings" });
    }
  });

  app.post("/api/requirement-pbs-mappings", async (req, res) => {
    try {
      const mappingData = insertRequirementPbsMappingSchema.parse(req.body);
      const mapping = await storage.createRequirementPbsMapping(mappingData);
      res.json(mapping);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid mapping data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create mapping" });
      }
    }
  });

  app.delete("/api/requirement-pbs-mappings/:requirementId/:pbsItemId", async (req, res) => {
    try {
      const deleted = await storage.deleteRequirementPbsMapping(req.params.requirementId, req.params.pbsItemId);
      if (!deleted) {
        return res.status(404).json({ message: "Mapping not found" });
      }
      res.json({ message: "Mapping deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete mapping" });
    }
  });

  // Requirement relationships
  app.get("/api/requirements/:requirementId/relationships", async (req, res) => {
    try {
      const relationships = await storage.getRequirementRelationships(req.params.requirementId);
      res.json(relationships);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch requirement relationships" });
    }
  });

  app.post("/api/requirement-relationships", async (req, res) => {
    try {
      const relationshipData = insertRequirementRelationshipSchema.parse(req.body);
      const relationship = await storage.createRequirementRelationship(relationshipData);
      res.json(relationship);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid relationship data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create requirement relationship" });
      }
    }
  });

  app.delete("/api/requirement-relationships/:id", async (req, res) => {
    try {
      await storage.deleteRequirementRelationship(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete requirement relationship" });
    }
  });

  // Verification Items
  app.get("/api/projects/:projectId/verification-items", async (req, res) => {
    try {
      const items = await storage.getVerificationItemsByProject(req.params.projectId);
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch verification items" });
    }
  });

  app.post("/api/verification-items", async (req, res) => {
    try {
      const itemData = insertVerificationItemSchema.parse(req.body);
      const item = await storage.createVerificationItem(itemData);
      res.json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid verification item data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create verification item" });
      }
    }
  });

  // Specifications
  app.get("/api/projects/:projectId/specifications", async (req, res) => {
    try {
      const specs = await storage.getSpecificationsByProject(req.params.projectId);
      res.json(specs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch specifications" });
    }
  });

  app.post("/api/specifications", async (req, res) => {
    try {
      const specData = insertSpecificationSchema.parse(req.body);
      const spec = await storage.createSpecification(specData);
      res.json(spec);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid specification data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create specification" });
      }
    }
  });

  // Export endpoints
  app.get("/api/projects/:projectId/export/compliance-matrix", async (req, res) => {
    try {
      const requirements = await storage.getRequirementsByProject(req.params.projectId);
      const pbsItems = await storage.getPbsItemsByProject(req.params.projectId);
      
      // Create CSV content
      const headers = ["ID", "Requirement", "Source", "Compliance", "Verification", "Owner", "Status", "PBS Items", "Evidence", "Notes"];
      const rows = await Promise.all(requirements.map(async (req) => {
        const mappings = await storage.getRequirementPbsMappings(req.id);
        const pbsMapped = mappings.map(m => {
          const pbs = pbsItems.find(p => p.id === m.pbsItemId);
          return pbs ? pbs.pbsId : '';
        }).join('; ');
        
        return [
          req.reqId,
          req.text.replace(/"/g, '""'),
          req.source?.replace(/"/g, '""') || "",
          req.compliance || "",
          req.verification || "",
          req.owner || "",
          req.status || "",
          pbsMapped,
          req.evidence?.replace(/"/g, '""') || "",
          req.notes?.replace(/"/g, '""') || "",
        ];
      }));

      const csv = [headers, ...rows]
        .map(row => row.map(cell => `"${cell}"`).join(","))
        .join("\n");

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="compliance-matrix.csv"');
      res.send(csv);
    } catch (error) {
      res.status(500).json({ message: "Failed to export compliance matrix" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
