import { ExtractedRequirement, ExtractionConfig } from '@shared/schema';

export interface DocumentMetadata {
  title?: string;
  author?: string;
  pageCount?: number;
  wordCount?: number;
  sections?: DocumentSection[];
}

export interface DocumentSection {
  id: string;
  title: string;
  level: number;
  content: string;
  pageNumber?: number;
  requirements?: ExtractedRequirement[];
}

export interface ParsedDocument {
  text: string;
  metadata: DocumentMetadata;
  sections: DocumentSection[];
  tables: DocumentTable[];
  rawStructure?: any;
}

export interface DocumentTable {
  id: string;
  title?: string;
  headers: string[];
  rows: string[][];
  pageNumber?: number;
  section?: string;
}

export class ServerDocumentParser {
  private static idCounter = 1;
  
  private static generateId(prefix = 'doc') {
    return `${prefix}-${Date.now()}-${this.idCounter++}`;
  }

  /**
   * Parse document buffer based on content type
   */
  static async parseDocument(buffer: Buffer, fileName: string, contentType?: string): Promise<ParsedDocument> {
    const fileExt = fileName.toLowerCase().split('.').pop();
    
    switch (fileExt) {
      case 'pdf':
        return await this.parsePDF(buffer);
      case 'docx':
        return await this.parseDOCX(buffer);
      case 'xlsx':
      case 'xls':
        return await this.parseExcel(buffer);
      case 'csv':
        return await this.parseCSV(buffer);
      case 'json':
        return await this.parseJSON(buffer);
      case 'txt':
      case 'md':
        return this.parseText(buffer.toString('utf-8'));
      case 'html':
        return this.parseHTML(buffer.toString('utf-8'));
      default:
        throw new Error(`Unsupported file type: ${fileExt}`);
    }
  }

  /**
   * Parse PDF document using pdfjs-dist
   */
  private static async parsePDF(buffer: Buffer): Promise<ParsedDocument> {
    /**
     * Attempt to parse a PDF buffer using pdfjs-dist.  In some
     * environments the default entry point for pdfjs-dist is designed
     * for browsers and attempts to fetch a worker script.  This can
     * cause the parser to fail in a Node context.  To work around
     * this we attempt to import the legacy build which is more
     * compatible with Node, and we explicitly disable the worker when
     * loading the document.  If pdfjs-dist is not available or
     * parsing fails for any reason, a secondary attempt is made using
     * pdf-parse (if installed).  Should both approaches fail, we
     * return a minimal fallback response so the calling code can
     * gracefully handle the failure.
     */
    try {
      console.log(`Attempting PDF parsing. Buffer size: ${buffer.length} bytes`);
      let pdfjsLib: any | null = null;
      // First try to import the Node-friendly legacy build
      try {
        pdfjsLib = await import('pdfjs-dist/legacy/build/pdf.js');
      } catch (legacyErr) {
        // Fall back to the default entry if legacy build is unavailable
        try {
          pdfjsLib = await import('pdfjs-dist');
        } catch (defaultErr) {
          pdfjsLib = null;
        }
      }
      if (pdfjsLib) {
        // Disable worker to avoid worker fetch issues in Node
        const loadingTask = pdfjsLib.getDocument({
          data: buffer,
          disableWorker: true
        });
        const pdf = await loadingTask.promise;
        let fullText = '';
        const sections: DocumentSection[] = [];
        // Extract text from each page
        for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
          const page = await pdf.getPage(pageNum);
          const textContent = await page.getTextContent();
          const pageText = (textContent.items as any[])
            .map((item) => (item && typeof (item as any).str === 'string' ? (item as any).str : ''))
            .join(' ')
            .replace(/\s+/g, ' ')
            .trim();
          if (pageText) {
            fullText += `Page ${pageNum}:\n${pageText}\n\n`;
            sections.push({
              id: this.generateId('page'),
              title: `Page ${pageNum}`,
              content: pageText,
              level: 1
            });
          }
        }
        const cleanedText = this.cleanText(fullText);
        const extractedSections = this.extractSections(cleanedText);
        const finalSections = extractedSections.length > sections.length ? extractedSections : sections;
        const metadata: DocumentMetadata = {
          title: `PDF Document (${pdf.numPages} pages)`,
          wordCount: this.countWords(cleanedText),
          sections: finalSections
        };
        console.log(
          `PDF parsing (pdfjs) successful: ${pdf.numPages} pages, ${cleanedText.length} chars`
        );
        return {
          text: cleanedText,
          metadata,
          sections: finalSections,
          tables: [],
          rawStructure: { numPages: pdf.numPages }
        };
      }
      // If we reach here then pdfjs-dist could not be imported; try pdf-parse
      try {
        const pdfParseModule: any = await import('pdf-parse');
        const pdfParse = pdfParseModule?.default || pdfParseModule;
        const data = await pdfParse(buffer);
        const rawText: string = data && typeof data.text === 'string' ? data.text : '';
        const cleanedText = this.cleanText(rawText);
        const extractedSections = this.extractSections(cleanedText);
        const metadata: DocumentMetadata = {
          title: data?.info?.Title || `PDF Document (${data?.numpages ?? '?' } pages)`,
          wordCount: this.countWords(cleanedText),
          sections: extractedSections
        };
        console.log(
          `PDF parsing (pdf-parse) successful: ${data?.numpages ?? '?' } pages, ${cleanedText.length} chars`
        );
        return {
          text: cleanedText,
          metadata,
          sections: extractedSections,
          tables: [],
          rawStructure: data
        };
      } catch (parseErr) {
        // fall through to final error handling
      }
      throw new Error('No PDF parser available');
    } catch (error) {
      console.error('PDF parsing failed:', error instanceof Error ? error.message : error);
      const fallbackText = `PDF parsing failed. Document received (${buffer.length} bytes). Please convert the PDF to text or use a different document type.`;
      const metadata: DocumentMetadata = {
        title: 'PDF Document (parsing failed)',
        wordCount: this.countWords(fallbackText),
        sections: []
      };
      return {
        text: fallbackText,
        metadata,
        sections: [
          {
            id: this.generateId('pdf-fallback'),
            title: 'PDF Content (fallback)',
            content: fallbackText,
            level: 1
          }
        ],
        tables: [],
        rawStructure: null
      };
    }
  }

  /**
   * Parse Excel document (XLSX/XLS)
   */
  private static async parseExcel(buffer: Buffer): Promise<ParsedDocument> {
    try {
      // Dynamic import to avoid loading issues
      const XLSX = await import('xlsx');
      
      // Parse the Excel file from buffer
      const workbook = XLSX.read(buffer, { type: 'buffer' });
      
      let allText = '';
      const sections: DocumentSection[] = [];
      const tables: DocumentTable[] = [];
      
      // Process each worksheet
      workbook.SheetNames.forEach((sheetName, sheetIndex) => {
        const worksheet = workbook.Sheets[sheetName];
        
        // Convert to JSON to get structured data
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' }) as string[][];
        
        // Extract text content for requirements parsing
        const sheetText = jsonData
          .map(row => row.filter(cell => cell && cell.toString().trim()).join(' | '))
          .filter(row => row.trim())
          .join('\n');
        
        if (sheetText.trim()) {
          allText += `Sheet: ${sheetName}\n${sheetText}\n\n`;
          
          sections.push({
            id: this.generateId('sheet'),
            title: `Sheet: ${sheetName}`,
            content: sheetText,
            level: 1
          });
          
          // Create table representation
          if (jsonData.length > 0) {
            const headers = jsonData[0]?.map((cell, index) => cell || `Column ${index + 1}`) || [];
            const rows = jsonData.slice(1).filter(row => row.some(cell => cell && cell.toString().trim()));
            
            if (rows.length > 0) {
              tables.push({
                id: this.generateId('table'),
                title: `Table from ${sheetName}`,
                headers,
                rows: rows.map(row => row.map(cell => cell?.toString() || '')),
                section: sheetName
              });
            }
          }
        }
      });
      
      const text = this.cleanText(allText);
      const extractedSections = this.extractSections(text);
      
      // Use extracted sections if they provide more structure, otherwise use sheet-based sections
      const finalSections = extractedSections.length > sections.length ? extractedSections : sections;
      
      const metadata: DocumentMetadata = {
        title: `Excel Workbook (${workbook.SheetNames.length} sheets)`,
        wordCount: this.countWords(text),
        sections: finalSections
      };

      return {
        text,
        metadata,
        sections: finalSections,
        tables,
        rawStructure: workbook
      };
    } catch (error) {
      console.error('Excel parsing error:', error instanceof Error ? error.message : 'Unknown error');
      throw new Error(`Failed to parse Excel file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Parse CSV file (structured requirements data)
   */
  private static async parseCSV(buffer: Buffer): Promise<ParsedDocument> {
    try {
      const csvContent = buffer.toString('utf-8');
      const lines = csvContent.split('\n').filter(line => line.trim());
      
      if (lines.length === 0) {
        throw new Error('Empty CSV file');
      }

      // Use robust CSV parsing library
      const { parse } = await import('csv-parse/sync');
      const rows = parse(csvContent, {
        skip_empty_lines: true,
        trim: true,
        auto_parse: true,
        auto_parse_date: false
      }) as string[][];

      const headers = rows[0];
      const dataRows = rows.slice(1);
      
      // Look for requirement-related columns
      const reqColumns = this.findRequirementColumns(headers);
      
      let allText = '';
      const sections: DocumentSection[] = [];
      const tables: DocumentTable[] = [];
      
      // Create table representation
      tables.push({
        id: this.generateId('csv-table'),
        title: 'CSV Data',
        headers,
        rows: dataRows,
        section: 'CSV Import'
      });
      
      // Extract text content
      if (reqColumns.textCol !== -1) {
        dataRows.forEach((row, index) => {
          const reqText = row[reqColumns.textCol];
          if (reqText && reqText.trim()) {
            allText += `${reqText}\n`;
            
            sections.push({
              id: this.generateId('csv-req'),
              title: `Requirement ${index + 1}`,
              content: reqText,
              level: 1
            });
          }
        });
      } else {
        // If no clear requirement column, concatenate all non-ID columns
        dataRows.forEach((row, index) => {
          const rowText = row.slice(1).filter(cell => cell && cell.trim()).join(' ');
          if (rowText) {
            allText += `Row ${index + 1}: ${rowText}\n`;
          }
        });
      }
      
      const text = this.cleanText(allText);
      
      const metadata: DocumentMetadata = {
        title: `CSV Data (${dataRows.length} rows)`,
        wordCount: this.countWords(text),
        sections
      };

      return {
        text,
        metadata,
        sections,
        tables,
        rawStructure: { headers, rows: dataRows }
      };
    } catch (error) {
      console.error('CSV parsing error:', error instanceof Error ? error.message : 'Unknown error');
      throw new Error(`Failed to parse CSV file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Parse JSON file (structured requirements data)
   */
  private static async parseJSON(buffer: Buffer): Promise<ParsedDocument> {
    try {
      const jsonContent = buffer.toString('utf-8');
      const data = JSON.parse(jsonContent);
      
      let allText = '';
      const sections: DocumentSection[] = [];
      const tables: DocumentTable[] = [];
      
      // Handle different JSON structures
      if (Array.isArray(data)) {
        // Array of requirements
        data.forEach((item, index) => {
          const text = this.extractTextFromObject(item);
          if (text) {
            allText += `${text}\n`;
            sections.push({
              id: this.generateId('json-item'),
              title: `Item ${index + 1}`,
              content: text,
              level: 1
            });
          }
        });
      } else if (typeof data === 'object') {
        // Single object or nested structure
        const text = this.extractTextFromObject(data);
        allText = text;
        sections.push({
          id: this.generateId('json-root'),
          title: 'JSON Content',
          content: text,
          level: 1
        });
      }
      
      const cleanedText = this.cleanText(allText);
      
      const metadata: DocumentMetadata = {
        title: 'JSON Data',
        wordCount: this.countWords(cleanedText),
        sections
      };

      return {
        text: cleanedText,
        metadata,
        sections,
        tables,
        rawStructure: data
      };
    } catch (error) {
      console.error('JSON parsing error:', error instanceof Error ? error.message : 'Unknown error');
      throw new Error(`Failed to parse JSON file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Parse HTML file
   */
  private static parseHTML(content: string): ParsedDocument {
    // Simple HTML parsing - remove tags and extract text
    const text = content
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<[^>]*>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    
    const cleanedText = this.cleanText(text);
    const sections = this.extractSections(cleanedText);
    
    const metadata: DocumentMetadata = {
      title: 'HTML Document',
      wordCount: this.countWords(cleanedText),
      sections
    };

    return {
      text: cleanedText,
      metadata,
      sections,
      tables: [],
      rawStructure: null
    };
  }

  /**
   * Helper: Find requirement-related columns in CSV headers
   */
  private static findRequirementColumns(headers: string[]) {
    const lowerHeaders = headers.map(h => h.toLowerCase());
    
    const textCol = lowerHeaders.findIndex(h => 
      h.includes('requirement') || h.includes('text') || h.includes('description') || h.includes('spec')
    );
    
    const idCol = lowerHeaders.findIndex(h => 
      h.includes('id') || h.includes('req') || h === 'id'
    );
    
    return { textCol, idCol };
  }

  /**
   * Helper: Extract text from JSON object recursively
   */
  private static extractTextFromObject(obj: any): string {
    if (typeof obj === 'string') {
      return obj;
    }
    
    if (typeof obj === 'object' && obj !== null) {
      const texts: string[] = [];
      
      // Look for common requirement fields
      const reqFields = ['requirement', 'text', 'description', 'spec', 'title', 'content'];
      
      for (const field of reqFields) {
        if (obj[field] && typeof obj[field] === 'string') {
          texts.push(obj[field]);
        }
      }
      
      // If no specific fields found, concatenate all string values
      if (texts.length === 0) {
        for (const key in obj) {
          if (typeof obj[key] === 'string') {
            texts.push(obj[key]);
          } else if (typeof obj[key] === 'object') {
            const nested = this.extractTextFromObject(obj[key]);
            if (nested) texts.push(nested);
          }
        }
      }
      
      return texts.join(' ');
    }
    
    return String(obj);
  }

  /**
   * Parse DOCX document
   */
  private static async parseDOCX(buffer: Buffer): Promise<ParsedDocument> {
    try {
      // Dynamic import to avoid any loading issues
      const mammoth = await import('mammoth');
      const result = await mammoth.extractRawText({ buffer });
      const text = this.cleanText(result.value);
      const sections = this.extractSections(text);
      const tables = this.extractTables(text);

      // Get structured content with styling
      const htmlResult = await mammoth.convertToHtml({ buffer });
      const htmlSections = this.extractSectionsFromHTML(htmlResult.value);
      
      // Only use HTML-derived sections if they would improve upon text-based sections
      // Otherwise, prefer the text-based sections that have content
      const finalSections = htmlSections.length > 0 && sections.length === 1 
        ? htmlSections 
        : sections;

      const metadata: DocumentMetadata = {
        wordCount: this.countWords(text),
        sections: finalSections
      };

      return {
        text,
        metadata,
        sections: finalSections,
        tables,
        rawStructure: { text: result.value, html: htmlResult.value }
      };
    } catch (error) {
      console.error('DOCX parsing error:', error);
      throw new Error(`Failed to parse DOCX: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Parse plain text
   */
  private static parseText(text: string): ParsedDocument {
    const cleanedText = this.cleanText(text);
    const sections = this.extractSections(cleanedText);
    const tables = this.extractTables(cleanedText);

    const metadata: DocumentMetadata = {
      wordCount: this.countWords(cleanedText),
      sections
    };

    return {
      text: cleanedText,
      metadata,
      sections,
      tables
    };
  }

  /**
   * Extract document sections
   */
  private static extractSections(text: string): DocumentSection[] {
    const sections: DocumentSection[] = [];
    const lines = text.split('\n').map(line => line.trim()).filter(Boolean);
    
    const headingPatterns = [
      /^(\d+(?:\.\d+)*)\s+(.+)$/,
      /^([A-Z](?:\.[A-Z])*)\s+(.+)$/,
      /^([IVXLC]+(?:\.[IVXLC]+)*)\s+(.+)$/,
      /^(Chapter|Section|Part)\s+(\d+(?:\.\d+)*)\s*[:-]?\s*(.+)$/i,
      /^([A-Z][A-Z\s]{2,})\s*$/,
    ];

    let currentSection: DocumentSection | null = null;
    let sectionContent: string[] = [];
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      let isHeading = false;
      let headingInfo: { level: number; title: string; id: string } | null = null;

      for (const pattern of headingPatterns) {
        const match = line.match(pattern);
        if (match) {
          const level = this.calculateHeadingLevel(match[1] || match[0]);
          const title = match[3] || match[2] || match[1];
          
          if (title && title.length > 2) {
            headingInfo = {
              level,
              title: title.trim(),
              id: this.generateId('section')
            };
            isHeading = true;
            break;
          }
        }
      }

      if (isHeading && headingInfo) {
        if (currentSection) {
          currentSection.content = sectionContent.join('\n').trim();
          sections.push(currentSection);
        }

        currentSection = {
          id: headingInfo.id,
          title: headingInfo.title,
          level: headingInfo.level,
          content: ''
        };
        sectionContent = [];
      } else if (currentSection) {
        sectionContent.push(line);
      } else {
        if (!currentSection) {
          currentSection = {
            id: this.generateId('section'),
            title: 'Introduction',
            level: 0,
            content: ''
          };
          sectionContent = [];
        }
        sectionContent.push(line);
      }
    }

    if (currentSection) {
      currentSection.content = sectionContent.join('\n').trim();
      sections.push(currentSection);
    }

    return sections;
  }

  /**
   * Extract tables
   */
  private static extractTables(text: string): DocumentTable[] {
    const tables: DocumentTable[] = [];
    const lines = text.split('\n');
    
    const tablePatterns = [
      /\|.+\|/,
      /\t.+\t/,
      /\s{3,}.+\s{3,}/,
    ];

    let currentTable: { headers?: string[]; rows: string[][] } | null = null;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      const isTableRow = tablePatterns.some(pattern => pattern.test(line));
      
      if (isTableRow) {
        const cells = this.parseTableRow(line);
        
        if (!currentTable) {
          currentTable = { rows: [] };
          currentTable.headers = cells;
        } else {
          currentTable.rows.push(cells);
        }
      } else if (currentTable && currentTable.rows.length > 0) {
        tables.push({
          id: this.generateId('table'),
          headers: currentTable.headers || [],
          rows: currentTable.rows,
          title: `Table ${tables.length + 1}`
        });
        currentTable = null;
      }
    }

    if (currentTable && currentTable.rows.length > 0) {
      tables.push({
        id: this.generateId('table'),
        headers: currentTable.headers || [],
        rows: currentTable.rows,
        title: `Table ${tables.length + 1}`
      });
    }

    return tables;
  }

  private static parseTableRow(line: string): string[] {
    if (line.includes('|')) {
      return line.split('|').map(cell => cell.trim()).filter(Boolean);
    } else if (line.includes('\t')) {
      return line.split('\t').map(cell => cell.trim()).filter(Boolean);
    } else {
      return line.split(/\s{3,}/).map(cell => cell.trim()).filter(Boolean);
    }
  }

  private static extractSectionsFromHTML(html: string): DocumentSection[] {
    const sections: DocumentSection[] = [];
    const headingRegex = /<h([1-6])[^>]*>(.*?)<\/h[1-6]>/gi;
    let match;
    
    while ((match = headingRegex.exec(html)) !== null) {
      const level = parseInt(match[1]);
      const title = match[2].replace(/<[^>]*>/g, '').trim();
      
      if (title) {
        sections.push({
          id: this.generateId('section'),
          title,
          level,
          content: ''
        });
      }
    }

    return sections;
  }

  private static calculateHeadingLevel(pattern: string): number {
    if (/^\d+$/.test(pattern)) return 1;
    if (/^\d+\.\d+$/.test(pattern)) return 2;
    if (/^\d+\.\d+\.\d+$/.test(pattern)) return 3;
    
    const dots = (pattern.match(/\./g) || []).length;
    return Math.min(dots + 1, 6);
  }

  private static cleanText(text: string): string {
    return text
      .replace(/\r\n/g, '\n')
      .replace(/\r/g, '\n')
      .replace(/\n{3,}/g, '\n\n')
      .replace(/[ \t]+/g, ' ')
      .trim();
  }

  private static countWords(text: string): number {
    return text.split(/\s+/).filter(word => word.length > 0).length;
  }

  /**
   * Enhanced requirement extraction
   */
  static extractRequirementsFromDocument(
    document: ParsedDocument, 
    config: ExtractionConfig
  ): ExtractedRequirement[] {
    console.log('=== ExtractRequirementsFromDocument Debug ===');
    console.log('Document:', {
      hasText: !!document.text,
      textLength: document.text?.length || 0,
      sectionsCount: document.sections?.length || 0,
      tablesCount: document.tables?.length || 0,
    });
    console.log('Config:', config);
    
    const requirements: ExtractedRequirement[] = [];
    const idGen = this.makeIdGen(config.idPrefix);
    
    // Safely iterate over sections if they exist
    if (document.sections && Array.isArray(document.sections)) {
      console.log(`Processing ${document.sections.length} sections`);
      document.sections.forEach((section, index) => {
        const sectionRequirements = this.extractRequirementsFromSection(
          section, 
          config, 
          idGen
        );
        console.log(`Section ${index}: extracted ${sectionRequirements.length} requirements`);
        requirements.push(...sectionRequirements);
      });
    }

    // Safely iterate over tables if they exist
    if (document.tables && Array.isArray(document.tables)) {
      console.log(`Processing ${document.tables.length} tables`);
      document.tables.forEach((table, index) => {
        const tableRequirements = this.extractRequirementsFromTable(
          table, 
          config, 
          idGen
        );
        console.log(`Table ${index}: extracted ${tableRequirements.length} requirements`);
        requirements.push(...tableRequirements);
      });
    }

    // If no sections or tables, try to extract from raw text
    if ((!document.sections || document.sections.length === 0) && 
        (!document.tables || document.tables.length === 0) && 
        document.text) {
      // Fall back to basic text extraction
      console.log('No structured sections/tables found, falling back to text extraction');
      console.log('Text sample:', document.text.substring(0, 200));
      const textRequirements = this.extractRequirementsFromText(document.text, config, idGen);
      console.log(`Text extraction: found ${textRequirements.length} requirements`);
      requirements.push(...textRequirements);
    }

    console.log(`=== Total extracted: ${requirements.length} requirements ===`);
    return requirements;
  }

  private static extractRequirementsFromText(
    rawText: string, 
    config: ExtractionConfig, 
    idGen: () => string
  ): ExtractedRequirement[] {
    if (!rawText) return [];

    const lines = rawText
      .replace(/\r/g, "\n")
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean);

    const ctxStack: string[] = [];
    const out: ExtractedRequirement[] = [];
    const reqRegex = config.includeShould
      ? /(\bshall\b|\bmust\b|\brequired\b|\bshould\b)/i
      : /(\bshall\b|\bmust\b|\brequired\b)/i;

    const headingRegex = /^(\d+(?:\.\d+)*|[A-Z]\.|[IVXLC]+\.)\s+(.+)/; // 1, 1.2, A., I.

    lines.forEach((line, idx) => {
      const headingMatch = line.match(headingRegex);
      if (config.captureContext && headingMatch) {
        const label = headingMatch[1];
        const title = headingMatch[2];
        ctxStack.push(`${label} ${title}`);
        // Trim stack to last 6 to avoid bloat
        if (ctxStack.length > 6) ctxStack.shift();
      }

      const isReq = reqRegex.test(line) && line.replace(/\s+/g, " ").length >= config.minLen;
      if (isReq) {
        const id = idGen();
        const context = config.captureContext ? ctxStack.slice(-3).join(" › ") : "";
        out.push({
          id,
          text: line,
          source: context || `Line ${idx + 1}`,
          compliance: "TBD",
          verification: this.suggestVerification(line),
          owner: "",
          status: "Open",
          evidence: "",
          notes: "",
        });
      }
    });

    // If we found nothing, try a paragraph-based fallback with SHALL-only
    if (out.length === 0) {
      const paras = rawText.split(/\n\s*\n/).map((p) => p.trim());
      paras.forEach((p, i) => {
        if (/(\bshall\b|\bmust\b)/i.test(p) && p.length >= config.minLen) {
          out.push({
            id: idGen(),
            text: p.replace(/\s+/g, " ").trim(),
            source: `Para ${i + 1}`,
            compliance: "TBD",
            verification: this.suggestVerification(p),
            owner: "",
            status: "Open",
            evidence: "",
            notes: "",
          });
        }
      });
    }

    return out;
  }

  private static suggestVerification(text: string): string {
    const t = text.toLowerCase();
    if (/test|demonstrate|perform|validate|measure/.test(t)) return "Test";
    if (/analy(s|z)e|model|simulate|calc/.test(t)) return "Analysis";
    if (/inspect|visual|conform/.test(t)) return "Inspection";
    if (/show|prove|operate|function/.test(t)) return "Demonstration";
    return "TBD";
  }

  private static extractRequirementsFromSection(
    section: DocumentSection,
    config: ExtractionConfig,
    idGen: () => string
  ): ExtractedRequirement[] {
    const requirements: ExtractedRequirement[] = [];
    
    const reqRegex = config.includeShould
      ? /(\bshall\b|\bmust\b|\brequired\b|\bshould\b|\bneed\s+to\b|\bmay\b)/i
      : /(\bshall\b|\bmust\b|\brequired\b|\bneed\s+to\b)/i;

    const sentences = this.splitIntoSentences(section.content);
    
    sentences.forEach((sentence) => {
      if (this.isRequirement(sentence, reqRegex, config.minLen)) {
        const requirement: ExtractedRequirement = {
          id: idGen(),
          text: sentence.trim(),
          source: `${section.title}`,
          compliance: "TBD",
          verification: this.enhancedVerificationSuggestion(sentence),
          owner: "",
          status: "Open",
          evidence: "",
          notes: `Extracted from section: ${section.title}`,
        };
        
        requirements.push(requirement);
      }
    });

    return requirements;
  }

  private static extractRequirementsFromTable(
    table: DocumentTable,
    config: ExtractionConfig,
    idGen: () => string
  ): ExtractedRequirement[] {
    const requirements: ExtractedRequirement[] = [];
    
    const reqRegex = config.includeShould
      ? /(\bshall\b|\bmust\b|\brequired\b|\bshould\b|\bneed\s+to\b|\bmay\b)/i
      : /(\bshall\b|\bmust\b|\brequired\b|\bneed\s+to\b)/i;

    table.rows.forEach((row, rowIdx) => {
      row.forEach((cell, colIdx) => {
        if (this.isRequirement(cell, reqRegex, config.minLen)) {
          const columnName = table.headers[colIdx] || `Column ${colIdx + 1}`;
          
          const requirement: ExtractedRequirement = {
            id: idGen(),
            text: cell.trim(),
            source: `${table.title || 'Table'} - ${columnName}`,
            compliance: "TBD",
            verification: this.enhancedVerificationSuggestion(cell),
            owner: "",
            status: "Open",
            evidence: "",
            notes: `Extracted from table: ${table.title || 'Untitled Table'}`,
          };
          
          requirements.push(requirement);
        }
      });
    });

    return requirements;
  }

  private static enhancedVerificationSuggestion(text: string): string {
    const t = text.toLowerCase();
    
    if (/test|verify|validate|measure|check|examine|assess|evaluate/.test(t)) {
      if (/performance|speed|throughput|response|load/.test(t)) return "Performance Test";
      if (/interface|ui|user|display|screen/.test(t)) return "UI Test";
      if (/security|encrypt|auth|access|permission/.test(t)) return "Security Test";
      if (/integration|connect|interface|api/.test(t)) return "Integration Test";
      return "Test";
    }
    
    if (/analy(s|z)e|model|simulate|calc|compute|determine/.test(t)) {
      if (/stress|load|structural|thermal/.test(t)) return "Structural Analysis";
      if (/risk|safety|hazard/.test(t)) return "Risk Analysis";
      if (/performance|efficiency/.test(t)) return "Performance Analysis";
      return "Analysis";
    }
    
    if (/inspect|visual|review|examine|observe|check/.test(t)) {
      if (/document|paper|manual|procedure/.test(t)) return "Document Review";
      if (/code|software/.test(t)) return "Code Review";
      return "Inspection";
    }
    
    if (/demonstrate|show|prove|exhibit|display|operate|function/.test(t)) {
      return "Demonstration";
    }
    
    return "TBD";
  }

  private static isRequirement(text: string, reqRegex: RegExp, minLen: number): boolean {
    if (!text || text.length < minLen) return false;
    if (!reqRegex.test(text)) return false;
    
    const cleanText = text.replace(/\s+/g, ' ').trim();
    
    if (/^(table|figure|section|chapter|page|note|example)/i.test(cleanText)) {
      return false;
    }
    
    if (cleanText.split(' ').length < 5) return false;
    
    return true;
  }

  private static splitIntoSentences(text: string): string[] {
    return text
      .split(/[.!?]+/)
      .map(s => s.trim())
      .filter(s => s.length > 10);
  }

  private static makeIdGen(prefix = "REQ-", pad = 3) {
    let n = 1;
    return () => `${prefix}${String(n++).padStart(pad, "0")}`;
  }
}