# ReqMatrix - Requirements Management System

## Overview

ReqMatrix is a comprehensive requirements management and compliance tracking system designed for complex projects. The application provides end-to-end traceability from requirements through Product Breakdown Structure (PBS) mapping to verification and compliance tracking. It features a modern web interface built with React and TypeScript, backed by a RESTful Express.js API with PostgreSQL database storage.

The system addresses the challenge of managing complex project requirements by providing structured import capabilities, visual PBS mapping, drag-and-drop functionality for requirement-to-component associations, and comprehensive reporting features. It's particularly suited for aerospace, defense, or other highly regulated industries where requirement traceability is critical.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development practices
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Framework**: Radix UI components with shadcn/ui design system for consistent, accessible interfaces
- **Styling**: Tailwind CSS with custom design tokens and CSS variables for theming
- **Drag & Drop**: React DnD for intuitive requirement-to-PBS mapping interactions
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js framework providing RESTful API endpoints
- **Language**: TypeScript throughout for end-to-end type safety
- **API Design**: RESTful architecture with resource-based endpoints following standard HTTP methods
- **Error Handling**: Centralized error handling with proper HTTP status codes
- **Development**: Hot module replacement and live reloading via Vite integration

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for database migrations and schema evolution
- **Connection Pooling**: Neon serverless PostgreSQL with connection pooling for scalability
- **Data Models**: Comprehensive schema supporting projects, requirements, PBS items, mappings, and verification items

### Authentication and Authorization
- **Authentication System**: Fully implemented with Replit Auth (OpenID Connect)
- **Multi-Provider Support**: Google, GitHub, X (Twitter), Apple, and email/password login methods
- **Session Management**: PostgreSQL-backed sessions with connect-pg-simple, 7-day TTL, secure cookies
- **Server-side Protection**: All data API endpoints protected with authentication middleware
- **Security Features**: CSRF protection (sameSite: lax), token refresh handling, proper logout flow
- **User Management**: Automatic user upsert from OIDC claims, profile data persistence

### Key Architectural Decisions

**Monorepo Structure**: Single repository with shared TypeScript schemas between client and server eliminates type mismatches and reduces development overhead. The `/shared` directory contains common data types and validation schemas.

**Type-Safe Database Layer**: Drizzle ORM chosen over traditional ORMs for its TypeScript-first approach, providing compile-time type checking and better performance. Schema definitions serve as single source of truth for data structures.

**Component-Based UI**: Radix UI primitives provide accessible, unstyled components that are then styled with Tailwind CSS. This approach ensures accessibility compliance while maintaining design flexibility.

**Real-time Data Synchronization**: TanStack Query handles caching, synchronization, and optimistic updates, reducing server load and improving user experience through intelligent background refetching.

**Drag-and-Drop Interactions**: React DnD enables intuitive requirement-to-PBS mapping through visual drag-and-drop, significantly improving user workflow efficiency over traditional form-based approaches.

## External Dependencies

### Database Services
- **Neon PostgreSQL**: Serverless PostgreSQL database with automatic scaling and connection pooling
- **Drizzle ORM**: TypeScript ORM for database operations with compile-time type safety
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### UI and Styling
- **Radix UI**: Comprehensive set of accessible, unstyled UI primitives including dialogs, dropdowns, and form components
- **Tailwind CSS**: Utility-first CSS framework with custom configuration for consistent theming
- **Lucide React**: Icon library providing consistent iconography throughout the application
- **Framer Motion**: Animation library for smooth transitions and interactions

### Development and Build Tools
- **Vite**: Fast build tool with hot module replacement and optimized production builds
- **TypeScript**: Static type checking across frontend, backend, and shared code
- **ESBuild**: Fast JavaScript bundler used by Vite for development and production builds

### React Ecosystem
- **TanStack Query**: Powerful data synchronization library for server state management
- **React Hook Form**: Performant forms library with minimal re-renders and built-in validation
- **React DnD**: Drag and drop functionality with HTML5 backend
- **Wouter**: Minimalist routing library for client-side navigation

### Utility Libraries
- **Zod**: Schema validation library integrated with form handling and API validation
- **date-fns**: Modern date utility library for date formatting and manipulation
- **clsx**: Utility for constructing className strings conditionally
- **nanoid**: URL-safe unique ID generator for client-side ID generation

The architecture prioritizes type safety, developer experience, and maintainability while providing a robust foundation for complex requirements management workflows.