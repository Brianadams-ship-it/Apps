import { sql } from "drizzle-orm";
import { pgTable, text, varchar, json, jsonb, timestamp, boolean, integer, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
// IMPORTANT: This table is mandatory for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// IMPORTANT: This table is mandatory for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const requirements = pgTable("requirements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id).notNull(),
  reqId: text("req_id").notNull(), // REQ-001, REQ-002, etc.
  text: text("text").notNull(),
  source: text("source"),
  compliance: text("compliance").default("TBD"), // Yes/No/Partial/TBD
  verification: text("verification").default("TBD"), // Test/Analysis/Inspection/Demonstration/TBD
  owner: text("owner"),
  status: text("status").default("Open"), // Open/In Progress/Blocked/Closed
  evidence: text("evidence"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const pbsItems = pgTable("pbs_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id).notNull(),
  pbsId: text("pbs_id").notNull(), // FC-001, NAV-001, etc.
  name: text("name").notNull(),
  description: text("description"),
  parentId: varchar("parent_id"), // Self-reference handled via business logic
  level: integer("level").default(1),
  icon: text("icon"),
  color: text("color"),
  owner: text("owner"),
  status: text("status").default("Active"), // Active/Inactive/Complete
  progress: integer("progress").default(0), // 0-100
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const requirementPbsMappings = pgTable("requirement_pbs_mappings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  requirementId: varchar("requirement_id").references(() => requirements.id).notNull(),
  pbsItemId: varchar("pbs_item_id").references(() => pbsItems.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const requirementRelationships = pgTable("requirement_relationships", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sourceRequirementId: varchar("source_requirement_id").references(() => requirements.id).notNull(),
  targetRequirementId: varchar("target_requirement_id").references(() => requirements.id).notNull(),
  relationshipType: text("relationship_type").notNull(), // depends-on, relates-to, conflicts-with, derives-from, refines, etc.
  description: text("description"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const verificationItems = pgTable("verification_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  requirementId: varchar("requirement_id").references(() => requirements.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  method: text("method").notNull(), // Test/Analysis/Inspection/Demonstration
  status: text("status").default("Planned"), // Planned/In Progress/Complete/Failed
  assignee: text("assignee"),
  dueDate: timestamp("due_date"),
  completedAt: timestamp("completed_at"),
  evidence: text("evidence"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const specifications = pgTable("specifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").references(() => projects.id).notNull(),
  name: text("name").notNull(),
  content: text("content").notNull(),
  url: text("url"),
  extractionConfig: json("extraction_config").$type<{
    idPrefix: string;
    includeShould: boolean;
    minLen: number;
    captureContext: boolean;
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRequirementSchema = createInsertSchema(requirements).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPbsItemSchema = createInsertSchema(pbsItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRequirementPbsMappingSchema = createInsertSchema(requirementPbsMappings).omit({
  id: true,
  createdAt: true,
});

export const insertRequirementRelationshipSchema = createInsertSchema(requirementRelationships).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertVerificationItemSchema = createInsertSchema(verificationItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSpecificationSchema = createInsertSchema(specifications).omit({
  id: true,
  createdAt: true,
});

// Types
export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;

export type Requirement = typeof requirements.$inferSelect;
export type InsertRequirement = z.infer<typeof insertRequirementSchema>;

export type PbsItem = typeof pbsItems.$inferSelect;
export type InsertPbsItem = z.infer<typeof insertPbsItemSchema>;

export type RequirementPbsMapping = typeof requirementPbsMappings.$inferSelect;
export type InsertRequirementPbsMapping = z.infer<typeof insertRequirementPbsMappingSchema>;

export type RequirementRelationship = typeof requirementRelationships.$inferSelect;
export type InsertRequirementRelationship = z.infer<typeof insertRequirementRelationshipSchema>;

export type VerificationItem = typeof verificationItems.$inferSelect;
export type InsertVerificationItem = z.infer<typeof insertVerificationItemSchema>;

export type Specification = typeof specifications.$inferSelect;
export type InsertSpecification = z.infer<typeof insertSpecificationSchema>;

export type User = typeof users.$inferSelect;
export type UpsertUser = typeof users.$inferInsert;

// Document parsing types
export interface ExtractedRequirement {
  id: string;
  text: string;
  source: string;
  compliance: string;
  verification: string;
  owner: string;
  status: string;
  evidence: string;
  notes: string;
}

export interface ExtractionConfig {
  idPrefix: string;
  includeShould: boolean;
  minLen: number;
  captureContext: boolean;
}

// Status and verification enums for better type safety
export const RequirementStatus = {
  OPEN: "Open",
  IN_PROGRESS: "In Progress", 
  REVIEW: "Review",
  BLOCKED: "Blocked",
  CLOSED: "Closed"
} as const;

export const VerificationMethod = {
  TEST: "Test",
  ANALYSIS: "Analysis", 
  INSPECTION: "Inspection",
  DEMONSTRATION: "Demonstration",
  TBD: "TBD"
} as const;

export const VerificationStatus = {
  PLANNED: "Planned",
  IN_PROGRESS: "In Progress",
  COMPLETE: "Complete", 
  PASSED: "Passed",
  FAILED: "Failed",
  PENDING: "Pending"
} as const;

export const ComplianceStatus = {
  YES: "Yes",
  NO: "No", 
  PARTIAL: "Partial",
  TBD: "TBD"
} as const;

export const PbsStatus = {
  ACTIVE: "Active",
  INACTIVE: "Inactive",
  COMPLETE: "Complete"
} as const;

// Critical requirement classification
export const CriticalRequirementKeywords = [
  'security', 'safety', 'critical', 'essential', 'mandatory',
  'shall not fail', 'fault tolerant', 'failsafe', 'emergency'
] as const;

export type RequirementStatusType = typeof RequirementStatus[keyof typeof RequirementStatus];
export type VerificationMethodType = typeof VerificationMethod[keyof typeof VerificationMethod];
export type VerificationStatusType = typeof VerificationStatus[keyof typeof VerificationStatus];
export type ComplianceStatusType = typeof ComplianceStatus[keyof typeof ComplianceStatus];
export type PbsStatusType = typeof PbsStatus[keyof typeof PbsStatus];

// Requirement relationship types
export const RequirementRelationshipType = {
  DEPENDS_ON: "depends-on",
  RELATES_TO: "relates-to", 
  CONFLICTS_WITH: "conflicts-with",
  DERIVES_FROM: "derives-from",
  REFINES: "refines",
  IMPLEMENTS: "implements",
  SATISFIES: "satisfies",
  VALIDATES: "validates"
} as const;

export type RequirementRelationshipTypeType = typeof RequirementRelationshipType[keyof typeof RequirementRelationshipType];
