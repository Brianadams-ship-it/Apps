import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTaskSchema, insertProgramSchema, insertWorkPackageSchema, insertSprintSchema, insertCommentSchema, insertTimeEntrySchema, insertPersonSchema } from "@shared/schema";
import { z } from "zod";
import { ExcelService } from "./excel";
import { GitHubService } from "./github";

export async function registerRoutes(app: Express): Promise<Server> {
  // Programs
  app.get("/api/programs", async (req, res) => {
    try {
      const programs = await storage.getPrograms();
      res.json(programs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch programs" });
    }
  });

  app.get("/api/programs/:id", async (req, res) => {
    try {
      const program = await storage.getProgram(req.params.id);
      if (!program) {
        return res.status(404).json({ message: "Program not found" });
      }
      res.json(program);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch program" });
    }
  });

  app.post("/api/programs", async (req, res) => {
    try {
      const program = insertProgramSchema.parse(req.body);
      const created = await storage.createProgram(program);
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid program data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create program" });
    }
  });

  // Work Packages
  app.get("/api/programs/:programId/work-packages", async (req, res) => {
    try {
      const workPackages = await storage.getWorkPackagesByProgram(req.params.programId);
      res.json(workPackages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch work packages" });
    }
  });

  app.post("/api/work-packages", async (req, res) => {
    try {
      const workPackage = insertWorkPackageSchema.parse(req.body);
      const created = await storage.createWorkPackage(workPackage);
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid work package data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create work package" });
    }
  });

  // Tasks
  app.get("/api/programs/:programId/tasks", async (req, res) => {
    try {
      const tasks = await storage.getTasksByProgram(req.params.programId);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.get("/api/tasks/:id", async (req, res) => {
    try {
      const task = await storage.getTask(req.params.id);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json(task);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch task" });
    }
  });

  app.post("/api/tasks", async (req, res) => {
    try {
      const task = insertTaskSchema.parse(req.body);
      const created = await storage.createTask(task);
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    try {
      const updates = insertTaskSchema.partial().parse(req.body);
      const updated = await storage.updateTask(req.params.id, updates);
      if (!updated) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteTask(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  // Sprints
  app.get("/api/programs/:programId/sprints", async (req, res) => {
    try {
      const sprints = await storage.getSprintsByProgram(req.params.programId);
      res.json(sprints);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sprints" });
    }
  });

  app.post("/api/sprints", async (req, res) => {
    try {
      const sprint = insertSprintSchema.parse(req.body);
      const created = await storage.createSprint(sprint);
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid sprint data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create sprint" });
    }
  });

  app.patch("/api/sprints/:id", async (req, res) => {
    try {
      const updates = insertSprintSchema.partial().parse(req.body);
      const updated = await storage.updateSprint(req.params.id, updates);
      if (!updated) {
        return res.status(404).json({ message: "Sprint not found" });
      }
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid sprint data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update sprint" });
    }
  });

  // Comments
  app.get("/api/tasks/:taskId/comments", async (req, res) => {
    try {
      const comments = await storage.getCommentsByTask(req.params.taskId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  app.post("/api/comments", async (req, res) => {
    try {
      const comment = insertCommentSchema.parse(req.body);
      const created = await storage.createComment(comment);
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid comment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  // Time Tracking
  app.get("/api/tasks/:taskId/time-entries", async (req, res) => {
    try {
      const timeEntries = await storage.getTimeEntriesByTask(req.params.taskId);
      res.json(timeEntries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch time entries" });
    }
  });

  app.get("/api/tasks/:taskId/active-timer/:user", async (req, res) => {
    try {
      const activeTimer = await storage.getActiveTimeEntry(req.params.taskId, req.params.user);
      res.json(activeTimer || null);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active timer" });
    }
  });

  app.post("/api/time-entries", async (req, res) => {
    try {
      const timeEntry = insertTimeEntrySchema.parse(req.body);
      const created = await storage.createTimeEntry(timeEntry);
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid time entry data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create time entry" });
    }
  });

  app.patch("/api/time-entries/:id", async (req, res) => {
    try {
      const updates = insertTimeEntrySchema.partial().parse(req.body);
      const updated = await storage.updateTimeEntry(req.params.id, updates);
      if (!updated) {
        return res.status(404).json({ message: "Time entry not found" });
      }
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid time entry data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update time entry" });
    }
  });

  app.post("/api/users/:user/stop-all-timers", async (req, res) => {
    try {
      await storage.stopAllActiveTimers(req.params.user);
      res.status(200).json({ message: "All active timers stopped" });
    } catch (error) {
      res.status(500).json({ message: "Failed to stop timers" });
    }
  });

  app.delete("/api/time-entries/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteTimeEntry(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Time entry not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete time entry" });
    }
  });

  // Persons
  app.get("/api/persons", async (req, res) => {
    try {
      const persons = await storage.getPersons();
      res.json(persons);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch persons" });
    }
  });

  app.get("/api/persons/by-resource/:resourceType", async (req, res) => {
    try {
      const persons = await storage.getPersonsByResourceType(req.params.resourceType);
      res.json(persons);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch persons by resource type" });
    }
  });

  app.get("/api/persons/:id", async (req, res) => {
    try {
      const person = await storage.getPerson(req.params.id);
      if (!person) {
        return res.status(404).json({ message: "Person not found" });
      }
      res.json(person);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch person" });
    }
  });

  app.get("/api/persons/:id/tasks", async (req, res) => {
    try {
      const tasks = await storage.getTasksByPerson(req.params.id);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tasks by person" });
    }
  });

  app.post("/api/persons", async (req, res) => {
    try {
      const person = insertPersonSchema.parse(req.body);
      const created = await storage.createPerson(person);
      res.status(201).json(created);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid person data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create person" });
    }
  });

  // Excel Export/Import Routes
  const excelService = new ExcelService();
  const githubService = new GitHubService();

  app.post("/api/export-excel", async (req, res) => {
    try {
      // Gather all data
      const programs = await storage.getPrograms();
      const allWorkPackages = [];
      const allTasks = [];
      const allSprints = [];
      
      for (const program of programs) {
        const workPackages = await storage.getWorkPackagesByProgram(program.id);
        allWorkPackages.push(...workPackages);
        
        const tasks = await storage.getTasksByProgram(program.id);
        allTasks.push(...tasks);
        
        const sprints = await storage.getSprintsByProgram(program.id);
        allSprints.push(...sprints);
      }
      
      const persons = await storage.getPersons();
      
      // Collect all comments and time entries for all tasks
      const allComments = [];
      const allTimeEntries = [];
      for (const task of allTasks) {
        const taskComments = await storage.getCommentsByTask(task.id);
        const taskTimeEntries = await storage.getTimeEntriesByTask(task.id);
        allComments.push(...taskComments);
        allTimeEntries.push(...taskTimeEntries);
      }

      // Generate Excel file
      const excelBuffer = await excelService.generateExcel({
        programs,
        workPackages: allWorkPackages,
        tasks: allTasks,
        sprints: allSprints,
        persons,
        comments: allComments,
        timeEntries: allTimeEntries
      });

      // Upload to GitHub
      await githubService.uploadFile(excelBuffer, 'Export project data to Excel');

      // Get the GitHub file URLs
      const exportFileUrl = await githubService.getExportFileUrl();
      
      res.json({
        success: true,
        message: 'Data exported to Excel and uploaded to GitHub successfully',
        exportFileUrl,
        exportedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error('Export error:', error);
      res.status(500).json({ 
        success: false,
        message: 'Failed to export data to Excel',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.post("/api/import-excel", async (req, res) => {
    try {
      // Download file from GitHub
      const fileInfo = await githubService.downloadFile();
      if (!fileInfo) {
        return res.status(404).json({ 
          success: false,
          message: 'Excel file not found on GitHub'
        });
      }

      // Parse Excel file
      console.log('Downloaded file info:', {
        contentLength: fileInfo.content.length,
        sha: fileInfo.sha,
        lastModified: fileInfo.lastModified
      });
      
      const buffer = Buffer.from(fileInfo.content, 'base64');
      console.log('Buffer size:', buffer.length);
      
      if (buffer.length === 0) {
        throw new Error('Downloaded file is empty');
      }
      
      const parsedData = await excelService.parseExcel(buffer);

      // Update storage with parsed data
      let updatedCount = 0;
      
      if (parsedData.programs) {
        for (const program of parsedData.programs) {
          await storage.updateProgram(program.id, program);
          updatedCount++;
        }
      }
      
      if (parsedData.workPackages) {
        for (const wp of parsedData.workPackages) {
          await storage.updateWorkPackage(wp.id, wp);
          updatedCount++;
        }
      }
      
      if (parsedData.tasks) {
        for (const task of parsedData.tasks) {
          await storage.updateTask(task.id, task);
          updatedCount++;
        }
      }
      
      if (parsedData.persons) {
        for (const person of parsedData.persons) {
          await storage.updatePerson(person.id, person);
          updatedCount++;
        }
      }
      
      if (parsedData.sprints) {
        for (const sprint of parsedData.sprints) {
          await storage.updateSprint(sprint.id, sprint);
          updatedCount++;
        }
      }

      res.json({
        success: true,
        message: `Successfully imported and updated ${updatedCount} items from Excel file`,
        importedAt: new Date().toISOString(),
        lastModified: fileInfo.lastModified
      });
    } catch (error) {
      console.error('Import error:', error);
      res.status(500).json({ 
        success: false,
        message: 'Failed to import data from Excel',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.get("/api/excel-status", async (req, res) => {
    try {
      const exportFileUrl = await githubService.getExportFileUrl();
      const importFileUrl = await githubService.getImportFileUrl();
      const lastModified = await githubService.getLastModified();
      
      res.json({
        exportFileUrl,
        importFileUrl,
        lastModified: lastModified?.toISOString() || null,
        available: true
      });
    } catch (error) {
      res.json({
        exportFileUrl: await githubService.getExportFileUrl(),
        importFileUrl: await githubService.getImportFileUrl(),
        lastModified: null,
        available: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
