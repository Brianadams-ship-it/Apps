import ExcelJS from 'exceljs';
import { Program, WorkPackage, Task, Sprint, Person, Comment, TimeEntry } from '@shared/schema';

export interface ExcelData {
  programs: Program[];
  workPackages: WorkPackage[];
  tasks: Task[];
  sprints: Sprint[];
  persons: Person[];
  comments: Comment[];
  timeEntries: TimeEntry[];
}

export class ExcelService {
  async generateExcel(data: ExcelData): Promise<Buffer> {
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Project Management App';
    workbook.created = new Date();

    // Programs Sheet
    const programsSheet = workbook.addWorksheet('Programs', {
      properties: { tabColor: { argb: 'FF3366CC' } }
    });
    this.setupProgramsSheet(programsSheet, data.programs);

    // Work Packages Sheet
    const workPackagesSheet = workbook.addWorksheet('Work Packages', {
      properties: { tabColor: { argb: 'FF66CC33' } }
    });
    this.setupWorkPackagesSheet(workPackagesSheet, data.workPackages);

    // Tasks Sheet
    const tasksSheet = workbook.addWorksheet('Tasks', {
      properties: { tabColor: { argb: 'FFCC6633' } }
    });
    this.setupTasksSheet(tasksSheet, data.tasks);

    // Persons Sheet
    const personsSheet = workbook.addWorksheet('Persons', {
      properties: { tabColor: { argb: 'FF33CC66' } }
    });
    this.setupPersonsSheet(personsSheet, data.persons);

    // Sprints Sheet
    const sprintsSheet = workbook.addWorksheet('Sprints', {
      properties: { tabColor: { argb: 'FFCC3366' } }
    });
    this.setupSprintsSheet(sprintsSheet, data.sprints);

    // Comments Sheet
    const commentsSheet = workbook.addWorksheet('Comments', {
      properties: { tabColor: { argb: 'FF6633CC' } }
    });
    this.setupCommentsSheet(commentsSheet, data.comments);

    // Time Entries Sheet
    const timeEntriesSheet = workbook.addWorksheet('Time Entries', {
      properties: { tabColor: { argb: 'FFCCCC33' } }
    });
    this.setupTimeEntriesSheet(timeEntriesSheet, data.timeEntries);

    return Buffer.from(await workbook.xlsx.writeBuffer());
  }

  private setupProgramsSheet(sheet: ExcelJS.Worksheet, programs: Program[]): void {
    // Headers
    sheet.columns = [
      { header: 'ID', key: 'id', width: 20 },
      { header: 'Name', key: 'name', width: 30 },
      { header: 'Description', key: 'description', width: 50 },
      { header: 'Start Date', key: 'startDate', width: 15 },
      { header: 'End Date', key: 'endDate', width: 15 },
      { header: 'Status', key: 'status', width: 15 },
      { header: 'Created At', key: 'createdAt', width: 20 }
    ];

    // Style headers
    this.styleHeader(sheet);

    // Add data
    programs.forEach(program => {
      sheet.addRow({
        id: program.id,
        name: program.name,
        description: program.description,
        startDate: program.startDate ? new Date(program.startDate) : null,
        endDate: program.endDate ? new Date(program.endDate) : null,
        status: program.status,
        createdAt: program.createdAt ? new Date(program.createdAt) : null
      });
    });
  }

  private setupWorkPackagesSheet(sheet: ExcelJS.Worksheet, workPackages: WorkPackage[]): void {
    sheet.columns = [
      { header: 'ID', key: 'id', width: 20 },
      { header: 'Program ID', key: 'programId', width: 20 },
      { header: 'Name', key: 'name', width: 30 },
      { header: 'Description', key: 'description', width: 50 },
      { header: 'Parent ID', key: 'parentId', width: 20 },
      { header: 'Order', key: 'order', width: 10 },
      { header: 'Created At', key: 'createdAt', width: 20 }
    ];

    this.styleHeader(sheet);

    workPackages.forEach(wp => {
      sheet.addRow({
        id: wp.id,
        programId: wp.programId,
        name: wp.name,
        description: wp.description,
        parentId: wp.parentId,
        order: wp.order,
        createdAt: wp.createdAt ? new Date(wp.createdAt) : null
      });
    });
  }

  private setupTasksSheet(sheet: ExcelJS.Worksheet, tasks: Task[]): void {
    sheet.columns = [
      { header: 'ID', key: 'id', width: 20 },
      { header: 'Work Package ID', key: 'workPackageId', width: 20 },
      { header: 'Title', key: 'title', width: 30 },
      { header: 'Description', key: 'description', width: 50 },
      { header: 'Status', key: 'status', width: 15 },
      { header: 'Task Type', key: 'taskType', width: 15 },
      { header: 'Assigned Resource', key: 'assignedResource', width: 20 },
      { header: 'Assigned Person ID', key: 'assignedPersonId', width: 20 },
      { header: 'Progress', key: 'progress', width: 10 },
      { header: 'Estimated Days', key: 'estimatedDays', width: 15 },
      { header: 'Remaining Days', key: 'remainingDays', width: 15 },
      { header: 'Current Workflow Step', key: 'currentWorkflowStep', width: 20 },
      { header: 'Completed Workflow Steps', key: 'completedWorkflowSteps', width: 30 },
      { header: 'Dependencies', key: 'dependencies', width: 30 },
      { header: 'Due Date', key: 'dueDate', width: 15 },
      { header: 'Priority', key: 'priority', width: 10 },
      { header: 'Tags', key: 'tags', width: 30 },
      { header: 'Created At', key: 'createdAt', width: 20 },
      { header: 'Updated At', key: 'updatedAt', width: 20 }
    ];

    this.styleHeader(sheet);

    tasks.forEach(task => {
      sheet.addRow({
        id: task.id,
        workPackageId: task.workPackageId,
        title: task.title,
        description: task.description,
        status: task.status,
        taskType: task.taskType,
        assignedResource: task.assignedResource,
        assignedPersonId: task.assignedPersonId,
        progress: task.progress,
        estimatedDays: task.estimatedDays,
        remainingDays: task.remainingDays,
        currentWorkflowStep: task.currentWorkflowStep,
        completedWorkflowSteps: Array.isArray(task.completedWorkflowSteps) ? task.completedWorkflowSteps.join(', ') : '',
        dependencies: Array.isArray(task.dependencies) ? task.dependencies.join(', ') : '',
        dueDate: task.dueDate ? new Date(task.dueDate) : null,
        priority: task.priority,
        tags: Array.isArray(task.tags) ? task.tags.join(', ') : '',
        createdAt: task.createdAt ? new Date(task.createdAt) : null,
        updatedAt: task.updatedAt ? new Date(task.updatedAt) : null
      });
    });
  }

  private setupPersonsSheet(sheet: ExcelJS.Worksheet, persons: Person[]): void {
    sheet.columns = [
      { header: 'ID', key: 'id', width: 20 },
      { header: 'Name', key: 'name', width: 25 },
      { header: 'Resource Type', key: 'resourceType', width: 20 },
      { header: 'Email', key: 'email', width: 30 },
      { header: 'Initials', key: 'initials', width: 10 },
      { header: 'Is Active', key: 'isActive', width: 10 },
      { header: 'Created At', key: 'createdAt', width: 20 }
    ];

    this.styleHeader(sheet);

    persons.forEach(person => {
      sheet.addRow({
        id: person.id,
        name: person.name,
        resourceType: person.resourceType,
        email: person.email,
        initials: person.initials,
        isActive: person.isActive,
        createdAt: person.createdAt ? new Date(person.createdAt) : null
      });
    });
  }

  private setupSprintsSheet(sheet: ExcelJS.Worksheet, sprints: Sprint[]): void {
    sheet.columns = [
      { header: 'ID', key: 'id', width: 20 },
      { header: 'Program ID', key: 'programId', width: 20 },
      { header: 'Name', key: 'name', width: 25 },
      { header: 'Start Date', key: 'startDate', width: 15 },
      { header: 'End Date', key: 'endDate', width: 15 },
      { header: 'Status', key: 'status', width: 15 },
      { header: 'Task IDs', key: 'taskIds', width: 40 },
      { header: 'Created At', key: 'createdAt', width: 20 }
    ];

    this.styleHeader(sheet);

    sprints.forEach(sprint => {
      sheet.addRow({
        id: sprint.id,
        programId: sprint.programId,
        name: sprint.name,
        startDate: sprint.startDate ? new Date(sprint.startDate) : null,
        endDate: sprint.endDate ? new Date(sprint.endDate) : null,
        status: sprint.status,
        taskIds: Array.isArray(sprint.taskIds) ? sprint.taskIds.join(', ') : '',
        createdAt: sprint.createdAt ? new Date(sprint.createdAt) : null
      });
    });
  }

  private setupCommentsSheet(sheet: ExcelJS.Worksheet, comments: Comment[]): void {
    sheet.columns = [
      { header: 'ID', key: 'id', width: 20 },
      { header: 'Task ID', key: 'taskId', width: 20 },
      { header: 'Author', key: 'author', width: 20 },
      { header: 'Content', key: 'content', width: 60 },
      { header: 'Created At', key: 'createdAt', width: 20 }
    ];

    this.styleHeader(sheet);

    comments.forEach(comment => {
      sheet.addRow({
        id: comment.id,
        taskId: comment.taskId,
        author: comment.author,
        content: comment.content,
        createdAt: comment.createdAt ? new Date(comment.createdAt) : null
      });
    });
  }

  private setupTimeEntriesSheet(sheet: ExcelJS.Worksheet, timeEntries: TimeEntry[]): void {
    sheet.columns = [
      { header: 'ID', key: 'id', width: 20 },
      { header: 'Task ID', key: 'taskId', width: 20 },
      { header: 'User', key: 'user', width: 20 },
      { header: 'Start Time', key: 'startTime', width: 20 },
      { header: 'End Time', key: 'endTime', width: 20 },
      { header: 'Duration (minutes)', key: 'duration', width: 15 },
      { header: 'Description', key: 'description', width: 40 },
      { header: 'Is Active', key: 'isActive', width: 10 },
      { header: 'Created At', key: 'createdAt', width: 20 }
    ];

    this.styleHeader(sheet);

    timeEntries.forEach(entry => {
      sheet.addRow({
        id: entry.id,
        taskId: entry.taskId,
        user: entry.user,
        startTime: entry.startTime ? new Date(entry.startTime) : null,
        endTime: entry.endTime ? new Date(entry.endTime) : null,
        duration: entry.duration,
        description: entry.description,
        isActive: entry.isActive,
        createdAt: entry.createdAt ? new Date(entry.createdAt) : null
      });
    });
  }

  private styleHeader(sheet: ExcelJS.Worksheet): void {
    sheet.getRow(1).eachCell(cell => {
      cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FF4472C4' }
      };
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
      cell.border = {
        top: { style: 'thin' },
        left: { style: 'thin' },
        bottom: { style: 'thin' },
        right: { style: 'thin' }
      };
    });
  }

  async parseExcel(buffer: Buffer): Promise<Partial<ExcelData>> {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(buffer);
    
    const data: Partial<ExcelData> = {};

    // Parse Programs
    const programsSheet = workbook.getWorksheet('Programs');
    if (programsSheet) {
      data.programs = this.parseSheet(programsSheet, this.mapProgram);
    }

    // Parse Work Packages
    const workPackagesSheet = workbook.getWorksheet('Work Packages');
    if (workPackagesSheet) {
      data.workPackages = this.parseSheet(workPackagesSheet, this.mapWorkPackage);
    }

    // Parse Tasks
    const tasksSheet = workbook.getWorksheet('Tasks');
    if (tasksSheet) {
      data.tasks = this.parseSheet(tasksSheet, this.mapTask);
    }

    // Parse Persons
    const personsSheet = workbook.getWorksheet('Persons');
    if (personsSheet) {
      data.persons = this.parseSheet(personsSheet, this.mapPerson);
    }

    // Parse Sprints
    const sprintsSheet = workbook.getWorksheet('Sprints');
    if (sprintsSheet) {
      data.sprints = this.parseSheet(sprintsSheet, this.mapSprint);
    }

    return data;
  }

  private parseSheet<T>(sheet: ExcelJS.Worksheet, mapper: (row: any) => T): T[] {
    const data: T[] = [];
    const headers: string[] = [];
    
    // Get headers from first row
    sheet.getRow(1).eachCell({ includeEmpty: true }, (cell, colNumber) => {
      headers[colNumber - 1] = cell.text.toLowerCase().replace(/\s+/g, '');
    });

    // Parse data rows
    sheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
      if (rowNumber === 1) return; // Skip header row
      
      const rowData: any = {};
      row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
        const header = headers[colNumber - 1];
        if (header) {
          rowData[header] = cell.value;
        }
      });
      
      if (rowData.id) { // Only include rows with an ID
        data.push(mapper(rowData));
      }
    });

    return data;
  }

  private mapProgram = (row: any): Program => ({
    id: row.id,
    name: row.name || '',
    description: row.description || null,
    startDate: this.parseDate(row.startdate),
    endDate: this.parseDate(row.enddate),
    status: row.status || 'active',
    createdAt: this.parseDate(row.createdat)
  });

  private mapWorkPackage = (row: any): WorkPackage => ({
    id: row.id,
    programId: row.programid || '',
    name: row.name || '',
    description: row.description || null,
    parentId: row.parentid || null,
    order: parseInt(row.order) || 0,
    createdAt: this.parseDate(row.createdat)
  });

  private mapTask = (row: any): Task => ({
    id: row.id,
    workPackageId: row.workpackageid || '',
    title: row.title || '',
    description: row.description || null,
    status: row.status || 'todo',
    taskType: row.tasktype || 'parts_assembly',
    assignedResource: row.assignedresource || null,
    assignedPersonId: row.assignedpersonid || null,
    progress: parseInt(row.progress) || 0,
    estimatedDays: parseInt(row.estimateddays) || null,
    remainingDays: parseInt(row.remainingdays) || null,
    currentWorkflowStep: row.currentworkflowstep || null,
    completedWorkflowSteps: row.completedworkflowsteps ? row.completedworkflowsteps.split(', ') : [],
    dependencies: row.dependencies ? row.dependencies.split(', ') : [],
    dueDate: this.parseDate(row.duedate),
    priority: row.priority || 'medium',
    tags: row.tags ? row.tags.split(', ') : [],
    attachmentCount: parseInt(row.attachmentcount) || 0,
    commentCount: parseInt(row.commentcount) || 0,
    createdAt: this.parseDate(row.createdat),
    updatedAt: this.parseDate(row.updatedat)
  });

  private mapPerson = (row: any): Person => ({
    id: row.id,
    name: row.name || '',
    resourceType: row.resourcetype || 'mechanical_engineer',
    email: row.email || null,
    initials: row.initials || '',
    isActive: row.isactive === true || row.isactive === 'true' || row.isactive === 1,
    createdAt: this.parseDate(row.createdat)
  });

  private mapSprint = (row: any): Sprint => ({
    id: row.id,
    programId: row.programid || '',
    name: row.name || '',
    startDate: this.parseDate(row.startdate) || new Date(),
    endDate: this.parseDate(row.enddate) || new Date(),
    status: row.status || 'planning',
    taskIds: row.taskids ? row.taskids.split(', ') : [],
    createdAt: this.parseDate(row.createdat)
  });

  private parseDate(value: any): Date | null {
    if (!value) return null;
    if (value instanceof Date) return value;
    if (typeof value === 'string' || typeof value === 'number') {
      const date = new Date(value);
      return isNaN(date.getTime()) ? null : date;
    }
    return null;
  }
}