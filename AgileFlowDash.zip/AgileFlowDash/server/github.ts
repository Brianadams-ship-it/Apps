import { Octokit } from '@octokit/rest';

let connectionSettings: any;

async function getAccessToken(): Promise<string> {
  if (connectionSettings && connectionSettings.settings.expires_at && new Date(connectionSettings.settings.expires_at).getTime() > Date.now()) {
    return connectionSettings.settings.access_token;
  }
  
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    'https://' + hostname + '/api/v2/connection?include_secrets=true&connector_names=github',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  const accessToken = connectionSettings?.settings?.access_token || connectionSettings.settings?.oauth?.credentials?.access_token;

  if (!connectionSettings || !accessToken) {
    throw new Error('GitHub not connected');
  }
  return accessToken;
}

// WARNING: Never cache this client.
// Access tokens expire, so a new client must be created each time.
// Always call this function again to get a fresh client.
export async function getUncachableGitHubClient(): Promise<Octokit> {
  const accessToken = await getAccessToken();
  return new Octokit({ auth: accessToken });
}

export interface GitHubFileInfo {
  content: string;
  sha: string;
  lastModified: string;
}

export class GitHubService {
  private owner = 'Brianadams-ship-it';
  private repo = 'Apps';
  private exportFilePath = 'project-data.xlsx'; // File we export to
  private importFilePath = 'Project Input.xlsx'; // File we import from

  async uploadFile(content: Buffer, commitMessage: string = 'Update project data'): Promise<void> {
    const github = await getUncachableGitHubClient();
    
    try {
      // Check if export file exists
      let sha: string | undefined;
      try {
        const existing = await github.rest.repos.getContent({
          owner: this.owner,
          repo: this.repo,
          path: this.exportFilePath,
        });
        if ('sha' in existing.data) {
          sha = existing.data.sha;
        }
      } catch (error) {
        // File doesn't exist, that's okay
      }

      await github.rest.repos.createOrUpdateFileContents({
        owner: this.owner,
        repo: this.repo,
        path: this.exportFilePath,
        message: commitMessage,
        content: content.toString('base64'),
        sha,
      });
    } catch (error) {
      console.error('Error uploading file to GitHub:', error);
      throw new Error('Failed to upload file to GitHub');
    }
  }

  async downloadFile(): Promise<GitHubFileInfo | null> {
    const github = await getUncachableGitHubClient();
    
    try {
      console.log(`Attempting to download file: ${this.importFilePath} from ${this.owner}/${this.repo}`);
      
      const response = await github.rest.repos.getContent({
        owner: this.owner,
        repo: this.repo,
        path: this.importFilePath,
      });

      console.log('GitHub API response:', {
        status: response.status,
        dataType: typeof response.data,
        isArray: Array.isArray(response.data),
        hasContent: !Array.isArray(response.data) && 'content' in response.data,
        hasDownloadUrl: !Array.isArray(response.data) && 'download_url' in response.data,
        fileSize: !Array.isArray(response.data) && 'size' in response.data ? response.data.size : 0,
        contentLength: !Array.isArray(response.data) && 'content' in response.data ? (response.data as any).content?.length : 0
      });

      // Handle single file response (not array)
      if (!Array.isArray(response.data)) {
        const fileData = response.data as any;
        
        // Handle large files (>1MB) that GitHub doesn't return content for
        if (fileData.download_url && (!fileData.content || fileData.content === '')) {
          console.log('Large file detected, downloading from:', fileData.download_url);
          
          const downloadResponse = await fetch(fileData.download_url);
          if (!downloadResponse.ok) {
            throw new Error(`Failed to download file: ${downloadResponse.statusText}`);
          }
          
          const arrayBuffer = await downloadResponse.arrayBuffer();
          const buffer = Buffer.from(arrayBuffer);
          const content = buffer.toString('base64');
          
          console.log('Downloaded large file:', {
            bufferSize: buffer.length,
            base64Length: content.length
          });
          
          return {
            content,
            sha: fileData.sha,
            lastModified: response.headers['last-modified'] || new Date().toISOString(),
          };
        }
        
        if (fileData.content) {
          console.log('Small file content stats:', {
            originalLength: fileData.content.length,
            isBase64: fileData.content.match(/^[A-Za-z0-9+/]*={0,2}$/),
            sha: fileData.sha
          });
          
          return {
            content: fileData.content,
            sha: fileData.sha,
            lastModified: response.headers['last-modified'] || new Date().toISOString(),
          };
        }
      }
    } catch (error) {
      console.error('GitHub download error:', {
        status: (error as any).status,
        message: (error as any).message,
        path: this.importFilePath
      });
      
      if ((error as any).status === 404) {
        return null; // File doesn't exist
      }
      throw new Error(`Failed to download file from GitHub: ${(error as any).message}`);
    }
    
    return null;
  }

  async getExportFileUrl(): Promise<string> {
    return `https://github.com/${this.owner}/${this.repo}/blob/main/${this.exportFilePath}`;
  }

  async getImportFileUrl(): Promise<string> {
    return `https://github.com/${this.owner}/${this.repo}/blob/main/${this.importFilePath}`;
  }

  async getLastModified(): Promise<Date | null> {
    const github = await getUncachableGitHubClient();
    
    try {
      const commits = await github.rest.repos.listCommits({
        owner: this.owner,
        repo: this.repo,
        path: this.importFilePath,
        per_page: 1,
      });

      if (commits.data.length > 0) {
        return new Date(commits.data[0].commit.committer?.date || commits.data[0].commit.author?.date || '');
      }
    } catch (error) {
      console.error('Error getting file last modified date:', error);
    }
    
    return null;
  }
}