import { type Program, type WorkPackage, type Task, type Sprint, type Comment, type TimeEntry, type Person, type InsertProgram, type InsertWorkPackage, type InsertTask, type InsertSprint, type InsertComment, type InsertTimeEntry, type InsertPerson } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Programs
  getPrograms(): Promise<Program[]>;
  getProgram(id: string): Promise<Program | undefined>;
  createProgram(program: InsertProgram): Promise<Program>;
  updateProgram(id: string, program: Partial<InsertProgram>): Promise<Program | undefined>;
  deleteProgram(id: string): Promise<boolean>;

  // Work Packages
  getWorkPackagesByProgram(programId: string): Promise<WorkPackage[]>;
  getWorkPackage(id: string): Promise<WorkPackage | undefined>;
  createWorkPackage(workPackage: InsertWorkPackage): Promise<WorkPackage>;
  updateWorkPackage(id: string, workPackage: Partial<InsertWorkPackage>): Promise<WorkPackage | undefined>;
  deleteWorkPackage(id: string): Promise<boolean>;

  // Tasks
  getTasksByWorkPackage(workPackageId: string): Promise<Task[]>;
  getTasksByProgram(programId: string): Promise<Task[]>;
  getTask(id: string): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: string): Promise<boolean>;

  // Sprints
  getSprintsByProgram(programId: string): Promise<Sprint[]>;
  getSprint(id: string): Promise<Sprint | undefined>;
  createSprint(sprint: InsertSprint): Promise<Sprint>;
  updateSprint(id: string, sprint: Partial<InsertSprint>): Promise<Sprint | undefined>;
  deleteSprint(id: string): Promise<boolean>;

  // Comments
  getCommentsByTask(taskId: string): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  deleteComment(id: string): Promise<boolean>;

  // Time Entries
  getTimeEntriesByTask(taskId: string): Promise<TimeEntry[]>;
  getActiveTimeEntry(taskId: string, user: string): Promise<TimeEntry | undefined>;
  createTimeEntry(timeEntry: InsertTimeEntry): Promise<TimeEntry>;
  updateTimeEntry(id: string, timeEntry: Partial<InsertTimeEntry>): Promise<TimeEntry | undefined>;
  deleteTimeEntry(id: string): Promise<boolean>;
  stopAllActiveTimers(user: string): Promise<void>;

  // Persons
  getPersons(): Promise<Person[]>;
  getPersonsByResourceType(resourceType: string): Promise<Person[]>;
  getPerson(id: string): Promise<Person | undefined>;
  createPerson(person: InsertPerson): Promise<Person>;
  updatePerson(id: string, person: Partial<InsertPerson>): Promise<Person | undefined>;
  deletePerson(id: string): Promise<boolean>;
  getTasksByPerson(personId: string): Promise<Task[]>;
}

export class MemStorage implements IStorage {
  private programs: Map<string, Program> = new Map();
  private workPackages: Map<string, WorkPackage> = new Map();
  private tasks: Map<string, Task> = new Map();
  private sprints: Map<string, Sprint> = new Map();
  private comments: Map<string, Comment> = new Map();
  private timeEntries: Map<string, TimeEntry> = new Map();
  private persons: Map<string, Person> = new Map();

  constructor() {
    this.initializeWithSampleData();
  }

  private initializeWithSampleData() {
    // Create sample program
    const program: Program = {
      id: "prog-1",
      name: "Spacecraft Design Project",
      description: "Complete spacecraft design and development program",
      startDate: new Date("2024-01-01"),
      endDate: new Date("2024-12-31"),
      status: "active",
      createdAt: new Date(),
    };
    this.programs.set(program.id, program);

    // Create sample work packages
    const workPackages: WorkPackage[] = [
      {
        id: "wp-1",
        programId: "prog-1",
        name: "Thermal Subsystem",
        description: "Thermal management and analysis",
        parentId: null,
        order: 1,
        createdAt: new Date(),
      },
      {
        id: "wp-2",
        programId: "prog-1",
        name: "Electrical Subsystem",
        description: "Power distribution and control systems",
        parentId: null,
        order: 2,
        createdAt: new Date(),
      },
      {
        id: "wp-3",
        programId: "prog-1",
        name: "Software Subsystem",
        description: "Flight control and communication software",
        parentId: null,
        order: 3,
        createdAt: new Date(),
      },
    ];

    workPackages.forEach(wp => this.workPackages.set(wp.id, wp));

    // Create sample persons
    const persons: Person[] = [
      {
        id: "person-1",
        name: "John Smith",
        resourceType: "mechanical_engineer",
        email: "john.smith@aerospace.com",
        initials: "JS",
        isActive: true,
        createdAt: new Date(),
      },
      {
        id: "person-2", 
        name: "Sarah Chen",
        resourceType: "electrical_engineer",
        email: "sarah.chen@aerospace.com",
        initials: "SC",
        isActive: true,
        createdAt: new Date(),
      },
      {
        id: "person-3",
        name: "Alex Rodriguez",
        resourceType: "software_engineer", 
        email: "alex.rodriguez@aerospace.com",
        initials: "AR",
        isActive: true,
        createdAt: new Date(),
      },
      {
        id: "person-4",
        name: "Emily Johnson",
        resourceType: "production",
        email: "emily.johnson@aerospace.com", 
        initials: "EJ",
        isActive: true,
        createdAt: new Date(),
      },
      {
        id: "person-5",
        name: "Michael Davis",
        resourceType: "system_lead",
        email: "michael.davis@aerospace.com",
        initials: "MD",
        isActive: true,
        createdAt: new Date(),
      },
    ];

    persons.forEach(person => this.persons.set(person.id, person));

    // Create sample tasks
    const tasks: Task[] = [
      {
        id: "task-1",
        workPackageId: "wp-1",
        title: "Thermal Analysis Simulation",
        description: "Perform comprehensive thermal analysis simulation",
        status: "todo",
        taskType: "parts_assembly",
        assignedResource: "mechanical_engineer",
        assignedPersonId: "person-1",
        progress: 0,
        estimatedDays: 5,
        remainingDays: 5,
        currentWorkflowStep: "design",
        completedWorkflowSteps: [],
        dependencies: [],
        dueDate: new Date("2024-11-25"),
        priority: "medium",
        tags: ["thermal", "simulation"],
        attachmentCount: 3,
        commentCount: 2,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "task-2",
        workPackageId: "wp-2",
        title: "Power Distribution Unit Design",
        description: "Design power distribution unit for spacecraft",
        status: "todo",
        taskType: "parts_assembly",
        assignedResource: "electrical_engineer",
        assignedPersonId: "person-2",
        progress: 15,
        estimatedDays: 8,
        remainingDays: 7,
        currentWorkflowStep: "design",
        completedWorkflowSteps: [],
        dependencies: [],
        dueDate: new Date("2024-11-28"),
        priority: "high",
        tags: ["electrical", "power"],
        attachmentCount: 0,
        commentCount: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "task-3",
        workPackageId: "wp-3",
        title: "Flight Control Software Module",
        description: "Implement flight control software module",
        status: "in_progress",
        taskType: "software",
        assignedResource: "software_engineer",
        assignedPersonId: "person-3",
        progress: 65,
        estimatedDays: 10,
        remainingDays: 2,
        currentWorkflowStep: "testing",
        completedWorkflowSteps: ["design", "implementation"],
        dependencies: [],
        dueDate: new Date("2024-11-20"),
        priority: "high",
        tags: ["software", "control"],
        attachmentCount: 0,
        commentCount: 5,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "task-4",
        workPackageId: "wp-1",
        title: "Structural Load Testing",
        description: "Perform structural load testing procedures",
        status: "in_progress",
        taskType: "testing",
        assignedResource: "production",
        assignedPersonId: "person-4",
        progress: 40,
        estimatedDays: 3,
        remainingDays: 2,
        currentWorkflowStep: "procedure",
        completedWorkflowSteps: ["setup"],
        dependencies: [],
        dueDate: new Date("2024-11-22"),
        priority: "medium",
        tags: ["testing", "structural"],
        attachmentCount: 2,
        commentCount: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "task-5",
        workPackageId: "wp-3",
        title: "Communication Protocol Implementation",
        description: "Implement spacecraft communication protocols",
        status: "in_progress",
        taskType: "software",
        assignedResource: "software_engineer",
        assignedPersonId: "person-3",
        progress: 80,
        estimatedDays: 6,
        remainingDays: 1,
        currentWorkflowStep: "code_review",
        completedWorkflowSteps: ["design", "implementation", "testing"],
        dependencies: [],
        dueDate: new Date("2024-11-21"),
        priority: "high",
        tags: ["software", "communication"],
        attachmentCount: 1,
        commentCount: 3,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "task-6",
        workPackageId: "wp-2",
        title: "Antenna Design Specifications",
        description: "Create detailed antenna design specifications",
        status: "review",
        taskType: "parts_assembly",
        assignedResource: "system_lead",
        assignedPersonId: "person-5",
        progress: 95,
        estimatedDays: 4,
        remainingDays: 0,
        currentWorkflowStep: "review_approval",
        completedWorkflowSteps: ["design", "hardware", "testing"],
        dependencies: [],
        dueDate: new Date("2024-11-19"),
        priority: "medium",
        tags: ["antenna", "rf"],
        attachmentCount: 5,
        commentCount: 2,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "task-7",
        workPackageId: "wp-2",
        title: "Battery Management System",
        description: "Design and implement battery management system",
        status: "review",
        taskType: "parts_assembly",
        assignedResource: "electrical_engineer",
        assignedPersonId: "person-2",
        progress: 90,
        estimatedDays: 7,
        remainingDays: 1,
        currentWorkflowStep: "review_approval",
        completedWorkflowSteps: ["design", "hardware", "testing"],
        dependencies: [],
        dueDate: new Date("2024-11-23"),
        priority: "high",
        tags: ["battery", "power"],
        attachmentCount: 3,
        commentCount: 4,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "task-8",
        workPackageId: "wp-1",
        title: "Initial Requirements Analysis",
        description: "Complete initial requirements analysis for thermal system",
        status: "completed",
        taskType: "documentation",
        assignedResource: "system_lead",
        assignedPersonId: "person-5",
        progress: 100,
        estimatedDays: 3,
        remainingDays: 0,
        currentWorkflowStep: "release",
        completedWorkflowSteps: ["draft", "review", "approval"],
        dependencies: [],
        dueDate: new Date("2024-11-10"),
        priority: "high",
        tags: ["requirements", "documentation"],
        attachmentCount: 2,
        commentCount: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "task-9",
        workPackageId: "wp-1",
        title: "Preliminary Design Review",
        description: "Conduct preliminary design review for thermal subsystem",
        status: "completed",
        taskType: "milestone",
        assignedResource: "system_lead",
        assignedPersonId: "person-5",
        progress: 100,
        estimatedDays: 2,
        remainingDays: 0,
        currentWorkflowStep: "completion",
        completedWorkflowSteps: ["planning", "execution", "review"],
        dependencies: [],
        dueDate: new Date("2024-11-08"),
        priority: "high",
        tags: ["milestone", "review"],
        attachmentCount: 4,
        commentCount: 6,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "task-10",
        workPackageId: "wp-1",
        title: "Environmental Testing Setup",
        description: "Set up environmental testing equipment and procedures",
        status: "blocked",
        taskType: "testing",
        assignedResource: "production",
        assignedPersonId: "person-4",
        progress: 25,
        estimatedDays: 5,
        remainingDays: 7, // Overdue
        currentWorkflowStep: "hardware",
        completedWorkflowSteps: ["setup"],
        dependencies: [],
        dueDate: new Date("2024-11-18"), // Overdue
        priority: "critical",
        tags: ["testing", "environmental"],
        attachmentCount: 1,
        commentCount: 3,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ];

    tasks.forEach(task => this.tasks.set(task.id, task));

    // Create sample sprint
    const sprint: Sprint = {
      id: "sprint-1",
      programId: "prog-1",
      name: "Sprint 3",
      startDate: new Date("2024-11-15"),
      endDate: new Date("2024-11-29"),
      status: "active",
      taskIds: ["task-1", "task-2", "task-3", "task-4", "task-5", "task-6", "task-7", "task-8", "task-9", "task-10"],
      createdAt: new Date(),
    };
    this.sprints.set(sprint.id, sprint);

    // Create sample comments
    const comments: Comment[] = [
      {
        id: "comment-1",
        taskId: "task-3",
        author: "John Smith",
        content: "Testing is progressing well. Found minor issue with attitude control precision that needs addressing.",
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      },
      {
        id: "comment-2",
        taskId: "task-3",
        author: "Maria Brown",
        content: "Implementation phase completed ahead of schedule. Moving to testing phase.",
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
      },
    ];

    comments.forEach(comment => this.comments.set(comment.id, comment));
  }

  // Programs
  async getPrograms(): Promise<Program[]> {
    return Array.from(this.programs.values());
  }

  async getProgram(id: string): Promise<Program | undefined> {
    return this.programs.get(id);
  }

  async createProgram(insertProgram: InsertProgram): Promise<Program> {
    const id = randomUUID();
    const program: Program = { 
      ...insertProgram, 
      id, 
      createdAt: new Date(),
      description: insertProgram.description || null,
      startDate: insertProgram.startDate || null,
      endDate: insertProgram.endDate || null,
      status: insertProgram.status || "active"
    };
    this.programs.set(id, program);
    return program;
  }

  async updateProgram(id: string, program: Partial<InsertProgram>): Promise<Program | undefined> {
    const existing = this.programs.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...program };
    this.programs.set(id, updated);
    return updated;
  }

  async deleteProgram(id: string): Promise<boolean> {
    return this.programs.delete(id);
  }

  // Work Packages
  async getWorkPackagesByProgram(programId: string): Promise<WorkPackage[]> {
    return Array.from(this.workPackages.values()).filter(wp => wp.programId === programId);
  }

  async getWorkPackage(id: string): Promise<WorkPackage | undefined> {
    return this.workPackages.get(id);
  }

  async createWorkPackage(insertWorkPackage: InsertWorkPackage): Promise<WorkPackage> {
    const id = randomUUID();
    const workPackage: WorkPackage = { 
      ...insertWorkPackage, 
      id, 
      createdAt: new Date(),
      description: insertWorkPackage.description || null,
      parentId: insertWorkPackage.parentId || null,
      order: insertWorkPackage.order || 0
    };
    this.workPackages.set(id, workPackage);
    return workPackage;
  }

  async updateWorkPackage(id: string, workPackage: Partial<InsertWorkPackage>): Promise<WorkPackage | undefined> {
    const existing = this.workPackages.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...workPackage };
    this.workPackages.set(id, updated);
    return updated;
  }

  async deleteWorkPackage(id: string): Promise<boolean> {
    return this.workPackages.delete(id);
  }

  // Tasks
  async getTasksByWorkPackage(workPackageId: string): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(task => task.workPackageId === workPackageId);
  }

  async getTasksByProgram(programId: string): Promise<Task[]> {
    const workPackages = await this.getWorkPackagesByProgram(programId);
    const workPackageIds = workPackages.map(wp => wp.id);
    return Array.from(this.tasks.values()).filter(task => workPackageIds.includes(task.workPackageId));
  }

  async getTask(id: string): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = randomUUID();
    const now = new Date();
    const task: Task = { 
      ...insertTask, 
      id, 
      createdAt: now, 
      updatedAt: now,
      status: insertTask.status || "todo",
      taskType: insertTask.taskType || "parts_assembly",
      progress: insertTask.progress || 0,
      estimatedDays: insertTask.estimatedDays || null,
      remainingDays: insertTask.remainingDays || null,
      description: insertTask.description || null,
      currentWorkflowStep: insertTask.currentWorkflowStep || null,
      completedWorkflowSteps: (insertTask.completedWorkflowSteps || []) as string[],
      dependencies: (insertTask.dependencies || []) as string[],
      dueDate: insertTask.dueDate || null,
      priority: insertTask.priority || "medium",
      tags: (insertTask.tags || []) as string[],
      attachmentCount: insertTask.attachmentCount || 0,
      commentCount: insertTask.commentCount || 0,
      assignedResource: insertTask.assignedResource || null,
      assignedPersonId: insertTask.assignedPersonId || null
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: string, task: Partial<InsertTask>): Promise<Task | undefined> {
    const existing = this.tasks.get(id);
    if (!existing) return undefined;
    const updated = { 
      ...existing, 
      ...task, 
      updatedAt: new Date(),
      completedWorkflowSteps: (task.completedWorkflowSteps || existing.completedWorkflowSteps || []) as string[],
      dependencies: (task.dependencies || existing.dependencies || []) as string[],
      tags: (task.tags || existing.tags || []) as string[]
    };
    this.tasks.set(id, updated);
    return updated;
  }

  async deleteTask(id: string): Promise<boolean> {
    return this.tasks.delete(id);
  }

  // Sprints
  async getSprintsByProgram(programId: string): Promise<Sprint[]> {
    return Array.from(this.sprints.values()).filter(sprint => sprint.programId === programId);
  }

  async getSprint(id: string): Promise<Sprint | undefined> {
    return this.sprints.get(id);
  }

  async createSprint(insertSprint: InsertSprint): Promise<Sprint> {
    const id = randomUUID();
    const sprint: Sprint = { 
      ...insertSprint, 
      id, 
      createdAt: new Date(),
      status: insertSprint.status || "planning",
      taskIds: (insertSprint.taskIds || []) as string[]
    };
    this.sprints.set(id, sprint);
    return sprint;
  }

  async updateSprint(id: string, sprint: Partial<InsertSprint>): Promise<Sprint | undefined> {
    const existing = this.sprints.get(id);
    if (!existing) return undefined;
    const updated = { 
      ...existing, 
      ...sprint,
      taskIds: (sprint.taskIds || existing.taskIds || []) as string[]
    };
    this.sprints.set(id, updated);
    return updated;
  }

  async deleteSprint(id: string): Promise<boolean> {
    return this.sprints.delete(id);
  }

  // Comments
  async getCommentsByTask(taskId: string): Promise<Comment[]> {
    return Array.from(this.comments.values()).filter(comment => comment.taskId === taskId);
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = randomUUID();
    const comment: Comment = { ...insertComment, id, createdAt: new Date() };
    this.comments.set(id, comment);
    return comment;
  }

  async deleteComment(id: string): Promise<boolean> {
    return this.comments.delete(id);
  }

  // Time Entries
  async getTimeEntriesByTask(taskId: string): Promise<TimeEntry[]> {
    return Array.from(this.timeEntries.values()).filter(entry => entry.taskId === taskId);
  }

  async getActiveTimeEntry(taskId: string, user: string): Promise<TimeEntry | undefined> {
    return Array.from(this.timeEntries.values()).find(entry => 
      entry.taskId === taskId && entry.user === user && entry.isActive
    );
  }

  async createTimeEntry(insertTimeEntry: InsertTimeEntry): Promise<TimeEntry> {
    const id = randomUUID();
    const timeEntry: TimeEntry = { 
      ...insertTimeEntry, 
      id, 
      createdAt: new Date(),
      isActive: insertTimeEntry.isActive ?? false,
      description: insertTimeEntry.description ?? null,
      duration: insertTimeEntry.duration ?? null,
      endTime: insertTimeEntry.endTime ?? null
    };
    this.timeEntries.set(id, timeEntry);
    return timeEntry;
  }

  async updateTimeEntry(id: string, timeEntry: Partial<InsertTimeEntry>): Promise<TimeEntry | undefined> {
    const existing = this.timeEntries.get(id);
    if (!existing) return undefined;
    
    // Calculate duration if endTime is being set and startTime exists
    let calculatedDuration = existing.duration;
    if (timeEntry.endTime && existing.startTime) {
      const start = new Date(existing.startTime);
      const end = new Date(timeEntry.endTime);
      const durationMs = end.getTime() - start.getTime();
      calculatedDuration = Math.max(1, Math.ceil(durationMs / (1000 * 60))); // Duration in minutes, minimum 1 minute
    }
    
    const updated = { 
      ...existing, 
      ...timeEntry,
      duration: calculatedDuration
    };
    this.timeEntries.set(id, updated);
    return updated;
  }

  async deleteTimeEntry(id: string): Promise<boolean> {
    return this.timeEntries.delete(id);
  }

  async stopAllActiveTimers(user: string): Promise<void> {
    const activeEntries = Array.from(this.timeEntries.values()).filter(entry => 
      entry.user === user && entry.isActive
    );
    
    const now = new Date();
    for (const entry of activeEntries) {
      const durationMs = now.getTime() - new Date(entry.startTime).getTime();
      const duration = Math.max(1, Math.ceil(durationMs / (1000 * 60))); // Duration in minutes, minimum 1 minute
      this.timeEntries.set(entry.id, {
        ...entry,
        endTime: now,
        duration,
        isActive: false
      });
    }
  }

  // Person methods
  async getPersons(): Promise<Person[]> {
    return Array.from(this.persons.values());
  }

  async getPersonsByResourceType(resourceType: string): Promise<Person[]> {
    return Array.from(this.persons.values()).filter(person => person.resourceType === resourceType);
  }

  async getPerson(id: string): Promise<Person | undefined> {
    return this.persons.get(id);
  }

  async createPerson(insertPerson: InsertPerson): Promise<Person> {
    const id = randomUUID();
    const now = new Date();
    const person: Person = {
      ...insertPerson,
      id,
      createdAt: now,
      isActive: insertPerson.isActive ?? true,
      email: insertPerson.email ?? null
    };
    this.persons.set(id, person);
    return person;
  }

  async updatePerson(id: string, person: Partial<InsertPerson>): Promise<Person | undefined> {
    const existing = this.persons.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...person };
    this.persons.set(id, updated);
    return updated;
  }

  async deletePerson(id: string): Promise<boolean> {
    return this.persons.delete(id);
  }

  async getTasksByPerson(personId: string): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(task => task.assignedPersonId === personId);
  }
}

export const storage = new MemStorage();
