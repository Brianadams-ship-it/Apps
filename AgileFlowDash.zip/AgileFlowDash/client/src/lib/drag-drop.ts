export interface DragDropContext {
  draggedItem: string | null;
  draggedFrom: string | null;
  draggedTo: string | null;
}

export class DragDropManager {
  private context: DragDropContext = {
    draggedItem: null,
    draggedFrom: null,
    draggedTo: null,
  };

  private callbacks: Array<(context: DragDropContext) => void> = [];

  public startDrag(itemId: string, sourceId: string) {
    this.context = {
      draggedItem: itemId,
      draggedFrom: sourceId,
      draggedTo: null,
    };
    this.notifyCallbacks();
  }

  public enterDrop(targetId: string) {
    if (this.context.draggedItem) {
      this.context.draggedTo = targetId;
      this.notifyCallbacks();
    }
  }

  public leaveDrop() {
    this.context.draggedTo = null;
    this.notifyCallbacks();
  }

  public endDrag(): DragDropContext {
    const result = { ...this.context };
    this.context = {
      draggedItem: null,
      draggedFrom: null,
      draggedTo: null,
    };
    this.notifyCallbacks();
    return result;
  }

  public subscribe(callback: (context: DragDropContext) => void) {
    this.callbacks.push(callback);
    return () => {
      this.callbacks = this.callbacks.filter(cb => cb !== callback);
    };
  }

  public getContext(): DragDropContext {
    return { ...this.context };
  }

  private notifyCallbacks() {
    this.callbacks.forEach(callback => callback(this.context));
  }
}

export const dragDropManager = new DragDropManager();
