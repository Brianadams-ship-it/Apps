import { Clock, Paperclip, MessageSquare, Link, TriangleAlert, CheckCircle, Eye, Timer } from "lucide-react";
import { Task, TimeEntry } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

interface TaskCardProps {
  task: Task;
  showStatus?: boolean;
}

export default function TaskCard({ task, showStatus = true }: TaskCardProps) {
  // Fetch time tracking data for this task
  const { data: timeEntriesData = [] } = useQuery<TimeEntry[]>({
    queryKey: ['/api/tasks', task.id, 'time-entries'],
    enabled: !!task.id,
  });

  // Calculate total time spent on this task
  const getTotalTimeSpent = () => {
    if (!Array.isArray(timeEntriesData) || timeEntriesData.length === 0) return 0;
    return timeEntriesData.reduce((total: number, entry: TimeEntry) => {
      return total + (entry.duration || 0);
    }, 0);
  };

  const formatTimeSpent = (minutes: number) => {
    if (minutes === 0) return '0h';
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    if (hours === 0) return `${remainingMinutes}m`;
    if (remainingMinutes === 0) return `${hours}h`;
    return `${hours}h ${remainingMinutes}m`;
  };

  const getResourceAbbreviation = (resource: string | null | undefined) => {
    if (!resource) return '';
    const mapping = {
      mechanical_engineer: 'ME',
      electrical_engineer: 'EE', 
      software_engineer: 'SE',
      production: 'PR',
      system_lead: 'PL',
    };
    return mapping[resource as keyof typeof mapping] || '';
  };

  const getStatusDisplay = () => {
    switch (task.status) {
      case 'completed':
        return { label: 'Complete', color: 'bg-green-100 text-green-800' };
      case 'in_progress':
        return { label: 'Testing', color: 'bg-yellow-100 text-yellow-800' };
      case 'review':
        return { label: 'Review', color: 'bg-purple-100 text-purple-800' };
      case 'blocked':
        return { label: 'Blocked', color: 'bg-red-100 text-red-800' };
      default:
        return { label: 'Design', color: 'bg-muted text-muted-foreground' };
    }
  };

  const getDueDateStatus = () => {
    if (!task.dueDate) return null;
    
    const today = new Date();
    const dueDate = new Date(task.dueDate);
    const diffDays = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) {
      return { text: `Overdue ${Math.abs(diffDays)} days`, color: 'text-red-600', icon: TriangleAlert };
    } else if (diffDays === 0) {
      return { text: 'Due Today', color: 'text-yellow-600', icon: Clock };
    } else if (diffDays <= 2) {
      return { text: `${diffDays} day${diffDays === 1 ? '' : 's'} left`, color: 'text-blue-600', icon: Clock };
    }
    
    return null;
  };

  const statusDisplay = getStatusDisplay();
  const dueDateStatus = getDueDateStatus();

  return (
    <div 
      className={`task-card status-${task.status} bg-card border border-border rounded-lg p-4 cursor-move`}
      data-testid={`task-${task.id}`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <h4 className="font-medium text-sm mb-1" data-testid={`task-title-${task.id}`}>
            {task.title}
          </h4>
          <p className="text-xs text-muted-foreground" data-testid={`task-work-package-${task.id}`}>
            {task.workPackageId.toUpperCase()} • {task.description?.substring(0, 30)}...
          </p>
        </div>
        {task.assignedResource && (
          <span 
            className={`resource-${task.assignedResource} text-xs text-white px-2 py-1 rounded-full`}
            data-testid={`task-resource-${task.id}`}
          >
            {getResourceAbbreviation(task.assignedResource)}
          </span>
        )}
      </div>
      
      <div className="space-y-2">
        <div className="flex justify-between text-xs">
          <span>Progress</span>
          <span data-testid={`task-progress-${task.id}`}>{task.progress}%</span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div 
            className="progress-bar h-2 rounded-full" 
            style={{ width: `${task.progress}%` }}
            data-testid={`task-progress-bar-${task.id}`}
          />
        </div>
        <div className="flex justify-between items-center text-xs">
          <div className="flex flex-col gap-1">
            <span className="text-muted-foreground" data-testid={`task-duration-${task.id}`}>
              {task.status === 'completed' 
                ? 'Completed' 
                : task.remainingDays 
                  ? `${task.remainingDays} days left` 
                  : `Est: ${task.estimatedDays} days`
              }
            </span>
            {getTotalTimeSpent() > 0 && (
              <div className="flex items-center gap-1 text-blue-600">
                <Timer className="w-3 h-3" />
                <span data-testid={`task-time-spent-${task.id}`}>
                  {formatTimeSpent(getTotalTimeSpent())} logged
                </span>
              </div>
            )}
          </div>
          {showStatus && (
            <span className={`px-2 py-1 rounded ${statusDisplay.color}`} data-testid={`task-status-${task.id}`}>
              {statusDisplay.label}
            </span>
          )}
        </div>
      </div>

      {/* Status indicators and metadata */}
      <div className="mt-3 space-y-2">
        {dueDateStatus && (
          <div className="flex items-center space-x-2">
            <dueDateStatus.icon className={`${dueDateStatus.color} text-xs`} />
            <span className={`text-xs ${dueDateStatus.color}`} data-testid={`task-due-date-${task.id}`}>
              {dueDateStatus.text}
            </span>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4 text-xs text-muted-foreground">
            {(task.attachmentCount || 0) > 0 && (
              <div className="flex items-center space-x-1">
                <Paperclip className="text-xs" />
                <span data-testid={`task-attachments-${task.id}`}>{task.attachmentCount} attachments</span>
              </div>
            )}
            
            {task.dependencies && task.dependencies.length > 0 && (
              <div className="flex items-center space-x-1">
                <Link className="text-xs" />
                <span data-testid={`task-dependencies-${task.id}`}>Linked to {task.dependencies.length} tasks</span>
              </div>
            )}
          </div>

          {(task.commentCount || 0) > 0 && (
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              <MessageSquare className="text-xs" />
              <span data-testid={`task-comments-${task.id}`}>{task.commentCount}</span>
            </div>
          )}
        </div>

        {/* Special status indicators */}
        {task.status === 'completed' && (
          <div className="flex items-center space-x-2">
            <CheckCircle className="text-green-500 text-xs" />
            <span className="text-xs text-green-600" data-testid={`task-completed-${task.id}`}>Approved & Released</span>
          </div>
        )}

        {task.status === 'review' && (
          <div className="flex items-center space-x-2">
            <Eye className="text-muted-foreground text-xs" />
            <span className="text-xs text-muted-foreground" data-testid={`task-review-${task.id}`}>
              {task.title.includes('Antenna') ? 'Awaiting John\'s review' : 'Ready for release'}
            </span>
          </div>
        )}

        {task.status === 'blocked' && (
          <div className="flex items-center space-x-2">
            <TriangleAlert className="text-red-500 text-xs" />
            <span className="text-xs text-red-600" data-testid={`task-blocked-${task.id}`}>Equipment unavailable</span>
          </div>
        )}
      </div>
    </div>
  );
}
