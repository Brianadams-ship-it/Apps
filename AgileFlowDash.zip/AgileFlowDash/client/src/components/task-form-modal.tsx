import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Calendar, Save, X } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { 
  Task, 
  WorkPackage, 
  insertTaskSchema, 
  taskStatuses, 
  taskTypes, 
  resourceTypes,
  type InsertTask 
} from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

interface TaskFormModalProps {
  task?: Task; // If provided, we're editing; otherwise, creating
  programId: string;
  workPackageId?: string; // Default work package for new tasks
  isOpen: boolean;
  onClose: () => void;
}

// Enhanced validation schema for the form
const taskFormSchema = insertTaskSchema.extend({
  title: z.string().min(1, "Title is required").max(100, "Title must be less than 100 characters"),
  description: z.string().optional(),
  estimatedDays: z.coerce.number().int().min(1, "Must be at least 1 day").max(365, "Must be less than 365 days").optional(),
  progress: z.coerce.number().int().min(0, "Progress cannot be negative").max(100, "Progress cannot exceed 100%").optional(),
  priority: z.enum(["low", "medium", "high", "critical"]).optional(),
  assignedResource: z.union([z.enum(["mechanical_engineer", "electrical_engineer", "software_engineer", "production", "system_lead"]), z.literal("none")]).optional(),
});

type TaskFormData = z.infer<typeof taskFormSchema>;

export default function TaskFormModal({ 
  task, 
  programId, 
  workPackageId, 
  isOpen, 
  onClose 
}: TaskFormModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditing = !!task;

  const { data: workPackages = [] } = useQuery<WorkPackage[]>({
    queryKey: ["/api/programs", programId, "work-packages"],
  });

  const form = useForm<TaskFormData>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: {
      workPackageId: task?.workPackageId || workPackageId || "",
      title: task?.title || "",
      description: task?.description || "",
      status: task?.status || "todo",
      taskType: task?.taskType || "parts_assembly",
      assignedResource: task?.assignedResource || undefined,
      progress: task?.progress || 0,
      estimatedDays: task?.estimatedDays || undefined,
      priority: (task?.priority as "low" | "medium" | "high" | "critical") || "medium",
    },
  });

  useEffect(() => {
    if (isOpen && task) {
      form.reset({
        workPackageId: task.workPackageId,
        title: task.title,
        description: task.description || "",
        status: task.status,
        taskType: task.taskType,
        assignedResource: task.assignedResource || undefined,
        progress: task.progress || 0,
        estimatedDays: task.estimatedDays || undefined,
        priority: (task.priority as "low" | "medium" | "high" | "critical") || "medium",
      });
    } else if (isOpen && !task) {
      form.reset({
        workPackageId: workPackageId || "",
        title: "",
        description: "",
        status: "todo",
        taskType: "parts_assembly",
        assignedResource: undefined,
        progress: 0,
        estimatedDays: undefined,
        priority: "medium",
      });
    }
  }, [isOpen, task, workPackageId, form]);

  const createTaskMutation = useMutation({
    mutationFn: async (data: TaskFormData) => {
      const response = await apiRequest("POST", "/api/tasks", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/programs", programId, "tasks"] });
      toast({
        title: "Task Created",
        description: "Your task has been created successfully.",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create task.",
        variant: "destructive",
      });
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async (data: TaskFormData) => {
      const response = await apiRequest("PATCH", `/api/tasks/${task!.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/programs", programId, "tasks"] });
      toast({
        title: "Task Updated",
        description: "Your task has been updated successfully.",
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update task.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: TaskFormData) => {
    // Handle "none" value for assignedResource
    const processedData = {
      ...data,
      assignedResource: data.assignedResource === "none" ? undefined : data.assignedResource,
    };
    
    if (isEditing) {
      updateTaskMutation.mutate(processedData);
    } else {
      createTaskMutation.mutate(processedData);
    }
  };

  const isLoading = createTaskMutation.isPending || updateTaskMutation.isPending;

  const getResourceDisplayName = (resource: string) => {
    const displayNames = {
      mechanical_engineer: "Mechanical Engineer",
      electrical_engineer: "Electrical Engineer", 
      software_engineer: "Software Engineer",
      production: "Production",
      system_lead: "System/Project Lead"
    };
    return displayNames[resource as keyof typeof displayNames] || resource;
  };

  const getTaskTypeDisplayName = (type: string) => {
    const displayNames = {
      parts_assembly: "Parts/Assembly",
      testing: "Testing",
      software: "Software",
      documentation: "Documentation",
      milestone: "Milestone"
    };
    return displayNames[type as keyof typeof displayNames] || type;
  };

  const getStatusDisplayName = (status: string) => {
    const displayNames = {
      todo: "To Do",
      in_progress: "In Progress",
      review: "Review",
      completed: "Completed",
      blocked: "Blocked"
    };
    return displayNames[status as keyof typeof displayNames] || status;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Calendar className="h-5 w-5" />
            <span>{isEditing ? "Edit Task" : "Create New Task"}</span>
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Work Package */}
              <FormField
                control={form.control}
                name="workPackageId"
                render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Work Package *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-work-package">
                          <SelectValue placeholder="Select work package" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {workPackages.map((wp) => (
                          <SelectItem key={wp.id} value={wp.id}>
                            {wp.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Title */}
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Title *</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter task title..."
                        data-testid="input-task-title"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Description */}
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem className="col-span-2">
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter task description..."
                        className="min-h-[80px]"
                        data-testid="input-task-description"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Task Type */}
              <FormField
                control={form.control}
                name="taskType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Task Type *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-task-type">
                          <SelectValue placeholder="Select task type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {taskTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {getTaskTypeDisplayName(type)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Status */}
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-task-status">
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {taskStatuses.map((status) => (
                          <SelectItem key={status} value={status}>
                            {getStatusDisplayName(status)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Assigned Resource */}
              <FormField
                control={form.control}
                name="assignedResource"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assigned Resource</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || ""}>
                      <FormControl>
                        <SelectTrigger data-testid="select-assigned-resource">
                          <SelectValue placeholder="Select resource" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {resourceTypes.map((resource) => (
                          <SelectItem key={resource} value={resource}>
                            {getResourceDisplayName(resource)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Priority */}
              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Priority</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-task-priority">
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Estimated Days */}
              <FormField
                control={form.control}
                name="estimatedDays"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Estimated Days</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="1" 
                        max="365" 
                        placeholder="Enter estimated days"
                        data-testid="input-estimated-days"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Estimated completion time in days
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Progress */}
              <FormField
                control={form.control}
                name="progress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Progress (%)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        min="0" 
                        max="100" 
                        placeholder="Enter progress percentage"
                        data-testid="input-task-progress"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Completion percentage (0-100%)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="flex justify-end space-x-2 pt-4 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isLoading}
                data-testid="button-cancel-task"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                data-testid="button-save-task"
              >
                <Save className="h-4 w-4 mr-2" />
                {isLoading ? "Saving..." : isEditing ? "Update Task" : "Create Task"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}