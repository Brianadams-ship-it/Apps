import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MoreHorizontal } from "lucide-react";
import { useState } from "react";
import TaskCard from "./task-card";
import { apiRequest } from "@/lib/queryClient";
import { Task, TaskStatus } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface KanbanBoardProps {
  programId: string;
  onTaskClick: (task: Task) => void;
}

interface Column {
  id: TaskStatus;
  title: string;
  count: number;
}

export default function KanbanBoard({ programId, onTaskClick }: KanbanBoardProps) {
  const [draggedTask, setDraggedTask] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ["/api/programs", programId, "tasks"],
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ taskId, updates }: { taskId: string; updates: Partial<Task> }) => {
      const response = await apiRequest("PATCH", `/api/tasks/${taskId}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/programs", programId, "tasks"] });
      toast({
        title: "Task Updated",
        description: "Task status has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update task status.",
        variant: "destructive",
      });
    },
  });

  const columns: Column[] = [
    {
      id: "todo",
      title: "To Do",
      count: tasks.filter(t => t.status === "todo").length,
    },
    {
      id: "in_progress",
      title: "In Progress",
      count: tasks.filter(t => t.status === "in_progress").length,
    },
    {
      id: "review",
      title: "Review",
      count: tasks.filter(t => t.status === "review").length,
    },
    {
      id: "completed",
      title: "Done",
      count: tasks.filter(t => t.status === "completed").length,
    },
    {
      id: "blocked",
      title: "Blocked",
      count: tasks.filter(t => t.status === "blocked").length,
    },
  ];

  const handleDragStart = (taskId: string) => {
    setDraggedTask(taskId);
  };

  const handleDragEnd = () => {
    setDraggedTask(null);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetStatus: TaskStatus) => {
    e.preventDefault();
    
    if (draggedTask) {
      const task = tasks.find(t => t.id === draggedTask);
      if (task && task.status !== targetStatus) {
        updateTaskMutation.mutate({
          taskId: draggedTask,
          updates: { status: targetStatus },
        });
      }
    }
    
    setDraggedTask(null);
  };

  if (isLoading) {
    return (
      <div className="flex space-x-6 h-full" data-testid="kanban-loading">
        {columns.map(column => (
          <div key={column.id} className="flex-1 bg-card rounded-lg border border-border">
            <div className="p-4 border-b border-border">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <h3 className="font-semibold">{column.title}</h3>
                  <div className="w-6 h-4 bg-muted rounded animate-pulse" />
                </div>
              </div>
            </div>
            <div className="p-4 space-y-4 min-h-96">
              {[1, 2].map(i => (
                <div key={i} className="h-32 bg-muted rounded animate-pulse" />
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="flex space-x-6 h-full" data-testid="kanban-board">
      {columns.map(column => (
        <div 
          key={column.id} 
          className="flex-1 bg-card rounded-lg border border-border"
          onDragOver={handleDragOver}
          onDrop={(e) => handleDrop(e, column.id)}
          data-testid={`column-${column.id}`}
        >
          <div className="p-4 border-b border-border">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <h3 className="font-semibold" data-testid={`column-title-${column.id}`}>
                  {column.title}
                </h3>
                <span 
                  className={`px-2 py-1 text-xs rounded-full ${
                    column.id === 'blocked' 
                      ? 'bg-destructive text-destructive-foreground'
                      : 'bg-muted text-muted-foreground'
                  }`}
                  data-testid={`column-count-${column.id}`}
                >
                  {column.count}
                </span>
              </div>
              <button 
                className="text-muted-foreground hover:text-foreground"
                data-testid={`column-menu-${column.id}`}
              >
                <MoreHorizontal className="h-4 w-4" />
              </button>
            </div>
          </div>
          <div className="p-4 space-y-4 min-h-96" data-testid={`column-content-${column.id}`}>
            {tasks
              .filter(task => task.status === column.id)
              .map(task => (
                <div
                  key={task.id}
                  draggable
                  onDragStart={() => handleDragStart(task.id)}
                  onDragEnd={handleDragEnd}
                  className={`cursor-move ${draggedTask === task.id ? 'opacity-50' : ''}`}
                  onClick={() => onTaskClick(task)}
                  data-testid={`draggable-task-${task.id}`}
                >
                  <TaskCard task={task} />
                </div>
              ))}
            {tasks.filter(task => task.status === column.id).length === 0 && (
              <div className="text-center text-muted-foreground py-8">
                No tasks
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
