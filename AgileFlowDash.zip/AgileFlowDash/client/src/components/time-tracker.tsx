import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Play, Pause, Clock, StopCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TimeEntry, Task } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TimeTrackerProps {
  task: Task;
  currentUser?: string;
}

export default function TimeTracker({ task, currentUser = "Current User" }: TimeTrackerProps) {
  const [description, setDescription] = useState("");
  const [elapsedTime, setElapsedTime] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch active timer for this task and user
  const { data: activeTimer } = useQuery<TimeEntry | null>({
    queryKey: ["/api/tasks", task.id, "active-timer", currentUser],
    refetchInterval: 1000, // Update every second when timer is running
  });

  // Fetch all time entries for this task
  const { data: timeEntries = [] } = useQuery<TimeEntry[]>({
    queryKey: ["/api/tasks", task.id, "time-entries"],
  });

  // Update elapsed time for active timer
  useEffect(() => {
    if (activeTimer && activeTimer.isActive) {
      const interval = setInterval(() => {
        const start = new Date(activeTimer.startTime);
        const now = new Date();
        const elapsed = Math.floor((now.getTime() - start.getTime()) / 1000);
        setElapsedTime(elapsed);
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [activeTimer]);

  const startTimerMutation = useMutation({
    mutationFn: async () => {
      // Stop any existing active timers first
      await apiRequest("POST", `/api/users/${currentUser}/stop-all-timers`, {});
      
      // Start new timer
      const response = await apiRequest("POST", "/api/time-entries", {
        taskId: task.id,
        user: currentUser,
        startTime: new Date(),
        description: description.trim() || null,
        isActive: true,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks", task.id, "active-timer", currentUser] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks", task.id, "time-entries"] });
      setDescription("");
      toast({
        title: "Timer Started",
        description: `Started tracking time for "${task.title}"`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start timer",
        variant: "destructive",
      });
    },
  });

  const stopTimerMutation = useMutation({
    mutationFn: async () => {
      if (!activeTimer) throw new Error("No active timer");
      const response = await apiRequest("PATCH", `/api/time-entries/${activeTimer.id}`, {
        endTime: new Date(),
        isActive: false,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks", task.id, "active-timer", currentUser] });
      queryClient.invalidateQueries({ queryKey: ["/api/tasks", task.id, "time-entries"] });
      toast({
        title: "Timer Stopped",
        description: "Time has been recorded successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error", 
        description: "Failed to stop timer",
        variant: "destructive",
      });
    },
  });

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDurationFromMinutes = (minutes: number | null) => {
    if (!minutes) return "0:00";
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  const getTotalTimeSpent = () => {
    return timeEntries.reduce((total, entry) => total + (entry.duration || 0), 0);
  };

  const isTimerRunning = activeTimer && activeTimer.isActive;

  return (
    <Card className="w-full" data-testid="time-tracker">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Clock className="h-5 w-5" />
          <span>Time Tracking</span>
          {isTimerRunning && (
            <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded-full">
              Running
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Current Timer Display */}
        {isTimerRunning && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-800 font-medium">Timer Running</p>
                <p className="text-2xl font-mono text-green-900" data-testid="elapsed-time">
                  {formatDuration(elapsedTime)}
                </p>
                {activeTimer.description && (
                  <p className="text-sm text-green-700">{activeTimer.description}</p>
                )}
              </div>
              <Button
                onClick={() => stopTimerMutation.mutate()}
                disabled={stopTimerMutation.isPending}
                variant="outline"
                className="border-green-300 text-green-700 hover:bg-green-100"
                data-testid="button-stop-timer"
              >
                <StopCircle className="h-4 w-4 mr-2" />
                {stopTimerMutation.isPending ? "Stopping..." : "Stop"}
              </Button>
            </div>
          </div>
        )}

        {/* Start Timer Controls */}
        {!isTimerRunning && (
          <div className="space-y-3">
            <div>
              <Label htmlFor="time-description">Description (optional)</Label>
              <Input
                id="time-description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What are you working on?"
                data-testid="input-time-description"
              />
            </div>
            <Button
              onClick={() => startTimerMutation.mutate()}
              disabled={startTimerMutation.isPending}
              className="w-full"
              data-testid="button-start-timer"
            >
              <Play className="h-4 w-4 mr-2" />
              {startTimerMutation.isPending ? "Starting..." : "Start Timer"}
            </Button>
          </div>
        )}

        {/* Time Summary */}
        <div className="border-t pt-4">
          <div className="flex justify-between items-center mb-3">
            <span className="text-sm font-medium">Total Time Spent</span>
            <span className="text-sm font-mono bg-muted px-2 py-1 rounded" data-testid="total-time">
              {formatDurationFromMinutes(getTotalTimeSpent())}
            </span>
          </div>
          
          {/* Recent Time Entries */}
          {timeEntries.length > 0 && (
            <div className="space-y-2">
              <span className="text-sm font-medium">Recent Sessions</span>
              <div className="max-h-32 overflow-y-auto space-y-1">
                {timeEntries
                  .filter(entry => !entry.isActive)
                  .slice(-3)
                  .reverse()
                  .map((entry) => (
                    <div
                      key={entry.id}
                      className="flex justify-between items-center text-xs bg-muted p-2 rounded"
                      data-testid={`time-entry-${entry.id}`}
                    >
                      <div>
                        <span className="font-medium">
                          {formatDurationFromMinutes(entry.duration)}
                        </span>
                        {entry.description && (
                          <span className="text-muted-foreground ml-2">
                            {entry.description}
                          </span>
                        )}
                      </div>
                      <span className="text-muted-foreground">
                        {new Date(entry.startTime).toLocaleDateString()}
                      </span>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}