import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { X, CheckCircle, Clock, Circle, Link, User, Send, Edit } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Task, Comment, workflowSteps } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import TaskFormModal from "./task-form-modal";
import TimeTracker from "./time-tracker";

interface TaskDetailModalProps {
  task: Task;
  programId: string;
  onClose: () => void;
}

export default function TaskDetailModal({ task, programId, onClose }: TaskDetailModalProps) {
  const [newComment, setNewComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: comments = [] } = useQuery<Comment[]>({
    queryKey: ["/api/tasks", task.id, "comments"],
  });

  const createCommentMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("POST", "/api/comments", {
        taskId: task.id,
        author: "Current User", // TODO: Replace with actual user system
        content,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks", task.id, "comments"] });
      setNewComment("");
      setIsSubmitting(false);
      toast({
        title: "Comment Added",
        description: "Your comment has been added successfully.",
      });
    },
    onError: () => {
      setIsSubmitting(false);
      toast({
        title: "Error",
        description: "Failed to add comment.",
        variant: "destructive",
      });
    },
  });

  const handleSubmitComment = () => {
    if (!newComment.trim()) return;
    setIsSubmitting(true);
    createCommentMutation.mutate(newComment.trim());
  };

  const getWorkflowSteps = () => {
    if (!task.taskType || !(task.taskType in workflowSteps)) {
      return [];
    }
    return workflowSteps[task.taskType as keyof typeof workflowSteps];
  };

  const getStepStatus = (step: string) => {
    if ((task.completedWorkflowSteps || []).includes(step)) {
      return 'completed';
    }
    if (task.currentWorkflowStep === step) {
      return 'in_progress';
    }
    return 'pending';
  };

  const getResourceFullName = (resource: string | null | undefined) => {
    if (!resource) return '';
    const mapping = {
      mechanical_engineer: 'Mechanical Engineer',
      electrical_engineer: 'Electrical Engineer',
      software_engineer: 'Software Engineer',
      production: 'Production',
      system_lead: 'System/Project Lead',
    };
    return mapping[resource as keyof typeof mapping] || resource;
  };

  const formatDate = (date: Date | string | null) => {
    if (!date) return '';
    return new Date(date).toLocaleDateString();
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getRelativeTime = (date: Date | string) => {
    const now = new Date();
    const commentDate = new Date(date);
    const diffHours = Math.floor((now.getTime() - commentDate.getTime()) / (1000 * 60 * 60));
    
    if (diffHours < 1) return 'Just now';
    if (diffHours < 24) return `${diffHours} hour${diffHours === 1 ? '' : 's'} ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays} day${diffDays === 1 ? '' : 's'} ago`;
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto" data-testid="task-detail-modal">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-semibold" data-testid="modal-task-title">
              {task.title}
            </DialogTitle>
            <Button variant="ghost" size="icon" onClick={onClose} data-testid="button-close-modal">
              <X className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex items-center space-x-4 mt-2">
            <span className="text-sm text-muted-foreground" data-testid="modal-work-package">
              {task.workPackageId.toUpperCase()} • Task ID: {task.id}
            </span>
            {task.assignedResource && (
              <span className={`resource-${task.assignedResource} text-xs text-white px-2 py-1 rounded-full`}>
                {getResourceFullName(task.assignedResource)}
              </span>
            )}
          </div>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          {/* Task Description */}
          <div>
            <h3 className="font-medium mb-2" data-testid="modal-description-header">Description</h3>
            <p className="text-sm text-muted-foreground" data-testid="modal-description">
              {task.description || 'No description provided.'}
            </p>
          </div>
          
          {/* Progress Section */}
          <div>
            <h3 className="font-medium mb-2" data-testid="modal-progress-header">Progress</h3>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Overall Progress</span>
                <span data-testid="modal-progress-percentage">{task.progress}%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-3">
                <div 
                  className="progress-bar h-3 rounded-full" 
                  style={{ width: `${task.progress}%` }}
                  data-testid="modal-progress-bar"
                />
              </div>
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Estimated: {task.estimatedDays} days</span>
                {task.dueDate && (
                  <span>Due: {formatDate(task.dueDate)}</span>
                )}
              </div>
            </div>
          </div>
          
          {/* Workflow Steps */}
          {getWorkflowSteps().length > 0 && (
            <div>
              <h3 className="font-medium mb-2" data-testid="modal-workflow-header">Workflow Steps</h3>
              <div className="space-y-2">
                {getWorkflowSteps().map((step, index) => {
                  const status = getStepStatus(step);
                  return (
                    <div 
                      key={step}
                      className={`flex items-center space-x-3 p-2 rounded ${
                        status === 'completed' ? 'bg-green-50' :
                        status === 'in_progress' ? 'bg-blue-50' : 'bg-gray-50'
                      }`}
                      data-testid={`workflow-step-${index}`}
                    >
                      {status === 'completed' ? (
                        <CheckCircle className="text-green-500 h-4 w-4" />
                      ) : status === 'in_progress' ? (
                        <Clock className="text-blue-500 h-4 w-4" />
                      ) : (
                        <Circle className="text-gray-400 h-4 w-4" />
                      )}
                      <span className={`text-sm ${status === 'pending' ? 'text-muted-foreground' : ''}`}>
                        {step.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </span>
                      <span className={`text-xs ml-auto ${
                        status === 'completed' ? 'text-green-600' :
                        status === 'in_progress' ? 'text-blue-600' : 'text-muted-foreground'
                      }`}>
                        {status === 'completed' ? 'Completed' :
                         status === 'in_progress' ? 'In Progress' : 'Pending'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
          
          {/* Dependencies */}
          {task.dependencies && task.dependencies.length > 0 && (
            <div>
              <h3 className="font-medium mb-2" data-testid="modal-dependencies-header">Dependencies</h3>
              <div className="space-y-2">
                {task.dependencies.map((depId, index) => (
                  <div 
                    key={depId}
                    className="flex items-center space-x-3 p-2 border border-border rounded"
                    data-testid={`dependency-${index}`}
                  >
                    <Link className="text-muted-foreground h-4 w-4" />
                    <span className="text-sm">Task {depId}</span>
                    <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded ml-auto">
                      Complete
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Time Tracking Section */}
          <div>
            <TimeTracker task={task} />
          </div>
          
          {/* Comments Section */}
          <div>
            <h3 className="font-medium mb-2" data-testid="modal-comments-header">
              Comments ({comments.length})
            </h3>
            <div className="space-y-3">
              {comments.map((comment) => (
                <div 
                  key={comment.id}
                  className="border border-border rounded p-3"
                  data-testid={`comment-${comment.id}`}
                >
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-xs text-white">
                      {getInitials(comment.author)}
                    </div>
                    <span className="text-sm font-medium">{comment.author}</span>
                    <span className="text-xs text-muted-foreground">
                      {getRelativeTime(comment.createdAt!)}
                    </span>
                  </div>
                  <p className="text-sm">{comment.content}</p>
                </div>
              ))}
              {comments.length === 0 && (
                <p className="text-sm text-muted-foreground">No comments yet.</p>
              )}
            </div>
            
            {/* Add Comment Form */}
            <div className="mt-4 space-y-3">
              <Textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Add a comment..."
                className="min-h-[80px]"
                data-testid="comment-input"
              />
              <div className="flex justify-end">
                <Button
                  onClick={handleSubmitComment}
                  disabled={!newComment.trim() || isSubmitting}
                  data-testid="button-add-comment"
                >
                  <Send className="h-4 w-4 mr-2" />
                  {isSubmitting ? "Adding..." : "Add Comment"}
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between border-t border-border pt-4">
          <Button 
            variant="secondary" 
            onClick={() => setIsEditModalOpen(true)}
            data-testid="button-edit-task"
          >
            <Edit className="h-4 w-4 mr-2" />
            Edit Task
          </Button>
          <div className="space-x-2">
            <Button variant="destructive" data-testid="button-delete-task">
              Delete
            </Button>
            <Button onClick={onClose} data-testid="button-close-task">
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
      
      <TaskFormModal
        task={task}
        programId={programId}
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
      />
    </Dialog>
  );
}
