import { useQuery } from "@tanstack/react-query";
import { 
  Columns, 
  Table, 
  Calendar, 
  Users, 
  ChartLine, 
  ProjectorIcon,
  ChevronRight,
  FileSpreadsheet 
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { Program, Sprint } from "@shared/schema";

interface SidebarProps {
  programId: string;
}

export default function Sidebar({ programId }: SidebarProps) {
  const [location] = useLocation();

  const { data: programs = [] } = useQuery<Program[]>({
    queryKey: ["/api/programs"],
  });

  const { data: sprints = [] } = useQuery<Sprint[]>({
    queryKey: ["/api/programs", programId, "sprints"],
  });

  const currentProgram = programs.find(p => p.id === programId);
  const activeSprint = sprints.find(s => s.status === 'active');

  const navItems = [
    { path: "/", icon: Columns, label: "Kanban Board" },
    { path: "/wbs", icon: Table, label: "WBS View" },
    { path: "/sprint-planning", icon: Calendar, label: "Sprint Planning" },
    { path: "/resources", icon: Users, label: "Resources" },
    { path: "/excel-sync", icon: FileSpreadsheet, label: "Excel Sync" },
    { path: "/analytics", icon: ChartLine, label: "Analytics" },
  ];

  const otherPrograms = programs.filter(p => p.id !== programId);

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col" data-testid="sidebar">
      {/* Logo and Brand */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <ProjectorIcon className="text-primary-foreground text-sm" />
          </div>
          <div>
            <h1 className="text-lg font-semibold" data-testid="app-title">AgileBoard Pro</h1>
            <p className="text-xs text-muted-foreground">Project Management</p>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 p-4">
        <div className="space-y-2">
          {navItems.map((item) => {
            const isActive = location === item.path;
            const IconComponent = item.icon;
            
            return (
              <Link key={item.path} href={item.path}>
                <button 
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${
                    isActive 
                      ? 'bg-primary text-primary-foreground' 
                      : 'hover:bg-accent hover:text-accent-foreground'
                  }`}
                  data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <IconComponent className="h-4 w-4" />
                  <span>{item.label}</span>
                </button>
              </Link>
            );
          })}
        </div>
        
        {/* Project Selector */}
        <div className="mt-8">
          <h3 className="text-sm font-medium text-muted-foreground mb-3" data-testid="projects-header">
            Active Projects
          </h3>
          <div className="space-y-2">
            {currentProgram && (
              <div className="p-3 bg-accent rounded-md" data-testid={`active-program-${currentProgram.id}`}>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{currentProgram.name}</span>
                  <span className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded">
                    Active
                  </span>
                </div>
                {activeSprint && (
                  <p className="text-xs text-muted-foreground mt-1">
                    {(activeSprint.taskIds || []).length} tasks • {
                      Math.ceil(
                        (new Date(activeSprint.endDate).getTime() - new Date().getTime()) / 
                        (1000 * 60 * 60 * 24)
                      )
                    } days left
                  </p>
                )}
              </div>
            )}
            
            {otherPrograms.map((program) => (
              <div 
                key={program.id}
                className="p-3 hover:bg-accent rounded-md cursor-pointer group" 
                data-testid={`program-${program.id}`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm">{program.name}</span>
                  <ChevronRight className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Switch to this project
                </p>
              </div>
            ))}
          </div>
        </div>
      </nav>
    </div>
  );
}
