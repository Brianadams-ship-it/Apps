import { useQuery } from "@tanstack/react-query";
import { Filter, Plus, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Program, Sprint } from "@shared/schema";

interface HeaderProps {
  programId: string;
  onCreateTask?: () => void;
}

export default function Header({ programId, onCreateTask }: HeaderProps) {
  const { data: program } = useQuery<Program>({
    queryKey: ["/api/programs", programId],
  });

  const { data: sprints = [] } = useQuery<Sprint[]>({
    queryKey: ["/api/programs", programId, "sprints"],
  });

  const activeSprint = sprints.find(s => s.status === 'active');

  // Mock task count and completion percentage
  const taskCount = 23;
  const completionPercentage = 67;

  return (
    <header className="bg-card border-b border-border px-6 py-4" data-testid="header">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold" data-testid="header-title">
            {program?.name || 'Loading...'}
          </h1>
          <div className="flex items-center space-x-4 mt-1">
            {activeSprint && (
              <span className="text-sm text-muted-foreground" data-testid="sprint-info">
                {activeSprint.name} • {new Date(activeSprint.startDate).toLocaleDateString()} - {new Date(activeSprint.endDate).toLocaleDateString()}
              </span>
            )}
            <span className="px-2 py-1 bg-accent text-accent-foreground text-xs rounded-full" data-testid="task-count">
              {taskCount} Tasks
            </span>
            <span className="px-2 py-1 bg-primary text-primary-foreground text-xs rounded-full" data-testid="completion-percentage">
              {completionPercentage}% Complete
            </span>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="secondary" data-testid="button-filter">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button onClick={onCreateTask} data-testid="button-add-task">
            <Plus className="mr-2 h-4 w-4" />
            Add Task
          </Button>
          <Button variant="ghost" size="icon" data-testid="button-settings">
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}
