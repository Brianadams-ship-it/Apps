import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, FileSpreadsheet, Download, Upload, ExternalLink, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";

interface ExcelStatus {
  exportFileUrl: string;
  importFileUrl: string;
  lastModified: string | null;
  available: boolean;
  error?: string;
}

interface ExcelResponse {
  success: boolean;
  message: string;
  exportFileUrl?: string;
  exportedAt?: string;
  importedAt?: string;
  lastModified?: string;
  error?: string;
}

export default function ExcelManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);

  // Query Excel status
  const { data: excelStatus, isLoading: statusLoading, refetch: refetchStatus } = useQuery<ExcelStatus>({
    queryKey: ['/api/excel-status'],
    refetchInterval: 30000, // Check for updates every 30 seconds
  });

  // Export mutation
  const exportMutation = useMutation({
    mutationFn: async (): Promise<ExcelResponse> => {
      const response = await apiRequest('POST', '/api/export-excel');
      return await response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "Export Successful",
          description: data.message,
          variant: "default",
        });
        refetchStatus();
      } else {
        toast({
          title: "Export Failed", 
          description: data.message,
          variant: "destructive",
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Export Error",
        description: error instanceof Error ? error.message : "Failed to export data",
        variant: "destructive",
      });
    },
  });

  // Import mutation
  const importMutation = useMutation({
    mutationFn: async (): Promise<ExcelResponse> => {
      const response = await apiRequest('POST', '/api/import-excel');
      return await response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "Import Successful",
          description: data.message,
          variant: "default",
        });
        // Invalidate all queries to refresh data
        queryClient.invalidateQueries();
        refetchStatus();
      } else {
        toast({
          title: "Import Failed",
          description: data.message,
          variant: "destructive",
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Import Error",
        description: error instanceof Error ? error.message : "Failed to import data",
        variant: "destructive",
      });
    },
  });

  const handleExport = async () => {
    setIsExporting(true);
    try {
      await exportMutation.mutateAsync();
    } finally {
      setIsExporting(false);
    }
  };

  const handleImport = async () => {
    setIsImporting(true);
    try {
      await importMutation.mutateAsync();
    } finally {
      setIsImporting(false);
    }
  };

  const handleViewExportFile = () => {
    if (excelStatus?.exportFileUrl) {
      window.open(excelStatus.exportFileUrl, '_blank');
    }
  };

  const handleViewImportFile = () => {
    if (excelStatus?.importFileUrl) {
      window.open(excelStatus.importFileUrl, '_blank');
    }
  };

  const handleRefresh = () => {
    refetchStatus();
  };

  if (statusLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5" />
            Master Excel File
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin" />
            <span className="ml-2">Loading Excel file status...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="excel-manager">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-green-600" />
            Master Excel File
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            data-testid="button-refresh-excel"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <Badge variant={excelStatus?.available ? "default" : "secondary"}>
            {excelStatus?.available ? "Available" : "Not Found"}
          </Badge>
          {excelStatus?.lastModified && (
            <span className="text-sm text-muted-foreground">
              Last updated: {format(new Date(excelStatus.lastModified), "MMM dd, yyyy 'at' h:mm a")}
            </span>
          )}
        </div>

        {excelStatus?.error && (
          <div className="text-sm text-red-600 bg-red-50 p-2 rounded-md">
            {excelStatus.error}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <Button
            onClick={handleExport}
            disabled={isExporting}
            className="flex items-center gap-2"
            data-testid="button-export-excel"
          >
            {isExporting ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Upload className="h-4 w-4" />
            )}
            Export to GitHub
          </Button>

          <Button
            onClick={handleImport}
            variant="outline"
            disabled={isImporting || !excelStatus?.available}
            className="flex items-center gap-2"
            data-testid="button-import-excel"
          >
            {isImporting ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Download className="h-4 w-4" />
            )}
            Import from GitHub
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
          <Button
            onClick={handleViewExportFile}
            variant="ghost"
            size="sm"
            className="flex items-center gap-2"
            data-testid="button-view-export-file"
          >
            <ExternalLink className="h-3 w-3" />
            View Export File
          </Button>

          <Button
            onClick={handleViewImportFile}
            variant="ghost"
            size="sm"
            disabled={!excelStatus?.available}
            className="flex items-center gap-2"
            data-testid="button-view-import-file"
          >
            <ExternalLink className="h-3 w-3" />
            Edit Import File
          </Button>
        </div>

        <div className="text-sm text-muted-foreground bg-gray-50 dark:bg-gray-800 p-3 rounded-md">
          <h4 className="font-medium mb-2">How it works:</h4>
          <ol className="list-decimal list-inside space-y-1">
            <li>Click "Export to GitHub" to save all current data to project-data.xlsx</li>
            <li>Click "Edit Import File" to open Project Input.xlsx for editing</li>
            <li>Edit the Project Input.xlsx file directly on GitHub or download and edit locally</li>
            <li>Click "Import from GitHub" to sync changes from Project Input.xlsx back to the application</li>
          </ol>
          <div className="mt-2 pt-2 border-t border-gray-200 dark:border-gray-700">
            <p className="text-xs"><strong>Export:</strong> project-data.xlsx (read-only backup)</p>
            <p className="text-xs"><strong>Import:</strong> Project Input.xlsx (editable master file)</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}