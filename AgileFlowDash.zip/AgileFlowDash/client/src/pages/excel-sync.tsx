import ExcelManager from "@/components/excel-manager";

export default function ExcelSync() {
  return (
    <div className="container mx-auto p-6 space-y-6" data-testid="page-excel-sync">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Excel Data Sync</h1>
        <p className="text-muted-foreground">
          Manage your master Excel file stored on GitHub. Export current data, edit the file online, 
          and import changes back to the application.
        </p>
      </div>
      
      <ExcelManager />
    </div>
  );
}