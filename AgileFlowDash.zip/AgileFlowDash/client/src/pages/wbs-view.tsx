import { useQuery } from "@tanstack/react-query";
import { ChevronDown, ChevronRight, Rocket, Thermometer, Bolt, Code, Circle, CheckCircle, Clock, Eye, Calendar } from "lucide-react";
import { useState } from "react";
import Sidebar from "@/components/sidebar";
import TaskDetailModal from "@/components/task-detail-modal";
import { Task, WorkPackage, Program } from "@shared/schema";
import { format } from "date-fns";

interface WBSItem {
  id: string;
  name: string;
  type: 'workPackage' | 'task';
  progress: number;
  phase: string;
  dueDate?: Date;
  task?: Task;
  workPackage?: WorkPackage;
}

interface Phase {
  name: string;
  color: string;
  bgColor: string;
  items: WBSItem[];
}

export default function WBSView() {
  const [selectedProgramId] = useState("prog-1");
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set(["prog-1"]));
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const { data: program } = useQuery<Program>({
    queryKey: ["/api/programs", selectedProgramId],
  });

  const { data: workPackages = [] } = useQuery<WorkPackage[]>({
    queryKey: ["/api/programs", selectedProgramId, "work-packages"],
  });

  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ["/api/programs", selectedProgramId, "tasks"],
  });

  const getPhaseFromName = (name: string): string => {
    if (name.includes('Design') || name.includes('Requirements') || name.includes('Specification')) return 'Design';
    if (name.includes('Hardware') || name.includes('Assembly') || name.includes('Manufacturing')) return 'Hardware';
    if (name.includes('Test') || name.includes('Testing') || name.includes('Verification')) return 'Test';
    if (name.includes('Software') || name.includes('Code') || name.includes('Programming')) return 'Software';
    if (name.includes('Integration') || name.includes('System')) return 'Integration';
    return 'Development';
  };

  const getPhaseColor = (phase: string): { color: string; bgColor: string } => {
    switch (phase) {
      case 'Design':
        return { color: 'text-white', bgColor: 'bg-green-400' };
      case 'Hardware':
        return { color: 'text-white', bgColor: 'bg-blue-400' };
      case 'Test':
        return { color: 'text-white', bgColor: 'bg-purple-400' };
      case 'Software':
        return { color: 'text-white', bgColor: 'bg-teal-400' };
      case 'Integration':
        return { color: 'text-white', bgColor: 'bg-orange-400' };
      default:
        return { color: 'text-white', bgColor: 'bg-gray-400' };
    }
  };

  const buildWBSStructure = (): Phase[] => {
    if (!program) return [];

    // Create WBS items from work packages and tasks
    const wbsItems: WBSItem[] = [];

    // Add work packages
    workPackages.forEach(wp => {
      const wpTasks = tasks.filter(t => t.workPackageId === wp.id);
      const progress = wpTasks.length > 0 
        ? Math.round(wpTasks.reduce((sum, t) => sum + (t.progress || 0), 0) / wpTasks.length)
        : 0;
      
      wbsItems.push({
        id: wp.id,
        name: wp.name,
        type: 'workPackage',
        progress,
        phase: getPhaseFromName(wp.name),
        workPackage: wp
      });

      // Add tasks under this work package
      wpTasks.forEach(task => {
        wbsItems.push({
          id: task.id,
          name: task.title,
          type: 'task',
          progress: task.progress || 0,
          phase: getPhaseFromName(wp.name),
          dueDate: task.dueDate ? new Date(task.dueDate) : undefined,
          task
        });
      });
    });

    // Group by phase
    const phaseMap = new Map<string, WBSItem[]>();
    wbsItems.forEach(item => {
      if (!phaseMap.has(item.phase)) {
        phaseMap.set(item.phase, []);
      }
      phaseMap.get(item.phase)!.push(item);
    });

    // Create phase objects
    const phases: Phase[] = [];
    phaseMap.forEach((items, phaseName) => {
      const colors = getPhaseColor(phaseName);
      phases.push({
        name: phaseName,
        color: colors.color,
        bgColor: colors.bgColor,
        items: items.sort((a, b) => {
          // Work packages first, then tasks
          if (a.type !== b.type) {
            return a.type === 'workPackage' ? -1 : 1;
          }
          return a.name.localeCompare(b.name);
        })
      });
    });

    return phases.sort((a, b) => {
      const order = ['Design', 'Hardware', 'Software', 'Integration', 'Test', 'Development'];
      return order.indexOf(a.name) - order.indexOf(b.name);
    });
  };

  const getResourceAbbreviation = (resource: string | null | undefined) => {
    if (!resource) return '';
    const mapping = {
      mechanical_engineer: 'ME',
      electrical_engineer: 'EE',
      software_engineer: 'SE',
      production: 'PR',
      system_lead: 'PL',
    };
    return mapping[resource as keyof typeof mapping] || '';
  };

  const formatDueDate = (date: Date) => {
    return format(date, 'MMM dd');
  };

  const getDaysUntilDue = (date: Date) => {
    const today = new Date();
    const diffTime = date.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const renderProgressBar = (progress: number) => {
    return (
      <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
        <div 
          className={`h-full rounded-full transition-all duration-300 ${
            progress >= 75 ? 'bg-green-500' :
            progress >= 50 ? 'bg-yellow-500' :
            progress >= 25 ? 'bg-orange-500' : 'bg-red-500'
          }`}
          style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
        />
      </div>
    );
  };

  const renderWBSItem = (item: WBSItem, index: number) => {
    const isWorkPackage = item.type === 'workPackage';
    const daysUntilDue = item.dueDate ? getDaysUntilDue(item.dueDate) : null;
    
    const handleItemClick = () => {
      // Only allow clicking on tasks, not work packages
      if (item.type === 'task' && item.task) {
        setSelectedTask(item.task);
      }
    };
    
    return (
      <div 
        key={item.id}
        className={`p-4 border border-gray-300 ${
          isWorkPackage 
            ? `${item.phase === 'Design' ? 'bg-green-500 text-white' : 
                item.phase === 'Hardware' ? 'bg-blue-500 text-white' :
                item.phase === 'Test' ? 'bg-purple-500 text-white' :
                item.phase === 'Software' ? 'bg-teal-500 text-white' :
                item.phase === 'Integration' ? 'bg-orange-500 text-white' : 'bg-gray-500 text-white'} font-semibold`
            : `${item.phase === 'Design' ? 'bg-green-50' : 
                item.phase === 'Hardware' ? 'bg-blue-50' :
                item.phase === 'Test' ? 'bg-purple-50' :
                item.phase === 'Software' ? 'bg-teal-50' :
                item.phase === 'Integration' ? 'bg-orange-50' : 'bg-gray-50'} ${item.type === 'task' ? 'cursor-pointer hover:bg-opacity-75' : ''}`
        } hover:shadow-md transition-shadow`}
        data-testid={`wbs-item-${item.id}`}
        onClick={handleItemClick}
      >
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-2">
            {isWorkPackage ? (
              <Rocket className="h-4 w-4" />
            ) : (
              <div className={`w-3 h-3 rounded-full ${
                item.task?.status === 'completed' ? 'bg-green-500' :
                item.task?.status === 'in_progress' ? 'bg-blue-500' :
                item.task?.status === 'review' ? 'bg-purple-500' :
                item.task?.status === 'blocked' ? 'bg-red-500' : 'bg-gray-400'
              }`} />
            )}
            <span className={`text-sm ${isWorkPackage ? 'font-bold' : 'font-medium'}`} data-testid={`item-name-${item.id}`}>
              {item.name}
            </span>
          </div>
          {item.task?.assignedResource && (
            <span className={`resource-${item.task.assignedResource} text-xs text-white px-2 py-1 rounded-full`}>
              {getResourceAbbreviation(item.task.assignedResource)}
            </span>
          )}
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span data-testid={`item-progress-${item.id}`}>{item.progress}%</span>
            {item.dueDate && (
              <div className="flex items-center space-x-1">
                <Calendar className="h-3 w-3" />
                <span className={`${
                  daysUntilDue !== null && daysUntilDue < 0 ? 'text-red-600 font-semibold' :
                  daysUntilDue !== null && daysUntilDue <= 3 ? 'text-orange-600' :
                  'text-gray-600'
                }`} data-testid={`item-due-date-${item.id}`}>
                  {formatDueDate(item.dueDate)}
                  {daysUntilDue !== null && daysUntilDue < 0 && ` (${Math.abs(daysUntilDue)}d overdue)`}
                </span>
              </div>
            )}
          </div>
          {renderProgressBar(item.progress)}
        </div>
      </div>
    );
  };

  const phases = buildWBSStructure();

  if (!program) {
    return (
      <div className="min-h-screen flex bg-background text-foreground" data-testid="wbs-view-page">
        <Sidebar programId={selectedProgramId} />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-muted-foreground">Loading Work Breakdown Structure...</h2>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-background text-foreground" data-testid="wbs-view-page">
      <Sidebar programId={selectedProgramId} />
      <div className="flex-1 flex flex-col">
        <div className="bg-card border-b border-border px-6 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold" data-testid="wbs-title">Work Breakdown Structure</h1>
            <button 
              className="px-4 py-2 bg-secondary text-secondary-foreground rounded-md hover:bg-muted"
              data-testid="button-export-wbs"
            >
              Export WBS
            </button>
          </div>
        </div>
        
        <main className="flex-1 p-6 overflow-auto">
          <div className="space-y-8" data-testid="wbs-phases">
            {phases.map((phase) => (
              <div key={phase.name} className="" data-testid={`phase-${phase.name.toLowerCase()}`}>
                <div className="flex">
                  {/* Phase Label */}
                  <div className={`w-32 ${phase.bgColor} ${phase.color} p-4 flex items-center justify-center font-bold text-sm border border-gray-300`}>
                    <span className="transform -rotate-90 whitespace-nowrap">{phase.name}</span>
                  </div>
                  
                  {/* Phase Items Grid */}
                  <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-0">
                    {phase.items.map((item, index) => renderWBSItem(item, index))}
                  </div>
                </div>
              </div>
            ))}
            
            {phases.length === 0 && (
              <div className="text-center text-muted-foreground py-12">
                <Rocket className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No Work Breakdown Structure</h3>
                <p>Create work packages and tasks to see them organized by phases.</p>
              </div>
            )}
          </div>
        </main>
      </div>
      
      {selectedTask && (
        <TaskDetailModal 
          task={selectedTask} 
          programId={selectedProgramId}
          onClose={() => setSelectedTask(null)} 
        />
      )}
    </div>
  );
}
