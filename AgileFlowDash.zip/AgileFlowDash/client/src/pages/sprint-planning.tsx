import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Calendar, Clock, Users, Target } from "lucide-react";
import Sidebar from "@/components/sidebar";
import TaskCard from "@/components/task-card";
import { Task, Sprint } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function SprintPlanning() {
  const [selectedProgramId] = useState("prog-1");
  const [selectedTasks, setSelectedTasks] = useState<Set<string>>(new Set());
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ["/api/programs", selectedProgramId, "tasks"],
  });

  const { data: sprints = [] } = useQuery<Sprint[]>({
    queryKey: ["/api/programs", selectedProgramId, "sprints"],
  });

  const currentSprint = sprints.find(s => s.status === 'active');
  const availableTasks = tasks.filter(task => 
    !(currentSprint?.taskIds || []).includes(task.id) && task.status !== 'completed'
  );

  const sprintTasks = currentSprint 
    ? tasks.filter(task => (currentSprint.taskIds || []).includes(task.id))
    : [];

  const toggleTaskSelection = (taskId: string) => {
    const newSelected = new Set(selectedTasks);
    if (newSelected.has(taskId)) {
      newSelected.delete(taskId);
    } else {
      newSelected.add(taskId);
    }
    setSelectedTasks(newSelected);
  };

  const addTasksToSprintMutation = useMutation({
    mutationFn: async (taskIds: string[]) => {
      if (!currentSprint) throw new Error("No active sprint");
      const updatedTaskIds = [...(currentSprint.taskIds || []), ...taskIds];
      const response = await apiRequest("PATCH", `/api/sprints/${currentSprint.id}`, {
        taskIds: updatedTaskIds,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/programs", selectedProgramId, "sprints"] });
      queryClient.invalidateQueries({ queryKey: ["/api/programs", selectedProgramId, "tasks"] });
      toast({
        title: "Tasks Added",
        description: `${selectedTasks.size} task(s) added to sprint successfully.`,
      });
      setSelectedTasks(new Set());
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add tasks to sprint.",
        variant: "destructive",
      });
    },
  });

  const removeTaskFromSprintMutation = useMutation({
    mutationFn: async (taskId: string) => {
      if (!currentSprint) throw new Error("No active sprint");
      const updatedTaskIds = (currentSprint.taskIds || []).filter(id => id !== taskId);
      const response = await apiRequest("PATCH", `/api/sprints/${currentSprint.id}`, {
        taskIds: updatedTaskIds,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/programs", selectedProgramId, "sprints"] });
      queryClient.invalidateQueries({ queryKey: ["/api/programs", selectedProgramId, "tasks"] });
      toast({
        title: "Task Removed",
        description: "Task removed from sprint successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove task from sprint.",
        variant: "destructive",
      });
    },
  });

  const addToSprint = () => {
    if (selectedTasks.size === 0) return;
    addTasksToSprintMutation.mutate(Array.from(selectedTasks));
  };

  const removeFromSprint = (taskId: string) => {
    removeTaskFromSprintMutation.mutate(taskId);
  };

  const calculateSprintCapacity = () => {
    return sprintTasks.reduce((total, task) => total + (task.estimatedDays || 0), 0);
  };

  const calculateSprintProgress = () => {
    if (sprintTasks.length === 0) return 0;
    return Math.round(sprintTasks.reduce((sum, task) => sum + (task.progress || 0), 0) / sprintTasks.length);
  };

  return (
    <div className="min-h-screen flex bg-background text-foreground" data-testid="sprint-planning-page">
      <Sidebar programId={selectedProgramId} />
      <div className="flex-1 flex flex-col">
        <div className="bg-card border-b border-border px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold" data-testid="sprint-planning-title">Sprint Planning</h1>
              {currentSprint && (
                <div className="flex items-center space-x-4 mt-1">
                  <span className="text-sm text-muted-foreground" data-testid="current-sprint-info">
                    {currentSprint.name} • {new Date(currentSprint.startDate).toLocaleDateString()} - {new Date(currentSprint.endDate).toLocaleDateString()}
                  </span>
                  <span className="px-2 py-1 bg-accent text-accent-foreground text-xs rounded-full">
                    {sprintTasks.length} Tasks
                  </span>
                  <span className="px-2 py-1 bg-primary text-primary-foreground text-xs rounded-full">
                    {calculateSprintProgress()}% Complete
                  </span>
                </div>
              )}
            </div>
            <div className="flex items-center space-x-3">
              <Button
                onClick={addToSprint}
                disabled={selectedTasks.size === 0 || addTasksToSprintMutation.isPending}
                data-testid="button-add-to-sprint"
              >
                {addTasksToSprintMutation.isPending ? "Adding..." : `Add Selected to Sprint (${selectedTasks.size})`}
              </Button>
              <Button variant="outline" data-testid="button-create-sprint">
                Create New Sprint
              </Button>
            </div>
          </div>
        </div>

        <main className="flex-1 p-6 overflow-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Sprint Overview */}
            <div className="lg:col-span-1 space-y-6">
              <Card data-testid="sprint-overview-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Target className="h-5 w-5" />
                    <span>Sprint Overview</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {currentSprint ? (
                    <>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Duration</span>
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-4 w-4" />
                          <span className="text-sm">14 days</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Capacity</span>
                        <div className="flex items-center space-x-1">
                          <Clock className="h-4 w-4" />
                          <span className="text-sm">{calculateSprintCapacity()} days</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Team Size</span>
                        <div className="flex items-center space-x-1">
                          <Users className="h-4 w-4" />
                          <span className="text-sm">5 engineers</span>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{calculateSprintProgress()}%</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div 
                            className="progress-bar h-2 rounded-full" 
                            style={{ width: `${calculateSprintProgress()}%` }}
                          />
                        </div>
                      </div>
                    </>
                  ) : (
                    <p className="text-sm text-muted-foreground">No active sprint</p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Available Tasks */}
            <div className="lg:col-span-1">
              <Card data-testid="available-tasks-card">
                <CardHeader>
                  <CardTitle>Available Tasks ({availableTasks.length})</CardTitle>
                </CardHeader>
                <CardContent className="max-h-96 overflow-y-auto space-y-3">
                  {availableTasks.map(task => (
                    <div 
                      key={task.id}
                      className={`cursor-pointer transition-all ${
                        selectedTasks.has(task.id) ? 'ring-2 ring-primary' : ''
                      }`}
                      onClick={() => toggleTaskSelection(task.id)}
                      data-testid={`available-task-${task.id}`}
                    >
                      <TaskCard task={task} showStatus={false} />
                    </div>
                  ))}
                  {availableTasks.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      No available tasks
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sprint Backlog */}
            <div className="lg:col-span-1">
              <Card data-testid="sprint-backlog-card">
                <CardHeader>
                  <CardTitle>Sprint Backlog ({sprintTasks.length})</CardTitle>
                </CardHeader>
                <CardContent className="max-h-96 overflow-y-auto space-y-3">
                  {sprintTasks.map(task => (
                    <div key={task.id} className="relative group" data-testid={`sprint-task-${task.id}`}>
                      <TaskCard task={task} showStatus={true} />
                      <Button
                        variant="outline"
                        size="sm"
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => removeFromSprint(task.id)}
                        disabled={removeTaskFromSprintMutation.isPending}
                        data-testid={`remove-task-${task.id}`}
                      >
                        {removeTaskFromSprintMutation.isPending ? "..." : "Remove"}
                      </Button>
                    </div>
                  ))}
                  {sprintTasks.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      No tasks in sprint
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
