import { useState } from "react";
import Sidebar from "@/components/sidebar";
import Header from "@/components/header";
import KanbanBoard from "@/components/kanban-board";
import TaskDetailModal from "@/components/task-detail-modal";
import TaskFormModal from "@/components/task-form-modal";
import { Task } from "@shared/schema";

export default function Dashboard() {
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isCreateTaskModalOpen, setIsCreateTaskModalOpen] = useState(false);
  const [selectedProgramId] = useState("prog-1"); // Default to first program

  return (
    <div className="min-h-screen flex bg-background text-foreground" data-testid="dashboard-page">
      <Sidebar programId={selectedProgramId} />
      <div className="flex-1 flex flex-col">
        <Header 
          programId={selectedProgramId} 
          onCreateTask={() => setIsCreateTaskModalOpen(true)}
        />
        <main className="flex-1 p-6 overflow-auto">
          <KanbanBoard 
            programId={selectedProgramId} 
            onTaskClick={setSelectedTask}
          />
        </main>
      </div>
      {selectedTask && (
        <TaskDetailModal 
          task={selectedTask} 
          programId={selectedProgramId}
          onClose={() => setSelectedTask(null)} 
        />
      )}
      
      <TaskFormModal
        programId={selectedProgramId}
        isOpen={isCreateTaskModalOpen}
        onClose={() => setIsCreateTaskModalOpen(false)}
      />
    </div>
  );
}
