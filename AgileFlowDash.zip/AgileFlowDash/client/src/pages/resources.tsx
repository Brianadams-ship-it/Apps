import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Users, User, Clock, CheckCircle, AlertTriangle, ChevronDown, ChevronRight, Calendar } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Task, Person } from "@shared/schema";
import { format } from "date-fns";

export default function Resources() {
  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ['/api/programs', 'prog-1', 'tasks'],
  });

  const { data: persons = [] } = useQuery<Person[]>({
    queryKey: ['/api/persons'],
  });

  const [viewByPerson, setViewByPerson] = useState(false);
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set());

  const resourceTypes = [
    { key: 'mechanical_engineer', name: 'Mechanical Engineer', abbrev: 'ME', color: 'bg-blue-600' },
    { key: 'electrical_engineer', name: 'Electrical Engineer', abbrev: 'EE', color: 'bg-yellow-600' },
    { key: 'software_engineer', name: 'Software Engineer', abbrev: 'SE', color: 'bg-green-600' },
    { key: 'production', name: 'Production', abbrev: 'PR', color: 'bg-purple-600' },
    { key: 'system_lead', name: 'System/Project Lead', abbrev: 'PL', color: 'bg-red-600' },
  ];


  const toggleSection = (sectionId: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(sectionId)) {
      newExpanded.delete(sectionId);
    } else {
      newExpanded.add(sectionId);
    }
    setExpandedSections(newExpanded);
  };

  const getTaskPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600';
      case 'in_progress': return 'text-blue-600';
      case 'blocked': return 'text-red-600';
      case 'todo': return 'text-gray-600';
      case 'in_review': return 'text-purple-600';
      default: return 'text-gray-600';
    }
  };

  const formatDueDate = (date: Date) => {
    return format(date, 'MMM dd');
  };

  const isOverdue = (dueDate: Date | null) => {
    if (!dueDate) return false;
    const today = new Date();
    return new Date(dueDate) < today;
  };

  const getResourceData = () => {
    if (viewByPerson) {
      // Show individual people
      return persons.map(person => ({
        key: person.id,
        name: person.name,
        abbrev: person.initials,
        color: resourceTypes.find(rt => rt.key === person.resourceType)?.color || 'bg-gray-600',
        id: person.id,
        displayName: person.name,
        isIndividual: true,
        resourceType: person.resourceType
      }));
    } else {
      // Show resource types
      return resourceTypes.map(resource => ({
        ...resource,
        id: resource.key,
        displayName: resource.name,
        isIndividual: false
      }));
    }
  };

  const getStatsForResource = (resource: any): any => {
    let resourceTasks: Task[];
    
    if (viewByPerson) {
      // Get tasks by person ID
      resourceTasks = tasks.filter(task => task.assignedPersonId === resource.id);
    } else {
      // Get tasks by resource type
      resourceTasks = tasks.filter(task => task.assignedResource === resource.key);
    }
    
    const totalTasks = resourceTasks.length;
    const completedTasks = resourceTasks.filter(task => task.status === 'completed').length;
    const inProgressTasks = resourceTasks.filter(task => task.status === 'in_progress').length;
    const blockedTasks = resourceTasks.filter(task => task.status === 'blocked').length;
    const overdueTasks = resourceTasks.filter(task => {
      if (!task.dueDate) return false;
      const dueDate = new Date(task.dueDate);
      const today = new Date();
      return dueDate < today && task.status !== 'completed';
    }).length;

    const workloadPercentage = Math.round((totalTasks / Math.max(tasks.length, 1)) * 100);
    
    return {
      totalTasks,
      completedTasks,
      inProgressTasks,
      blockedTasks,
      overdueTasks,
      workloadPercentage,
      tasks: resourceTasks
    };
  };

  const resourceData = getResourceData();
  const unassignedTasks = tasks.filter(task => !task.assignedResource);

  return (
    <div className="p-6 space-y-6" data-testid="resources-page">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Users className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold" data-testid="resources-title">Resources</h1>
            <p className="text-muted-foreground">Team capacity and workload overview</p>
          </div>
        </div>
        
        {/* View Toggle */}
        <div className="flex items-center space-x-3" data-testid="view-toggle">
          <Label htmlFor="view-mode" className="text-sm font-medium">
            View by Resource Type
          </Label>
          <Switch
            id="view-mode"
            checked={viewByPerson}
            onCheckedChange={setViewByPerson}
            data-testid="view-toggle-switch"
          />
          <Label htmlFor="view-mode" className="text-sm font-medium">
            View by Person
          </Label>
        </div>
      </div>

      {/* Resource Overview Cards with Expandable Task Lists */}
      <div className="space-y-4">
        {resourceData.map((resource) => {
          const stats = getStatsForResource(resource);
          const completionRate = stats.totalTasks > 0 ? (stats.completedTasks / stats.totalTasks) * 100 : 0;
          const isExpanded = expandedSections.has(resource.id);
          
          return (
            <Card key={resource.key} className="relative" data-testid={`resource-card-${resource.key}`}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`${resource.color} text-white w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold`}>
                      {resource.abbrev}
                    </div>
                    <div>
                      <CardTitle className="text-lg" data-testid={`resource-name-${resource.key}`}>
                        {resource.displayName}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">
                        {stats.totalTasks} tasks assigned
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleSection(resource.id)}
                    className="flex items-center space-x-2"
                    data-testid={`expand-button-${resource.key}`}
                  >
                    <span className="text-sm">
                      {isExpanded ? 'Hide Tasks' : 'Show Tasks'}
                    </span>
                    {isExpanded ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Stats Row */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {/* Workload Progress */}
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Workload</span>
                      <span data-testid={`workload-${resource.key}`}>{stats.workloadPercentage}%</span>
                    </div>
                    <Progress value={stats.workloadPercentage} className="h-2" />
                  </div>

                  {/* Completion Rate */}
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Completion Rate</span>
                      <span data-testid={`completion-rate-${resource.key}`}>{Math.round(completionRate)}%</span>
                    </div>
                    <Progress value={completionRate} className="h-2" />
                  </div>

                  {/* Task Status Summary */}
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm" data-testid={`completed-tasks-${resource.key}`}>
                        {stats.completedTasks}
                      </span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4 text-blue-600" />
                      <span className="text-sm" data-testid={`active-tasks-${resource.key}`}>
                        {stats.inProgressTasks}
                      </span>
                    </div>
                    {stats.overdueTasks > 0 && (
                      <div className="flex items-center space-x-1">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                        <span className="text-sm text-red-600" data-testid={`overdue-tasks-${resource.key}`}>
                          {stats.overdueTasks}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Expandable Task List */}
                {isExpanded && (
                  <div className="border-t pt-4" data-testid={`task-list-${resource.key}`}>
                    <h4 className="font-medium mb-3">Assigned Tasks</h4>
                    {stats.tasks.length === 0 ? (
                      <p className="text-sm text-muted-foreground italic">No tasks assigned</p>
                    ) : (
                      <div className="space-y-2">
                        {stats.tasks.map((task) => (
                          <div 
                            key={task.id} 
                            className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                            data-testid={`task-item-${task.id}`}
                          >
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <h5 className="font-medium text-sm" data-testid={`task-title-${task.id}`}>
                                  {task.title}
                                </h5>
                                <Badge 
                                  variant="outline" 
                                  className={`text-xs ${getTaskPriorityColor(task.priority || 'medium')}`}
                                  data-testid={`task-priority-${task.id}`}
                                >
                                  {task.priority || 'medium'}
                                </Badge>
                              </div>
                              <div className="flex items-center space-x-3 text-xs text-muted-foreground">
                                <span>{task.workPackageId.toUpperCase()}</span>
                                <span className={getStatusColor(task.status)}>
                                  {task.status.replace('_', ' ')}
                                </span>
                                {task.progress !== null && (
                                  <span>{task.progress}% complete</span>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              {task.dueDate && (
                                <div className={`flex items-center space-x-1 text-xs ${
                                  isOverdue(task.dueDate) ? 'text-red-600' : 'text-muted-foreground'
                                }`}>
                                  <Calendar className="h-3 w-3" />
                                  <span data-testid={`task-due-date-${task.id}`}>
                                    {formatDueDate(new Date(task.dueDate))}
                                    {isOverdue(task.dueDate) && ' (Overdue)'}
                                  </span>
                                </div>
                              )}
                              {task.progress !== null && (
                                <div className="w-16">
                                  <Progress value={task.progress} className="h-1" />
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Unassigned Tasks Section */}
      {unassignedTasks.length > 0 && (
        <Card data-testid="unassigned-tasks-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <User className="h-5 w-5" />
              <span>Unassigned Tasks</span>
              <Badge variant="secondary" data-testid="unassigned-count">
                {unassignedTasks.length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {unassignedTasks.map((task) => (
                <div 
                  key={task.id} 
                  className="flex items-center justify-between p-3 border rounded-lg"
                  data-testid={`unassigned-task-${task.id}`}
                >
                  <div>
                    <h4 className="font-medium" data-testid={`unassigned-task-title-${task.id}`}>
                      {task.title}
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      {task.workPackageId.toUpperCase()} • {task.status}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline" data-testid={`unassigned-task-status-${task.id}`}>
                      {task.status}
                    </Badge>
                    {task.dueDate && (
                      <span className="text-sm text-muted-foreground">
                        Due: {new Date(task.dueDate).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}