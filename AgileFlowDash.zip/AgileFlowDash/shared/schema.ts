import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Resource types enum
export const resourceTypes = [
  "mechanical_engineer",
  "electrical_engineer", 
  "software_engineer",
  "production",
  "system_lead"
] as const;

// Task status enum
export const taskStatuses = [
  "todo",
  "in_progress", 
  "review",
  "completed",
  "blocked"
] as const;

// Task types and their workflows
export const taskTypes = [
  "parts_assembly",
  "testing",
  "software",
  "documentation",
  "milestone"
] as const;

// Workflow steps for different task types
export const workflowSteps = {
  parts_assembly: ["design", "hardware", "testing", "review_approval", "dwg_release"],
  testing: ["setup", "procedure", "hardware", "testing", "report"],
  software: ["design", "implementation", "testing", "code_review", "documentation"],
  documentation: ["draft", "review", "approval", "release"],
  milestone: ["planning", "execution", "review", "completion"]
} as const;

export const programs = pgTable("programs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const workPackages = pgTable("work_packages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  programId: varchar("program_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  parentId: varchar("parent_id"), // For hierarchical work packages
  order: integer("order").default(0),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  workPackageId: varchar("work_package_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  status: text("status", { enum: taskStatuses }).notNull().default("todo"),
  taskType: text("task_type", { enum: taskTypes }).notNull().default("parts_assembly"),
  assignedResource: text("assigned_resource", { enum: resourceTypes }),
  assignedPersonId: varchar("assigned_person_id"), // Reference to persons table
  progress: integer("progress").default(0), // 0-100
  estimatedDays: integer("estimated_days"),
  remainingDays: integer("remaining_days"),
  currentWorkflowStep: text("current_workflow_step"),
  completedWorkflowSteps: jsonb("completed_workflow_steps").$type<string[]>().default([]),
  dependencies: jsonb("dependencies").$type<string[]>().default([]), // Array of task IDs
  dueDate: timestamp("due_date"),
  priority: text("priority").default("medium"), // low, medium, high, critical
  tags: jsonb("tags").$type<string[]>().default([]),
  attachmentCount: integer("attachment_count").default(0),
  commentCount: integer("comment_count").default(0),
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`),
});

export const sprints = pgTable("sprints", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  programId: varchar("program_id").notNull(),
  name: text("name").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  status: text("status").notNull().default("planning"), // planning, active, completed
  taskIds: jsonb("task_ids").$type<string[]>().default([]),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const comments = pgTable("comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: varchar("task_id").notNull(),
  author: text("author").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const persons = pgTable("persons", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  resourceType: text("resource_type", { enum: resourceTypes }).notNull(),
  email: text("email"),
  initials: text("initials").notNull(), // For display purposes (e.g., "JD" for John Doe)
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const timeEntries = pgTable("time_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  taskId: varchar("task_id").notNull(),
  user: text("user").notNull(), // User who tracked the time
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"), // Null if timer is still running
  duration: integer("duration"), // Duration in minutes, calculated when endTime is set
  description: text("description"), // Optional description of what was worked on
  isActive: boolean("is_active").default(false), // True if timer is currently running
  createdAt: timestamp("created_at").default(sql`now()`),
});

// Insert schemas
export const insertProgramSchema = createInsertSchema(programs).omit({
  id: true,
  createdAt: true,
});

export const insertWorkPackageSchema = createInsertSchema(workPackages).omit({
  id: true,
  createdAt: true,
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSprintSchema = createInsertSchema(sprints).omit({
  id: true,
  createdAt: true,
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  createdAt: true,
});

export const insertPersonSchema = createInsertSchema(persons).omit({
  id: true,
  createdAt: true,
});

export const insertTimeEntrySchema = createInsertSchema(timeEntries).omit({
  id: true,
  createdAt: true,
}).extend({
  startTime: z.union([z.date(), z.string().transform((str) => new Date(str))]),
  endTime: z.union([z.date(), z.string().transform((str) => new Date(str))]).optional(),
});

// Types
export type Program = typeof programs.$inferSelect;
export type WorkPackage = typeof workPackages.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type Sprint = typeof sprints.$inferSelect;
export type Comment = typeof comments.$inferSelect;
export type TimeEntry = typeof timeEntries.$inferSelect;
export type Person = typeof persons.$inferSelect;

export type InsertProgram = z.infer<typeof insertProgramSchema>;
export type InsertWorkPackage = z.infer<typeof insertWorkPackageSchema>;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type InsertSprint = z.infer<typeof insertSprintSchema>;
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type InsertTimeEntry = z.infer<typeof insertTimeEntrySchema>;
export type InsertPerson = z.infer<typeof insertPersonSchema>;

export type ResourceType = typeof resourceTypes[number];
export type TaskStatus = typeof taskStatuses[number];
export type TaskType = typeof taskTypes[number];
