# Overview

This is a project management application designed for engineering teams, specifically handling programs, work packages, tasks, sprints, and team resources. The application provides multiple views including a Kanban board for task management, a Work Breakdown Structure (WBS) view for hierarchical project organization, and sprint planning capabilities. It's built as a full-stack web application with a React frontend and Express.js backend, using PostgreSQL for data persistence.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client uses React 18 with TypeScript and follows a modern component-based architecture. Key architectural decisions include:

- **Component Library**: Radix UI components with shadcn/ui styling for consistent, accessible UI components
- **Styling**: Tailwind CSS with CSS variables for theming, supporting both light and dark modes
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation for type-safe form management
- **Build Tool**: Vite for fast development and optimized production builds

The frontend follows a pages/components pattern with shared UI components in the components/ui directory and page-specific components organized by feature.

## Backend Architecture
The server uses Express.js with TypeScript in ESM format. Key architectural decisions include:

- **API Design**: RESTful API endpoints following resource-based routing patterns
- **Data Layer**: Storage abstraction interface with in-memory implementation for development
- **Type Safety**: Shared schema definitions between client and server using Zod for validation
- **Development**: Hot module reloading with Vite integration for development mode
- **Error Handling**: Centralized error handling middleware with structured error responses

## Data Storage Solutions
The application uses a PostgreSQL database with Drizzle ORM for type-safe database operations:

- **Schema Management**: Centralized schema definitions in shared/schema.ts with Drizzle table definitions
- **Database Client**: Neon serverless PostgreSQL adapter for cloud deployment
- **Migrations**: Drizzle Kit for schema migrations and database management
- **Type Safety**: Generated TypeScript types from database schema using drizzle-zod

The data model includes hierarchical relationships: Programs contain Work Packages, which contain Tasks. Sprints can reference multiple tasks across work packages.

## Authentication and Authorization
Currently, the application does not implement authentication or authorization mechanisms. This appears to be designed for internal team use or is in early development stages.

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting service
- **Drizzle ORM**: Type-safe database ORM and query builder
- **Drizzle Kit**: Database migration and management tools

## UI and Design System
- **Radix UI**: Headless, accessible React component primitives
- **shadcn/ui**: Pre-built component library built on Radix UI
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library for consistent iconography

## Development and Build Tools
- **Vite**: Frontend build tool and development server
- **TypeScript**: Static type checking across the entire stack
- **ESBuild**: Fast JavaScript bundler for server-side code
- **PostCSS**: CSS processing with Autoprefixer

## State Management and Data Fetching
- **TanStack Query**: Server state management, caching, and synchronization
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: Runtime type validation and schema parsing

## Development Environment
- **Replit**: Development environment with specific plugins for error handling and debugging
- **Node.js**: JavaScript runtime environment
- **Express.js**: Web application framework for the API server

The application is designed for deployment on platforms that support Node.js applications with PostgreSQL databases, with specific optimizations for Replit's development environment.